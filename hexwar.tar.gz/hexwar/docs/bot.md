# Bot (M4: Dễ + Thường; M9: Khó + tính cách + cân bằng)

Nguồn: PLAN mục 9. Mã: `packages/bot/src` (`attacks.ts`, `evaluate.ts`, `choose.ts`, `hard.ts`, `personality.ts`).

## Cách bot chọn nước

Cả hai độ khó **chấm 1 nước** (không tìm kiếm sâu) trên danh sách `legalMoves` của engine — bot không bao giờ đi nước
engine không cho (PLAN 9.1 "không gian lận"); `GameSession` còn kiểm lại bằng `checkMove` trước khi áp dụng.

| Thành phần (PLAN 9.2) | Cách tính |
|---|---|
| Vật chất | Ăn quân: + giá trị quân bị ăn (R-82: P1 N3 B3 R5 Q9, Hề 2 + 3 vì giữ Vua). Ăn Vua không có Hề cứu (R-60): +60; có Hề cứu (R-51): +4. Phong cấp (R-41): + chênh lệch giá trị |
| An toàn | Sau nước đi, tìm mọi quân địch ăn được từng quân của mình ở nước tới (kể cả tù binh trưng dụng, R-32). Mỗi đối thủ chỉ đi một nước trước lượt kế của mình → gán tham lam quân giá trị nhất cho một đối thủ chưa dùng. Mất Vua không có Hề cứu: −200 |
| Thu hẹp | Quân đứng trên vòng sắp biến mất bị phạt theo số hiệp còn lại (1 hiệp: ×1; 2: ×0,6; ≤4: ×0,3; ≤8: ×0,12; ≤16: ×0,04) × độ sâu; Vua tính như mất Vua (D-09: Hề không cứu). Khi Vua đang trong vùng nguy hiểm: thưởng dọn ô trống phía trong quanh Vua |
| Vị trí / mục tiêu | +0,06 mỗi hạng tiến vào gần tâm; +0,15 mỗi ô tiến gần Vua của đối thủ gần nhất; phạt nếu Hề rời quá tầm hồi sinh (R-51) |
| Sức ép (Thường) | +0,25 × giá trị quân địch lớn nhất mà quân vừa đi đe doạ ở nước sau |

| Độ khó | Hành vi (PLAN 9.3) |
|---|---|
| Dễ | Mỗi lượt có ~60% "nhìn thấy" nước ăn (không thấy thì bỏ hẳn nước ăn khỏi lựa chọn lượt đó); nhiễu ngẫu nhiên 0–1,2; chỉ xét an toàn của Vua và quân vừa đi; vẫn tránh thu hẹp |
| Thường | Đủ mọi thành phần trên, nhiễu 0–0,05 chỉ để phá hoà |
| Khó (M9, `hard.ts`) | Bước 1: chấm TẤT CẢ nước bằng đúng bảng điểm Thường ở trên, giữ **top-K (K=8)**. Bước 2: với mỗi ứng viên, áp dụng THẬT (`applyMove`) rồi mô phỏng THẬT phản đòn tốt nhất của tối đa 5 đối thủ theo đúng thứ tự lượt của engine (`legalMoves`/`applyMove`/`timeoutTurn` — không tự chế luật ăn quân/lượt thứ hai), mỗi đối thủ chỉ xét nước ăn/đe doạ Vua và chỉ đi ĐÚNG 1 nước; trừ vật chất THẬT mất đi (không chiết khấu) thay cho ước lượng `danger` 0,9× của bước 1 (cộng lại phần đã trừ ở bước 1 trước khi trừ khoản thật — xem "Sửa lỗi cộng dồn hai lần" bên dưới) |

Tất định: RNG của mỗi quyết định = `mix(seed ván, hiệp, ghế, số hành động)` (`botRngFor`). Độ trễ "suy nghĩ" 1–6 giây
nằm ở `GameSession`, không ở bot.

## Tính cách (M9, PLAN 9.4)

`personality.ts`: mỗi tính cách chỉ NHÂN HỆ SỐ lên đúng `WEIGHTS` hiện có (không tách công thức `scoreMove` riêng) và
đổi `TargetStrategy` (Vua đối thủ nào để "săn"). `'balanced'` = nhân 1 = đúng hành vi trước M9 (an toàn ngược: mọi lời
gọi cũ không truyền `personality` cho kết quả giống hệt bit-for-bit, có test).

| Tính cách | Hệ số đổi (so với 1) | Ý tưởng |
|---|---|---|
| Hung hăng | `hunt` ×2, `pressure` ×1,6, `eliminate` ×1,15, `kingHitSaved` ×1,3, `threatFactor` ×0,7, `center`/`jesterFar` ×0,6 | Tấn công sớm, chấp nhận rủi ro hơn, bớt thận trọng vị trí/Hề |
| Thủ thế | `threatFactor` ×1,4, `jesterGuard` ×1,6, `kingEscape` ×1,7, `jesterFar` ×2, `hunt` ×0,35, `pressure` ×0,5 | Giữ Vua + Hề, dọn lối thoát khi sắp thu hẹp, gần như không chủ động săn đuổi |
| Cơ hội | `hunt` ×0,2, `pressure` ×1,5, `threatFactor` ×1,15, `kingEscape` ×1,2; **mục tiêu đổi sang Vua YẾU NHẤT** (không phải gần nhất) | Không khơi mào, chờ người khác đánh nhau rồi nhặt quân của kẻ đã suy yếu |

Áp dụng cho từng ghế bot: solo (`menu.ts`, mọi bot cùng một tính cách) và phòng riêng/online (`lobby.ts`, host chọn
theo từng ghế khi thêm bot). Bot lấp chỗ tự động ở ghép nhanh và AFK→bot (X-04) dùng `'balanced'`.

## Sửa lỗi cộng dồn hai lần rủi ro (M9)

Bản đầu của `chooseHardMove` (bước 2) tính `finalScore = candidate.score − lost`, trong đó `candidate.score` (bước 1)
**đã tự trừ sẵn** một ước lượng đe doạ (`danger`, chiết khấu 0,9× của `scoreMove`, dùng chung với bot Thường) cho
CHÍNH quân sắp bị ăn lại đó — rồi `lost` (mô phỏng thật ở bước 2) trừ THÊM đúng khoản mất mát ấy một lần nữa, không
chiết khấu. Kết quả: Khó bị phạt gấp đôi cho cùng một rủi ro, khiến nó né tránh cả những **cú đổi ngang giá hoàn
toàn hợp lý** (ví dụ Mã đổi Mã) như thể chúng lỗ thật — chơi thụ động hơn cả Thường. Phát hiện được qua đấu thử thật
(xem bên dưới: tỉ lệ thắng ban đầu chỉ ~16%, ngang bằng ngẫu nhiên, dù thuật toán "khó hơn" Thường về lý thuyết).

**Sửa**: bước 2 cộng lại đúng khoản `danger` đã trừ ở bước 1 trước khi trừ `lost` thật (`finalScore = candidate.score
+ candidate.danger − lost`) — thay ước lượng bằng số liệu mô phỏng thật, không cộng dồn cả hai. Sau khi sửa, ván
toàn bot Khó (mục "công bằng ghế" bên dưới) kết thúc nhanh hẳn (trung vị hiệp giảm từ hơn 380 xuống 90) — đúng hướng
"đổi quân dứt khoát hơn khi hợp lý" thay vì kéo dài vì quá thận trọng. Bài học cho các milestone sau có bước "chấm 1
nước rồi mô phỏng thêm": nếu bước chấm 1 nước đã có SẴN một ước lượng cho đúng thứ đang được mô phỏng lại chính xác
hơn ở bước sau, phải thay thế (cộng lại rồi trừ số thật), không được cộng dồn cả hai nguồn. Test hồi quy:
`packages/bot/test/hard.test.ts` ("không cộng dồn hai lần cùng một rủi ro cho một cú đổi NGANG GIÁ").

## Đấu thử hàng loạt (số đo thật)

Lệnh: `ARENA_GAMES=36 pnpm --filter @hexwar/bot arena`. Mỗi ván chơi trọn tới khi kết thúc bằng engine thật, luật mặc
định (R=24, lịch thu hẹp gốc + kéo dài D-07, hiệp giới hạn 450). Ghế của bot đang đo xoay vòng 0→5 theo ván. Lần chạy
cuối (sau khi chỉnh trọng số ở M4), 36 ván mỗi cấu hình:

### 1 Thường vs 5 Dễ

| Chỉ số | Giá trị |
|---|--:|
| Tỉ lệ thắng của bot Thường (ngẫu nhiên = 16,7%; **chỉ tiêu PLAN 9.3: ≥ 35%**) | **72,2%** (26/36) |
| Ván kết thúc ở hiệp giới hạn 450 | 27,8% |
| Số lần một bot bị loại vì thu hẹp (tổng 36 ván × 6 ghế) | 1 |
| Số hiệp khi kết thúc: trung vị / p90 | 379 / 450 |
| Thời gian nghĩ mỗi nước: p50 / p95 / max (ms) | 2,6 / 25,4 / 79,4 (ngân sách PLAN 9.1: 1 500) |

### 6 Dễ

| Chỉ số | Giá trị |
|---|--:|
| Tỉ lệ thắng của ghế đang đo (ngẫu nhiên = 16,7%) | 8,3% (3/36) — 36 ván quá ít để kết luận về công bằng ghế (sai số chuẩn ≈ 6%); PLAN 9.5 yêu cầu 1000 ván, làm ở M9 |
| Ván kết thúc ở hiệp giới hạn 450 | 41,7% |
| Số lần bị loại vì thu hẹp | 0 |
| Số hiệp khi kết thúc: trung vị / p90 | 446 / 450 |
| Thời gian nghĩ mỗi nước: p50 / p95 / max (ms) | 2,4 / 6,0 / 32,6 |

## Đấu thử hàng loạt M9 (Khó, sau khi sửa lỗi cộng dồn ở trên)

Cùng lệnh, thêm biến môi trường mới (PLAN 9.5 muốn 1000 ván/mục, nhưng một ván chạy hết trên bàn 1801 ô tốn tới
chục giây thật trong sandbox này — 1000 ván một lần vượt quá thời gian một lệnh có thể chạy; xem chú thích đầu
`packages/bot/test/winrate.arena.ts` và `tools/arena_combine.py`):

```bash
ARENA_GAMES=n ARENA_ONLY=hardVsNormal,fairness ARENA_SEED_OFFSET=k ARENA_RAW_OUT=/tmp/out-k.json pnpm --filter @hexwar/bot arena
python3 tools/arena_combine.py /tmp/out-0.json /tmp/out-10.json ...   # gộp nhiều đợt (offset khác nhau) thành 1 báo cáo
```

### 1 Khó vs 5 Thường — **25 ván thật, gộp 2 đợt** (offset 0 và 20, sau khi sửa lỗi cộng dồn)

| Chỉ số | Giá trị |
|---|--:|
| Tỉ lệ thắng của bot Khó (ngẫu nhiên = 16,7%; **chỉ tiêu PLAN 9.3: ≥ 30%**) | **16,0%** (4/25) — **CHƯA ĐẠT chỉ tiêu** |
| Ván kết thúc ở hiệp giới hạn 450 | 28,0% |
| Số hiệp khi kết thúc: trung vị / p90 | 404 / 450 |
| Thời gian nghĩ mỗi nước: p50 / p95 / max (ms) | 7,9 / 40,4 / 99,8 (ngân sách PLAN 9.1: 1 500) |

**Đọc số liệu này thế nào**: 16,0% với 25 ván có sai số chuẩn ước lượng ≈ 7,4 điểm phần trăm quanh mức ngẫu nhiên 16,7% — tức là
**thống kê không phân biệt được** "Khó mạnh hơn Thường một chút" với "Khó ngang Thường" ở cỡ mẫu này, nhưng **loại
trừ được** khả năng Khó đã đạt chỉ tiêu ≥ 30% (0,3 cách 16,0% khoảng 1,9 lần sai số chuẩn). Trước khi sửa lỗi cộng
dồn, hai đợt 10 và 15 ván (seed y hệt các seed dùng ở trên) cũng ra 2/10 và 2/15 — sửa lỗi không đổi rõ tỉ lệ thắng
ở đúng các ván này, dù có đổi hẳn cách chơi (xem mục "công bằng ghế" bên dưới): kết luận là bản top-K + mô phỏng
phản đòn hiện tại, dù đúng đặc tả PLAN 9.3 và không còn lỗi cộng dồn, **chưa đủ mạnh hơn Thường một cách đo được**
trong thế trận 1-chọi-5 — xem "Việc còn lại" bên dưới.

### 6 Khó — công bằng ghế (PLAN 9.5) — **10 ván thật** (sau khi sửa lỗi cộng dồn)

| Ghế | Tỉ lệ thắng |
|---|--:|
| Ghế 0 | 0,0% (0/10) |
| Ghế 1 | 10,0% (1/10) |
| Ghế 2 | 30,0% (3/10) |
| Ghế 3 | 0,0% (0/10) |
| Ghế 4 | 50,0% (5/10) |
| Ghế 5 | 10,0% (1/10) |

Mục tiêu PLAN 9.5: 16,7% ± 3%, cần ~1000 ván để sai số chuẩn ≈ 1,2%; ở 10 ván sai số chuẩn ước lượng ≈ 9,1% —
**quá ít để kết luận bất cứ điều gì về công bằng ghế** (bàn cờ đã kiểm chứng bất biến xoay hình học tuyệt đối bằng
`tools/verify_board.py` và test `packages/rules`, nên bất kỳ lệch nào ở đây nhiều khả năng chỉ là nhiễu thống kê cỡ
mẫu nhỏ, không phải bàn cờ/luật lệch ghế). Điểm đáng chú ý hơn cả tỉ lệ thắng: ván kết thúc ở hiệp giới hạn giảm về
0% (từ ~1 trong 10 trước khi sửa) và **trung vị hiệp giảm mạnh còn 90** (trước khi sửa, ván trộn Khó/Thường trung vị
hơn 380) — đúng hướng "6 bot Khó đổi quân dứt khoát, ván kết thúc nhanh" mà lỗi cộng dồn từng cản trở.

Lịch sử chỉnh (cùng lệnh, để thấy tác động):

| Phiên bản | 1 Thường vs 5 Dễ: thắng / hết giờ 450 / trung vị hiệp | 6 Dễ: hết giờ 450 / trung vị hiệp |
|---|---|---|
| Ban đầu (chưa có "săn Vua", chưa có "lối thoát Vua") | 2 ván thử: cả 2 hết giờ 450; 1 bot Thường chết vì thu hẹp ở hiệp 180 (Vua bị quân mình vây) | — |
| + săn Vua 0,1 + lối thoát Vua, Dễ nhiễu 2,5 (36 ván) | 83,3% / 22,2% / 419 | 94,4% / 450 |
| + săn Vua 0,15, Dễ nhiễu 1,2, Dễ bỏ hẳn nước ăn khi "không thấy" (36 ván, **hiện tại**) | 72,2% / 27,8% / 379 | 41,7% / 446 |

## Hạn chế đã biết

- **Bot Khó CHƯA đạt chỉ tiêu PLAN 9.3 (≥ 30% so với 5 Thường)** đo được ở trên (16,0%, 25 ván). Sau khi sửa lỗi cộng
  dồn hai lần (mục ở trên), thuật toán đúng đặc tả (top-K=8 + mô phỏng phản đòn thật 5 đối thủ) và rõ ràng chơi dứt
  khoát hơn (thấy qua ván toàn-Khó nhanh gấp 4 lần), nhưng ưu thế đó CHƯA đo được thành tỉ lệ thắng cao hơn khi phải
  một mình chọi 5 Thường. Giả thuyết hợp lý nhất (chưa kiểm chứng, việc của lần chỉnh tiếp theo): (a) top-K=8 giới
  hạn theo ĐÚNG bảng điểm Thường nên chỉ tinh chỉnh MỘT NƯỚC không rẽ hướng chiến lược mới — lợi thế chỉ ở chiến
  thuật (không "lỡ" đổi quân lỗ/hụt đổi quân lời), không phải chiều sâu tính toán thật; (b) 5 Thường đã đủ tốt để
  hiếm khi tạo ra bẫy chiến thuật rõ ràng cho Khó khai thác trong thế trận 1-chọi-5 tự do (khác hẳn thế trận 2 người
  dàn dựng tay ở `hard.test.ts`); (c) khả năng "bot mạnh nhất bị 5 bot còn lại tự nhiên dồn đánh" (rủi ro đã nêu ở
  PLAN mục 16 "xử người dẫn đầu") — `hunt`/`pressure` của Thường có thể tự nhiên nhắm vào ai đang thể hiện tốt nhất.
  **Việc còn lại** (không chặn milestone kế tiếp, xem `docs/questions.md`): chạy mô phỏng lớn hơn (cần nhiều thời
  gian máy hơn một phiên tương tác cho phép — dùng `ARENA_SEED_OFFSET`/`tools/arena_combine.py` để gộp nhiều đợt),
  rồi thử một trong: tăng K, cho Khó trọng số hơi khác Thường ở bước 1 (không chỉ đúng bảng điểm Thường) để tự tìm
  cơ hội tốt hơn trước khi lọc bằng mô phỏng, hoặc nâng lên MCTS rollout ngắn như PLAN 9.3 đã gợi ý làm phương án 2.
- **Ván dài**: nhiều ván kéo gần tới hiệp giới hạn 450 khi có bot Thường tham gia (Dễ hoặc hỗn hợp Khó/Thường); chỉ
  ván TOÀN bot Khó mới kết thúc nhanh (trung vị 90 hiệp). Preset Tiêu chuẩn/Nhanh (X-09, `applyPreset`, đã có từ
  M6.1) là hướng xử lý chính; số liệu M9 ở trên có thể dùng để hiệu chỉnh `roundScale` thêm nếu cần (chưa làm — cần
  đo cả ba preset bằng đấu thử thật trước khi đổi số, việc còn lại).
- **Bot chat (PLAN 9.4 "thỉnh thoảng gửi câu chat có sẵn")**: cố tình CHƯA làm ở M9 (không nằm trong nội dung M9
  liệt kê ở PLAN mục 15) — **đã làm sau M10**: `packages/bot/src/chat.ts` (`decideBotChat`, thuần, tất định theo
  RNG riêng `botChatRngFor`) + nối dây ở `packages/server/src/room.ts` (`maybeSendBotChat`), không đổi gì ở phần
  chọn nước đi. Có kịch bản thao túng tâm lý thật (trấn an giả nạn nhân sau khi ăn quân; kích động cả bàn đánh
  người đang dẫn đầu khi bị đe doạ) bên cạnh vài câu xã giao/thiện chí (trêu chọc khi hạ Vua, cảnh báo thu hẹp,
  chào đầu ván) — xem `docs/progress.md` mục "Bổ sung sau M10 — Bot chat" và `docs/decisions.md` mục cùng tên.
- Bot 1 nước (Dễ/Thường) không lên kế hoạch nhiều lượt (ví dụ vây Vua địch), không có "trí nhớ thù hận" (PLAN 9.2).
- Chỉ tiêu "trong trận 1 vs 5 Dễ, người tập chơi thắng nhiều hơn bình thường" (PLAN 9.3) cần người thật chơi thử; chưa đo.
- Công bằng ghế (PLAN 9.5, cả Dễ lẫn Khó) mới đo ở cỡ mẫu nhỏ (10–36 ván, sai số chuẩn 6–9 điểm phần trăm); PLAN
  9.5 muốn 1000 ván (sai số chuẩn ≈ 1,2%) — chưa chạy được trong một phiên tương tác vì mỗi ván tốn tới chục giây
  thật trên bàn 1801 ô; hạ tầng để gộp nhiều đợt nhỏ thành một mẫu lớn đã có (`ARENA_SEED_OFFSET`,
  `tools/arena_combine.py`), chỉ cần chạy đủ đợt (việc còn lại, có thể chạy nền/qua nhiều phiên).
