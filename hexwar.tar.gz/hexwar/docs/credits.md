# Nguồn gốc tài nguyên

Chưa có tài nguyên bên ngoài dạng FILE (hình, âm thanh, font, mô hình 3D nạp từ đĩa). Mọi thứ trong repo hiện là mã
nguồn và tài liệu — kể cả hình dáng quân cờ (procedural, `packages/client/src/scene/piece-geometry.ts`) và âm thanh
(tổng hợp lúc chạy, xem hàng dưới). Mỗi tài nguyên thêm vào phải ghi ở đây: tên, nguồn, giấy phép, nơi dùng. Nếu có
nội dung do AI tạo mà người chơi thấy hoặc nghe được, ghi rõ để khai báo với Steam (PLAN 13.4).

| Tài nguyên | Nguồn | Giấy phép | Dùng ở |
|---|---|---|---|
| Nhạc nền + hiệu ứng âm thanh (PLAN 12.6) — **placeholder tổng hợp bằng mã**, không phải bản ghi âm/sáng tác nào; dựng lúc chạy bằng dao động (`OscillatorNode`) và nhiễu trắng lọc qua Web Audio API, không nạp file âm thanh nào từ đĩa | Tự tạo bằng mã (không sao chép/lấy mẫu từ nguồn nào) | Không áp dụng (không phải tác phẩm có giấy phép cần khai — do mã sinh ra tất định, không phải nội dung AI tạo sinh) — **CẦN THAY bằng nhạc/SFX thật (sáng tác riêng hoặc CC0/mua bản quyền) trước khi phát hành**, xem `docs/questions.md` Q-39 | `packages/client/src/core/audio-cues.ts` (bảng tần số/thời lượng), `packages/client/src/net/audio-manager.ts` (phát thật qua `AudioContext`) |
