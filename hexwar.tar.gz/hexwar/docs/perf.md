# Hiệu năng đồ hoạ

PLAN 12.5: "Đo và ghi vào `docs/perf.md` ở mỗi milestone đồ hoạ: FPS trung bình/1% thấp, số draw call, bộ nhớ GPU.
Mục tiêu 60 FPS ở mức Thấp trên máy yếu." Trang này ghi số đo thật của **M3** và giải thích vì sao số đo ở
đây **không** thể dùng để kết luận đạt/không đạt mục tiêu 60 FPS.

## ⚠️ Cảnh báo môi trường đo — đọc trước khi dùng số bên dưới

Toàn bộ số đo trong tài liệu này lấy từ Playwright chạy **Chromium headless trong sandbox đám mây, dùng
SwiftShader** (kết xuất 3D bằng phần mềm, không có GPU thật). Đây là môi trường CI/dev duy nhất hiện có,
**không phải** "máy yếu" theo nghĩa PLAN 12.5 (máy yếu vẫn có GPU thật, dù chậm). Cụ thể:

- SwiftShader raster hoá hoàn toàn bằng CPU của container CI, không dùng bất kỳ tăng tốc phần cứng nào.
- Container CI dùng chung CPU với nhiều tiến trình khác, không có ngân sách hiệu năng ổn định.
- Do đó số FPS đo được ở đây **thấp hơn nhiều bậc** so với một GPU tích hợp rẻ tiền trên máy thật, và
  **không tỉ lệ thuận** với hiệu năng GPU thật (cổ chai là CPU rasterization, không phải cổ chai điển hình
  của GPU thật như băng thông bộ nhớ hay số ROP).
- Các test trong `e2e/perf.spec.ts` vì vậy chỉ khẳng định **vòng lặp vẽ còn sống** (`fps > 5`, một ngưỡng
  kiểm tra không-bị-treo, không phải ngưỡng hiệu năng), **không** khẳng định hay bác bỏ mục tiêu 60 FPS.
- **Việc đo 60 FPS mức Thấp trên máy yếu thật (PLAN 12.5) vẫn chưa làm được và cần một máy có GPU thật**
  (kể cả GPU tích hợp yếu) — xem mục "Việc còn lại" bên dưới.

## Số đo thật (SwiftShader, Chromium headless, viewport 1280×720)

Đo bằng `requestAnimationFrame` đếm khung hình trong 2 giây liên tục, sau khi ván đã tải và ổn định. Xem
`packages/client/e2e/perf.spec.ts`.

| Cảnh | FPS đo được | Ghi chú |
|---|--:|---|
| Thế cờ đầu, đứng yên (1801 ô + 108 quân, chưa chọn quân) | **~7.2 FPS** | 3 `InstancedMesh` (bàn, quân, tô sáng rỗng); camera đứng yên |
| Có quân đang chọn (đang tô ô đi được + đang hoạt ảnh chờ) | **~6.9 FPS** | Thêm `HighlightMesh` có instance thật; chênh lệch trong biên độ nhiễu của môi trường CI dùng chung CPU, không phải giảm hiệu năng thật do thêm tô sáng |

**Đo lại ở M4** (cùng môi trường; nay có thêm Web Worker chạy ván + HUD HTML mới): **7,4 FPS** đứng yên, **7,2 FPS**
khi đang tô ô — không đổi so với M3 trong biên độ nhiễu. Bot nghĩ trong Worker nên không chiếm luồng vẽ (p95 thời gian
nghĩ ≈ 25 ms/nước, docs/bot.md).

Hai số gần bằng nhau (chênh lệch nằm trong biên độ nhiễu của CI, không phải một khoản giảm rõ rệt khi thêm
tô sáng) là tín hiệu tốt cho thấy chi phí không nằm ở số instance mà ở chi phí cố định của việc raster hoá
1801+108 hình lăng trụ lục giác bằng phần mềm — đúng như dự đoán với SwiftShader (chi phí per-pixel/per-triangle
rất cao khi không có GPU, gần như không phụ thuộc số lệnh vẽ vì cả ba nhóm mesh đã gộp thành 9 draw call bằng
`InstancedMesh` ngay từ đầu — xem bảng draw call bên dưới).

## Số draw call và cấu trúc scene

Cố định, không đổi theo trạng thái ván (đúng mục tiêu PLAN 6.6 — dựng sẵn dung lượng tối đa, không tạo/huỷ
mesh khi chơi):

| Đối tượng | Loại mesh | Số draw call | Dung lượng tối đa |
|---|---|--:|--:|
| Bàn cờ (`BoardMesh`) | 1 `InstancedMesh` | 1 | `cellCount(radius)` ô, tối đa 1801 |
| Quân cờ (`PieceScene`) | 7 `InstancedMesh` (1/loại quân) | 7 | 108 quân/loại (thực tế mỗi loại ít hơn nhiều) |
| Tô sáng (`HighlightMesh`) | 1 `InstancedMesh` | 1 | 256 ô |
| **Tổng** | | **9 draw call** | |

Thu hẹp vòng ngoài chỉ giảm `InstancedMesh.count` (PLAN: không dựng lại hình học), nên số draw call không
đổi suốt ván — chỉ số tam giác thực sự được raster hoá giảm dần.

## Bộ nhớ GPU

Chưa đo được: môi trường SwiftShader không có driver GPU thật nên không có số liệu bộ nhớ GPU (VRAM) đáng
tin cậy để báo cáo (`chrome://gpu` báo "Software only, hardware acceleration unavailable"). Cần đo lại trên
máy có GPU thật cùng lúc với mục "Việc còn lại" bên dưới.

## M10: hậu kỳ (bóng đổ/bloom/SSAO) + biểu tượng đế quân — số đo thật

PLAN 12.5 thêm hậu kỳ theo mức đồ hoạ (`EffectComposer`: `RenderPass` → `SSAOPass` → `UnrealBloomPass` →
`OutputPass`, `app/main.ts`) và PLAN 12.3/11.5 thêm 6 `InstancedMesh` biểu tượng đế quân (`scene/badge-scene.ts`).
Đo lại bằng cùng phương pháp (`requestAnimationFrame` đếm khung hình 2 giây, `e2e/perf.spec.ts`), cùng môi trường
SwiftShader ở trên, thế cờ đầu, mức đồ hoạ MẶC ĐỊNH mới ("Vừa": bóng mềm cho quân + bloom nhẹ, không SSAO):

| Cảnh | FPS đo được | Ghi chú |
|---|--:|---|
| Thế cờ đầu, đứng yên, mức Vừa (mặc định mới) | **~3,3 FPS** | Giảm mạnh so với ~7,4 FPS ở M4 (chưa có hậu kỳ) — đúng như dự đoán: `SSAOPass`/`UnrealBloomPass` cần nhiều lượt đọc/ghi framebuffer, rất tốn trên raster phần mềm dù bản thân thuật toán "nhẹ" trên GPU thật |
| Có quân đang chọn (đang tô ô đi được), mức Vừa | **~3,2 FPS** | Cùng biên độ với ô trên — chi phí nằm ở hậu kỳ, không phải ở việc tô sáng thêm |

**Chưa đo được ở mức Thấp (không hậu kỳ, dự kiến gần bằng số M4 cũ) và mức Cao (thêm SSAO + phản xạ, dự kiến CÒN
CHẬM HƠN mức Vừa nhiều)** trong bộ đo tự động — `e2e/perf.spec.ts` chỉ đo mức mặc định để giữ thời gian chạy CI hợp
lý; đo thủ công ở mức Cao (xem `e2e/menu-settings.spec.ts`) cho thấy một khung hình có thể mất hơn 1 giây, đủ chậm
để làm lộ ra một lỗi treo thật khi đổi ngôn ngữ giữa lúc vòng lặp vẽ còn chạy (đã sửa, xem `docs/decisions.md` mục
M10) — số liệu chính xác cho mức Cao vẫn cần đo trên máy có GPU thật (mục "Việc còn lại" bên dưới, nay áp dụng cho
cả 3 mức, không chỉ mức mặc định).

**Ngưỡng "còn sống" của `perf.spec.ts` đã hạ từ >5 xuống >2 FPS** để khớp số đo thật ở mức Vừa mặc định — vẫn đủ để
bắt một vòng lặp thật sự treo (0 khung hình), không phải một ngưỡng hiệu năng (xem chú thích đầu file đó).

### Số draw call cập nhật

| Đối tượng | Loại mesh | Số draw call | Dung lượng tối đa |
|---|---|--:|--:|
| Bàn cờ (`BoardMesh`) | 1 `InstancedMesh` | 1 | tối đa 1801 ô |
| Quân cờ (`PieceScene`) | 7 `InstancedMesh` (1/loại quân) | 7 | 108 quân/loại |
| Tô sáng (`HighlightMesh`) | 1 `InstancedMesh` | 1 | 256 ô |
| Cảnh báo đe doạ (`ThreatMesh`, X-06) | 1 `InstancedMesh` | 1 | 256 ô |
| **Biểu tượng đế quân (`BadgeScene`, M10, PLAN 12.3)** | 6 `InstancedMesh` (1/hình) | 6 | 108/hình |
| **Hạt hiệu ứng (`EffectsLayer`, M10, PLAN 12.4)** | 1 `THREE.Points` | 1 | 480 hạt |
| **Tổng (thế cờ đầu)** | | **17 draw call** | |

Tăng từ 9 lên 17 draw call — vẫn cố định (không đổi theo trạng thái ván, đúng PLAN 6.6), và số draw call KHÔNG phải
nguyên nhân của việc giảm FPS ở trên (chi phí thật nằm ở hậu kỳ theo pixel, không theo số lệnh vẽ — xem lý giải ở
số đo M3 phía trên, vẫn đúng cho M10).

## Việc còn lại (việc của bạn — cần máy có GPU thật)

1. Mở `packages/client` bằng `pnpm dev` trên một máy có GPU thật (kể cả máy yếu/GPU tích hợp — đúng đối
   tượng PLAN 12.5 "mức Thấp trên máy yếu"), mở DevTools → tab Rendering → "FPS meter", hoặc dùng
   `chrome://tracing`, ghi lại FPS trung bình và 1% thấp trong khi: (a) đứng yên, (b) đang xoay/kéo camera,
   (c) đang có hoạt ảnh di chuyển quân, (d) ngay sau một lần thu hẹp vòng.
2. Ghi số liệu đó vào bảng ở trên (thêm cột "Môi trường: GPU thật — tên máy/GPU") để so sánh với số
   SwiftShader hiện tại.
3. Dùng `chrome://gpu` hoặc tab Memory của DevTools để lấy số bộ nhớ GPU thật.
4. Nếu FPS thật dưới 60 ở mức Thấp, các hướng tối ưu ưu tiên theo PLAN 6.6: giảm số vertex mỗi lục giác
   (`hex-geometry.ts`), gộp `HighlightMesh` không đổi hình học, hoặc hạ `antialias`/`pixelRatio` theo mức đồ
   hoạ (M5, mục "settings").
