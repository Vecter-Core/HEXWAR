# Tiến độ

## M0 — Khởi tạo: **xong trừ spike Steam + Electron**

| Hạng mục (PLAN 15) | Trạng thái |
|---|---|
| Repo, pnpm workspace, 7 package theo mục 6.3 | Xong. Chỉ `packages/rules` có code; 6 package còn lại là khung rỗng typecheck được |
| tsconfig strict, ESLint, Vitest | Xong. ESLint chặn `Math.random`, `Date`, DOM, mạng, `node:*` trong engine (đã thử thật) |
| CI (`.github/workflows/ci.yml`) | Đã viết: lint, typecheck, test, build, `verify_board.py`, fixture còn khớp. **Chưa chạy trên GitHub** vì chưa có remote |
| `CLAUDE.md` | Xong (Phụ lục A + mục lệnh) |
| `tools/verify_board.py` chạy được và nằm trong CI | Xong: 30/30 PASS |
| **Spike Steam + Electron** | **Chưa chạy.** Cần Windows + Steam client. Checklist và rủi ro bảo mật ở `docs/spike-steam-electron.md` |
| Đăng ký Steamworks, trả phí | Việc của bạn (cần tài khoản) |

## M1 — Engine hình học và nước đi: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN: "1801 ô, 108 quân, 57 nước đi đầu ở cả 6 ghế; bất biến xoay".

| Tiêu chí | Kết quả | Test |
|---|---|---|
| 1801 ô (hạng 24 có 144 ô) | Đạt | `geometry.test.ts` |
| 108 quân, không trùng ô, không quân nào ở hạng 24 | Đạt | `board.test.ts` |
| **57 nước đi đầu ở cả 6 ghế** (Hậu 7, Vua 5, Hề 6, Xe 4, Tượng 12, Mã 12, Tốt 11) | Đạt | `moves.test.ts` |
| Từng nước đi khớp **bản Python độc lập** (342 nước = 57 × 6, cùng loại quân / ô đến / có ăn) | Đạt | `python-crosscheck.test.ts` |
| Bất biến xoay 60° trên thế cờ ngẫu nhiên | Đạt | `properties.test.ts` (fast-check) |
| `legalMoves` ⇔ `explainIllegal` trên mọi quân × mọi ô | Đạt | `properties.test.ts`, `moves.test.ts` |

**Số liệu lần chạy cuối:** lint sạch · typecheck 7 package · **142 test / 6 file qua** · `verify_board.py` 30/30 PASS · fixture sinh lại giống hệt.

Thử đột biến để chắc test không "xanh vì dễ": sửa cố ý 5 chỗ trong `moves.ts` (Tượng 5 bước nhảy, Tốt ăn thẳng, Hề ăn quân, Mã đáp vào quân mình, Xe không dừng ở địch) đều làm 3–18 test đỏ; đã khôi phục.

### Luật đã hiện thực và có test (mã luật → test)

| Mã | Nội dung | Ở đâu |
|---|---|---|
| 4.3 | Nước đi 7 loại quân (Tốt, Mã, Tượng, Xe, Hậu, Vua, Hề) | `moves.test.ts` |
| R-01 | Đúng 6 ghế | `board.test.ts` |
| R-20 | Quân trượt bị chặn; ô trung gian của bước nhảy đỉnh không cản; ô có tù binh chặn | `moves.test.ts` |
| R-21 | Đích phải còn trên bàn, dừng ở biên hiện tại | `moves.test.ts`, `properties.test.ts` |
| R-22 | Tốt không đi 2 ô | `moves.test.ts`, `config.test.ts` |
| R-50 (phần nước đi) | Hề không ăn quân | `moves.test.ts` |
| D-02, D-03, D-06, D-07 | Hướng đi, tầm đi (cả hai chế độ đo), lịch thu hẹp | `moves.test.ts`, `config.test.ts` |

### Chưa làm (đúng phạm vi M1) — đã làm ở M2, xem mục dưới

Tù binh (R-30…37), kill/phong cấp, Hề hồi sinh, Vua bị ăn, thu hẹp áp lên trạng thái, xúc xắc, lượt/hiệp/đồng hồ, xếp hạng, `applyMove`, sự kiện, `hash`.

## M2 — Engine luật đặc biệt: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN: "Toàn bộ ca biên 4.10 có test; ván mô phỏng ngẫu nhiên chạy trọn không lỗi".

**Số liệu lần chạy cuối:** lint sạch · typecheck 7 package · **294 test / 12 file qua** · `verify_board.py` 30/30 PASS · đột biến **64/66 bị bắt, 1 tương đương (chứng minh), 1 đã bổ sung test rồi bị bắt** (chi tiết bên dưới).

### Ca biên 4.10 → test (11/11)

| # | Ca biên (PLAN 4.10) | Test (`packages/rules/test/…`) |
|--:|---|---|
| 1 | Tốt ăn Hậu ở hiệp 1, hiệp 2 dùng Hậu ăn Vua | `captives.test.ts` › "R-32 + R-60 (ca biên 4.10): Tốt ăn Hậu…" |
| 2 | Vua bị ăn khi Hề cách 5 ô / 6 ô | `captives.test.ts` › hai test "R-51 (ca biên 4.10)"; thêm nhóm "R-34 + R-51" cho ca ô Vua đang giữ tù binh (ăn thường và ăn bằng trưng dụng) |
| 3 | Tốt ăn quân thứ 6 là Mã địch | `captives.test.ts` › "R-41 (ca biên 4.10)" |
| 4 | Chủ tù binh ăn lại người giữ | `captives.test.ts` › "R-34 + R-36 (ca biên 4.10)" |
| 5 | Người thứ ba ăn người giữ | `captives.test.ts` › "R-34 (ca biên 4.10): người thứ ba…" |
| 6 | Người giữ mang tù binh của hai chủ, bị một chủ ăn | `captives.test.ts` › "R-34 (ca biên 4.10): người giữ mang tù binh của hai chủ…" |
| 7 | Người giữ tù binh bị loại giữa hiệp | `captives.test.ts` › "R-35 (ca biên 4.10)" |
| 8 | Vòng biến mất có tù binh + người giữ | `shrink.test.ts` › "ca biên 4.10: vòng biến mất có tù binh + người giữ…" |
| 9 | Người mở hiệp bị loại | `turn.test.ts` › nhóm "R-10 + R-61" (bị ăn Vua ở lượt người khác; tự đầu hàng ở lượt mình) và `shrink.test.ts` › "người mở hiệp bị loại vì thu hẹp" |
| 10 | Tất cả bị loại cùng lúc do thu hẹp | `shrink.test.ts` › "ca biên 4.10: tất cả bị loại cùng lúc → hoà…" (+ đồng hạng 1, 1, 3) |
| 11 | Hết giờ ở lượt có tù binh tới hạn | `turn.test.ts` › "ca biên 4.10 (R-33): hết giờ…" |

### Luật đã hiện thực và có test

| Mã | Nội dung | Ở đâu |
|---|---|---|
| R-01…R-03 | Xúc xắc 3 viên, hoà thì chỉ người hoà tung lại, thứ tự đi bắt đầu từ người thắng | `dice.ts`, `turn.test.ts` |
| R-10…R-14 | Hiệp/lượt, người mở hiệp, hết giờ, tự bỏ lượt khi hết nước, kiểm tra nước đi | `turn.ts`, `turn.test.ts` |
| R-30…R-37 | Tù binh: tạo, trưng dụng, hết hạn, chuyển giao/giải cứu, giải phóng, ô trống gần nhất | `captives.ts`, `draft.ts`, `captives.test.ts` |
| R-40…R-42 | Kill, phong cấp theo kill tích luỹ | `promotion.ts`, `captives.test.ts` |
| R-50…R-52, R-60, R-61 | Hề hồi sinh Vua (1 lần, tầm 5), loại người chơi, đầu hàng | `captives.ts`, `turn.ts`, `captives.test.ts`, `turn.test.ts` |
| R-70…R-72, D-09 | Thu hẹp, cảnh báo vàng/đỏ, loại cùng đợt, Hề cứu khỏi thu hẹp (cờ) | `shrink.ts`, `shrink.test.ts` |
| R-80…R-82 | Thắng khi còn một Vua, hiệp giới hạn 450, điểm và xếp hạng (đồng hạng) | `draft.ts`, `score.ts`, `score.test.ts`, `shrink.test.ts` |
| PLAN 6.5, 14 | 18 loại sự kiện, `hash` tất định, bất biến trạng thái | `events.ts`, `hash.ts`, `validate.ts`, `score.test.ts`, `validate.test.ts` |

### Mô phỏng và bất biến

- `simulation.test.ts`: 19 test. Ván ngẫu nhiên có seed (1–8) chạy **trọn tới khi kết thúc** với cấu hình luật thật (R=24), bàn R=16 lịch thu hẹp thưa, phong cấp dễ (1/2/3/4 kill), và biến thể cờ (tù binh nằm im, không giải cứu, Hề cứu khỏi thu hẹp, kill không tích luỹ). Sau **mỗi nước đi** kiểm `assertValidState` và các đại lượng đơn điệu (số quân, hiệp, bán kính không tăng…).
- Kiểm thêm: kết quả ván nhất quán với xếp hạng; dòng sự kiện hợp lý (hiệp tăng từng đơn vị, mỗi lượt đúng người); **tất định** (cùng seed → cùng dãy hash); độ phủ sự kiện (14 loại sự kiện chính phải xuất hiện; `JESTER_REVIVED`, `CAPTIVE_RELEASED`, `CAPTIVE_TRANSFERRED`, `TURN_SKIPPED` được phủ bằng test đơn vị vì mô phỏng không đảm bảo gặp); `checkMove` ⇔ `legalMoves` trên thế cờ thật; **bất biến xoay** của `applyMove` (xoay cả thế cờ rồi đi nước tương ứng ⇒ kết quả xoay tương ứng; bỏ qua các nước có thả tù binh vì luật hoà của R-36 — chọn ô có `q` nhỏ hơn trước — không bất biến khi xoay).
- Thời gian chạy cả bộ test: ~4 giây cho phần mô phỏng.

### Kiểm thử đột biến (`python3 tools/mutate.py`)

66 đột biến, mỗi cái sửa một chỗ trong luật rồi chạy cả bộ test:

| Nhóm | Số đột biến | Kết quả |
|---|--:|---|
| Tù binh, Vua, Hề (`captives.ts`) | 15 | 15 bị bắt (C09 sống sót ở đợt đầu → đã thêm test → bị bắt) |
| Phong cấp (`promotion.ts`) | 4 | 4 bị bắt |
| Loại người, ô trống, kết thúc ván (`draft.ts`) | 8 | 8 bị bắt |
| Điểm, xếp hạng (`score.ts`) | 4 | 4 bị bắt |
| Thu hẹp, cảnh báo (`shrink.ts`) | 9 | 8 bị bắt, **H05 tương đương** |
| Lượt, hiệp, hết giờ, đầu hàng (`turn.ts`) | 15 | 15 bị bắt |
| Xúc xắc (`dice.ts`) | 4 | 4 bị bắt |
| Trưng dụng trong `moves.ts` | 3 | 3 bị bắt |
| `validateState` | 4 | 4 bị bắt |

- **C09** (Vua bị ăn bằng trưng dụng, ô Vua đang giữ tù binh, Hề cứu): là **lỗ hổng test thật**, đã thêm hai test ở `captives.test.ts` (nhóm "R-34 + R-51"); chạy lại thì bị bắt.
- **H05** (bỏ việc chụp điểm cả đợt trước khi loại từng người khi thu hẹp): là **đột biến tương đương**. Điểm của B chỉ phụ thuộc quân thuộc B và kill của B; loại A chỉ xoá quân của A và **thả** (không xoá) tù binh A đang giữ, mà tù binh vẫn tính cho chủ cũ (R-31). Đã kiểm chứng trên hàng nghìn thế cờ mô phỏng (có tù binh) và thêm thành test thường trực ở `score.test.ts`; nếu sau này luật điểm đổi thì test đó đỏ và phần chụp điểm trở nên bắt buộc.
- Script không chạy trong CI (chậm, gắn với chuỗi mã nguồn); chạy lại khi sửa luật.

### Điểm cần bạn xem

`docs/questions.md` có 12 giả định mới (Q-07 … Q-17 và Q-19) và 2 mục cần bạn quyết (Q-02 Tốt đi 2 ô, Q-18 hằng số xúc xắc ngoài cấu hình). **Q-01 không còn chặn**: tù binh "ở lại" hay "đi theo" không quan sát được vì R-33 loại chúng ngay cuối lượt đó.

### Chưa làm (đúng phạm vi)

- `applyPreset` (X-09, nhân lịch thu hẹp theo `roundScale`): hoãn tới M9.
- "3 lượt hết giờ liên tiếp → bot", giữ ghế 90 giây, đồng hồ 60 giây thật: thuộc server (M6). Engine chỉ cung cấp `timeoutTurn`, `resign`.
- Bot, giao diện, mạng: các milestone sau.

## M3 — Client 3D + ván hotseat một máy: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN M3: dựng renderer Three.js thật cho bàn cờ + quân + tô sáng, chơi được một ván hotseat
trọn vẹn trên một máy (chuột + bàn phím thật, không giả lập), có ảnh chụp cảnh chuẩn và số đo hiệu năng
trung thực.

**Số liệu lần chạy cuối:** lint sạch · typecheck cả workspace · **106 test đơn vị / 8 file (`packages/client`) qua**
· **9/9 test Playwright (e2e thật, renderer + engine thật) qua** · `verify_board.py` 30/30 PASS · `pnpm check`
xanh toàn repo.

### Những gì đã dựng (đúng phạm vi M3.3, không đụng luật `packages/rules`)

| Lớp | File | Việc |
|---|---|---|
| Bàn cờ | `scene/board-mesh.ts` | Một `InstancedMesh` cho toàn bộ 1801 ô, xếp theo hạng tăng dần để thu hẹp chỉ cần giảm `count` (PLAN 6.6: không dựng lại hình học) |
| Quân cờ | `scene/piece-scene.ts` | 7 `InstancedMesh` (một/loại quân), đồng bộ mỗi khung hình từ `DisplayModel` + `AnimationDirector`, trả `PickablePiece[]` cho `picking.ts` |
| Tô sáng | `scene/highlight-mesh.ts` | Một `InstancedMesh` tô ô đang chọn (vàng) + ô đi được/ăn được/trưng dụng (màu theo `classifyMove`), PLAN 11.2 |
| Lắp ráp cảnh | `scene/board-scene.ts` | Ánh sáng, camera, `sync()` mỗi khung hình, dọn tài nguyên (`dispose`) |
| Input | `app/input.ts` | Chuột thật: xoay (phải-kéo), lia (giữa-kéo/Shift-kéo), phóng to/nhỏ (lăn), chọn/đi bằng chuột trái (có ngưỡng phân biệt kéo/bấm); bàn phím: Esc, Q/E xoay 60°, WASD lia, F về góc ghế đang đi, M bật/tắt nhìn từ trên |
| HUD | `app/hud.ts`, `app/event-text.ts`, `app/style.css` | Pha/lượt, nút tung xúc xắc, thông báo sự kiện (toast, qua i18n), bảng xếp hạng cuối ván |
| Điểm vào | `app/main.ts`, `index.html`, `vite.config.ts` | Ván hotseat một máy thật; `?seed=` để tái lập; `?e2e=1` bật móc gỡ lỗi cho Playwright |

### Ca biên / bất biến kỹ thuật → test

| # | Điều cần đúng | Test |
|--:|---|---|
| 1 | 1801 ô + 108 quân dựng đúng vị trí, đúng màu, thu hẹp chỉ ẩn chứ không dựng lại hình học | `test/hex-geometry.test.ts`, ảnh chụp `4-ring-collapsed.png` |
| 2 | Kích thước hình học từng loại quân đủ lớn để chứa bản vẽ (không bị cắt) | `test/piece-geometry.test.ts` (21/21, sau khi sửa `PIECE_FOOTPRINT` cho Q/K/J — xem "Sự cố" bên dưới) |
| 3 | Toạ độ ô ↔ điểm màn hình khớp hai chiều (dùng để bấm chuột thật trong e2e) | `test/layout-camera.test.ts` |
| 4 | Chọn quân bằng tia chiếu chuột đúng quân đang hiển thị (kể cả khi đang có hoạt ảnh) | `test/display-model.test.ts`, e2e test #1 (bấm chuột thật) |
| 5 | Hoạt ảnh chỉ đọc sự kiện, không tự quyết luật; nội suy đúng khi có nhiều sự kiện dồn | `test/animation.test.ts` |
| 6 | Mọi loại `GameEvent` đều có bản dịch HUD (không thiếu case) | `test/event-text.test.ts` (15 test, có test quét toàn bộ enum sự kiện) |
| 7 | Mọi khoá i18n dùng trong client đều tồn tại ở cả `vi.json` và `en.json` | `test/i18n.test.ts` |
| 8 | Bấm chuột thật (không giả lập sự kiện DOM) đưa quân đi đúng qua `GameController` thật | `e2e/hotseat.spec.ts` test #1 |
| 9 | Chơi trọn một ván tới khi kết thúc (tối đa 6000 hành động) không lỗi, không kẹt, ra đúng 6 hạng, có ít nhất một hạng 1 | `e2e/hotseat.spec.ts` test #2 |
| 10 | Sau nhiều hành động, mọi quân trên bàn có toạ độ hữu hạn (không "bay" ra ngoài khi hoạt ảnh chồng lấn) | `e2e/hotseat.spec.ts` test #3 |
| 11 | Vòng lặp vẽ không treo ở thế cờ đầu và khi đang hoạt ảnh + tô sáng | `e2e/perf.spec.ts` (2 test, số đo thật ở `docs/perf.md`) |
| 12 | 4 cảnh chuẩn dựng đúng bằng renderer thật (đầu ván, đang chọn quân, vừa ăn quân, đã thu hẹp) | `e2e/screenshots.spec.ts` (4 test, ảnh ở `packages/client/test-results/screenshots/`) |

### Sự cố đáng chú ý (đáng nhớ cho các milestone đồ hoạ sau, đã ghi vào `docs/decisions.md`)

- **Quân cờ và ô bàn cờ render ra màu đen tuyền dù `setColorAt()` đặt màu đúng**: nguyên nhân là bật
  `material.vertexColors = true` trong khi hình học không có thuộc tính màu theo đỉnh — shader nhân màu với
  một thuộc tính "không tồn tại" (mặc định `(0,0,0)` theo đặc tả WebGL) TRƯỚC khi nhân với màu theo instance,
  hoá đen toàn bộ. Chỉ cần **không** bật cờ đó — `InstancedMesh.setColorAt()` tự đủ. Phát hiện bằng cách tự
  nhìn ảnh chụp thật (không chỉ tin test số liệu qua), xem chi tiết ở `docs/decisions.md`.
- Cường độ đèn ở giá trị "trực giác" (0.5–1.5) gần như tối đen: Three.js bản dùng ở đây không còn "đèn kiểu
  cũ", đơn vị đèn theo vật lý nên phải tăng lên nhiều lần (đã chỉnh 3.2/3.6/0.8).
- `rules.config.json` và các file i18n `.json` cần `with { type: 'json' }` khi import để chạy được dưới bộ
  nạp ESM gốc của Node (Playwright), dù Vite/Vitest không cần cú pháp này.

### Chưa làm (đúng phạm vi M3, đã ghi vào `docs/perf.md` và `docs/questions.md`)

- Đo 60 FPS mức Thấp trên **máy có GPU thật** (PLAN 12.5): môi trường hiện tại chỉ có SwiftShader (phần
  mềm) nên số FPS đo được không dùng để kết luận đạt/không đạt mục tiêu — cần bạn đo trên máy thật.
- Bot, mạng nhiều người, Electron/Steam, menu cài đặt (đổi ngôn ngữ trong ứng dụng, mức đồ hoạ): các
  milestone sau (M4 trở đi theo PLAN).

## M4 — Solo với bot: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN: "Chơi trọn ván 1 vs 5 bot từ đầu tới kết thúc, thoát và vào lại được".

**Số liệu lần chạy cuối:** lint sạch · typecheck cả workspace · **439 test đơn vị / 25 file** (rules 294, client 118,
bot 15, protocol 12) · **13/13 test Playwright** (trình duyệt thật, Web Worker thật) · `verify_board.py` 30/30 ·
`pnpm check` xanh toàn repo · `vite build` ra bundle chính + bundle Worker riêng.

### Nghiệm thu → bằng chứng

| Tiêu chí | Bằng chứng |
|---|---|
| Chơi trọn ván 1 vs 5 bot tới khi kết thúc | `e2e/solo.spec.ts` › "chơi TRỌN ván": qua màn hình thật + Worker thật, lần chạy cuối **1451 hành động, kết thúc ở hiệp 392** (còn một Vua), bảng kết quả 6 hạng (ảnh `7-solo-result.png`). Không giao diện: `protocol/test/session.test.ts` và `client/test/game-link.test.ts` cũng chơi trọn ván |
| Thoát và vào lại được | `e2e/solo.spec.ts` › màn bắt đầu → ván mới → chơi 120 hành động → "Lưu & thoát" → **tải lại hẳn trang** → "Tiếp tục": cùng `hash` trạng thái, cùng `seq`, chơi tiếp được. Test không giao diện: thoát giữa ván rồi vào lại cho kết quả **y hệt** ván không thoát (tất định) |
| `LocalTransport` + Worker | `net/transport.ts` (`WorkerTransport`), `net/local-worker.ts`; bot + `GameSession` chỉ nằm trong bundle Worker |
| Bot Dễ + Thường | `packages/bot`; 1 Thường vs 5 Dễ thắng **72,2%** (chỉ tiêu PLAN 9.3: ≥ 35%), p95 thời gian nghĩ 25 ms (ngân sách 1,5 s) — `docs/bot.md` |
| HUD tối thiểu: lượt, hiệp, đồng hồ, danh sách người | `app/hud-model.ts` (thuần, 6 test) + `app/hud.ts`; đồng hồ 60 giây thật chạy trên HUD (`e2e/solo.spec.ts` › "bấm chuột thật trong ván solo"); ảnh `6-solo-hud.png` |
| Xúc xắc | Nút tung ở HUD; tự tung sau 15 giây (PLAN 7.3) — test ở session |
| Lưu/tiếp tục (X-10), tự lưu mỗi lượt | `protocol/src/save.ts` (seed + log hành động + hash = cũng là replay X-11); bản lưu hỏng/bị sửa/khác bản luật bị từ chối có lý do (test từng loại, kể cả e2e "bản lưu hỏng") |

### Đã làm thêm vì dùng chung với M6 (rẻ khi làm ngay)

- `GameSession` (`packages/protocol`): kiểm message bằng Zod (không tin client, PLAN 7.6), `seq` chống đi trên thế cờ cũ,
  đồng hồ lượt + thời gian hoạt ảnh (PLAN 7.4), **X-04** (3 lần hết giờ → bot lái tạm, thao tác lại thì lấy lại quyền),
  người chơi đầu hàng/bị loại thì bot đi nhanh cho ván kết thúc.
- Hotseat 6 người (M3) cũng chạy qua `GameSession` + Worker; test e2e M3 giữ nguyên và vẫn qua.
- CI: thêm job `e2e` (Playwright + tải ảnh chụp lên làm artifact).

### Kiểm tra test có sức bắt lỗi (đột biến thủ công)

| Đột biến | Kết quả |
|---|---|
| Tốt ăn thẳng thay vì chéo trong bản đồ đe doạ của bot | 2 test đối chiếu đỏ |
| Tù binh chưa tới hạn vẫn ra đòn | test đối chiếu đỏ |
| Bot Dễ luôn thấy nước ăn (100% thay vì ~60%) | test tỉ lệ ~60% đỏ |
| Bot bỏ qua hạng đang biến mất (`>` thay `>=`) | 2 test thu hẹp đỏ |
| Session không kiểm `seq` | test STALE_SEQ đỏ |
| Bỏ so `hash` khi tải ván lưu | test ván lưu bị sửa đỏ |
| X-04 cần 4 lần hết giờ thay vì 3 | test X-04 đỏ |

### Ảnh chụp (renderer + HUD thật, `packages/client/test-results/screenshots/`)

`5-menu.png` (màn bắt đầu), `6-solo-hud.png` (ván solo: bảng người chơi, hiệp, "Lượt của bạn", đồng hồ), `7-solo-result.png`
(kết quả ván trọn), cùng 4 ảnh cảnh chuẩn của M3.

### Chưa làm (đúng phạm vi)

- Bot Khó, tính cách, 1000 ván đo công bằng ghế, preset Tiêu chuẩn/Nhanh: M9. Ván bot hiện khá dài (docs/bot.md, Q-25).
- Menu/cài đặt/HUD đầy đủ (bản đồ nhỏ, chat, thông tin quân đang chọn, nút đầu hàng có xác nhận), chọn độ khó từng ghế: M5.
- Hiệu năng trên GPU thật: vẫn cần bạn đo (docs/perf.md).

## M5 — Giao diện hoàn chỉnh: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN: "Đi hết luồng menu → ván → kết quả không lỗi; kiểm tra chữ Việt có dấu".

**Số liệu lần chạy cuối:** lint sạch · typecheck cả workspace · **472 test đơn vị / 29 file** (rules 294, client 151,
bot 15, protocol 12) · **16/16 test Playwright** (menu → cài đặt → ván → kết quả, trình duyệt thật) · `verify_board.py`
30/30 · `pnpm check` xanh toàn repo.

### Nghiệm thu → bằng chứng

| Tiêu chí | Bằng chứng |
|---|---|
| Đi hết luồng menu → cài đặt → ván → kết quả không lỗi | `e2e/menu-settings.spec.ts` (3 test: menu tiếng Việt, đổi cài đặt + tải lại ngôn ngữ, X-14 xác nhận nước đi) + `e2e/solo.spec.ts`, `e2e/hotseat.spec.ts` chạy lại toàn bộ sau khi thêm menu Cài đặt — không lỗi console ở bất kỳ test nào |
| Chữ Việt có dấu hiển thị đúng | Ảnh `8-menu-vi.png` (`HEXWAR`, "Cờ lục giác 6 người · Bạn đấu với 5 bot"), `9-settings.png` ("Cài đặt", "Giảm chuyển động", "Cảnh báo đe doạ") — assert `toHaveText` so khớp chuỗi có dấu, không chỉ `toContainText` |

### Những gì đã dựng (đúng phạm vi PLAN mục 11, không đụng luật `packages/rules`)

| Hạng mục (PLAN 11) | File | Việc |
|---|---|---|
| Cài đặt (11.5) | `net/settings-store.ts`, `app/settings-panel.ts` | Ngôn ngữ, mức đồ hoạ, giảm chuyển động, cảnh báo đe doạ, xác nhận nước đi — lưu `localStorage`, mở được từ menu chính **và** từ trong ván |
| Bản đồ nhỏ (11.2 "Dưới trái") | `core/minimap-model.ts` (thuần), `app/minimap.ts` (canvas 2D riêng, không phải WebGL) | Chấm màu theo ghế, vòng sắp biến mất nhấp nháy vàng/đỏ, bấm để dịch camera tới điểm đó |
| Thông tin quân đang chọn (11.2 "Dưới giữa") | `core/selection-model.ts` (thuần), `app/hud.ts` | Loại quân, tầm đi, kills/ngưỡng phong cấp kế tiếp (thanh tiến độ 6/10/15/20), trạng thái trưng dụng |
| Cảnh báo thu hẹp (X-01) | `scene/board-mesh.ts` (`pulseWarning`) | Ô của vòng sắp biến mất nhấp nháy vàng (còn ≥ 2 hiệp) → đỏ (còn 1 hiệp) **ngay trên bàn cờ 3D**, không chỉ chữ HUD (đã có từ M2/M3) |
| Cảnh báo đe doạ (X-06) | `core/threats.ts` (thuần, dùng lại `attackersInState` của `@hexwar/bot`), `scene/threat-mesh.ts` | Tô đỏ mờ quân đang bị nhắm ăn ở lượt kế; báo riêng khi Vua của mình bị đe doạ (toast) |
| Giải thích nước sai | `controller.ts` → `ControllerListener.onRejected` → `hud.announceRejected` | Dùng lại `checkMove`/`IllegalReason` đã có từ M1/M2 qua i18n `illegal.*` — chỉ còn thiếu dây nối ở M4, nối nốt ở M5 |
| Xác nhận nước đi (X-14) | `core/controller.ts` (`Selection.pendingMove`, `ControllerOptions.confirmMoves`, `confirmPending`/`cancelPending`) | Tuỳ chọn (mặc định tắt = đi ngay, giữ nguyên hành vi M3/M4); bật thì bấm ô đích lần đầu chỉ đặt chờ, bấm lại/nút Xác nhận mới đi |
| Đầu hàng có xác nhận (X-05) | `app/hud.ts` (hộp thoại `.hud-confirm-dialog`) | Bấm "Đầu hàng" → hộp thoại hỏi lại → mới gọi `GameLink.resign()` |
| Màn kết quả đầy đủ (11.6) | `app/hud.ts` (`showResult`) | Mỗi hạng thêm số quân còn lại + còn sống/bị loại hiệp nào (`RankEntry` có từ M2, chưa hiển thị ở M4) |
| i18n vi/en (11.7) | `assets/i18n/vi.json`, `en.json` | +30 cặp khoá mới cho toàn bộ mục trên; script đối chiếu xác nhận đúng 130 khoá khớp ở cả hai file |

### Ca biên / bất biến kỹ thuật → test

| # | Điều cần đúng | Test |
|--:|---|---|
| 1 | Cài đặt lưu đúng qua `localStorage`, phục hồi đúng khi dữ liệu hỏng/thiếu trường | `test/settings-store.test.ts` (6 test) |
| 2 | Thông tin quân đang chọn đúng cho cả 7 loại quân, đúng tiến độ phong cấp, đúng khi đang trưng dụng | `test/selection-model.test.ts` (8 test) |
| 3 | Đe doạ tính đúng (dùng lại đúng bản đồ tấn công của bot, không viết lại), nhớ đệm không trả nhầm khi đổi trạng thái | `test/threats.test.ts` (6 test) |
| 4 | Bản đồ nhỏ: chấm đúng ghế, chỉ báo sắp biến mất khi thật sự trong khung cảnh báo (không phải mọi lúc còn vòng ngoài) | `test/minimap-model.test.ts` (7 test) |
| 5 | X-14: mặc định tắt giữ nguyên hành vi cũ (mọi test M3/M4 không sửa vẫn xanh); bật thì bấm 1 = chờ, bấm lại/`confirmPending` = đi, `cancelPending` = huỷ chờ vẫn giữ quân | `test/controller.test.ts` nhóm "xác nhận nước đi (X-14)" (7 test) |
| 6 | Đi hết luồng thật: menu → Cài đặt (đổi ngôn ngữ **tải lại trang thật**, đồ hoạ, tuỳ chọn) → đóng → hotseat → HUD đầy đủ | `e2e/menu-settings.spec.ts` (3 test, trình duyệt thật) |
| 7 | X-14 bấm chuột **thật** (không giả lập DOM): bấm ô đích lần 1 bàn cờ chưa đổi, nút "Xác nhận" mới đi | `e2e/menu-settings.spec.ts` › test thứ 3 |
| 8 | Toàn bộ khoá i18n dùng ở client tồn tại ở cả `vi.json`/`en.json` (đã có từ M3, chạy lại sau khi thêm ~30 khoá) | `test/i18n.test.ts` |

### Sự cố đáng chú ý (đã sửa, ghi vào `docs/decisions.md` để tránh lặp lại)

- **CSS `#app canvas` (không có lớp riêng) đè cả canvas bản đồ nhỏ**: quy tắc `width:100%; height:100%` định cho canvas cảnh 3D chính vô tình khớp **mọi** canvas con của `#app`, kéo cả canvas bản đồ nhỏ (`app/minimap.ts`, vốn chỉ 148×148px, định vị tuyệt đối) giãn ra phủ kín màn hình — chặn mọi cú bấm chuột trên toàn trang. Phát hiện bằng e2e thật (`.hud-dice` bị "canvas... intercepts pointer events"), không thấy được nếu chỉ đọc code. Sửa bằng cách đặt lớp riêng `.hexwar-canvas` chỉ cho canvas chính.
- **`.hud-selection` (bảng thông tin quân đang chọn) chặn chuột vào đúng bàn cờ bên dưới nó**: bảng này đặt **giữa-dưới màn hình** — đúng vị trí quân của ghế mình (PLAN 3.3 "ghế 0 ở đáy") thường đứng — và có `pointer-events: auto` cho cả bảng để bấm được nút Xác nhận/Huỷ. Hệ quả: chọn một quân gần hàng của mình rồi bấm ô đích cũng gần đó có thể bấm trúng bảng chữ thay vì bàn cờ, im lặng không làm gì (bắt được bằng e2e X-14 chập chờn ~1/3 lần chạy, seed ngẫu nhiên qua nút "Hotseat" thật). Sửa bằng cách tắt `pointer-events` ở bảng, chỉ bật lại ở đúng `.hud-selection-actions` (vùng hai nút) — bấm xuyên qua phần chữ, chỉ chặn đúng vùng nút.
- **`findMovablePiece` (móc gỡ lỗi Playwright) có thể chọn một ô đích nằm NGOÀI khung hình camera hiện tại**: bàn 1801 ô, góc "toàn cảnh" của hotseat không đảm bảo mọi ô đều nằm trong FOV; bấm chuột thật vào toạ độ tính ra cho một ô như vậy chỉ trúng khoảng trống. Chỉ lộ ra khi vào ván qua nút "Hotseat" thật (seed ngẫu nhiên mỗi lần) chứ không phải `?autostart=hotseat&seed=` cố định như các test M3/M4. Sửa tận gốc: chuyển `findMovablePiece` vào hẳn `DebugHook` (`app/e2e-hook.ts`, có sẵn `getOrbit`), dùng lại đúng `cameraPose`/`projectToNdc` của trang để chỉ trả về nước đi mà **cả ô xuất phát lẫn ô đích** đều nằm trong khung hình — `e2e/support.ts` chỉ còn gọi lại, không tính toán camera ở phía Node nữa (một nguồn duy nhất).
- **Lớp `.menu` dùng chung cho cả menu chính lẫn bảng Cài đặt** (cùng kiểu "thẻ giữa màn hình") làm `page.locator('.menu')`/`.menu-title` khớp **2 phần tử** (bảng Cài đặt tuy ẩn bằng `hud-hidden` vẫn nằm trong DOM) — vỡ 4 chỗ trong `solo.spec.ts` (M4, viết trước khi có Cài đặt) và 1 chỗ trong test menu mới. Sửa test bằng `:not(.settings)` thay vì đổi tên lớp CSS (đổi CSS sẽ phải viết lại kiểu dáng cho bảng Cài đặt).
- **Nút "Cài đặt"/"Đầu hàng" (góc dưới-phải mới ở M5) đè lên dòng gợi ý phím tắt** (đã có từ M3, cũng nằm ở mép dưới): cả hai cùng `bottom: 10px`. Chuyển nhóm nút lên `bottom: 46px` (ngang bản đồ nhỏ ở góc đối diện) — thấy bằng cách tự nhìn ảnh chụp thật `6-solo-hud.png`, không phải vì test nào đỏ.

### Quyết định thiết kế (chi tiết + lý do ở `docs/decisions.md`)

Đổi ngôn ngữ tải lại trang (không làm UI phản ứng theo locale), mức đồ hoạ M5 chỉ đổi `devicePixelRatio` hiệu dụng, X-14 là tuỳ chọn cộng thêm không phá hành vi cũ, đe doạ dùng lại nguyên bản đồ tấn công của bot, nhớ đệm theo tham chiếu đối tượng trong `threats.ts`, hộp thoại đầu hàng nằm trong `Hud` (không tách lớp riêng).

### Chưa làm (ngoài phạm vi M5, đúng PLAN 11)

- Chat, voice, tay cầm/Steam Deck, hỗ trợ truy cập (cỡ chữ, độ tương phản), đổi phím: M7/M11/sau này.
- Mức đồ hoạ Cao chưa có bóng đổ/SSAO/bloom thật (12.5) — đó là việc của M10; M5 chỉ đổi độ phân giải nội bộ qua `devicePixelRatio` như đã ghi rõ trong `settings-panel.ts` để không hứa quá phạm vi.
- Nút "nhảy tới" (Vua của tôi / quân đang chọn / nước đi cuối / vòng sắp biến mất) ở PLAN 11.4: chỉ mới có bấm-vào-bản-đồ-nhỏ; các nút nhảy nhanh khác để M10 (đồ hoạ hoàn thiện) cùng lúc làm UI camera đầy đủ hơn.

### Ảnh chụp (renderer + HUD thật, `packages/client/test-results/screenshots/`)

`8-menu-vi.png` (menu chính tiếng Việt), `9-settings.png` (bảng Cài đặt), cùng `5,6,7` (M4) và 4 ảnh cảnh chuẩn (M3) — toàn bộ chạy lại sau M5 để xác nhận không vỡ hình vì các lớp CSS mới.

## M6 — Online: **xong, đạt nghiệm thu (trừ 1 mục cần bạn tự làm)**

Nghiệm thu theo PLAN mục 7/6.6: "Test tích hợp 6 client + ngắt/nối; thử thật 2 máy qua internet". Vế đầu làm và
kiểm chứng được trong sandbox này bằng client/server thật (không mock); vế "2 máy qua internet thật" cần mạng thật
và máy thật của bạn — xem mục "Chưa làm" bên dưới.

**Số liệu lần chạy cuối:** lint sạch · typecheck cả 8 package (thêm `@hexwar/server`) · **514 test đơn vị** (rules
300, client 151, bot 15, protocol 18, server 15, cộng dồn từ M9 sang sớm ở M6.1) · **18/18 test Playwright** (16 test
cũ M3–M5 chạy lại không đổi hành vi + 2 test online mới: ghép nhanh 1 người + 5 bot, và tạo phòng riêng vào bằng mã
ở tab thứ hai) · `verify_board.py` 30/30 · `pnpm check` xanh toàn repo.

### Nghiệm thu → bằng chứng

| Tiêu chí (PLAN 6.6 / 7) | Bằng chứng |
|---|---|
| Test tích hợp nhiều client thật qua WebSocket thật (không mock tầng nào) | `packages/server/test/game.test.ts`: 6 kết nối `ws` thật cùng vào 1 phòng riêng, mỗi kết nối thấy đúng 1 ghế của mình; một nước đi của 1 người phát `game.events` giống hệt tới cả 6; nước gửi sai `seq` (`STALE_SEQ`) chỉ tới đúng người gửi, không ai khác thấy gì |
| Ngắt kết nối / kết nối lại trong hạn ân hạn giữ nguyên ghế | `game.test.ts`: ngắt rồi nối lại (cùng token) trong `reconnectGraceSeconds` → nhận lại đúng ghế cũ + `game.snapshot` gửi lại; test riêng cho hết hạn ân hạn (`reconnectGraceSecondsOverride: 0`) xác nhận token vẫn còn (danh tính không mất) nhưng **không** còn được gắn lại vào phòng (`NOT_IN_ROOM`) |
| Sảnh chờ + ghép trận thật, bot lấp chỗ trống | `packages/server/test/lobby.test.ts` (10 test: `hello` bắt tay, ghép nhanh 1 người + bot lấp 5 ghế, 2 người ghép chung 1 phòng ghép nhanh, tạo/vào phòng riêng bằng mã, thêm/bớt bot, chỉ chủ phòng mới đổi cấu hình, giới hạn tốc độ gửi, giới hạn kích thước gói tin, gói tin không phải JSON) |
| Client thật (trình duyệt) chơi được một ván online trọn vẹn | `packages/client/e2e/online.spec.ts`: menu → "Chơi online" → "Ghép nhanh" → 5 bot lấp chỗ (thật, có `botFillDelayMs`) → ván tự bắt đầu → đợi đúng lượt mình → bấm chuột thật đi 1 nước → xác nhận nước đã tới server và quay lại đúng vị trí |
| "you"/góc nhìn đúng cho từng kết nối riêng biệt | `online.spec.ts` test 2 (2 tab trình duyệt) + `lobby.test.ts`: mỗi kết nối chỉ thấy `you` là đúng ghế của mình, hai tab luôn khác ghế nhau |
| Server không tin dữ liệu từ client (PLAN 7.6) | `lobby.test.ts`: gửi 60 gói `queue.leave` liên tục → bị `RATE_LIMITED`; gửi gói > 16 KB → server tự đóng kết nối; gửi chuỗi không phải JSON → `BAD_MESSAGE`, không crash server |

### Những gì đã dựng (đúng phạm vi PLAN mục 7, không đụng luật `packages/rules`)

| Hạng mục (PLAN 7) | File | Việc |
|---|---|---|
| Preset luật (X-09, kéo sớm từ M9 vì cần cho phòng online) | `packages/rules/src/presets.ts` | `applyPreset('classic'\|'fast'\|...)`: đổi giờ mỗi lượt + lịch thu hẹp; không đụng `reconnectGraceSeconds`/`afkTimeoutsBeforeBot` (hằng số độc lập với preset) |
| Giao thức sảnh/phòng (protocol) | `packages/protocol/src/lobby-messages.ts` (schema Zod) | `hello`/`hello.ack`, `queue.join`/`room.create`/`room.join`/`room.ready`/`room.addBot`/`room.removeBot`/`room.setConfig`/`room.leave`, `room.state`/`room.closed`/`lobby.error` |
| Server (`packages/server`, gói mới — **không** nằm dưới ràng buộc "thuần/tất định" của `rules`/`bot`/`protocol`) | `identity.ts`, `connection.ts`, `room.ts`, `matchmaker.ts`, `server.ts`, `bot.ts`, `main.ts` | Danh tính khách (`IdentityStore`, token `randomUUID`), vòng đời phòng (`lobby`→`game`, ghép nhanh tự lấp bot theo hẹn giờ / phòng riêng dùng mã 6 ký tự), giới hạn tốc độ gửi (token bucket) + giới hạn kích thước gói (`maxPayload`), tái sử dụng nguyên `GameSession` của `packages/protocol` (không viết engine mạng thứ hai) |
| Client: `WebSocketTransport` | `packages/client/src/net/websocket-transport.ts` | Ghép chung 1 kết nối WebSocket cho cả 3 tầng: `game.*` (đúng interface `Transport` sẵn có từ M4, dùng lại y hệt cho hotseat/solo), `lobby.*` (sảnh/phòng riêng), trạng thái kết nối (`connecting`/`open`/`closed`) |
| Client: màn "Chơi online" + Phòng chờ | `app/online-menu.ts`, `app/lobby.ts` | Ghép nhanh / tạo phòng riêng / vào bằng mã; phòng chờ hiện danh sách ghế (trống/bot/người, chủ phòng, sẵn sàng, mất kết nối), chủ phòng thêm/bớt bot, ai cũng bấm Sẵn sàng được (trừ ghế bot) |
| i18n vi/en | `assets/i18n/vi.json`, `en.json` | +1 khoá menu (`menu.online`) + 10 khoá `online.*` + 16 khoá `lobby.*`, kiểm tra khớp 100% qua `test/i18n.test.ts` (đã có từ M3) |

### Hai chỗ phải sửa lại `GameSession` để dùng đúng cho nhiều kết nối thật (không có ở hotseat/solo)

`GameSession` (viết từ M4) vốn được thiết kế cho **một** nơi nhận sự kiện (Worker cục bộ, hotseat trên 1 máy). Online
có **nhiều kết nối riêng biệt** cùng nói chuyện với một `GameSession`, lộ ra 2 giả định ngầm phải vá ở tầng `Room`
(không sửa `GameSession`, giữ nguyên hợp đồng M4):

1. **Định tuyến phản hồi theo người gửi** — `GameSession.options.reply` cố định lúc tạo (1 hàm cho mọi output). `Room`
   dùng một trường tạm `replyTarget`, gán đúng trước mỗi lần gọi `session.handle()` rồi xoá ngay sau (an toàn vì
   `handle()` chạy đồng bộ hoàn toàn) — để lỗi "sai `seq`" của một người chỉ về đúng người đó, không văng ra cho cả bàn.
2. **Trường `you` cá nhân hoá theo từng người nhận** — `snapshotFor()` hotseat trả `you` = **tất cả** ghế người (đúng
   cho 1 máy 6 người). `Room.broadcastGame()` chặn riêng `game.snapshot` và gửi mỗi kết nối một bản có `you` chỉ gồm
   đúng ghế của họ; `game.events` (không có `you`) vẫn quảng bá y hệt cho tất cả.

Cả hai được kiểm chứng trực tiếp bằng test tích hợp thật (`game.test.ts`, `lobby.test.ts`) chứ không chỉ đọc code.

### Sự cố đáng chú ý (đã sửa, chi tiết + lý do ở `docs/decisions.md`)

- **`ws` ném lỗi không ai bắt khi vượt giới hạn kích thước gói tin**: thiếu `ws.on('error', ...)` trên từng kết nối khiến `RangeError` (`WS_ERR_UNSUPPORTED_MESSAGE_LENGTH`) văng thành "Uncaught Exception", sập cả tiến trình test. Sửa bằng cách thêm listener rỗng (dọn dẹp đã có sẵn ở `close`).
- **Test đua (race) sai giữa `Promise.race` và `waitFor` bị timeout**: một nhánh `waitFor` hết hạn thì **từ chối** (reject) chứ không giải quyết (resolve), khiến lỗi chưa-bắt thắng cuộc đua trước khi nhánh dự phòng kịp chạy. Sửa bằng `.then(() => false, () => true)` ở cả hai nhánh.
- **Lớp `.menu` dùng chung sẽ vỡ khi thêm 2 màn overlay mới** (Online, Phòng chờ) cũng tái dùng `.menu-subtitle`/`.menu-info`/`.menu-error` — phát hiện **trước khi chạy test nào** bằng cách đọc lại `settings-panel.ts`. Đổi hẳn lớp gốc của menu chính thành `menu main` (thay vì tiếp tục nối chuỗi `:not(.settings):not(.online):not(.lobby)` không mở rộng được) và sửa lại toàn bộ locator Playwright liên quan.

### Chưa làm (đúng phạm vi, ghi rõ để không hiểu nhầm là đã xong)

- **"Thử thật 2 máy qua internet" (PLAN 6.6/7) — việc của bạn**: môi trường này không có 2 máy thật nối qua internet để kiểm; toàn bộ kiểm chứng ở trên dùng client thật + server thật nhưng chạy chung một tiến trình/localhost. Muốn xác nhận: chạy `node packages/server/dist/main.js` (sau khi build) trên một máy có địa chỉ mạng tới được, đổi `resolveServerUrl` (hoặc `?server=ws://<ip>:<port>`) ở máy thứ hai, thử chơi thật.
- Không có "tự kết nối lại khi mất mạng"/khôi phục sau khi **tải lại trang** (F5): `WebSocketTransport` chỉ tự phục hồi khi socket còn sống trong cùng một tab (ví dụ mất sóng WiFi ngắn ở tầng TCP mà trình duyệt tự nối lại). Tải lại trang tạo kết nối mới, không có token cũ, nên không tự vào lại ván đang chơi — token hiện chỉ giữ trong bộ nhớ `WebSocketTransport`, chưa lưu `localStorage`. Ghi vào `docs/questions.md` (Q-26) vì đây là quyết định phạm vi, không phải giới hạn kỹ thuật.
- Chọn preset luật khi ghép trận: `OnlineMenu` chưa có bộ chọn, ghép nhanh/tạo phòng đều dùng cứng preset `'classic'`. `Room.setConfig` (chủ phòng đổi được ở tầng server/protocol) đã có, chỉ thiếu UI — dễ thêm sau, không phải làm lại.
- Phòng riêng lấp chỗ trống bằng bot: chỉ **chủ phòng bấm `+ Thêm bot`** thủ công cho từng ghế, không tự lấp như phòng ghép nhanh (đó là quyết định có chủ đích — xem Q-27).
- Xác thực Steam vẫn hoãn tới M11 đúng PLAN 7.1 ("chế độ khách chỉ dành cho bản dev"); toàn bộ M6 chạy bằng danh tính khách (`Khách123`, tên ngẫu nhiên).

### Quyết định thiết kế (chi tiết + lý do ở `docs/decisions.md`)

Ngữ nghĩa `reconnectGraceSeconds` (hạn giữ chỗ ở phòng, độc lập hoàn toàn với X-04 lái-tạm-bằng-bot của
`GameSession`), 2 chỗ vá `GameSession` cho nhiều kết nối (định tuyến `reply`, cá nhân hoá `you`), đổi lớp `.menu`
chính thành `menu main`, tách `openGame` khỏi việc tự dựng `Transport` để dùng chung cho cả solo/hotseat/online,
không làm khôi phục phiên qua tải lại trang ở M6.

## M7 — Chat và voice: **xong, đạt nghiệm thu**

Nghiệm thu theo PLAN mục 15 (M7): "6 client nghe nhau; whisper chỉ tới đúng người (test tự động); tùy chọn ẩn IP
hoạt động". Cả ba đều kiểm chứng được bằng test tự động thật (không mock WebRTC/WebSocket) trong sandbox này, không
mục nào cần bạn tự làm — khác với M6 (mục "thử thật 2 máy qua internet" vẫn còn đó, xem "Chưa làm" bên dưới).

**Số liệu lần chạy cuối:** lint sạch · typecheck cả 8 package · **540 test đơn vị** (rules 300, client 172, bot 15,
protocol 27, server 26 — tăng từ M6 chủ yếu ở `protocol` (schema chat/voice + bộ lọc từ cấm) và `server` (chat.test.ts
+ một test chống 1 người báo cáo nhiều lần tự "câm" người khác, xem "Sự cố đáng chú ý") · **21/21 test Playwright**
(18 test cũ M3–M6 chạy lại không đổi hành vi + 3 test voice mới) · `verify_board.py` 30/30 · `pnpm check` xanh toàn
repo.

### Nghiệm thu → bằng chứng

| Tiêu chí (PLAN mục 15, M7) | Bằng chứng |
|---|---|
| "6 client nghe nhau" (voice, PLAN 8.5) | `packages/client/e2e/voice.spec.ts`: **6 tab trình duyệt thật** (không mock WebRTC), mic giả (`--use-fake-device-for-media-stream`), cùng vào 1 phòng riêng qua server thật, cả 6 bật Mic+Nghe → mesh đầy đủ **15 kết nối** (mỗi người 5) đàm phán tới `RTCPeerConnection.connectionState === 'connected'` ở **cả sáu** tab, không chỉ "có ít nhất một" |
| "whisper chỉ tới đúng người" (test tự động, PLAN 8.2) | `packages/server/test/chat.test.ts`: 6 kết nối `ws` thật, một người nhắn riêng cho một người khác → chỉ người gửi + người nhận thấy tin, **4 người còn lại xác nhận không thấy gì** (không chỉ suy luận từ code); cùng kiểu kiểm tra áp dụng cho kênh "Người đã bị loại" và relay `voice.signal` (chỉ đúng một ghế đích thấy) |
| "tùy chọn ẩn IP hoạt động" (Chỉ đi qua TURN, PLAN 8.5) | `voice.spec.ts`: bật "Chỉ đi qua TURN" ở cả hai bên TRƯỚC khi bật Mic → `RTCPeerConnection` mới tạo có đúng `iceTransportPolicy: 'relay'` (đọc bằng `RTCPeerConnection.getConfiguration()` thật qua móc gỡ lỗi mới `voiceIcePolicy()`). Không kiểm được việc ẩn IP có hiệu quả THẬT (cần TURN server thật, việc triển khai hạ tầng của bạn — PLAN 7.7, xem `docs/questions.md` Q-31); test chỉ xác nhận code nối đúng dây tới cấu hình trình duyệt |
| Chat toàn phòng + câu có sẵn + giới hạn tốc độ + báo cáo/hạn chế (PLAN 8.1, 8.3, 8.4) | `chat.test.ts` (10 test): phát toàn phòng tới đúng 6 người; câu có sẵn gửi bằng `phraseId` không phải chữ tự do; quá 5 tin/10 giây → `RATE_LIMITED`; đủ 3 NGƯỜI KHÁC NHAU báo cáo → `RESTRICTED`, còn 1 người báo cáo nhiều lần thì KHÔNG bị hạn chế (test mới, xem "Sự cố đáng chú ý"); không nhắn riêng/báo cáo được cho bot/chính mình/ghế trống |
| Client thật (trình duyệt) dùng được toàn bộ luồng chat + voice | `voice.spec.ts` (test 2 tab): menu → phòng → Sẵn sàng → HUD → mở `VoiceBar` → xin quyền mic (hộp thoại giải thích thật) → bật Mic/Nghe → mesh tự dựng; `ChatPanel` (roster, tab whisper, chặn/báo cáo, điều khiển voice từng người) được kiểm bằng 172 test đơn vị (`chat-panel` không tự viết test DOM riêng — logic tách hết ra `core/chat-model.ts`/`core/voice-model.ts` thuần, có test) |

### Những gì đã dựng (đúng phạm vi PLAN mục 8, không đụng luật `packages/rules`)

| Hạng mục (PLAN 8) | File | Việc |
|---|---|---|
| Giao thức chat/báo cáo/voice | `packages/protocol/src/chat.ts` | `chat.send`/`report.player`/`voice.signal` (client→server), `chat.message`/`chat.error`/`report.ack`/`voice.signal` (server→client) — cùng kết nối WebSocket với `lobby.*`/`game.*` (M6), tách theo `type` trước khi phân giải schema. 24 câu có sẵn (`PHRASE_GROUPS`, 4 nhóm) gửi bằng mã |
| Bộ lọc từ cấm (khung minh hoạ, xem Q-28) | `packages/protocol/src/profanity.ts` | `censorText(text, locale)`: thay từ khớp bằng dấu `*`, không phân biệt hoa/thường; danh sách thật là việc của bạn |
| Server: kênh chat + giới hạn tốc độ + báo cáo/hạn chế + relay voice | `packages/server/src/room.ts` (`handleChatMessage`, `handleChatSend`, `handleReport`, `handleVoiceSignal`) | Kênh `all`/`whisper`/`dead` (kênh "Hệ thống" không đi qua `chat.send`, xem `docs/decisions.md`); `RateLimiter` riêng cho chat (5 tin/10 giây); đếm báo cáo theo NGƯỜI báo cáo khác nhau (ngưỡng 3, cửa sổ 24 giờ, phạt 15 phút — hằng số ở đầu `room.ts`); relay `voice.signal` nguyên văn, không hiểu nội dung |
| Client thuần (không DOM): mô hình chat + voice | `packages/client/src/core/chat-model.ts`, `core/voice-model.ts` | Chat: tab/kênh, lọc hiển thị theo mute/block, khoá dịch câu có sẵn. Voice: `isPolite`, `shouldConnect`, `wantedPeers`, `isSpeaking`, phân giải `VoiceSignalData` — 14 test riêng cho voice, có thể chạy trong Vitest (Node) vì không đụng `RTCPeerConnection`/DOM thật |
| Client: `ChatPanel` (UI chat + roster + điều khiển voice từng người) | `app/chat-panel.ts` | Gấp lại mặc định (bài học M5, không chặn nhầm cú bấm vào bàn cờ); tab toàn phòng/khán giả/nhắn riêng theo từng người; vòng chọn câu nhanh (phím `T`); mỗi hàng người chơi có nút tắt tiếng-chữ/chặn/báo cáo VÀ (M7.4) chấm "đang nói", thanh trượt âm lượng, nút tắt-nghe-voice riêng người đó; huy hiệu số tin chưa đọc trên nút nổi khi gấp lại |
| Client: `VoiceManager` + `VoiceBar` (thi hành WebRTC thật) | `net/voice-manager.ts`, `app/voice-bar.ts` | Mesh WebRTC "perfect negotiation" (MDN) qua `voice.signal`; `getUserMedia` bật sẵn khử tiếng vọng/khử ồn/tự chỉnh âm lượng; Mic bật = sẵn sàng, giữ phím `V` mới thật sự gửi (push-to-talk, không renegotiate); chỉ đo mức âm lượng bằng `AnalyserNode` cho chỉ báo "đang nói" (không ghi âm/lưu); thanh nổi góc dưới-phải: Mic/Nghe/chọn thiết bị/"Chỉ đi qua TURN"/nút thử mic |
| Cài đặt voice (bền vững, mọi phòng) | `net/settings-store.ts` | +`voiceTurnOnly: boolean`, +`voiceMicDeviceId: string \| null`, cùng mẫu `graphics`/`locale` đã có từ M5 |
| Móc gỡ lỗi Playwright mở rộng | `app/e2e-hook.ts` | +`voicePeerStates()` (trạng thái `RTCPeerConnection` thật từng ghế), +`voiceIcePolicy(seat)` (đọc `iceTransportPolicy` thật) — chỉ bật bằng `?e2e=1`, không ảnh hưởng luồng chơi bình thường |
| i18n vi/en | `assets/i18n/vi.json`, `en.json` | +khoá `chat.*`/`phrase.*`/`voice.*`, tổng **225 khoá mỗi ngôn ngữ**, khớp 100% qua `test/i18n.test.ts` |

### Sự cố đáng chú ý (đã sửa, chi tiết + lý do ở `docs/decisions.md`)

- **Đua tranh giành quyền mở kết nối (glare) khiến WebRTC kẹt vĩnh viễn ở `connectionState === 'new'`**: bản đầu để cả hai phía của một cặp cùng chủ động khởi tạo `RTCPeerConnection` khi nhu cầu kết nối của MỖI BÊN tự đổi, gây ra offer/answer đua nhau ngay từ lúc khởi tạo nguội dù đã theo đúng mẫu "perfect negotiation" chuẩn của MDN. Bắt được bằng Playwright thật (2 tab, mic giả) chứ không phải đọc code. Sửa bằng cách chỉ để đúng MỘT bên (impolite, ghế nhỏ hơn) chủ động mở kết nối lúc khởi tạo nguội; bên kia chỉ phản ứng khi thật sự nhận offer. Xem chi tiết kỹ thuật đầy đủ + bài học rút ra ở `docs/decisions.md` mục M7.
- **Một người có thể tự "câm" người khác bằng cách tự báo cáo nhiều lần**: bản đầu của `CHAT_REPORT_THRESHOLD` đếm TỔNG SỐ LƯỢT báo cáo trong cửa sổ 24 giờ, không phân biệt người báo cáo — một người bấm báo cáo 3 lần (cách nhau đủ lâu để không đụng giới hạn tốc độ) đã đủ để khiến người khác bị `RESTRICTED`, ngược với ý PLAN 8.4 "bị báo cáo nhiều lần" (ngụ ý nhiều NGƯỜI). Phát hiện khi viết tài liệu nghiệm thu cho mục này (đọc lại `handleReport` để mô tả đúng hành vi thì thấy sai), không phải từ một test có sẵn — không có test nào trước đó thử "một người báo cáo lặp lại". Sửa bằng cách đổi `reportedAt` từ mảng mốc giờ sang mảng `{at, reporterId}`, chỉ giữ MỚI NHẤT một mục cho mỗi `reporterId`, đếm ngưỡng theo độ dài mảng đó (= số người khác nhau). Thêm test mới xác nhận hành vi đúng (`chat.test.ts`).
- **`X-14` (xác nhận nước đi) chập chờn ~1/3 lần khi vào ván qua menu thật (không phải lỗi mới của M7)**: chạy lại toàn bộ 21 test Playwright vài lần trong lúc làm M7 thấy `menu-settings.spec.ts` X-14 thỉnh thoảng báo "thế cờ đầu phải có ít nhất một quân đi được" — đây là sự cố ĐÃ BIẾT từ M5 (xem chú thích ở `app/e2e-hook.ts` `findMovablePiece`: bàn 1801 ô, góc camera không đảm bảo mọi quân "đi được" đều đủ nằm trong khung hình + đúng tiêu chí lọc, seed ngẫu nhiên không cố định vì test đi qua menu thật). Không sửa ở M7 (ngoài phạm vi, không đụng gì tới chat/voice) — ghi lại ở đây để không ai tưởng nhầm là do thay đổi M7 gây ra; xem lại nếu muốn hết chập chờn hẳn (ví dụ nới tiêu chí lọc `findMovablePiece` hoặc cố định seed cho riêng test này).

### Chưa làm (đúng phạm vi, ghi rõ để không hiểu nhầm là đã xong)

- **TURN server thật (PLAN 7.7) — việc của bạn**: `DEFAULT_ICE_SERVERS` chỉ có STUN công khai; "Chỉ đi qua TURN" đã đúng dây (kiểm bằng test) nhưng không có TURN thật thì bật lên = không kết nối được (đúng ý "thà không nối còn hơn lộ IP", nhưng cần bạn biết trước). Triển khai coturn + cấp thông tin đăng nhập ngắn hạn theo phiên, xem `docs/questions.md` Q-31.
- Danh sách từ cấm chỉ là khung minh hoạ (9 từ), chưa đủ dùng thật — việc biên soạn nội dung của bạn, xem Q-28. Cân nhắc thêm `ISteamUtils::FilterText` của Steamworks lúc làm M11.
- Ba hằng số ngưỡng báo cáo (3 người / 24 giờ / phạt 15 phút) là điểm khởi đầu, chưa có dữ liệu thật để tinh chỉnh — xem Q-29.
- Voice chỉ có Push-to-talk (phím `V`); PLAN 8.5 có nhắc tới lựa chọn "mic mở có phát hiện giọng nói" nhưng chưa làm (không bắt buộc, PLAN cho cả hai lựa chọn) — có thể thêm sau bằng cách bật `track.enabled` theo `isSpeaking()` (đã có sẵn hàm thuần) thay vì theo phím giữ.
- Không có lựa chọn thiết bị LOA riêng (chỉ có chọn micro) — `<audio>` phát qua loa mặc định hệ thống; chọn loa ra ngoài (`setSinkId`) chưa hỗ trợ ở mọi trình duyệt như micro, để dành nếu có nhu cầu thật.
- Bot vẫn chưa gửi câu chat có sẵn thỉnh thoảng (PLAN 9.4) — thuộc M9 (tính cách bot), không phải M7.
- Mute/chặn/hội thoại riêng không nhớ qua phòng khác (quyết định có chủ đích, xem Q-30); "Thử thật 2 máy qua internet" cho voice (glare qua mạng thật, không phải localhost) vẫn là việc của bạn giống hệt lý do đã ghi ở mục M6.

### Quyết định thiết kế (chi tiết + lý do ở `docs/decisions.md`)

Giao thức chat/voice là "kênh thứ ba" trên cùng một WebSocket của M6; câu có sẵn gửi bằng mã để không cần lọc từ;
lọc từ cấm chạy ở client (moderation nhẹ, không phải chống gian lận); giới hạn tốc độ chat tách khỏi giới hạn gói
tin chung; ngưỡng báo cáo đếm theo người khác nhau; voice là WebRTC mesh với server chỉ relay tín hiệu; tách quyết
định thuần (`voice-model.ts`, test được) khỏi thi hành WebRTC thật (`voice-manager.ts`, chỉ kiểm bằng Playwright);
Mic bật = sẵn sàng, giữ phím mới gửi (không renegotiate); điều khiển voice riêng-từng-người nằm trong `ChatPanel`,
điều khiển chung-cả-phòng nằm trong `VoiceBar`; trạng thái chat/voice riêng-từng-phòng bị xoá khi rời ván, cài đặt
thiết bị/quyền riêng tư thì bền vững qua mọi phòng.

## M8 — Tân thủ: **xong cả hai phần** (lõi engine + màn hình client), một số đơn giản hoá đã ghi ở `docs/questions.md`

Milestone M8 theo PLAN mục 15 gồm hai phần: (1) dữ liệu 13 bài + runner chạy trên engine thật + "người chơi ảo"
giải được cả 13 bài trong CI, và (2) màn tân thủ thật ở client (mở lần đầu, gợi ý theo thời gian, Bỏ qua/Làm lại,
lưu tiến độ). Phần (1) xong từ trước; phần (2) nay đã xong — mục "Đã dựng (phần 2 — client)" và "Đơn giản hoá đã
chọn" bên dưới liệt kê chính xác những gì làm và những chỗ cắt gọn có chủ đích.

### Nghiệm thu phần (1) → bằng chứng

| Tiêu chí (PLAN mục 15) | Bằng chứng |
|---|---|
| "Người chơi ảo" giải xong cả 13 bài trong CI | `packages/tutorial/test/solve.test.ts`: `solveLesson()` tự tìm và đi nước thoả mục tiêu ở mọi bước `'move'` của cả 12 bài có kịch bản (T1–T6, T7–T11) bằng chính `legalMoves`/`applyMove` thật của `@hexwar/rules`, không giả lập luật riêng. T13 ("Trận tập") không có kịch bản riêng — dùng nguyên ván solo thật đã được `@hexwar/client`/`@hexwar/bot` kiểm từ M4 (xem `docs/decisions.md`) |

### Những gì đã dựng (`packages/tutorial`, thuần — không đụng DOM/mạng, giống quy ước của `packages/rules`)

| Phần | Nội dung |
|---|---|
| `types.ts` | Mô hình dữ liệu `Lesson`/`Step`/`Goal` — từ vựng `Goal` đóng (6 loại + `all`), JSON-serializable, dùng chung cho runner/solver/hint tương lai |
| `goal.ts` | `goalMet()` — một nguồn duy nhất đánh giá mục tiêu, dùng bởi cả runner lẫn solver (không thể lệch nhau, đúng mẫu `legalMoves`/`explainIllegal` của `packages/rules`) |
| `runner.ts` | `startLesson`/`pump`/`acknowledgeInfo`/`attemptMove` — chạy một bài trên `GameState` thật; nước sai luật bị từ chối (giữ nguyên trạng thái, trả `IllegalReason` để hiện giải thích); nước đúng luật nhưng chưa đạt mục tiêu vẫn được ÁP DỤNG THẬT (chơi thật, đúng PLAN 10.1), chỉ chưa sang bước kế |
| `solver.ts` | `findHintMove()` (nền tảng dùng chung cho gợi ý 15s/30s ở client SAU NÀY) + `solveLesson()` ("người chơi ảo" cho CI) |
| `scenarios/t1.ts`…`t13.ts` | 13 bài đúng PLAN 10.2, dựng bằng `makeState`/`createPiece` + hàm hình học có sẵn (không chép tay toạ độ) |
| `strings.ts` | `TUTORIAL_STRINGS` — toàn bộ lời thoại vi/en đã soạn sẵn, đúng khoá dùng trong `scenarios/*.ts`, chờ client copy vào `vi.json`/`en.json` |

### Kỹ thuật đáng chú ý → `docs/decisions.md`

Ghế phụ không quân (`seats: [0, 1]`) để tránh `checkGameOver` kết thúc ván ngay khi chỉ có một ghế thật; goal `pieceAt`
để ép đúng một trong nhiều nước hợp lệ; T7/T8/T9 dùng ghế 1 làm đối thủ thật hoặc bước `'auto'` kịch bản; T12 tự
tìm seed xúc xắc thay vì hardcode; T13 không có kịch bản riêng (dùng ván thật).

### Đã dựng (phần (2) — `@hexwar/client`)

| Phần | Nội dung |
|---|---|
| `net/tutorial-transport.ts` | `TutorialTransport` — cài `Transport` bằng một `ScenarioLesson` của `@hexwar/tutorial`; phát `game.snapshot`/`game.events`/`game.rejected` ĐÚNG hình dạng giao thức thật (`@hexwar/protocol`), một `game.events` cho MỖI hành động atomic (giống `GameSession.commit`), không gộp nhiều bước 'auto' liên tiếp thành một sự kiện (xem `docs/decisions.md`) |
| `net/tutorial-progress-store.ts` | `TutorialProgressStore` — cùng khuôn `SaveStore`/`SettingsStore`: `hexwar.tutorial.v1`, nhớ bài đã hoàn thành + đã từng mở màn tân thủ chưa (`hasStarted`) |
| `app/tutorial-panel.ts` | `TutorialPanel` — màn danh sách 13 bài (đánh dấu bài đã xong) + bảng lời thoại/nút nổi (Tiếp tục, Bỏ qua bài, Làm lại bài, Về danh sách bài) khi đang học; `tick()` gọi mỗi khung hình để cập nhật chữ + hẹn giờ gợi ý 15s/30s bằng `findHintMove` + `GameController.select` |
| `app/menu.ts`, `app/main.ts` | Nút "Tân thủ" ở menu chính; `ActiveGame.mode` thêm `'tutorial'`; ván tân thủ dùng NGUYÊN `GameLink`/`Hud`/`BoardScene`/`attachInput` của ván thật, không viết lại UI riêng; camera co theo bán kính bài nhỏ; tự mở bài 1 khi `!hasStarted()` và không có `?e2e=1`/`?autostart=` |
| `assets/i18n/vi.json`, `en.json` | Copy nguyên `TUTORIAL_STRINGS` (13 bài) + khoá giao diện tân thủ mới (`tutorial.picker.*`, `tutorial.done.*`, `tutorial.skip`, …) |
| `test/tutorial-progress-store.test.ts` | Vitest cho store (cùng mẫu `settings-store.test.ts`) |
| `e2e/tutorial.spec.ts` | Playwright thật: menu → tân thủ → hoàn thành T1 bằng bấm chuột thật (không dùng móc gỡ lỗi để "chơi hộ") → Bỏ qua T2 không đánh dấu hoàn thành → tải lại trang → tiến độ vẫn còn |

### Đơn giản hoá đã chọn (chi tiết + lý do ở `docs/questions.md`)

- T13 ("Trận tập") dùng thẳng `startSolo('easy')` — không ép hạn hiệp 50 riêng, không tự đánh dấu "đã xong" (không
  có tín hiệu hoàn thành tự nhiên vì đây là ván solo thật, không có `runner`).
- Gợi ý 15s/30s chỉ tô sáng quân + MỌI nước đi hợp lệ của nó (dùng lại `GameController.select`), không vẽ riêng
  đúng một ô đích/"bóng mờ đường đi" như PLAN 10.1 mô tả đầy đủ; mốc 30s thêm một dòng chữ nhắc mạnh hơn.
- Bài kết thúc bằng ăn Vua thật (T7, T9) để `Hud` tự hiện màn kết quả chung của ván thật, không phủ thêm bảng
  "hoàn thành" riêng của tân thủ — chỉ định tuyến lại hai nút của màn đó.

### Chưa làm (ngoài phạm vi được giao cho phần client của M8 lần này)

- Mở khoá ghép trận online sau khi hoàn thành T1–T11 + nút "Tôi đã biết chơi" (PLAN 10.1) — chưa đụng tới.
- "3 người mới thử xong tutorial không cần hỏi" (PLAN mục 15) chỉ kiểm chứng được bằng người dùng thật.

## M9 — Bot nâng cao và cân bằng: **code xong, một chỉ tiêu số liệu CHƯA đạt** (xem `docs/questions.md` Q-37/Q-38)

Nghiệm thu theo PLAN mục 15: "Đạt các chỉ tiêu mục 9.3, công bằng ghế 16,7% ± 3%".

| Tiêu chí | Kết quả | Ghi chú |
|---|---|---|
| Bot Khó: top-K=8 + mô phỏng thật phản đòn 5 đối thủ (`packages/bot/src/hard.ts`) | Đạt (đúng thuật toán, tất định, không gian lận — có test) | `hard.test.ts` |
| 1 Khó vs 5 Thường thắng ≥ 30% (PLAN 9.3) | **CHƯA đạt**: 16,0% thật (4/25 ván) | `docs/bot.md` mục M9; xem Q-37 |
| 6 Khó công bằng ghế 16,7% ± 3% (PLAN 9.5) | Đo ở cỡ mẫu nhỏ (10 ván, sai số chuẩn ≈ 9%) — chưa đủ để kết luận đạt hay không | `docs/bot.md`; xem Q-38 |
| 3 tính cách (Hung hăng/Thủ thế/Cơ hội), hành vi đo được khác nhau (PLAN 9.4) | Đạt, có test đo được sự khác biệt trên thế cờ dựng tay | `personality.test.ts` |
| `'balanced'` không đổi hành vi Dễ/Thường trước M9 | Đạt (bit-for-bit) | `personality.test.ts` |
| Chỉnh preset Tiêu chuẩn/Nhanh bằng dữ liệu mô phỏng thật (PLAN 9, X-09) | `applyPreset` đã có từ M6.1; **chưa chỉnh lại `roundScale`** bằng số liệu M9 (chưa đủ dữ liệu, xem Q-38) |  |
| Client: chọn độ khó Khó + tính cách ở màn bắt đầu (solo) và phòng riêng/online | Đạt (`menu.ts`, `lobby.ts`) — vá thêm khoá i18n còn thiếu và tham số `personality` còn sót ở `startSolo` (phát hiện bằng `pnpm typecheck` thật) | `packages/client` |
| Bot thỉnh thoảng gửi câu chat có sẵn (PLAN 9.4) | Cố tình hoãn ở M9 (không nằm trong nội dung M9 ở PLAN mục 15) — **làm sau M10, xem mục "Bổ sung sau M10 — Bot chat" bên dưới** |  |

**Số liệu lần chạy cuối:** lint sạch · typecheck 7 package (đã sửa 3 lỗi kiểu thật ở `main.ts`, thiếu tham số
`personality` cho `startSolo`) · **586 test / toàn bộ package qua** (rules 300, bot 33, tutorial 21, protocol 27,
server 26, client 179) · `verify_board.py` 30/30 PASS · e2e Playwright (solo, hotseat, menu/settings, tutorial — 11
kịch bản) chạy thật bằng trình duyệt, đều qua, bao gồm một ván solo trọn 1196 hành động tới hiệp 337 không lỗi engine.

### Việc đáng chú ý: phát hiện và sửa một lỗi cộng dồn hai lần rủi ro ở bot Khó

Đấu thử thật (không phải đọc code) lộ ra bot Khó ban đầu chỉ thắng ngang mức ngẫu nhiên dù thuật toán "khó hơn"
Thường về lý thuyết — truy ra `chooseHardMove` phạt cùng một rủi ro HAI LẦN (một lần qua ước lượng chiết khấu của
`scoreMove`, một lần qua mô phỏng thật ở bước 2), khiến Khó né cả những cú đổi ngang giá hợp lý, chơi thụ động hơn
cả Thường. Đã sửa (cộng lại phần ước lượng trước khi trừ số thật) — sau khi sửa, ván toàn bot Khó nhanh hẳn (trung
vị hiệp giảm từ hơn 380 xuống 90), nhưng tỉ lệ thắng 1-chọi-5 với Thường CHƯA đo được cải thiện rõ (vẫn ~16%, xem
`docs/bot.md`). Chi tiết đầy đủ + bài học ở `docs/decisions.md` mục "Bot Khó, tính cách và cân bằng — M9".

### Hạ tầng mới: chạy đấu thử hàng loạt theo nhiều đợt nhỏ rồi gộp lại

PLAN 9.5 muốn 1000 ván/mục nhưng một ván tốn tới hàng chục giây thật trên bàn 1801 ô — 1000 ván một lần vượt quá
thời gian một lệnh trong phiên tương tác. Thêm `ARENA_SEED_OFFSET`/`ARENA_ONLY`/`ARENA_RAW_OUT` vào
`packages/bot/test/winrate.arena.ts` và `tools/arena_combine.py` để chạy nhiều đợt (offset khác nhau ⇒ ván khác
nhau, vẫn tất định) rồi cộng thẳng số ván/số thắng thật thành một báo cáo — đã dùng để lấy 25 và 10 ván thật ở trên;
còn cách xa 1000 ván/mục PLAN 9.5 muốn (việc còn lại, xem Q-38).

### Chưa làm

- Chỉnh Khó/preset tới khi đạt chỉ tiêu PLAN 9.3 (Q-37).
- Đấu thử đủ ~1000 ván/mục cho sai số chuẩn ≈ 1,2% như PLAN 9.5 muốn (Q-38).
- Bot chat câu có sẵn (PLAN 9.4) — cố tình hoãn ở M9, **đã làm sau M10** (xem mục dưới).
- 1000 ván không giao diện đo "không lỗi engine, mọi ván kết thúc trước hiệp giới hạn" (PLAN 9.5, ý đầu) — mới chạy
  vài chục ván có `validate: true` trong test CI (`hard.test.ts`), chưa chạy 1000 ván validate đầy đủ.

## M10 — Đồ hoạ và âm thanh: **phần code xong**, phần "cần máy/tài nguyên thật" chưa làm được trong sandbox

Nghiệm thu theo PLAN mục 15 ("Video/ảnh chụp đạt chuẩn trang cửa hàng; số đo hiệu năng ghi vào `docs/perf.md`.
**Đăng trang Coming Soon**") tách thành hai phần: phần **code** (giao cho phiên này) và phần cần máy GPU thật/tài
sản thật/thủ tục Steam (ngoài phạm vi một sandbox không GPU, không tài khoản Steam — xem `docs/questions.md`).

| Tiêu chí | Kết quả | Ghi chú |
|---|---|---|
| Hiệu ứng thu hẹp "rung → nứt → rơi kèm bụi" (PLAN 12.2/12.4) | Đạt — `core/collapse-fx.ts` (toán thuần, test) + `board-mesh.ts` (áp lên ô thật) + bụi qua `EffectsLayer.spawnCollapseDust` | `collapse-fx.test.ts` |
| 6 biểu tượng hình học trên đế quân, không phụ thuộc màu (PLAN 12.3/11.5) | Đạt | `badge.test.ts`, `badge-geometry.test.ts` |
| Hiệu ứng còn lại của bảng PLAN 12.4 (`impact`/`kingHit` đã có từ M3 nhưng CHƯA từng được vẽ; `dissolve`/`promote`/`beam` mới) | Đạt — `AnimationDirector.effects()` nay có nơi tiêu thụ thật (`EffectsLayer`), rung nhẹ camera khi ăn Vua | `animation.test.ts`, `scene/effects-layer.ts` (không test đơn vị riêng — thuần THREE, xem chú thích tại chỗ) |
| 3 mức đồ hoạ THẬT (không chỉ đổi `pixelRatio` như M5) — bóng đổ, hậu kỳ, mật độ hạt, phản xạ (PLAN 12.5) | Đạt — `core/graphics-quality.ts` (bảng thuần) + `EffectComposer`/`SSAOPass`/`UnrealBloomPass` thật ở `main.ts` | `graphics-quality.test.ts`; số đo thật ở `docs/perf.md` mục M10 |
| Nhạc nền theo pha + SFX tổng hợp Web Audio (PLAN 12.6) | Đạt về mặt code (tổng hợp bằng mã, không file ngoài) — **CHƯA phải nhạc/SFX thật do người sáng tác**, xem Q-39 | `audio-cues.test.ts`; khai báo placeholder ở `docs/credits.md` |
| Đo hiệu năng ghi vào `docs/perf.md` | Đạt một phần — đo được ở mức mặc định (Vừa) dưới SwiftShader; **chưa đo được mức Thấp/Cao và chưa đo trên GPU thật** | `docs/perf.md` mục M10, Q-40 |
| Video/ảnh chụp đạt chuẩn trang cửa hàng Steam | **Chưa làm** — cần độ phân giải/khung hình chuẩn Steamworks và render trên GPU thật (SwiftShader không đại diện), ngoài phạm vi sandbox này | `docs/questions.md` |
| Đăng trang Coming Soon | **Chưa làm** — cần tài khoản Steamworks đã đăng ký + trả phí (PLAN 13.1, việc của bạn từ M0, xem "Việc còn lại") | |

**Số liệu lần chạy cuối:** lint sạch · typecheck 7 package · **621 test / toàn bộ package qua** (rules 300, bot 33,
tutorial 21, protocol 27, server 26, client 214 — client tăng 35 test so với M9: `badge`, `badge-geometry`,
`collapse-fx`, `graphics-quality`, `audio-cues`, thêm 3 loại `Effect` mới ở `animation.test.ts`) · `verify_board.py`
30/30 PASS · **toàn bộ 9 file e2e Playwright (hotseat, solo, menu-settings, screenshots, perf, tutorial, voice,
online) chạy thật bằng trình duyệt, đều qua** sau khi sửa các vấn đề dưới đây.

### Việc đáng chú ý: chạy lại toàn bộ e2e thật lộ ra một lỗi treo thật + ba chỗ ngưỡng thời gian đã lỗi thời

Mức đồ hoạ mặc định đổi sang "Vừa" (bóng mềm + bloom, PLAN 12.5) làm vòng lặp vẽ chậm hẳn dưới renderer phần mềm
(SwiftShader, không GPU thật) của sandbox này — không phải lỗi logic, nhưng lộ ra một lỗi treo thật (đổi ngôn ngữ
ở mức Cao có thể khiến trang không phản hồi giữa lúc điều hướng, đã **sửa thật** bằng cách dừng vòng lặp vẽ trước
khi tải lại trang) và làm ba bài kiểm cũ hết hạn thời gian chờ dù hành vi vẫn đúng: `perf.spec.ts`'s ngưỡng "còn
sống" (>5 FPS, đo thật nay ~3,2), `screenshots.spec.ts`/`menu-settings.spec.ts`'s bài liên quan tới mức đồ hoạ Cao,
và `voice.spec.ts`'s hạn chờ mesh WebRTC khi nhiều tab cùng vẽ hậu kỳ tranh CPU. Đã sửa CẢ HAI phía: một lỗi treo
thật (code), và các ngưỡng/hạn chờ đã lỗi thời (test) — mỗi chỗ có chú thích tại chỗ giải thích vì sao, không hạ
mức đồ hoạ mặc định hay tắt hậu kỳ chỉ để test qua (CLAUDE.md "không sửa test để cho qua nếu test sai — phải giải
thích và sửa có lý do"; ở đây MỘT PHẦN test đúng là môi trường/ngưỡng lỗi thời, phần còn lại là code thật có lỗi).
Chi tiết đầy đủ cho từng chỗ sửa ở `docs/decisions.md` mục M10.

### Hạ tầng mới

- `core/graphics-quality.ts`, `core/collapse-fx.ts`, `core/badge.ts`, `core/audio-cues.ts`: 4 bảng tra cứu/toán
  THUẦN mới (không THREE/DOM), theo đúng khuôn `core/` đã lập từ M3 — test được bằng Node.
- `scene/badge-scene.ts`, `scene/badge-geometry.ts`, `scene/effects-layer.ts`: 3 lớp THREE thật mới, dựng sẵn dung
  lượng tối đa (không tạo/xoá đối tượng mỗi khung hình, PLAN 6.6).
- `net/audio-manager.ts`: lớp mỏng chạm `AudioContext` thật, cùng ranh giới core/net với `voice-manager.ts`.
- Cài đặt (`net/settings-store.ts`) thêm `volumeMaster`/`volumeMusic`/`volumeSfx`; `app/settings-panel.ts` thêm 3
  thanh trượt âm lượng.

### Chưa làm

- Nhạc/SFX thật do người sáng tác thay cho placeholder tổng hợp bằng mã (Q-39) — cần trước khi phát hành.
- Đo FPS/draw call/bộ nhớ GPU trên máy có GPU thật, cả 3 mức đồ hoạ (Q-40) — số liệu hiện tại chỉ từ SwiftShader.
- `PieceModelRegistry`/mô hình glTF thật (Q-41) — PLAN tự nói đây là việc CHỈ làm khi có họa sĩ, không phải thiếu sót.
- Video/ảnh chụp đạt chuẩn trang cửa hàng Steam + đăng trang Coming Soon (PLAN 13.1) — cần tài khoản Steamworks
  thật + máy có GPU thật, ngoài phạm vi sandbox này.

## Bổ sung sau M10 — Bot chat (hoàn thành mục hoãn của PLAN 9.4)

Mục "Bot thỉnh thoảng gửi câu chat có sẵn phù hợp" (PLAN 9.4) bị hoãn có chủ đích ở M9 (không nằm trong nội dung
M9 theo PLAN mục 15, xem `docs/decisions.md`). Bạn yêu cầu làm sau khi M10 xong, kèm thêm ý cụ thể: bot không cần
mạnh hơn để "đấu trí" (bàn 6 người đã đủ hỗn loạn), nhưng đôi khi phải chủ động nhắn cho người chơi, **kể cả thao
túng tâm lý** (không chỉ chat xã giao), miễn nước đi vẫn logic (không cần đổi gì ở thuật toán chọn nước — cố tình
không đụng `choose.ts`/`evaluate.ts`/`hard.ts`).

| Tiêu chí | Kết quả | Ghi chú |
|---|---|---|
| Bot tự quyết định có chat hay không sau mỗi nước đi, tất định theo seed (X-11/X-10) | Đạt — `packages/bot/src/chat.ts` `decideBotChat`, RNG riêng `botChatRngFor` (không đụng dòng ngẫu nhiên chọn nước của `botRngFor`) | `packages/bot/test/chat.test.ts` (20 test) |
| Có kịch bản **thao túng tâm lý** thật, không chỉ câu xã giao | Đạt — 2 kịch bản: (1) vừa ăn quân → đôi khi nhắn RIÊNG trấn an giả nạn nhân (`diplomacy.noHarmIntended`) thay vì trêu công khai, để họ chủ quan/chậm trả đũa; (2) Vua mình bị đe doạ hoặc chủ động theo xác suất nền → kích động cả bàn đánh người ĐANG DẪN ĐẦU THẬT (`rankPlayers`, R-82), đổ hướng chú ý khỏi mình | như trên |
| Có kịch bản chat không thao túng (thiện chí/xã giao) để không phải lúc nào cũng "nham hiểm" | Đạt — trêu chọc khi hạ được Vua đối thủ, cảnh báo thu hẹp mức đỏ, chào hỏi đầu ván | như trên |
| Tính cách (PLAN 9.4) ảnh hưởng tần suất từng kịch bản, không chỉ một bảng số chung | Đạt — `chatRatesFor(personality)`, cùng khuôn nhân hệ số với `weightsFor` (`personality.ts`): Hung hăng trêu chọc/kích động nhiều hơn, ít nhượng bộ; Thủ thế thiên trấn an giả hơn là đối đầu; Cơ hội thích "đổ vấy" | `chat.test.ts` |
| `@hexwar/bot` vẫn KHÔNG phụ thuộc `@hexwar/protocol` (nguyên tắc từ M9) | Đạt — `BotPhraseId` là một tập con **chép lại** các giá trị `PhraseId` thật, đúng mẫu đã dùng cho `Personality` | so sánh thấy ở `packages/server/test/bot-chat.test.ts` |
| Nối vào đúng pipeline `phraseId`/`chat.send` đã có từ M7, không sửa `GameSession`/`@hexwar/protocol` | Đạt — chỉ thêm ở `packages/server/src/room.ts` (`maybeSendBotChat`, gọi từ `broadcastGame` mỗi khi có `game.events` của MỘT NƯỚC ĐI thật của ghế bot), dùng lại đúng `randomUUID`/cấu trúc `ChatMessage`/định tuyến đích theo kênh đã có ở `handleChatSend` | |
| Test tích hợp qua WebSocket thật (không mock) | Đạt — 1 người thật tự đầu hàng ngay (X-05) để 5 bot chơi ở "chế độ khán giả" (`spectatorBotDelayMs`, `FAST_TIMING` = 0), chờ thấy MỘT câu chat thật từ ghế bot; seed ván online là ngẫu nhiên thật (`Room.start`) nên test không khẳng định đúng câu nào, chỉ khẳng định có xảy ra + đúng dạng + đúng nguồn ghế bot | `packages/server/test/bot-chat.test.ts` — chạy lặp lại nhiều lần khi viết để xác nhận không chập chờn (xác suất cả 5 bot cùng im lặng nhiều lượt liên tiếp gần như bằng 0, xem chú thích trong `chat.ts`) |
| Cross-check `BotPhraseId ⊆ PhraseId` thật | Đạt — sống ở `@hexwar/server` (gói DUY NHẤT phụ thuộc cả hai gói), không phải ở `@hexwar/bot` | `bot-chat.test.ts` |

**Số liệu lần chạy cuối:** lint sạch · typecheck 7 package · **642 test / toàn bộ package qua** (rules 300, bot 52,
tutorial 21, protocol 27, server 28, client 214 — tăng từ M10: bot +19 [33→52], server +2 [26→28]) ·
`verify_board.py` 30/30 PASS.

### Một quyết định thiết kế đáng chú ý: không dùng `TURN_STARTED` để dò "lượt đầu tiên của chính bot"

Bản nháp đầu của kịch bản "chào hỏi đầu ván" dò sự kiện `TURN_STARTED` của chính ghế bot trong đúng đợt sự kiện
của nước đi đó. Đọc lại `packages/rules/src/turn.ts` (`settleTurn` → `advanceTurn` → `beginTurn`) mới thấy
`TURN_STARTED` của một lượt luôn được phát ra SAU KHI người đi trước đã đi xong, nằm trong đợt sự kiện của
NGƯỜI ĐI TRƯỚC — nghĩa là kịch bản này gần như không bao giờ khớp `seat === chính bot đang xét` trong thực tế (chỉ
khớp ở tình huống suy biến: một mình bot đó còn sống). Phát hiện bằng cách LẦN THEO đúng luồng phát sự kiện thật
trong `turn.ts` (không phải chỉ đọc lại comment của chính mình), không phải bằng test thất bại — vì bài test đơn vị
ban đầu tự dựng mảng `events` giả nên "khớp" một cách nhân tạo, che mất lỗi cho tới khi đối chiếu với dòng xử lý
thật. Sửa bằng cách đổi điều kiện sang `state.round <= 1` (kiểm tra ngay trên trạng thái SAU nước đi, không cần
lần tìm sự kiện) — bỏ lỡ đúng một ghế (ghế kết thúc hiệp 1 thấy `round` đã sang 2), chấp nhận được vì đây chỉ là
câu chào cho vui, không mang ý nghĩa chiến thuật. Bài học: một sự kiện tên "TURN_STARTED" gắn với `seat` không tự
động có nghĩa "lượt của `seat` VỪA bắt đầu ngay bây giờ" — phải đọc đúng thứ tự phát sự kiện thật (mục 4.10 PLAN)
trước khi dùng nó làm điều kiện, kể cả khi tên sự kiện nghe rất trực quan.

## Việc còn lại (việc của bạn, không chặn milestone kế tiếp)

1. **Xem `docs/questions.md`**, nhất là Q-02 và Q-18, và xác nhận hoặc đổi các giả định Q-07 … Q-17 và Q-19 (mỗi mục nêu rõ chỗ sửa).
2. Chạy spike Steam + Electron (`docs/spike-steam-electron.md`) và điền kết luận.
3. Đăng ký Steamworks và trả phí (thời gian chờ dài, nên làm sớm, PLAN 13.1).
4. Chép `PLAN.md` vào thư mục gốc của repo (bản đóng gói không kèm PLAN.md vì bạn đã có bản gốc).
5. Đẩy lên GitHub để CI chạy lần đầu. Chưa có commit nào được tạo.
6. **Chơi thử một ván solo** (`pnpm --filter @hexwar/client dev`, mở http://localhost:5173) và cho ý kiến về độ khó bot / độ dài ván; xác nhận Q-22 … Q-25 trong `docs/questions.md`.
7. **Đo FPS thật trên máy có GPU** theo hướng dẫn ở `docs/perf.md` (mục "Việc còn lại") — số đo SwiftShader
   hiện tại không thay thế được việc này.
8. **Thử thật 2 máy qua internet** (PLAN 6.6/7): chạy `@hexwar/server` trên một máy/VPS có địa chỉ mạng tới được,
   nối từ máy thứ hai qua `?server=ws://<ip>:<port>` (hoặc `wss://` sau proxy TLS) — sandbox này không có 2 máy
   thật để tự làm phần này.
9. **Triển khai TURN server thật** (coturn, PLAN 7.7) và cấp thông tin đăng nhập ngắn hạn theo phiên cho voice —
   xem `docs/questions.md` Q-31. Không có việc này thì "Chỉ đi qua TURN" chỉ khiến voice không kết nối được.
10. **Tự biên soạn danh sách từ cấm đầy đủ hơn** (`packages/protocol/src/profanity.ts` hiện chỉ có 9 từ minh hoạ) và
    quyết định có bật thêm `ISteamUtils::FilterText` của Steamworks không (lúc làm M11) — xem Q-28.
11. Xác nhận hoặc chỉnh lại 3 hằng số ngưỡng hạn chế chat do báo cáo (3 người / 24 giờ / 15 phút,
    `packages/server/src/room.ts`) bằng dữ liệu người chơi thật — xem Q-29.

## Chạy lại

```bash
pnpm install
pnpm check          # lint + typecheck + test + verify_board.py
pnpm golden:gen     # chỉ khi tools/verify_board.py thay đổi
python3 tools/mutate.py [tiền_tố_id…]   # kiểm thử đột biến (~10 phút toàn bộ); mã thoát 1 nếu có đột biến sống sót thật

# M3: chơi thử ván hotseat thật trong trình duyệt
pnpm --filter @hexwar/client dev            # mở http://localhost:5173 (thêm ?seed=1 để tái lập)

# M3: bộ test Playwright thật (renderer + engine thật, không giả lập) — ảnh chụp ra
# packages/client/test-results/screenshots/, số FPS in ra console (xem docs/perf.md)
cd packages/client && npx playwright test

# M6: chạy server online thật (mặc định cổng 8080, đổi bằng biến môi trường PORT)
pnpm --filter @hexwar/server start
# rồi mở client trỏ tới server đó (mặc định client tự nối tới cùng host, cổng 8080; đổi bằng ?server=ws://<host>:<port>)
```
