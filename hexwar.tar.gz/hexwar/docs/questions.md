# Câu hỏi mở

Theo `CLAUDE.md`: chỗ nào PLAN.md mơ hồ hoặc thiếu thì làm theo mặc định ở mục 2, ghi vào đây và hỏi.
Mỗi câu ghi **cách đã làm** để bạn xác nhận hoặc đổi.

## Cần bạn quyết định

### Q-02 — Nước đi đầu 2 ô của Tốt (R-22, `pawn.doubleStep`)
PLAN chỉ nói "không có, có thể bật" mà không định nghĩa khi bật. Vì Tốt được **lùi**, khái niệm "chưa di chuyển / hàng xuất phát" mơ hồ, và chưa rõ có được nhảy qua quân chắn không.
- **Đã làm:** `rules.config.json` chỉ chấp nhận `pawn.doubleStep = false`; đặt `true` sẽ bị từ chối với thông báo rõ ràng. Muốn bật thì cần bạn định nghĩa luật.

### Q-18 — Hằng số xúc xắc chưa nằm trong `rules.config.json`
R-02 cố định 3 xúc xắc 6 mặt, nhưng `CLAUDE.md` yêu cầu mọi con số luật ở file cấu hình, còn Phụ lục C của PLAN không có mục cho xúc xắc.
- **Đã làm:** hằng số nằm trong `dice.ts` (3 xúc xắc, 6 mặt, tối đa 1000 lần tung lại khi hoà, chỉ là ngưỡng chặn lỗi RNG). Đổi số xúc xắc/mặt là đổi luật nên nếu bạn muốn chỉnh được thì thêm mục `dice` vào cấu hình (việc nhỏ, có thể làm cùng M9 khi làm preset).

## Đã chọn mặc định — chỉ cần xác nhận

### Q-01 — Tù binh: khi quân giữ tù binh di chuyển, tù binh có đi theo không? (R-31, R-32, R-33) — **không còn chặn**
Câu hỏi gốc ở M1 là chặn M2. Khi hiện thực thì thấy nó **không quan sát được**: R-33 loại mọi tù binh của A ngay **cuối chính lượt đó** (dù dùng hay không, dù đang ở đâu), và không ai đi xen giữa nước đi của A và cuối lượt. Nên "ở lại ô cũ" hay "đi theo quân giữ" cho ra cùng một trạng thái ổn định.
- **Đã làm:** tù binh ở nguyên ô. Bất biến `validateState` (kiểm sau mọi nước đi ở các test mô phỏng): ở trạng thái ổn định, mọi tù binh nằm chung ô với một quân **hoạt động** của người giữ, và người giữ còn sống. Mọi cách để bất biến này bị phá (người giữ bị ăn, bị loại, ô bị thu hẹp) đều có xử lý và test riêng (R-34, R-35, R-70).
- Chỉ cần bạn xác nhận nếu sau này muốn đổi R-33 (ví dụ tù binh sống thêm một lượt); khi đó câu hỏi này mở lại.

### Q-03 — `GameState.opener` và `turnSeat` là `null` trước khi tung xúc xắc
PLAN 6.5 khai báo kiểu `Seat`, nhưng trước khi tung xúc xắc (R-02) chưa có người đi đầu. Đặt giá trị giả (ví dụ ghế 0) dễ gây lỗi ngầm, nên dùng `Seat | null`.
- **Cập nhật ở M2:** `order` **không** còn rỗng trước xúc xắc mà là `[0,1,2,3,4,5]` (đủ 6 ghế, để `checkMove`/`legalMoves` và giao diện có danh sách ghế ngay). `rollDice` xoay `order` để bắt đầu từ người thắng (R-03) và đặt `opener`, `turnSeat`, `phase = 'playing'`. Test `board.test.ts` đã cập nhật theo hợp đồng mới (không nới lỏng kiểm tra).

### Q-04 — `newGame(config, seats, seed)`: tham số `seats` dùng làm gì?
PLAN liệt kê tham số này nhưng R-01 quy định luôn đúng 6 ghế. **Đã làm:** chỉ kiểm tra `seats` là hoán vị của 0..5 (sai thì ném lỗi R-01). Nếu bạn muốn `seats` mang thông tin "ghế nào là người / bot / độ khó", nên đổi thành `SeatSetup[]` ở M4 khi làm bot.

### Q-05 — Nghĩa của `reach.metric = "hops"` (D-03, phương án khác)
PLAN chỉ mô tả "đếm số bước theo đường đi của quân". **Đã làm:** mỗi bước dọc một tia (bước cạnh dài 1 ô, bước nhảy đỉnh dài 2 ô) tính là 1 bước; tầm tối đa = số bước. Ví dụ Tượng tầm 9 → 9 bước nhảy = 18 ô; Hề tầm 3 → 3 bước theo cả 12 hướng (36 ô đích trên bàn trống). Mặc định vẫn là `"distance"` (đúng PLAN). Có test cho cả hai chế độ.

### Q-06 — Vua "1 bước" theo hướng đỉnh
Theo `verify_board.py`, Vua đi đúng 1 bước theo mỗi trong 12 hướng, nên bước theo hướng đỉnh (V) dài 2 ô lưới. **Đã làm:** khớp bản Python (golden Vua = 5 nước ở thế đầu).

## Giả định mới khi làm M2 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

Mỗi mục có test riêng; đổi ý thì sửa chỗ nêu ở cột "Ở đâu".

### Q-07 — Tù binh được trưng dụng đi theo khung của **người giữ** (R-32)
PLAN nói "đi nó 1 nước theo luật loại quân của nó" nhưng Tốt có hướng "tiến" phụ thuộc ghế. **Đã làm:** quân được trưng dụng coi như quân của người giữ khi tính nước đi (`asConscripted` trong `moves.ts`), nên Tốt bị bắt sẽ "tiến về tâm" theo góc nhìn người giữ. Các quân khác đối xứng nên không khác biệt. Test: `turn.test.ts` (đột biến V02).

### Q-08 — `captive.rescueByOwner = false` (tắt X-08)
Khi tắt, quân giữ tù binh bị chủ của tù binh ăn thì không thể "giải cứu"; nhưng một người cũng không thể giữ quân của chính mình. **Đã làm:** tù binh đó **mất luôn** (`CAPTIVE_EXPIRED`); các tù binh của người thứ ba vẫn chuyển giao như R-34. Ở `captives.ts` (`handleHolderCaptives`), test trong `simulation.test.ts` (biến thể).

### Q-09 — Vua bị ăn khi ô Vua đang có tù binh (R-34 × R-51 × R-60)
PLAN chỉ nói về "quân giữ tù binh bị ăn" nói chung. **Đã làm:**
- Ăn thường, Hề cứu Vua → Vua dời sang ô Hề, tù binh ở lại ô cũ với người ăn: xử lý đúng R-34 (chuyển giao cho người ăn; tù binh của chính người ăn được giải cứu).
- Ăn thường, không Hề cứu → người đó bị loại, tù binh họ giữ được giải phóng (R-35, R-60).
- **Ăn bằng trưng dụng** (Vua bị tù binh ăn), Hề cứu → không chuyển giao/giải cứu; mọi tù binh của Vua được **thả tại chỗ** với lý do `holder_lost`, vì quân ăn (tù binh) sẽ bị loại cuối lượt nên không thể là "người giữ mới".
Test: `captives.test.ts` (nhóm "R-34 + R-51"), đã kiểm chứng bằng đột biến C09.

### Q-10 — Tù binh trưng dụng ăn quân đang giữ tù binh
R-32 nói quân bị tù binh ăn "bị loại ngay". **Đã làm:** các tù binh mà quân đó đang giữ được **thả tại chỗ** (`holder_lost`, ô trống gần nhất, R-36), vì người giữ đã mất. Không chuyển giao cho ai.

### Q-11 — Hiệp giới hạn cứng 450 (R-81)
**Đã làm:** ván kết thúc **ngay khi hiệp 450 bắt đầu** (sau `ROUND_STARTED`, sau thu hẹp nếu có, trước lượt của ai). Không ai đi trong hiệp 450. Người thắng là người xếp hạng nhất **duy nhất**; nếu đồng hạng nhất thì `winner = null`. Cấu hình `hardCapRound` bị ràng buộc phải sau hiệp thu hẹp cuối (M1).

### Q-12 — Đồng hạng (R-82)
R-82 không nói khi đồng điểm. **Đã làm:** đồng hạng theo kiểu thi đấu (1, 1, 3): cùng trạng thái sống/chết, cùng thời điểm bị loại (batch) và cùng điểm thì chia sẻ hạng. Trường `rank` của `RankEntry` phản ánh điều đó; thứ tự hiển thị trong mảng chỉ để ổn định (theo ghế).

### Q-13 — "Tổng kill" của người chơi (R-40, R-82)
**Đã làm:** `playerKills[seat]` tăng 1 cho mỗi quân địch bị ăn bởi nước đi của seat đó, gồm: nước ăn thường, ăn bằng tù binh trưng dụng (chỉ tính cho người chơi, không cho quân nào, R-40), ăn Vua (kể cả khi Hề cứu, R-51 "vẫn được tính kill") và ăn Hề. **Không** tính: quân biến mất vì thu hẹp (R-70), tù binh hết hạn, đầu hàng. Tù binh **không** được tính điểm cho người giữ (R-31).

### Q-14 — Thời điểm chụp điểm khi bị loại (R-82: "so điểm tại thời điểm đó")
**Đã làm:** điểm bị loại = điểm ngay trước khi loại (gồm cả tù binh của người đó đang bị người khác giữ, R-31). Với thu hẹp: chụp **sau khi** quân trên vòng biến mất đã bị xoá và **trước khi** loại bất kỳ ai trong đợt. Với luật điểm hiện tại việc loại người này không đổi điểm người kia (test bất biến ở `score.test.ts`), nên đây chỉ là phòng thủ.

### Q-15 — Thu hẹp: "vòng biến mất" là vòng ngoài cùng **hiện tại**
**Đã làm:** mỗi lần thu hẹp loại vòng có hạng = bán kính hiện tại (24 ở lần đầu, khớp bảng 3.5), không cần cấu hình gán hạng theo hiệp. Người loại bởi thu hẹp cùng đợt dùng chung một `batch` (R-72, R-82). Hề chỉ cứu Vua khỏi thu hẹp khi bật `jester.savesFromCollapse` (D-09) **và** Hề không nằm trên vòng biến mất.

### Q-16 — Lượt tự bỏ vì không có nước đi (R-13)
**Đã làm:** phát `TURN_STARTED` rồi `TURN_SKIPPED { reason: 'no_moves' }`; lượt đó vẫn là một lượt nên tù binh tới hạn của người đó vẫn bị loại (R-33) và có thể dẫn tới hiệp mới. Vòng lặp tự bỏ lượt có chặn cứng theo hiệp giới hạn. "Có nước đi" gồm cả nước trưng dụng tù binh. Trường hợp hết giờ: `TURN_SKIPPED { reason: 'timeout' }`; "3 lượt hết giờ liên tiếp → bot" là việc của server (M6).

### Q-17 — Cờ `armed` của tù binh chỉ là `false` giữa một hành động
`armed = false` chỉ tồn tại từ lúc tù binh mới tạo/chuyển giao tới cuối lượt của người đi (4.10 bước 4); ở mọi trạng thái công khai sau `applyMove` đều là `true`. Giữ trường này (thay vì bỏ) vì PLAN 6.5 có nó và nó làm rõ vòng đời trong mã. `validateState` bắt buộc `armed` là boolean.

### Q-19 — Người mở hiệp bị loại (R-10)
**Đã làm:** người còn sống kế tiếp thành người mở hiệp; `round` không tăng thêm. Riêng khi người mở hiệp **tự đầu hàng ở lượt của mình**, lượt kế vẫn thuộc hiệp hiện tại (những người sau còn chưa đi), hiệp mới chỉ bắt đầu khi thứ tự quay về người mở hiệp **mới**. Test: `turn.test.ts` (nhóm "R-10 + R-61"), đã kiểm chứng bằng đột biến T05/T10.

## Giả định mới khi làm M3 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-20 — Phím `M` dùng cho "bật/tắt nhìn từ trên xuống", không phải "bản đồ nhỏ" như PLAN 11.3 — **đã quyết ở M5**
PLAN 11.3 gán `M` cho bật/tắt **bản đồ nhỏ** (mục 11.2, "Dưới trái"). Ở M3 bản đồ nhỏ chưa tồn tại nên `M` được dùng tạm cho "nhìn từ trên xuống" (PLAN 11.4, cũng chưa có phím gán sẵn); câu hỏi để ngỏ tới khi làm bản đồ nhỏ thật ở M5.
- **Đã quyết ở M5:** **giữ `M` = nhìn từ trên xuống**, không đổi. Bản đồ nhỏ (`app/minimap.ts`) làm **luôn hiện** trong lúc chơi (góc dưới-trái, PLAN 11.2) thay vì bật/tắt bằng phím — không có trạng thái "tắt" nên không cần phím riêng cho nó. Lý do: nhìn-từ-trên-xuống là thao tác camera dùng thường xuyên (bàn 1801 ô rất khó định hướng), còn bản đồ nhỏ nhỏ gọn (148×148px, góc màn hình) và trong suốt nên không chiếm chỗ đáng kể để phải ẩn đi lúc không cần. Muốn tạm giấu vẫn bấm được: bấm ra ngoài bản đồ để chơi tiếp, không có gì bị che.
- Toàn bộ phím vẫn gán lại được (PLAN 11.3) nên đây không phải giới hạn kỹ thuật — chỉ cần bạn muốn đổi lại thành bật/tắt bằng phím thì sửa `packages/client/src/app/minimap.ts` (thêm trạng thái ẩn/hiện) + `app/input.ts` (thêm case phím) + `app/main.ts` (nối `Minimap.setVisible`).
- `Space` xác nhận (X-14) và `Esc` huỷ chờ **đã hiện thực ở M5** (`app/input.ts`). Còn lại của PLAN 11.3 (`Tab` quân kế, `T` chat nhanh, `V` nói) **chưa làm**: `Tab` cần danh sách quân riêng chưa có UI, để M10 (đồ hoạ hoàn thiện) cùng lúc làm UI camera đầy đủ; chat/voice thuộc M7.

### Q-21 — Ngôn ngữ mặc định khi vào ván (M3 chưa có bộ chọn ngôn ngữ trong ứng dụng)
PLAN 11.5 xếp "Ngôn ngữ: Tiếng Việt, English" vào màn Cài đặt, thuộc M5. M3 chỉ cần "đọc sự kiện engine" nên chưa có UI đổi ngôn ngữ.
- **Đã làm:** `main.ts` gọi cứng `translatorFor('vi')`. Toàn bộ chữ vẫn đi qua khoá i18n (không chữ cứng, đúng `CLAUDE.md`) nên đổi ngôn ngữ ở M5 chỉ cần đọc cấu hình lưu và gọi `translatorFor(locale)` thay vì hằng số `'vi'` — không cần sửa bất kỳ chỗ nào khác.

## Giả định mới khi làm M4 — chỉ cần xác nhận

### Q-22 — Ván solo cũng tính giờ 60 giây mỗi lượt và bot lái tạm sau 3 lần hết giờ (R-12, X-04)
PLAN không nói rõ ván solo có tạm dừng/không giới hạn giờ hay không. **Đã làm:** đúng luật R-12 như ván online (60 giây + thời gian hoạt ảnh, PLAN 7.4); 3 lượt hết giờ liên tiếp thì bot Thường lái tạm ghế người chơi, bấm đi một nước là lấy lại quyền. "Lưu & thoát" giữa chừng rồi vào lại thì đồng hồ lượt bắt đầu lại đủ 60 giây. Nếu bạn muốn ván solo có nút tạm dừng hoặc tắt đồng hồ, đó là một tuỳ chọn nhỏ ở session (`timing.turnClock`) — cần bạn quyết để thêm vào màn cài đặt (M5).

### Q-23 — Ghế của người chơi trong ván solo
R-01: "Ghế do server gán ngẫu nhiên". **Đã làm:** ghế = `seed mod 6` (ngẫu nhiên theo seed ván, tái lập được); camera tự xoay để ghế mình ở đáy màn hình (PLAN 3.3). Ở `net/seats.ts`.

### Q-24 — Độ khó "Trộn" ở màn bắt đầu
PLAN 7.2 cho chủ phòng chọn độ khó **từng** bot; màn bắt đầu tối thiểu của M4 chỉ có 3 lựa chọn: Dễ (5 bot Dễ), Thường (5 bot Thường), Trộn (xen kẽ Dễ/Thường, mặc định). Chọn từng ghế là việc của màn phòng chờ (M5/M6).

### Q-25 — Ván rất dài với bot
Đấu thử hàng loạt (docs/bot.md) cho thấy nhiều ván bot kéo tới gần hiệp giới hạn 450 (đúng cảnh báo ở PLAN mục 2). Không đổi luật; ghi nhận để M9 (cân bằng, preset Tiêu chuẩn/Nhanh X-09) xử lý. Nếu bạn muốn M4 đã có preset ngắn hơn cho solo, cần làm `applyPreset` (hiện hoãn tới M9, xem mục M2).

## Giả định mới khi làm M6 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-26 — Danh khách online (guest) so với Steam, và khôi phục phiên qua tải lại trang
PLAN 7.1 nói "chế độ khách chỉ dành cho bản dev", nghĩa là Steam (M11) sẽ là đường xác thực thật; M6 chỉ có khách. Cũng theo đó, PLAN không nói online có cần khôi phục ván đang chơi sau khi **tải lại trang** (F5)/đóng-mở trình duyệt hay không.
- **Đã làm:** danh tính khách được cấp bằng `randomUUID()` (tên ngẫu nhiên kiểu `Khách123`), server nhớ token này để cho **nối lại trong cùng phiên** (mất mạng ngắn, tab vẫn còn) qua đúng cơ chế `reconnectGraceSeconds` (mục M6 ở `docs/decisions.md`). Token **không** lưu `localStorage`, nên tải lại trang luôn tạo danh tính khách mới — không tự vào lại ván đang chơi được, coi như rời phòng khi hết hạn ân hạn.
- Cần bạn xác nhận: có muốn M7 (hoặc sớm hơn) thêm lưu token vào `localStorage` để tải lại trang vẫn vào lại được ván, hay để dành việc này cho lúc làm Steam/danh tính bền vững thật ở M11 (khi đó "khôi phục phiên" có thể gắn liền với đăng nhập Steam luôn, làm 1 lần).

### Q-27 — Phòng riêng không tự lấp bot theo hẹn giờ như phòng ghép nhanh
PLAN 7.2 nói tới việc bot lấp chỗ trống nói chung nhưng không phân biệt rõ giữa ghép nhanh và phòng riêng (tạo bằng mã, chơi với bạn bè).
- **Đã làm:** chỉ **ghép nhanh** (`quickMatch: true`) tự lấp bot bằng hẹn giờ (`botFillDelayMs`, mặc định 20 giây) khi có người đầu tiên vào. **Phòng riêng** (`quickMatch: false`) không tự lấp gì cả — chủ phòng phải bấm "+ Thêm bot" cho từng ghế trống, vì mục đích phòng riêng thường là chờ đúng bạn bè vào, tự lấp bot theo giờ có thể "cướp" ghế trước khi bạn bè kịp vào.
- Cần bạn xác nhận nếu muốn đổi (ví dụ phòng riêng cũng tự lấp sau một hẹn giờ dài hơn, hoặc thêm nút "lấp hết bằng bot" cho chủ phòng bấm 1 lần thay vì bấm từng ghế) — sửa ở `packages/server/src/room.ts` (`armBotFillTimer`) và `app/lobby.ts`.

## Giả định mới khi làm M7 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-28 — Danh sách từ cấm (PLAN 8.4 "lọc từ cấm bằng danh sách nội bộ theo ngôn ngữ")
PLAN không cho danh sách từ cấm thật, chỉ nói "danh sách nội bộ theo ngôn ngữ" và gợi ý cân nhắc thêm bộ lọc của Steamworks (`ISteamUtils::FilterText`) khi triển khai — việc đó chỉ làm được thật sau khi tích hợp Steam (M11).
- **Đã làm:** `packages/protocol/src/profanity.ts` (`censorText`) chỉ là **khung minh hoạ cơ chế**: 5 từ tiếng Việt + 4 từ tiếng Anh thật đủ để có test và để hàm không trống rỗng, thay từ khớp bằng dấu `*` cùng độ dài, không phân biệt hoa/thường. Chạy ở **client** khi hiển thị theo tuỳ chọn cá nhân "ẩn từ tục" (PLAN 8.4) — không phải một chốt chặn an ninh ở server (chat không có gian lận thắng/thua để chặn cứng, xem `docs/decisions.md` M7).
- Việc của bạn trước khi phát hành: tự biên soạn danh sách từ cấm đầy đủ hơn (nhiều biến thể viết tắt/không dấu tiếng Việt hay bị né lọc), và quyết định có bật `ISteamUtils::FilterText` của Steamworks song song hay không (đọc tài liệu Steamworks lúc làm M11, đúng gợi ý PLAN 8.4). Muốn chặn cứng ở server (không cho bypass bằng cách tự sửa client) chỉ cần gọi `censorText` thêm một dòng trong `Room.handleChatMessage` trước khi phát tin đi — không phải viết lại gì.

### Q-29 — Ngưỡng "bị báo cáo nhiều lần trong ngày" (PLAN 8.4)
PLAN chỉ nói "người bị báo cáo nhiều lần trong ngày bị hạn chế chat tạm thời (ngưỡng chỉnh được)", không cho số cụ thể.
- **Đã làm:** `CHAT_REPORT_THRESHOLD = 3` báo cáo (từ **3 người khác nhau** — một người báo cáo nhiều lần không cộng dồn, xem `Room.handleChatMessage`) trong cửa sổ `CHAT_REPORT_WINDOW_MS = 24 giờ` thì bị `chatRestrictedUntil` = giờ hiện tại + `CHAT_RESTRICTION_MS = 15 phút` (chặn `chat.send`, mã lỗi `RESTRICTED`; không chặn chơi cờ). Cả ba hằng số nằm ở đầu `packages/server/src/room.ts`, chỉnh trực tiếp tại đó — đúng như PLAN gọi là "ngưỡng chỉnh được", chưa cần đưa ra UI/cấu hình vì chưa có dữ liệu thật để biết ngưỡng hợp lý.
- Cần bạn xác nhận hoặc chỉnh lại 3 con số này khi có dữ liệu người chơi thật (báo cáo giả/vu khống có thể cần ngưỡng cao hơn hoặc thời gian phạt dài hơn).

### Q-30 — Mute/chặn/hội thoại riêng chỉ tồn tại trong một phòng, không nhớ qua ván sau
PLAN không nói rõ các thiết lập cá nhân (tắt tiếng ai đó, chặn ai đó, tab hội thoại riêng đang mở) có cần nhớ giữa các ván/phòng khác nhau hay không.
- **Đã làm:** `ChatPanel.hide()` (gọi khi rời ván online, `main.ts`) xoá sạch `mutedSeats`/`blockedSeats`/`listenMutedSeats`/mọi tab hội thoại — vào phòng mới luôn bắt đầu "sạch", không mang định kiến từ phòng cũ sang (ghế 2 ở phòng này có thể là người hoàn toàn khác ghế 2 ở phòng trước). Cùng logic áp dụng cho `VoiceManager.dispose()` (chặn/âm lượng/tắt-nghe từng người, PLAN 8.5).
- Cần bạn xác nhận nếu muốn "chặn" bền vững hơn (ví dụ chặn theo danh tính thay vì theo ghế, nhớ qua nhiều phòng) — cần danh tính bền vững thật (Steam, M11) để "chặn" có ý nghĩa lâu dài; với danh khách (Q-26) mỗi phiên đổi danh tính nên chặn theo phiên là lựa chọn hợp lý nhất hiện có.

### Q-31 — TURN server thật (PLAN 7.7, 8.5 "chỉ đi qua TURN")
PLAN yêu cầu server TURN (coturn) làm hạ tầng dự phòng cho voice mesh và tuỳ chọn ẩn IP, nhưng đây là việc triển khai server thật (domain, chứng chỉ, thông tin đăng nhập ngắn hạn cấp theo phiên) — không làm được trong sandbox này.
- **Đã làm:** `VoiceManager` (`packages/client/src/net/voice-manager.ts`) nhận `iceServers` qua constructor (`DEFAULT_ICE_SERVERS` hiện chỉ có STUN công khai của Google) và tự đặt `iceTransportPolicy: 'relay'` cho mọi `RTCPeerConnection` mới khi bật "Chỉ đi qua TURN" — có test Playwright thật xác nhận cấu hình này áp đúng (`e2e/voice.spec.ts`). Không kiểm được việc ẩn IP có hiệu quả thật vì chưa có TURN server nào chạy ở đây; bật "Chỉ đi qua TURN" mà không có TURN thật trong danh sách `iceServers` sẽ khiến kết nối **không bao giờ nối được** (không có STUN/host nào lọt qua bộ lọc `relay`) — đúng hành vi mong muốn về mặt an toàn (thà không nối còn hơn lộ IP), nhưng cần bạn biết trước khi bật tuỳ chọn này ở bản chưa có TURN.
- Việc của bạn: triển khai coturn thật (PLAN 7.7), cấp thông tin đăng nhập ngắn hạn theo phiên (không hardcode), rồi truyền vào `iceServers` khi dựng `VoiceManager` ở `main.ts` (hiện đang dùng `DEFAULT_ICE_SERVERS` cứng — cần đổi thành lấy từ cấu hình/roster server gửi xuống nếu muốn thông tin đăng nhập TURN đổi theo phiên).

## Giả định mới khi làm M8 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-32 — T12 dạy chat/voice bằng lời thoại, không dựng lại bằng dữ liệu giả
PLAN 10.2 (bài T12) liệt "gửi câu có sẵn; nhắn riêng cho 1 bot mẫu; bật thử voice" chung với "tung 3 xúc xắc; thứ tự kim đồng hồ" — coi cả bốn thứ như cùng một loại nội dung tương tác được trong bài học.
- **Đã làm:** phần xúc xắc/thứ tự đi dựng bằng engine thật (`rollDice`, một nước đi thật) như mọi bài khác. Phần chat/voice **chỉ là lời thoại** (`tutorial.t12.chat`, `tutorial.t12.voice`) mô tả tính năng sẽ gặp trong trận thật, không có ô nhập/nút voice giả nào hoạt động trong bài học — lý do kỹ thuật: chat/voice sống ở `@hexwar/server`/`@hexwar/client` (cần kết nối/DOM thật, M7), còn `packages/tutorial` cố tình giữ thuần (không đụng DOM/mạng) giống `packages/rules`, xem `docs/decisions.md` mục M8.
- Cần bạn xác nhận nếu muốn nâng cấp: cách hợp lý nhất là ở TẦNG CLIENT (không phải `packages/tutorial`) bật thật `ChatPanel`/`VoiceBar` ở "chế độ demo" (gửi câu có sẵn thật vào một khung chat cục bộ giả lập một bot mẫu) khi hiển thị bước này — không cần đổi gì ở gói `tutorial`.

### Q-33 — 13 bài chỉ có tiếng Việt/Anh soạn sẵn (`packages/tutorial/src/strings.ts`), chưa qua người bản ngữ duyệt
PLAN 10.1 yêu cầu "ít chữ nhiều thao tác" và i18n vi/en đầy đủ (mục 11), nhưng không có ai duyệt nội dung lời thoại thật.
- **Đã làm:** toàn bộ lời thoại 13 bài (tiêu đề + từng bước) đã viết bằng cả tiếng Việt và tiếng Anh trong `TUTORIAL_STRINGS`, đủ để client copy thẳng vào `vi.json`/`en.json` (mục `tutorial.*`) mà không phải bịa chữ. Bản tiếng Anh là dịch thẳng nghĩa (chưa qua người bản ngữ duyệt văn phong).
- Việc của bạn: đọc lại giọng văn tiếng Việt (đúng đối tượng "người mới") và, nếu phát hành tiếng Anh thật, nhờ người bản ngữ duyệt lại bản dịch trước khi lên cửa hàng.

## Giả định mới khi làm phần client của M8 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-34 — T13 ("Trận tập") không ép hạn hiệp 50 riêng, không tự đánh dấu "đã hoàn thành"
PLAN 10.2 tả T13: "1 người + 5 bot Dễ... chơi tới khi thắng hoặc tới hiệp 50".
- **Đã làm:** chọn T13 gọi thẳng `startSolo('easy')` — đúng luồng solo thật đã có từ M4 (`hardCapRound` mặc định của `rules.config.json` là 450, không phải 50 riêng cho tân thủ; xâu chuỗi một giới hạn hiệp tuỳ biến qua tận `GameSession`/`rules.config.json` chỉ cho một lối vào là việc không cân xứng với milestone này). Vì T13 chạy như một ván solo bình thường (`game.mode` đổi thành `'solo'`, không còn là `'tutorial'`), nó không có `RunnerState`/tín hiệu "đã hoàn thành" nào để `TutorialProgressStore` bắt lấy — màn danh sách bài không bao giờ đánh dấu T13 là "Đã xong", kể cả sau khi chơi và thắng thật.
- Cần bạn xác nhận: có đáng công thêm một `hardCapRound` tuỳ biến (đi qua `SessionTiming`/`GameSession`, hiện chỉ có trong `RulesConfig` — R-80 không có "hạn hiệp"/collapse tự ép thắng thua ở hiệp 50, đó là một giới hạn CHỈ RIÊNG cho ván tập) hay để nguyên dùng cấu hình solo mặc định; và nếu muốn T13 hiện "Đã xong" trong danh sách, cách rẻ nhất là đánh dấu ngay khi BẤM VÀO (trước khi chơi) — có làm không, hay chấp nhận T13 không bao giờ có dấu hoàn thành.

### Q-35 — Gợi ý 15s/30s tô sáng "quân + mọi nước đi của nó", không phải đúng một ô đích/"bóng mờ đường đi"
PLAN 10.1: "sau 15 giây không đi, làm nổi bật quân/nước gợi ý; sau 30 giây, hiện thêm bóng mờ đường đi".
- **Đã làm:** `TutorialPanel.tick()` gọi `findHintMove` (đã có sẵn từ phần lõi M8) để tìm đúng MỘT nước thoả mục tiêu, nhưng cách "làm nổi bật" tái dùng nguyên `GameController.select(pieceId)` — cơ chế tô ô hiện có (PLAN 11.2) tô TẤT CẢ nước đi hợp lệ của quân đó, không có khái niệm "chỉ tô riêng một ô đích trong số nhiều ô hợp lệ". Mốc 30 giây không vẽ đường đi (không có animation/marker riêng cho "đường đi dự kiến" trong `BoardScene` hiện tại) mà chỉ thêm một dòng thông báo chữ nhắc thẳng vào quân/ô đang sáng.
- Cần bạn xác nhận: có đáng công thêm (a) một chế độ tô ô thứ hai "chỉ đúng ô X" cho `BoardScene`/`selection-model.ts`, và (b) một hiệu ứng "bóng mờ đường đi" thật (marker/animation dọc theo các ô trung gian của nước trượt) — hay giữ nguyên đơn giản hoá này vì tân thủ chỉ có tối đa vài nước hợp lệ mỗi bước nên "tô cả quân" đã đủ rõ trong thực tế.

### Q-36 — Bài kết thúc bằng ăn Vua thật (T7, T9) không có bảng "hoàn thành" riêng của tân thủ
Xem `docs/decisions.md` mục "M8 (client)" cho lý do kỹ thuật (tránh hai lớp UI kết quả tranh nhau).
- **Đã làm:** tiến độ vẫn được ghi nhận đúng lúc (`TutorialProgressStore.markCompleted` chạy ngay khi `runner.done`, không đợi người bấm nút nào) — chỉ riêng PHẦN HIỂN THỊ dùng lại `.hud-result` chung thay vì bảng tân thủ riêng, nên chữ trên màn đó là chữ ván thường ("Ván mới"/"Về màn chính") dù bấm vào lại đưa người chơi sang bài kế tiếp/danh sách bài (đúng ý nghĩa tân thủ, chỉ khác CHỮ hiển thị).
- Cần bạn xác nhận: có đáng công đổi CHỮ hai nút đó riêng cho ngữ cảnh tân thủ (ví dụ `Hud` nhận thêm nhãn nút tuỳ biến) hay giữ nguyên vì hành vi (điều hướng) đã đúng, chỉ nhãn nút chưa khớp ngữ cảnh 100%.

## Giả định mới khi làm M9 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-37 — Bot Khó chưa đạt chỉ tiêu PLAN 9.3 (≥ 30% so với 5 Thường); có tiếp tục chỉnh ngay không?
PLAN 9.3 tự nói chỉ tiêu là "mục tiêu khởi điểm; điều chỉnh sau khi chạy mô phỏng thực" — không nói phải đạt được
trước khi milestone tiếp theo bắt đầu.
- **Đã làm:** cài đúng thuật toán PLAN 9.3 mô tả (top-K=8 + mô phỏng thật phản đòn 5 đối thủ theo thứ tự lượt), sửa
  một lỗi cộng dồn hai lần rủi ro làm Khó chơi thụ động quá mức (xem `docs/decisions.md`/`docs/bot.md` mục M9), và đo
  thật bằng đấu thử (25 ván: 16,0%, chưa đạt 30%; xem `docs/bot.md`). Không tiếp tục vòng chỉnh trọng số/thuật toán
  thêm trong phiên này — việc này có thể tốn nhiều vòng đấu thử lớn (mỗi vòng hàng chục phút thật, xem Q-38) mà
  không chắc tới đích, trong khi các phần khác của M9 (tính cách, công bằng ghế đo được ở cỡ nhỏ, client wiring) đã
  xong và không phụ thuộc con số này.
- Việc của bạn: quyết định có đáng dành thêm thời gian máy (nhiều đợt đấu thử lớn qua `tools/arena_combine.py`) để
  chỉnh Khó tới ≥30% trước khi phát hành, hay chấp nhận Khó ở mức "khó hơn Thường về chiến thuật, chưa chắc thắng
  nhiều hơn trong 1-chọi-5" và điều chỉnh lại chỉ tiêu/mô tả trong PLAN hoặc màn chọn độ khó của client.

### Q-38 — Đấu thử hàng loạt 1000 ván/mục (PLAN 9.5) chưa chạy được trong phiên này
Một ván chạy hết trên bàn 1801 ô tốn tới hàng chục giây thật (đo được: trung bình 15–30 giây/ván tuỳ cấu hình bot),
nên 1000 ván một mục (PLAN 9.5 muốn sai số chuẩn ≈ 1,2%) cần nhiều giờ chạy liền — vượt quá một lệnh trong phiên
tương tác.
- **Đã làm:** thêm `ARENA_SEED_OFFSET`/`ARENA_ONLY`/`ARENA_RAW_OUT` vào `packages/bot/test/winrate.arena.ts` và
  script `tools/arena_combine.py` để chạy nhiều đợt nhỏ (mỗi đợt vài phút, offset khác nhau ⇒ ván khác nhau) rồi
  gộp thành một báo cáo — đã dùng để lấy 25 ván (1 Khó vs 5 Thường) và 10 ván (6 Khó, công bằng ghế) thật, ghi ở
  `docs/bot.md` mục M9 kèm sai số chuẩn rõ ràng cho từng cỡ mẫu.
- Việc của bạn: chạy thêm nhiều đợt (có thể qua nhiều phiên/máy, hoặc một tiến trình nền dài hơi ngoài sandbox này)
  tới khi đủ ~1000 ván mỗi mục rồi cập nhật lại `docs/bot.md`; hoặc chấp nhận cỡ mẫu hiện tại (đã ghi rõ sai số
  chuẩn để không hiểu nhầm là kết luận chắc chắn).

## Giả định mới khi làm M10 (PLAN mơ hồ hoặc chưa nói) — chỉ cần xác nhận

### Q-39 — Âm thanh (PLAN 12.6) hiện là placeholder TỔNG HỢP BẰNG MÃ, chưa phải nhạc/SFX thật do người sáng tác
PLAN 12.6: "Chỉ dùng âm thanh do bạn tạo hoặc có giấy phép rõ ràng... Lập bảng nguồn gốc tài nguyên `docs/credits.md`
từ đầu." Sandbox này không có nhạc sĩ hay thư viện âm thanh có giấy phép để dùng.
- **Đã làm:** toàn bộ nhạc nền + hiệu ứng (`core/audio-cues.ts`, `net/audio-manager.ts`) tổng hợp bằng Web Audio
  (`OscillatorNode`/nhiễu trắng lọc), không nạp file nào — đúng nghĩa "do bạn tạo" (không vi phạm giấy phép ai),
  nhưng chất lượng chỉ ở mức đặt chỗ (placeholder), không phải sản phẩm cuối. Đã ghi chú vào `docs/credits.md`.
- Cần bạn xác nhận: có cần đặt nhạc sĩ/thư viện SFX có giấy phép (CC0 hoặc mua bản quyền) trước khi phát hành thật
  không — đây gần như chắc chắn CÓ cần (mục "Trang cửa hàng"/PLAN 13.4 đề cập khai báo nội dung, và người chơi
  thật khó chấp nhận nhạc tổng hợp thô làm sản phẩm cuối), chỉ hỏi để xác nhận mốc thời gian: làm trước Coming Soon
  (M10 gốc) hay có thể để tới gần M13 (nộp build).

### Q-40 — Đo FPS thật với hậu kỳ (bóng đổ/bloom/SSAO) trên máy có GPU thật vẫn CHƯA làm được ở M10 này
`docs/perf.md` đã ghi từ M3/M4: số đo SwiftShader (renderer phần mềm) không đại diện cho GPU thật. M10 thêm hậu kỳ
(`EffectComposer`: bóng đổ ở Vừa/Cao, bloom ở Vừa/Cao, SSAO + phản xạ ở Cao) làm khoảng cách này RÕ RỆT hơn nhiều:
đo thật dưới SwiftShader chỉ còn ~3,2 FPS ở mức Vừa (mặc định) — không phải vì hậu kỳ tốn kém trên GPU thật, mà vì
môi trường này không có tăng tốc phần cứng cho đúng loại phép toán mà SSAO/bloom cần (đọc/ghi framebuffer nhiều lần).
- **Đã làm:** xác nhận vòng lặp vẽ vẫn "sống" (không treo) ở cả 3 mức bằng `perf.spec.ts` (hạ ngưỡng sang tay theo
  số đo thật, xem `docs/decisions.md` mục M10); phát hiện và sửa một chỗ có thể treo thật (đổi ngôn ngữ ở mức Cao,
  xem cùng mục).
- Việc của bạn: đo lại theo đúng hướng dẫn ở `docs/perf.md` mục "Việc còn lại" (nay áp dụng thêm cho cả 3 mức đồ
  hoạ, không chỉ mức mặc định cũ) trên một máy có GPU thật trước khi tin số liệu này đại diện cho trải nghiệm thật.

### Q-41 — Mô hình quân vẫn dựng bằng code (procedural), chưa có mô hình glTF do họa sĩ làm
PLAN 12.3: "giai đoạn đầu dựng bằng code..., sau đó thay bằng mô hình glTF nếu có họa sĩ." `PieceModelRegistry`
(namespace, chưa dựng thật ở M10 vì chưa có mô hình nào để đăng ký) vẫn còn là việc mở, không phải lỗi.
- **Đã làm:** giữ nguyên hình dáng procedural đã có từ M3 (LatheGeometry/ExtrudeGeometry theo `piece-geometry.ts`),
  không đổi gì ở M10 vì PLAN tự nói đây là thứ tự đúng khi CHƯA có họa sĩ.
- Cần bạn xác nhận: có đáng dựng sẵn khung `PieceModelRegistry` (khoá theo loại quân, fallback procedural) NGAY Ở
  M10 dù chưa có mô hình thật để đăng ký (chuẩn bị chỗ cắm sau) — hay để dành việc này tới lúc thật sự có mô hình.
