# Spike M0: Steam + Electron

**Trạng thái: CHƯA CHẠY. Cần thực hiện trên máy Windows có Steam client.**
Tiêu chí nghiệm thu M0 (PLAN mục 15) yêu cầu "spike có kết luận bằng văn bản (đi tiếp hay chuyển Godot)". Đây là phần duy nhất của M0 chưa xong, vì không thể chạy Steam client và Electron có cửa sổ trong môi trường đám mây nơi mã này được viết.

## Việc cần kiểm chứng (PLAN 6.2, 13.2)

Dùng AppID thử nghiệm **480** (Spacewar). Steam client phải đang chạy và đã đăng nhập.

| # | Kiểm chứng | Đạt khi |
|---|---|---|
| S1 | `steamworks.js` khởi tạo được trong Electron **bản dev** | `init(480)` không lỗi; đọc được tên người chơi Steam |
| S2 | Như S1 nhưng trong **bản đóng gói** (electron-builder hoặc electron-packager) | Không lỗi thiếu module native; ghi lại cần cấu hình `asarUnpack` cho file `.node` nào |
| S3 | **Steam Overlay** hiện trong cửa sổ Electron | Bấm `Shift+Tab` mở được overlay, bạn bè và trình duyệt Steam dùng được |
| S4 | **Lobby** và mời bạn bè | Tạo lobby, mời một tài khoản Steam khác, tài khoản đó vào được |
| S5 | **Auth Session Ticket** | Lấy được vé từ client; máy chủ xác thực được qua Steam Web API (cần Web API key, không đưa vào repo) |
| S6 | Thành tích, Rich Presence, Steam Cloud | Mỗi thứ chạy được một ví dụ nhỏ (có thể để M11 nếu S1–S5 đạt) |

## Điều đã tra được từ README của `steamworks.js` (phiên bản 0.4.0 trên npm)

- Khởi tạo bằng `init(appId)`, hoặc không truyền gì và dùng file `steam_appid.txt`.
- Bật overlay trong Electron bằng cách gọi `electronEnableSteamOverlay()` ở cuối `main.js`.
- README nói rõ đây là **module native, mặc định không dùng được trong renderer process**.
- README **hướng dẫn đặt `contextIsolation: false` và `nodeIntegration: true`** cho cửa sổ để dùng được.
- README **không đề cập**: lobby, matchmaking, Steam Cloud, Auth Session Ticket, Rich Presence, giới hạn phiên bản Electron/Node, cách đóng gói asar, nền tảng hỗ trợ. Những mục này phải kiểm chứng qua kiểu TypeScript của gói hoặc thử thực tế (S2, S4, S5, S6). Chưa có bằng chứng nào cho thấy chúng hoạt động.

## Rủi ro bảo mật cần cân nhắc trong spike

Game có **chat văn bản tự do và voice** (PLAN mục 8), tức là hiển thị nội dung do người chơi khác gửi. Cấu hình mà README hướng dẫn (`nodeIntegration: true`, `contextIsolation: false`) nghĩa là nếu renderer có lỗi XSS thì kẻ xấu chạy được mã Node trên máy người chơi.

Nên thử theo thứ tự ưu tiên:
1. Giữ `nodeIntegration: false`, `contextIsolation: true`; **mọi lệnh Steam gọi ở main process** và renderer chỉ nói chuyện qua `preload` + `contextBridge` (IPC). Kiểm tra overlay (S3) có còn chạy không.
2. Nếu overlay chỉ chạy với cấu hình yếu hơn, ghi lại và cân nhắc: cách ly cửa sổ hiển thị chat, hoặc chọn phương án Godot (mục 6.4).

## Phần việc hành chính (không phải kỹ thuật, nhưng nên làm ngay từ M0)

Theo PLAN 13.1: đăng ký Steamworks, trả phí Steam Direct (100 USD mỗi ứng dụng), hoàn tất hồ sơ danh tính/thuế/ngân hàng, và xác nhận thời gian chờ trước khi phát hành trên Steamworks. Việc này cần tài khoản của bạn; mình không làm được.

## Kết luận

*(điền sau khi chạy: đi tiếp Electron / chuyển Godot, kèm kết quả S1–S6 và cấu hình `webPreferences` cuối cùng)*
