// Bản đồ đe doạ cho bot (PLAN 9.2 "An toàn Vua", 9.3 "kiểm tra phản đòn tức thì"): "quân nào ăn được quân đang
// đứng ở ô X ngay nước tới?".
//
// Tính NGƯỢC từ ô mục tiêu (nhìn ra theo 12 tia, 12 ô Mã, 12 ô Vua, 6 ô Tốt) thay vì sinh toàn bộ nước đi của 5
// đối thủ: nhanh hơn hàng chục lần, đủ để bot Thường chấm hàng trăm nước mỗi lượt trong ngân sách 1,5 giây.
// Đây là bản sao HÌNH HỌC của luật ăn quân trong packages/rules/src/moves.ts; test `attacks.test.ts` đối chiếu từng
// kết quả với `legalMoves` của engine trên hàng nghìn thế cờ mô phỏng, nên hai bên không thể lệch nhau âm thầm.
import {
  DIR,
  E_DIRS,
  KNIGHT_JUMPS,
  V_DIRS,
  add,
  cellKey,
  isOnBoard,
  rotate,
  type Cell,
  type GameState,
  type Piece,
  type PieceType,
  type RulesConfig,
  type Seat,
} from '@hexwar/rules';

/** Ô trên bàn: tối đa một quân hoạt động + các tù binh nằm chung ô (R-30). */
export interface Occupant {
  active: Piece | undefined;
  captives: Piece[];
}

export type Occupancy = Map<number, Occupant>;

export function buildOccupancy(pieces: readonly Piece[]): Occupancy {
  const map: Occupancy = new Map();
  for (const piece of pieces) {
    const key = cellKey(piece.cell);
    let occupant = map.get(key);
    if (occupant === undefined) {
      occupant = { active: undefined, captives: [] };
      map.set(key, occupant);
    }
    if (piece.status === 'active') occupant.active = piece;
    else occupant.captives.push(piece);
  }
  return map;
}

/** Một quân có thể ra đòn: quân hoạt động, hoặc tù binh đã tới hạn trưng dụng (R-32) — khi đó đánh cho người giữ. */
export interface Attacker {
  readonly piece: Piece;
  /** Người ra đòn: chủ quân, hoặc người giữ nếu là tù binh trưng dụng. */
  readonly seat: Seat;
  readonly conscript: boolean;
}

/** Các quân ở ô `at` có thể ra đòn ngay nước tới, kèm người ra đòn. */
function strikersAt(occupant: Occupant | undefined, config: RulesConfig): Attacker[] {
  if (occupant === undefined) return [];
  const out: Attacker[] = [];
  if (occupant.active !== undefined) out.push({ piece: occupant.active, seat: occupant.active.owner, conscript: false });
  if (config.captive.conscript) {
    for (const c of occupant.captives) {
      // R-32: chỉ tù binh "sẵn sàng" (armed) mới trưng dụng được ở lượt kế của người giữ.
      if (c.armed === true && c.holder !== undefined) out.push({ piece: c, seat: c.holder, conscript: true });
    }
  }
  return out;
}

/** Số bước tối đa theo một tia (D-03), khớp `maxSteps` của engine. */
function maxSteps(type: 'R' | 'B' | 'Q', kind: 'E' | 'V', config: RulesConfig): number {
  const reach = config.reach[type];
  if (config.reach.metric === 'hops') return reach;
  return Math.floor(reach / (kind === 'E' ? 1 : 2));
}

const SLIDES_ON: Record<'E' | 'V', ReadonlySet<PieceType>> = {
  E: new Set<PieceType>(['R', 'Q']),
  V: new Set<PieceType>(['B', 'Q']),
};

/** Hướng ăn chéo của Tốt ghế `seat` (khung ghế: NE, NW, SE, SW xoay theo ghế; không ăn thẳng, 4.3). */
const PAWN_CAPTURE_DIRS: readonly (readonly Cell[])[] = [0, 1, 2, 3, 4, 5].map((seat) =>
  [DIR.NE, DIR.NW, DIR.SE, DIR.SW].map((d) => rotate(d, seat)),
);

const KING_STEPS: readonly Cell[] = [...E_DIRS, ...V_DIRS];

/**
 * Mọi quân KHÔNG thuộc `victimOwner` có thể ăn một quân hoạt động của `victimOwner` nếu nó đứng ở `target`, xét trên
 * bản đồ ô `occ` và bán kính `radius`. Ô `target` coi như có quân của nạn nhân (nên không chặn chính nó).
 * `ignore` (tuỳ chọn): id quân không được tính là kẻ ra đòn (ví dụ quân vừa bị ăn trong nước đang thử).
 */
export function attackersOf(
  occ: Occupancy,
  config: RulesConfig,
  radius: number,
  target: Cell,
  victimOwner: Seat,
  ignore?: ReadonlySet<string>,
): Attacker[] {
  const out: Attacker[] = [];
  const consider = (a: Attacker, ok: boolean): void => {
    if (ok && a.seat !== victimOwner && !(ignore?.has(a.piece.id) ?? false)) out.push(a);
  };

  // Quân trượt (Xe, Tượng, Hậu; R-20): nhìn ra theo từng tia, dừng ở ô có quân đầu tiên (kể cả ô chỉ có tù binh).
  for (const [kind, dirs] of [['E', E_DIRS] as const, ['V', V_DIRS] as const]) {
    for (const dir of dirs) {
      for (let k = 1; ; k++) {
        const at = add(target, dir, k);
        if (!isOnBoard(at, radius)) break; // R-21
        const occupant = occ.get(cellKey(at));
        if (occupant === undefined) continue;
        for (const a of strikersAt(occupant, config)) {
          const type = a.piece.type;
          consider(a, SLIDES_ON[kind].has(type) && k <= maxSteps(type as 'R' | 'B' | 'Q', kind, config));
        }
        break;
      }
    }
  }

  // Mã (nhảy qua quân chắn) và Vua (1 bước theo 12 hướng): tập bước đối xứng nên chỉ cần nhìn ngược.
  for (const [type, steps] of [['N', KNIGHT_JUMPS] as const, ['K', KING_STEPS] as const]) {
    for (const step of steps) {
      const at = add(target, step, -1);
      if (!isOnBoard(at, radius)) continue;
      for (const a of strikersAt(occ.get(cellKey(at)), config)) consider(a, a.piece.type === type);
    }
  }

  // Tốt: ăn chéo theo khung ghế của NGƯỜI RA ĐÒN (tù binh trưng dụng dùng khung của người giữ, Q-07).
  for (const dir of E_DIRS) {
    const at = add(target, dir, -1);
    if (!isOnBoard(at, radius)) continue;
    for (const a of strikersAt(occ.get(cellKey(at)), config)) {
      const dirs = PAWN_CAPTURE_DIRS[a.seat] ?? [];
      consider(a, a.piece.type === 'P' && dirs.some((d) => d.q === dir.q && d.r === dir.r));
    }
  }
  return out;
}

/** Tiện ích cho test và bot: đe doạ trên một trạng thái engine hoàn chỉnh. */
export function attackersInState(state: GameState, target: Cell, victimOwner: Seat): Attacker[] {
  return attackersOf(buildOccupancy(state.pieces), state.config, state.radius, target, victimOwner);
}
