// Chat của bot (PLAN 9.4 "Bot thỉnh thoảng gửi câu chat có sẵn phù hợp", để dành từ M9 — xem docs/decisions.md
// mục M9 "Chưa làm"). Yêu cầu (làm sau M10, theo đề nghị của bạn): bot KHÔNG cần mạnh hơn để "đấu trí" — bàn 6
// người đã đủ hỗn loạn — nhưng đôi khi phải NHẮN cho người chơi, kể cả THAO TÚNG TÂM LÝ (đổ vấy, trấn an giả,
// kích động đánh người dẫn đầu), miễn là có logic đọc được từ trạng thái ván, không phải chọn ngẫu nhiên vô căn cứ.
//
// Thuần (không DOM/mạng/Date.now/Math.random — CLAUDE.md), tất định theo `rng` do người gọi cấp (giống
// `botRngFor` ở choose.ts): cùng seed + cùng trạng thái luôn ra cùng quyết định chat (X-11 phát lại, X-10 ván lưu).
//
// `@hexwar/bot` KHÔNG phụ thuộc `@hexwar/protocol` (xem bot.ts của server, "chép lại thay vì tách gói dùng
// chung"): `BotPhraseId` dưới đây là một TẬP CON các giá trị thật của `PhraseId` (packages/protocol/src/chat.ts),
// chép lại theo đúng mẫu đã có của `Personality` — server có test đối chiếu tập con này còn hợp lệ
// (packages/server/test, nơi DUY NHẤT phụ thuộc cả hai gói).
import { createRng, rankPlayers, scoreOf, type Cell, type GameEvent, type GameState, type Rng, type Seat } from '@hexwar/rules';
import { attackersInState } from './attacks';
import type { Personality } from './personality';

/**
 * Tập con câu có sẵn mà bot biết dùng (PLAN 8.3 định nghĩa đầy đủ 24 câu ở `packages/protocol/src/chat.ts`;
 * bot chỉ cần một phần nhỏ, đủ cho các kịch bản dưới). Dịch bằng đúng khoá i18n `phrase.<id>` như câu người gửi.
 */
export const BOT_PHRASE_IDS = [
  'greeting.goodLuck',
  'greeting.hello',
  'diplomacy.attackLeader',
  'diplomacy.dontAttackMe',
  'diplomacy.noHarmIntended',
  'warning.ringVanishing',
  'emote.gg',
  'emote.haha',
  'emote.tooBad',
] as const;
export type BotPhraseId = (typeof BOT_PHRASE_IDS)[number];

export type BotChatChannel = 'all' | 'whisper';

export interface BotChatDecision {
  readonly phraseId: BotPhraseId;
  readonly channel: BotChatChannel;
  /** Bắt buộc đúng khi và chỉ khi `channel === 'whisper'` (cùng quy ước với `ChatSendSchema`, packages/protocol). */
  readonly to?: Seat;
}

/** Trộn seed giống hệt `choose.ts` (chép lại có chủ đích, xem đầu file) + một hằng số riêng để dòng ngẫu nhiên
 * của chat KHÔNG trùng với dòng chọn nước đi dù cùng `(state.seed, state.round, seat, actionIndex)`. */
function mix(...parts: readonly number[]): number {
  let h = 0x9e3779b9;
  for (const part of parts) {
    h = Math.imul(h ^ (part >>> 0), 0x85ebca6b);
    h ^= h >>> 13;
    h = Math.imul(h, 0xc2b2ae35);
    h ^= h >>> 16;
  }
  return h >>> 0;
}

/** Muối riêng cho dòng ngẫu nhiên "chat" (chữ "CHAT" đọc như số, không có ý nghĩa gì khác ngoài tách dòng). */
const CHAT_RNG_SALT = 0x43_48_41_54;

/** RNG riêng cho quyết định chat của một lượt bot — độc lập với `botRngFor` (choose.ts) để hỏi/không hỏi chat
 * không ảnh hưởng tới nước đi đã chọn. */
export function botChatRngFor(state: GameState, seat: Seat, actionIndex: number): Rng {
  return createRng(mix(state.seed, state.round, seat, actionIndex, CHAT_RNG_SALT));
}

/** Xác suất mỗi kịch bản kích hoạt (0..1) — điểm khởi đầu hiệu chỉnh bằng chơi thử, không phải số "đúng tuyệt
 * đối" (cùng tinh thần `WEIGHTS`, evaluate.ts). */
export interface ChatRates {
  /** Vừa loại được Vua đối thủ (ăn hẳn, không có Hề cứu): trêu chọc công khai. */
  readonly tauntOnElimination: number;
  /** Vừa ăn một quân bất kỳ của đối thủ: có phản ứng (công khai hoặc thao túng riêng nạn nhân). */
  readonly captureReaction: number;
  /** Trong số các lần phản ứng khi ăn quân: tỉ lệ chọn NHẮN RIÊNG trấn an giả nạn nhân thay vì trêu công khai. */
  readonly deceiveVictimShare: number;
  /** Vua của mình đang bị đe doạ ngay lượt tới: có phản ứng. */
  readonly threatenedReaction: number;
  /** Trong số các lần bị đe doạ: tỉ lệ chọn KÍCH ĐỘNG đánh người dẫn đầu (đổ hướng chú ý) thay vì cầu hoà riêng
   * với kẻ mạnh nhất đang đe doạ mình. */
  readonly inciteVsPlead: number;
  /** Mỗi lượt (không cần bị đe doạ): xác suất nền chủ động kích động cả bàn đánh người dẫn đầu. */
  readonly inciteLeaderAmbient: number;
  /** Vừa có cảnh báo đỏ một vòng sắp biến mất: xác suất báo công khai (tỏ ra thiện chí, xây thiện cảm). */
  readonly collapseHeadsUp: number;
  /** Lượt đầu tiên của ván: xác suất chào hỏi. */
  readonly openingGreeting: number;
}

const BASE_RATES: ChatRates = {
  tauntOnElimination: 0.5,
  captureReaction: 0.3,
  deceiveVictimShare: 0.4,
  threatenedReaction: 0.25,
  inciteVsPlead: 0.5,
  inciteLeaderAmbient: 0.04,
  collapseHeadsUp: 0.15,
  openingGreeting: 0.6,
};

/**
 * Hệ số nhân lên `BASE_RATES` theo tính cách (PLAN 9.4, cùng mẫu `MULTIPLIERS` của personality.ts): Hung hăng
 * trêu chọc/kích động nhiều hơn và ít nhượng bộ hơn khi bị đe doạ; Thủ thế thiên về trấn an giả (né đối đầu) và
 * hiếm khi chủ động kích động; Cơ hội thích "đổ vấy" (kích động + trấn an giả) hơn là công khai đối đầu.
 */
const RATE_MULTIPLIERS: Record<Personality, Partial<Record<keyof ChatRates, number>>> = {
  balanced: {},
  aggressive: { tauntOnElimination: 1.3, captureReaction: 1.3, deceiveVictimShare: 0.6, threatenedReaction: 0.8, inciteVsPlead: 1.6, inciteLeaderAmbient: 1.8 },
  defensive: { tauntOnElimination: 0.6, captureReaction: 0.7, deceiveVictimShare: 1.4, threatenedReaction: 1.4, inciteVsPlead: 0.5, inciteLeaderAmbient: 0.3 },
  opportunist: { tauntOnElimination: 0.8, captureReaction: 1.1, deceiveVictimShare: 1.5, inciteVsPlead: 1.3, inciteLeaderAmbient: 1.5 },
};

function clamp01(x: number): number {
  return Math.max(0, Math.min(1, x));
}

/** `BASE_RATES` đã nhân hệ số của tính cách, kẹp lại trong [0, 1] (nhân dồn nhiều bước có thể vượt 1). */
export function chatRatesFor(personality: Personality): ChatRates {
  const mult = RATE_MULTIPLIERS[personality];
  const out = {} as Record<string, number>;
  for (const key of Object.keys(BASE_RATES) as (keyof ChatRates)[]) {
    out[key] = clamp01(BASE_RATES[key] * (mult[key] ?? 1));
  }
  return out as unknown as ChatRates;
}

function findEvent<T extends GameEvent['type']>(events: readonly GameEvent[], type: T, extra: (e: Extract<GameEvent, { type: T }>) => boolean = () => true): Extract<GameEvent, { type: T }> | undefined {
  return events.find((e): e is Extract<GameEvent, { type: T }> => e.type === type && extra(e as Extract<GameEvent, { type: T }>));
}

function kingCellOf(state: GameState, seat: Seat): Cell | undefined {
  for (const p of state.pieces) {
    if (p.owner === seat && p.status === 'active' && p.type === 'K') return p.cell;
  }
  return undefined;
}

/** Người dẫn đầu (hạng 1, còn sống) KHÁC `seat`, nếu có — dùng bảng xếp hạng thật của luật (R-82), không phải
 * ước lượng riêng của bot, để "kích động đánh người dẫn đầu" luôn trỏ đúng người đang thật sự dẫn đầu. */
function leaderSeatOtherThan(state: GameState, seat: Seat): Seat | undefined {
  const top = rankPlayers(state).find((r) => r.rank === 1 && r.alive && r.seat !== seat);
  return top?.seat;
}

/** PLAN 9.4: vừa ăn hẳn Vua đối thủ (không phải chỉ ăn tới Hề cứu) → trêu chọc công khai. */
function tauntOnElimination(events: readonly GameEvent[], seat: Seat, rates: ChatRates, rng: Rng): BotChatDecision | null {
  const won = events.some((e) => e.type === 'KING_CAPTURED' && e.by === seat);
  if (!won || rng.next() >= rates.tauntOnElimination) return null;
  return { phraseId: rng.next() < 0.5 ? 'emote.gg' : 'emote.haha', channel: 'all' };
}

/**
 * PLAN 9.4 "thao túng tâm lý": vừa ăn một quân của đối thủ. Thay vì luôn trêu công khai, đôi khi NHẮN RIÊNG
 * cho chính nạn nhân một câu trấn an giả ("không có ý gây hại đâu") — làm họ chủ quan, chậm trả đũa hoặc dồn
 * giận sang ghế khác thay vì mình.
 */
function captureReaction(events: readonly GameEvent[], seat: Seat, rates: ChatRates, rng: Rng): BotChatDecision | null {
  const capture = findEvent(events, 'CAPTURED', (e) => e.seat === seat && e.victimOwner !== seat);
  if (capture === undefined || rng.next() >= rates.captureReaction) return null;
  if (rng.next() < rates.deceiveVictimShare) {
    return { phraseId: 'diplomacy.noHarmIntended', channel: 'whisper', to: capture.victimOwner };
  }
  return { phraseId: rng.next() < 0.5 ? 'emote.haha' : 'emote.tooBad', channel: 'all' };
}

/**
 * PLAN 9.4 "thao túng tâm lý": Vua của mình đang bị đe doạ ăn ngay lượt tới. Thay vì chỉ lo tự vệ bằng nước đi,
 * đôi khi bot còn CHỦ ĐỘNG kích động cả bàn quay sang đánh người đang dẫn đầu (đổ hướng chú ý khỏi mình) — hoặc,
 * nếu không có ai rõ ràng đang dẫn đầu để đổ vấy, nhắn riêng cầu hoà với đúng kẻ mạnh nhất trong số đang đe doạ.
 */
function threatenedDeflect(state: GameState, seat: Seat, rates: ChatRates, rng: Rng): BotChatDecision | null {
  const king = kingCellOf(state, seat);
  if (king === undefined) return null;
  const attackers = attackersInState(state, king, seat);
  if (attackers.length === 0 || rng.next() >= rates.threatenedReaction) return null;
  const leader = leaderSeatOtherThan(state, seat);
  if (leader !== undefined && rng.next() < rates.inciteVsPlead) {
    return { phraseId: 'diplomacy.attackLeader', channel: 'all' };
  }
  const strongest = attackers.reduce((best, a) => (scoreOf(state, a.seat) > scoreOf(state, best.seat) ? a : best));
  return { phraseId: 'diplomacy.dontAttackMe', channel: 'whisper', to: strongest.seat };
}

/** PLAN 9.4: không cần bị đe doạ để kích động — mỗi lượt có một xác suất nền nhỏ chủ động lái dư luận đánh
 * người dẫn đầu (đúng nghĩa thao túng chủ động, không chỉ phòng vệ). */
function inciteLeaderAmbient(state: GameState, seat: Seat, rates: ChatRates, rng: Rng): BotChatDecision | null {
  if (rng.next() >= rates.inciteLeaderAmbient) return null;
  const leader = leaderSeatOtherThan(state, seat);
  if (leader === undefined) return null;
  return { phraseId: 'diplomacy.attackLeader', channel: 'all' };
}

/** Không thao túng — thiện chí thật: cảnh báo công khai khi một vòng sắp biến mất ở mức đỏ (thông tin ai cũng
 * suy ra được từ HUD, nhưng nói ra vẫn xây được thiện cảm/liên minh nhất thời). */
function collapseHeadsUp(events: readonly GameEvent[], rates: ChatRates, rng: Rng): BotChatDecision | null {
  const warn = findEvent(events, 'RING_WARNING', (e) => e.level === 'red');
  if (warn === undefined || rng.next() >= rates.collapseHeadsUp) return null;
  return { phraseId: 'warning.ringVanishing', channel: 'all' };
}

/**
 * Còn ở hiệp 1: chào hỏi, không mang tính chiến thuật gì — chỉ cho bàn cờ có sinh khí hơn. Không dùng
 * `TURN_STARTED` để dò "đúng lượt đầu tiên của mình": sự kiện đó của LƯỢT KẾ TIẾP (bất kỳ ghế nào) luôn nằm
 * trong đợt sự kiện của lượt mình VỪA ĐI XONG, không phải của chính lượt mình (`turn.ts`: `beginTurn` phát
 * `TURN_STARTED` từ `advanceTurn`, gọi SAU khi `settleTurn` xử lý xong lượt của mình) — nên chỉ cần kiểm
 * `state.round` (SAU khi đi) còn là 1 là đủ; bỏ lỡ đúng một ghế (ghế kết thúc hiệp 1, thấy round đã sang 2) là
 * chấp nhận được vì đây chỉ là câu chào cho vui.
 */
function openingGreeting(state: GameState, rates: ChatRates, rng: Rng): BotChatDecision | null {
  if (state.round > 1 || rng.next() >= rates.openingGreeting) return null;
  return { phraseId: rng.next() < 0.5 ? 'greeting.goodLuck' : 'greeting.hello', channel: 'all' };
}

/**
 * Quyết định bot có nhắn gì sau một lượt của `seat` hay không (PLAN 9.4). `events` là các sự kiện engine phát ra
 * TỪ CHÍNH lượt vừa xử lý (bao gồm cả `ROUND_STARTED`/`TURN_STARTED`/`RING_WARNING` đi kèm nếu có). Không có giới
 * hạn tốc độ riêng ở đây: trả về NHIỀU NHẤT một quyết định mỗi lần gọi, và nơi gọi (packages/server) chỉ gọi đúng
 * một lần sau mỗi nước đi thật của một ghế bot — tự nhiên đã giãn cách bằng đúng nhịp lượt chơi, không cần thêm
 * `CHAT_RATE_LIMIT` (giới hạn đó là cho NGƯỜI gõ tay, PLAN 8.4).
 *
 * Tất định theo `rng`: gọi từng kịch bản theo một THỨ TỰ CỐ ĐỊNH (không phụ thuộc kết quả gọi trước ngoài việc
 * dừng ở kịch bản đầu tiên khớp), nên cùng trạng thái + cùng dòng `rng` luôn ra cùng quyết định (X-11, X-10).
 * Trả về kịch bản ĐẦU TIÊN khớp theo thứ tự ưu tiên: loại được Vua > vừa ăn quân > đang bị đe doạ > kích động chủ
 * động > cảnh báo thu hẹp > chào đầu ván.
 */
export function decideBotChat(state: GameState, seat: Seat, events: readonly GameEvent[], personality: Personality, rng: Rng): BotChatDecision | null {
  const rates = chatRatesFor(personality);
  return (
    tauntOnElimination(events, seat, rates, rng) ??
    captureReaction(events, seat, rates, rng) ??
    threatenedDeflect(state, seat, rates, rng) ??
    inciteLeaderAmbient(state, seat, rates, rng) ??
    collapseHeadsUp(events, rates, rng) ??
    openingGreeting(state, rates, rng)
  );
}
