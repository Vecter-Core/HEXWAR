// Chọn nước đi theo độ khó (PLAN 9.3): Dễ + Thường từ M4, Khó (`hard.ts`) từ M9.
// Tất định: mọi yếu tố ngẫu nhiên lấy từ `rng` do người gọi cấp (thường tạo từ seed ván + hiệp + ghế, xem
// `botRngFor`), nên replay (X-11) và ván lưu (X-10) cho ra đúng cùng nước đi.
import { cellKey, createRng, legalMoves, type GameState, type Move, type Rng, type Seat } from '@hexwar/rules';
import { buildContext, scoreMove, total, type ScoreOptions } from './evaluate';
import { chooseHardMove } from './hard';
import { targetStrategyFor, weightsFor, type Personality } from './personality';

export type Difficulty = 'easy' | 'normal' | 'hard';

export const DIFFICULTIES: readonly Difficulty[] = ['easy', 'normal', 'hard'];

interface Profile {
  /** Xác suất "nhìn thấy" nước ăn quân trong lượt này (PLAN 9.3 Dễ: ~60%). */
  readonly captureSight: number;
  /** Biên độ nhiễu cộng vào điểm từng nước (PLAN 9.3 Dễ: "chấm điểm 1 nước + nhiễu ngẫu nhiên"). */
  readonly noise: number;
  readonly fullDanger: boolean;
  readonly pressure: boolean;
}

const PROFILES: Record<'easy' | 'normal', Profile> = {
  // Dễ: chấm 1 nước + nhiễu lớn; ăn quân miễn phí khoảng 60% số lượt; vẫn tránh để Vua bị ăn ngay và vẫn tránh thu hẹp.
  easy: { captureSight: 0.6, noise: 1.2, fullDanger: false, pressure: false },
  // Thường: tham lam 1 nước theo bảng điểm + kiểm tra phản đòn tức thì của từng đối thủ; nhiễu nhỏ chỉ để phá hoà.
  normal: { captureSight: 1, noise: 0.05, fullDanger: true, pressure: true },
};

/** Trộn các số nguyên thành một seed 32-bit (không dùng cho bảo mật; chỉ để tách dòng ngẫu nhiên theo lượt). */
function mix(...parts: readonly number[]): number {
  let h = 0x9e3779b9;
  for (const part of parts) {
    h = Math.imul(h ^ (part >>> 0), 0x85ebca6b);
    h ^= h >>> 13;
    h = Math.imul(h, 0xc2b2ae35);
    h ^= h >>> 16;
  }
  return h >>> 0;
}

/**
 * RNG riêng cho một quyết định của bot: phụ thuộc seed ván, hiệp, ghế và số hành động đã xảy ra, nên hai lượt khác
 * nhau không dùng chung dãy số, còn cùng một lượt thì luôn cho cùng kết quả (PLAN 9.1: tất định theo seed).
 */
export function botRngFor(state: GameState, seat: Seat, actionIndex: number): Rng {
  return createRng(mix(state.seed, state.round, seat, actionIndex));
}

export interface Decision {
  readonly move: Move;
  readonly score: number;
  /** Số nước đã chấm (để đo hiệu năng, PLAN 9.1 ngân sách 1,5 giây). */
  readonly considered: number;
}

/**
 * Nước đi bot chọn cho `seat` ở trạng thái hiện tại, hoặc null nếu không có nước nào (R-13 — engine sẽ tự bỏ lượt).
 * Không kiểm tra "tới lượt ai": người gọi (GameSession) chỉ hỏi khi đúng lượt của bot.
 *
 * `personality` (PLAN 9.4, M9) chỉ có ý nghĩa với Thường/Khó; mặc định `'balanced'` = hành vi hiện có, không đổi
 * (nhân mọi trọng số với 1), nên mọi lời gọi cũ không truyền `personality` cho kết quả giống hệt trước M9.
 */
export function chooseMove(state: GameState, seat: Seat, difficulty: Difficulty, rng: Rng, personality: Personality = 'balanced'): Decision | null {
  if (difficulty === 'hard') return chooseHardMove(state, seat, rng, personality);
  const moves = legalMoves(state, seat);
  if (moves.length === 0) return null;
  const profile = PROFILES[difficulty];
  const options: ScoreOptions = {
    seesCaptures: rng.next() < profile.captureSight,
    fullDanger: profile.fullDanger,
    pressure: profile.pressure,
  };
  const ctx = buildContext(state, seat, { weights: weightsFor(personality), targetStrategy: targetStrategyFor(personality) });
  // Bot "không nhìn thấy" nước ăn trong lượt này (Dễ, PLAN 9.3 ~60%): bỏ qua hẳn các nước ăn nếu còn nước khác,
  // thay vì chỉ không cộng điểm ăn (khi đó nước ăn vẫn hay thắng nhờ điểm vị trí và tỉ lệ thực tế lệch khỏi ~60%).
  const occ = ctx.occ;
  const isCapture = (m: Move): boolean => {
    const target = occ.get(cellKey(m.to))?.active;
    return target !== undefined && target.owner !== seat;
  };
  const quiet = options.seesCaptures ? moves : moves.filter((m) => !isCapture(m));
  const pool = quiet.length > 0 ? quiet : moves;
  let best: Move | undefined;
  let bestScore = Number.NEGATIVE_INFINITY;
  for (const move of pool) {
    const score = total(scoreMove(ctx, move, options)) + rng.next() * profile.noise;
    if (score > bestScore) {
      bestScore = score;
      best = move;
    }
  }
  return best === undefined ? null : { move: best, score: bestScore, considered: moves.length };
}
