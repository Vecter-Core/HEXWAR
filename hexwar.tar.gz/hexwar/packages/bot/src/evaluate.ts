// Chấm điểm một nước đi cho bot (PLAN 9.2). Chấm 1 nước (không tìm kiếm sâu): mỗi thành phần trả về một con số
// theo "đơn vị quân Tốt" để cộng được với nhau. Các trọng số nằm ở `WEIGHTS` — là hằng số của BOT, không phải luật,
// nên không nằm trong rules.config.json (luật chỉ đọc từ `state.config`, ví dụ giá trị quân R-82, tầm hồi sinh R-51).
import {
  E_DIRS,
  V_DIRS,
  add,
  cellKey,
  isOnBoard,
  dist,
  legalMovesOfPiece,
  ring,
  upcomingCollapses,
  type Cell,
  type GameState,
  type Move,
  type Piece,
  type PieceType,
  type Seat,
  type UpcomingCollapse,
} from '@hexwar/rules';
import { attackersOf, buildOccupancy, type Occupancy, type Occupant } from './attacks';

/**
 * Bộ trọng số theo đúng hình dạng của `WEIGHTS`, nhưng cho phép giá trị bất kỳ (không `as const`) — dùng để mỗi
 * tính cách (PLAN 9.4, `personality.ts`) truyền vào một bản đã nhân hệ số, không tách riêng logic `scoreMove`.
 */
export type BotWeights = { readonly [K in keyof typeof WEIGHTS]: number };

/** Cách chọn Vua đối thủ để "săn" (PLAN 9.2 "Mục tiêu"): gần nhất (mặc định) hoặc yếu nhất (PLAN 9.4 "Cơ hội"). */
export type TargetStrategy = 'nearest' | 'weakest';

/** Trọng số của bot (không phải luật). Đổi ở đây khi cân bằng (M9). */
export const WEIGHTS = {
  /** Mất Vua mà không có Hề cứu = bị loại cả đội (R-60). */
  kingLoss: 200,
  /** Vua bị ăn nhưng Hề cứu (R-51): mất Hề và mất thế. */
  kingLossSaved: 6,
  /** Loại hẳn một đối thủ bằng cách ăn Vua (R-60). */
  eliminate: 60,
  /** Ăn Vua nhưng Hề của họ cứu (R-51): họ mất Hề. */
  kingHitSaved: 4,
  /** Hề đáng giá hơn giá trị điểm (R-82 J=2) vì giữ được Vua (R-51). */
  jesterGuard: 3,
  /** Tỉ lệ thiệt hại dự kiến khi quân đứng ở ô bị đe doạ (đối thủ chưa chắc chọn đòn đó). */
  threatFactor: 0.9,
  /** Thưởng đe doạ quân địch có giá trị ở nước sau. */
  pressure: 0.25,
  /** Thưởng tiến 1 hạng vào gần tâm (PLAN 9.2 "kiểm soát vùng giữa"; cũng tránh thu hẹp về lâu dài). */
  center: 0.06,
  /** Phạt khi Hề cách Vua quá tầm hồi sinh (R-51). */
  jesterFar: 1.5,
  /** Khi Vua sắp bị thu hẹp: thưởng mỗi ô "lối thoát vào trong" quanh Vua được dọn trống (tỉ lệ trên nguy cơ). */
  kingEscape: 0.3,
  /** Thưởng mỗi ô tiến gần Vua của đối thủ mục tiêu (PLAN 9.2 "Mục tiêu": đối thủ gần nhất). */
  hunt: 0.15,
} as const;

/** Mức khẩn cấp của thu hẹp theo số hiệp còn lại trước khi vòng biến mất (PLAN 9.2 "Thu hẹp", R-71). */
function collapseUrgency(roundsLeft: number): number {
  if (roundsLeft <= 1) return 1; // thu hẹp ở đầu hiệp sau: nước này là cơ hội cuối
  if (roundsLeft === 2) return 0.6;
  if (roundsLeft <= 4) return 0.3;
  if (roundsLeft <= 8) return 0.12;
  if (roundsLeft <= 16) return 0.04;
  return 0;
}

/** Bối cảnh tính một lần cho mỗi lượt của bot, dùng chung cho mọi nước thử. */
export interface EvalContext {
  readonly state: GameState;
  readonly seat: Seat;
  /** Trọng số dùng để chấm nước này (mặc định `WEIGHTS`; tính cách M9 truyền bản đã nhân hệ số, `personality.ts`). */
  readonly weights: BotWeights;
  readonly occ: Occupancy;
  readonly upcoming: readonly UpcomingCollapse[];
  /** Ghế nào đang có Hề đủ gần để hồi sinh Vua nếu Vua bị ăn (R-51). */
  readonly jesterSaves: ReadonlySet<Seat>;
  readonly byId: ReadonlyMap<string, Piece>;
  /** Vua của đối thủ mục tiêu, theo `TargetStrategy` (mặc định gần nhất; PLAN 9.4 "Cơ hội": yếu nhất). */
  readonly targetKing: Cell | undefined;
}

function kingAndJester(state: GameState, seat: Seat): { king?: Piece; jester?: Piece } {
  let king: Piece | undefined;
  let jester: Piece | undefined;
  for (const p of state.pieces) {
    if (p.owner !== seat || p.status !== 'active') continue;
    if (p.type === 'K') king = p;
    else if (p.type === 'J') jester = p;
  }
  return { king, jester };
}

function nearestEnemyKing(state: GameState, seat: Seat): Cell | undefined {
  const mine = kingAndJester(state, seat).king;
  const from = mine?.cell ?? { q: 0, r: 0 };
  let best: Cell | undefined;
  let bestDist = Number.POSITIVE_INFINITY;
  for (const p of state.pieces) {
    if (p.type !== 'K' || p.status !== 'active' || p.owner === seat) continue;
    const d = dist(from, p.cell);
    if (d < bestDist) {
      bestDist = d;
      best = p.cell;
    }
  }
  return best;
}

/** Tổng giá trị quân đang hoạt động của `seat` (R-82, không tính kill) — dùng để đo "ai đang yếu nhất". */
function totalMaterial(state: GameState, seat: Seat): number {
  let sum = 0;
  for (const p of state.pieces) {
    if (p.owner === seat && p.status === 'active') sum += state.config.score[p.type];
  }
  return sum;
}

/** PLAN 9.4 "Cơ hội": Vua của đối thủ còn sống có tổng vật chất THẤP NHẤT (chờ người khác đánh nhau rồi nhặt). */
function weakestEnemyKing(state: GameState, seat: Seat): Cell | undefined {
  let best: Cell | undefined;
  let bestMaterial = Number.POSITIVE_INFINITY;
  for (const p of state.pieces) {
    if (p.type !== 'K' || p.status !== 'active' || p.owner === seat) continue;
    const material = totalMaterial(state, p.owner);
    if (material < bestMaterial) {
      bestMaterial = material;
      best = p.cell;
    }
  }
  return best;
}

export interface BuildContextOptions {
  /** Mặc định `WEIGHTS` (PLAN 9.4: mỗi tính cách truyền một bản đã nhân hệ số, xem `personality.ts`). */
  readonly weights?: BotWeights;
  /** Mặc định 'nearest' (PLAN 9.2). */
  readonly targetStrategy?: TargetStrategy;
}

export function buildContext(state: GameState, seat: Seat, options: BuildContextOptions = {}): EvalContext {
  const jesterSaves = new Set<Seat>();
  for (const s of state.order) {
    const { king, jester } = kingAndJester(state, s);
    // R-51: Hề còn sống, không phải tù binh, và cách Vua ≤ tầm hồi sinh.
    if (king !== undefined && jester !== undefined && dist(king.cell, jester.cell) <= state.config.reach.jesterReviveDistance) {
      jesterSaves.add(s);
    }
  }
  const targetStrategy = options.targetStrategy ?? 'nearest';
  return {
    state,
    seat,
    weights: options.weights ?? WEIGHTS,
    targetKing: targetStrategy === 'weakest' ? weakestEnemyKing(state, seat) : nearestEnemyKing(state, seat),
    occ: buildOccupancy(state.pieces),
    upcoming: upcomingCollapses(state),
    jesterSaves,
    byId: new Map(state.pieces.map((p) => [p.id, p])),
  };
}

/** Giá trị quân (R-82) dùng làm "vật chất"; Vua tính riêng, Hề cộng thêm giá trị giữ Vua. */
export function pieceValue(ctx: EvalContext, type: PieceType): number {
  if (type === 'J') return ctx.state.config.score.J + ctx.weights.jesterGuard;
  return ctx.state.config.score[type];
}

/** Thiệt hại nếu `seat` mất quân này (Vua: bị loại hay chỉ mất Hề, R-51/R-60). */
function lossValue(ctx: EvalContext, piece: Piece, seat: Seat): number {
  if (piece.type !== 'K') return pieceValue(ctx, piece.type);
  return ctx.jesterSaves.has(seat) ? ctx.weights.kingLossSaved : ctx.weights.kingLoss;
}

/** R-70/R-71: nguy cơ quân ở ô `at` biến mất cùng vòng ngoài (0 = an toàn trong tầm nhìn của bot). */
export function collapseRisk(ctx: EvalContext, at: Cell): number {
  const r = ring(at);
  for (const { event, roundsLeft } of ctx.upcoming) {
    if (r >= event.ring) return collapseUrgency(roundsLeft) * (r - event.ring + 1);
  }
  return 0;
}

function collapseWeight(ctx: EvalContext, piece: Piece): number {
  // D-09: Vua chết vì thu hẹp thì không có Hề cứu → luôn tính như mất Vua.
  return piece.type === 'K' ? ctx.weights.kingLoss : pieceValue(ctx, piece.type);
}

/** Bản đồ ô sau nước đi: sao nông + thay đúng các ô bị chạm (không sửa bản gốc dùng chung). */
function occupancyAfter(ctx: EvalContext, mover: Piece, move: Move, victim: Piece | undefined, promoted: PieceType): Occupancy {
  const occ = new Map(ctx.occ);
  const fromKey = cellKey(mover.cell);
  const from = occ.get(fromKey) as Occupant;
  const toKey = cellKey(move.to);
  if (move.conscript === true) {
    // R-32/R-33: tù binh trưng dụng đi xong sẽ bị loại cuối lượt → không còn trên bàn khi đối thủ đi.
    occ.set(fromKey, { active: from.active, captives: from.captives.filter((c) => c.id !== mover.id) });
    const at = occ.get(toKey);
    if (at !== undefined) occ.set(toKey, { active: undefined, captives: at.captives }); // nạn nhân bị loại ngay (R-32)
    return occ;
  }
  if (from.captives.length === 0) occ.delete(fromKey);
  else occ.set(fromKey, { active: undefined, captives: from.captives });
  const moved: Piece = { ...mover, cell: move.to, type: promoted };
  const at = occ.get(toKey);
  // R-30: nạn nhân thành tù binh của mình nằm chung ô (chưa tới hạn → không ra đòn được).
  const captives = [...(at?.captives ?? []), ...(victim !== undefined ? [{ ...victim, status: 'captive' as const, holder: ctx.seat, armed: false }] : [])];
  occ.set(toKey, { active: moved, captives });
  return occ;
}

/** Loại quân sau khi ăn (R-41), để chấm điểm phong cấp và đặt đúng loại quân vào bản đồ ô. */
function promotedType(ctx: EvalContext, mover: Piece, capturing: boolean): PieceType {
  const cfg = ctx.state.config.promotion;
  if (!capturing || mover.origin !== 'P' || mover.status !== 'active') return mover.type;
  const kills = mover.kills + 1;
  const ladder: readonly [PieceType, number][] = [
    ['Q', cfg.Q],
    ['R', cfg.R],
    ['B', cfg.B],
    ['N', cfg.N],
  ];
  const rank = (t: PieceType): number => ['P', 'N', 'B', 'R', 'Q'].indexOf(t);
  for (const [type, threshold] of ladder) {
    if (kills >= threshold && rank(type) > rank(mover.type)) return type;
  }
  return mover.type;
}

function kingIdOf(ctx: EvalContext): string {
  for (const p of ctx.state.pieces) if (p.owner === ctx.seat && p.status === 'active' && p.type === 'K') return p.id;
  return '';
}

const KING_STEPS = [...E_DIRS, ...V_DIRS];

/** Số ô Vua có thể bước vào nằm ở hạng thấp hơn (gần tâm hơn) và không bị quân/tù binh nào chiếm. */
function escapeCells(occ: Occupancy, king: Cell, radius: number): number {
  const r = ring(king);
  let n = 0;
  for (const step of KING_STEPS) {
    const to = add(king, step);
    if (isOnBoard(to, radius) && ring(to) < r && !occ.has(cellKey(to))) n++;
  }
  return n;
}

export interface MoveScore {
  readonly gain: number;
  readonly danger: number;
  readonly collapse: number;
  readonly position: number;
}

export interface ScoreOptions {
  /** Có nhìn thấy lợi ích ăn quân không (bot Dễ đôi khi "bỏ lỡ", PLAN 9.3). */
  readonly seesCaptures: boolean;
  /** Xét đe doạ lên mọi quân của mình (Thường) hay chỉ Vua + quân vừa đi (Dễ). */
  readonly fullDanger: boolean;
  /** Thưởng đe doạ quân địch ở nước sau (Thường). */
  readonly pressure: boolean;
}

/** Chấm một nước đi theo góc nhìn `ctx.seat`. Điểm cao hơn = tốt hơn. */
export function scoreMove(ctx: EvalContext, move: Move, options: ScoreOptions): MoveScore {
  const { state, seat } = ctx;
  const mover = ctx.byId.get(move.pieceId);
  if (mover === undefined) throw new Error(`scoreMove: không có quân ${move.pieceId}`);
  const victim = ctx.occ.get(cellKey(move.to))?.active;
  const capturing = victim !== undefined && victim.owner !== seat;
  const conscript = move.conscript === true;

  // ---- Lợi ích trực tiếp: ăn quân, loại người chơi, phong cấp -------------------------------------------------
  let gain = 0;
  const eliminated = new Set<Seat>();
  if (capturing && options.seesCaptures) {
    if (victim.type === 'K') {
      if (ctx.jesterSaves.has(victim.owner)) gain += ctx.weights.kingHitSaved;
      else {
        gain += ctx.weights.eliminate;
        eliminated.add(victim.owner);
      }
    } else {
      gain += pieceValue(ctx, victim.type);
    }
  }
  const newType = conscript ? mover.type : promotedType(ctx, mover, capturing);
  if (options.seesCaptures && newType !== mover.type) gain += pieceValue(ctx, newType) - pieceValue(ctx, mover.type); // R-41

  // ---- Thu hẹp và vị trí: chỉ quân vừa đi thay đổi (tù binh trưng dụng sẽ bị loại cuối lượt nên không tính) ------
  let collapse = 0;
  let position = 0;
  if (!conscript) {
    const weight = collapseWeight(ctx, mover);
    collapse = weight * (collapseRisk(ctx, mover.cell) - collapseRisk(ctx, move.to));
    if (mover.type !== 'K') position += ctx.weights.center * (ring(mover.cell) - ring(move.to));
    if (mover.type !== 'K' && mover.type !== 'J' && ctx.targetKing !== undefined) {
      position += ctx.weights.hunt * (dist(mover.cell, ctx.targetKing) - dist(move.to, ctx.targetKing));
    }
    const reach = state.config.reach.jesterReviveDistance;
    if (mover.type === 'K' || mover.type === 'J') {
      const partner = state.pieces.find((p) => p.owner === seat && p.status === 'active' && p.type === (mover.type === 'K' ? 'J' : 'K'));
      if (partner !== undefined) {
        const before = dist(mover.cell, partner.cell) > reach ? 1 : 0;
        const after = dist(move.to, partner.cell) > reach ? 1 : 0;
        position += ctx.weights.jesterFar * (before - after);
      }
    }
  }

  const occAfter = occupancyAfter(ctx, mover, move, capturing ? victim : undefined, newType);

  // ---- Vua sắp bị thu hẹp mà bị quân mình vây (bot 1 nước không tự lên kế hoạch dọn đường): thưởng dọn lối -----
  const myKing = ctx.byId.get(kingIdOf(ctx)) ;
  if (myKing !== undefined && mover.id !== myKing.id) {
    const risk = collapseRisk(ctx, myKing.cell);
    if (risk > 0) {
      const before = escapeCells(ctx.occ, myKing.cell, state.radius);
      const after = escapeCells(occAfter, myKing.cell, state.radius);
      position += ctx.weights.kingLoss * risk * ctx.weights.kingEscape * (after - before);
    }
  }

  // ---- Đe doạ sau nước đi (PLAN 9.3 Thường: phản đòn tức thì của từng đối thủ, chỉ xét nước ăn) ----------------
  const ignore = new Set<string>(capturing ? [victim.id] : []);
  const guarded: { value: number; seats: Seat[] }[] = [];
  for (const p of state.pieces) {
    if (p.owner !== seat || p.status !== 'active') continue;
    const cellNow = !conscript && p.id === mover.id ? move.to : p.cell;
    if (!options.fullDanger && p.type !== 'K' && p.id !== mover.id) continue;
    const seats = attackersOf(occAfter, state.config, state.radius, cellNow, seat, ignore)
      .map((a) => a.seat)
      .filter((s) => !eliminated.has(s));
    if (seats.length === 0) continue;
    const piece = p.id === mover.id ? { ...p, type: newType } : p;
    guarded.push({ value: lossValue(ctx, piece, seat), seats });
  }
  // Mỗi đối thủ chỉ đi một nước trước lượt kế của mình: gán tham lam quân giá trị nhất cho một đối thủ chưa dùng.
  guarded.sort((a, b) => b.value - a.value);
  const used = new Set<Seat>();
  let danger = 0;
  for (const g of guarded) {
    const who = g.seats.find((s) => !used.has(s));
    if (who === undefined) continue;
    used.add(who);
    danger += g.value * ctx.weights.threatFactor;
  }

  // ---- Sức ép: quân vừa đi đe doạ quân địch giá trị nhất nào ở nước sau ---------------------------------------
  if (options.pressure && !conscript) {
    const after = state.pieces.map((p) => {
      if (p.id === mover.id) return { ...p, cell: move.to, type: newType };
      if (capturing && p.id === victim.id) return { ...p, status: 'captive' as const, holder: seat, armed: false };
      return p;
    });
    const view: GameState = { ...state, pieces: after };
    let best = 0;
    for (const m of legalMovesOfPiece(view, mover.id)) {
      const target = occAfter.get(cellKey(m.to))?.active;
      if (target === undefined || target.owner === seat || eliminated.has(target.owner)) continue;
      const value = target.type === 'K' ? (ctx.jesterSaves.has(target.owner) ? ctx.weights.kingHitSaved : ctx.weights.eliminate / 4) : pieceValue(ctx, target.type);
      best = Math.max(best, value);
    }
    position += ctx.weights.pressure * best;
  }

  return { gain, danger, collapse, position };
}

export function total(s: MoveScore): number {
  return s.gain - s.danger + s.collapse + s.position;
}
