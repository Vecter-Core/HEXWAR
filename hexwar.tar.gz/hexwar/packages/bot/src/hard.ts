// Bot Khó (PLAN 9.3, M9): top-K ứng viên theo điểm chấm 1 nước (bảng đánh giá y hệt Thường), rồi mô phỏng phản
// đòn TỐT NHẤT của tối đa 5 đối thủ theo đúng thứ tự lượt của engine THẬT (`legalMoves`/`applyMove`/`timeoutTurn`
// — không tự chế lại một bản luật ăn quân/lượt thứ hai). Xem docs/decisions.md mục M9 cho lý do chọn hình dạng
// thuật toán này và thứ tự ưu tiên phản đòn (vật chất trước, ăn Vua chỉ là phương án cuối).
import { applyMove, legalMoves, timeoutTurn, type Cell, type GameState, type Move, type Piece, type Rng, type Seat } from '@hexwar/rules';
import { buildContext, scoreMove, total, WEIGHTS, type ScoreOptions } from './evaluate';
import { targetStrategyFor, weightsFor, type Personality } from './personality';

/** PLAN 9.3 "top-K (K≈8)". */
export const HARD_TOP_K = 8;
/** Cùng biên độ với nhiễu phá hoà của bot Thường (`docs/bot.md`) — chỉ để tách các nước đồng điểm, không đổi thứ hạng rõ ràng. */
const HARD_NOISE = 0.05;
/** "mô phỏng phản ứng ... của 5 đối thủ theo thứ tự lượt" (PLAN 9.3): tối đa 5 người, ít hơn nếu bàn còn dưới 6 ghế sống. */
const HARD_MAX_REPLIES = 5;

export interface HardDecision {
  readonly move: Move;
  readonly score: number;
  readonly considered: number;
}

function activePieceAt(state: GameState, at: Cell, owner: Seat): Piece | undefined {
  return state.pieces.find((p) => p.owner === owner && p.status === 'active' && p.cell.q === at.q && p.cell.r === at.r);
}

/**
 * Nước phản đòn gây thiệt hại nhất của `opponent` nhắm vào quân của `target`, CHỈ xét ăn quân / đe doạ Vua
 * (PLAN 9.3 "chỉ xét nước ăn/đe doạ Vua"): ưu tiên ăn một quân thường (không phải Vua) có giá trị R-82 cao nhất;
 * ăn Vua (giá trị R-82 = 0, nên tự nhiên xếp cuối nếu so trực tiếp) chỉ được chọn khi KHÔNG có nước ăn quân
 * thường nào khác trong lượt đó — giữ đúng thứ tự ưu tiên đã đặc tả (xem docs/decisions.md mục M9); trong game
 * thật hai lựa chọn hiếm khi cùng tồn tại cho một đối thủ ở cùng một lượt (mỗi nước chỉ đi một quân).
 */
function bestDamagingReply(state: GameState, opponent: Seat, target: Seat): Move | undefined {
  let best: { move: Move; value: number } | undefined;
  let kingCapture: Move | undefined;
  for (const move of legalMoves(state, opponent)) {
    const victim = activePieceAt(state, move.to, target);
    if (victim === undefined) continue;
    if (victim.type === 'K') {
      kingCapture ??= move;
      continue;
    }
    const value = state.config.score[victim.type];
    if (best === undefined || value > best.value) best = { move, value };
  }
  return best?.move ?? kingCapture;
}

/**
 * Mô phỏng tối đa `HARD_MAX_REPLIES` đối thủ còn sống, MỖI NGƯỜI ĐÚNG 1 NƯỚC, theo thứ tự lượt thật của engine:
 * đi từ `afterMine.turnSeat`, dừng khi quay lại lượt của `seat` (một vòng đối thủ đã xong), ván kết thúc, hoặc
 * hết ngân sách. Không có nước ăn/đe doạ Vua nào cho đối thủ đó thì họ "không làm gì" trong mô phỏng (đúng phạm
 * vi PLAN 9.3), dùng `timeoutTurn` thật để lượt trôi đúng luật (tù binh tới hạn của họ vẫn bị loại, R-33) thay vì
 * tự chế cách "bỏ lượt" thứ hai.
 */
function simulateReplies(afterMine: GameState, seat: Seat): GameState {
  let sim = afterMine;
  const visited = new Set<Seat>();
  for (let i = 0; i < HARD_MAX_REPLIES; i++) {
    if (sim.phase !== 'playing') break;
    const opponent = sim.turnSeat;
    if (opponent === null || opponent === seat || visited.has(opponent)) break;
    visited.add(opponent);
    const reply = bestDamagingReply(sim, opponent, seat);
    sim = reply === undefined ? timeoutTurn(sim).state : applyMove(sim, reply).state;
  }
  return sim;
}

/**
 * Vật chất của `seat` mất đi từ `after` (ngay sau nước đang thử, bước 3a) tới `final` (sau khi mô phỏng phản đòn,
 * bước 3b): mỗi quân đang hoạt động ở `after` mà tới `final` đã biến mất hoặc thành tù binh (R-82 `state.config.score`),
 * cộng thêm `WEIGHTS.kingLoss` nếu `seat` bị loại hẳn trong mô phỏng (R-60, không được Hề cứu).
 */
function materialLost(after: GameState, final: GameState, seat: Seat): number {
  let lost = 0;
  for (const p of after.pieces) {
    if (p.owner !== seat || p.status !== 'active') continue;
    const now = final.pieces.find((q) => q.id === p.id);
    if (now === undefined || now.status !== 'active') lost += after.config.score[p.type];
  }
  if (final.eliminated.some((e) => e.seat === seat)) lost += WEIGHTS.kingLoss;
  return lost;
}

/**
 * Bot Khó (PLAN 9.3). Giả định (như `chooseMove`): đúng lượt của `seat`, gọi trực tiếp `legalMoves`/`applyMove`
 * thật nên không cần kiểm lại tính hợp lệ — engine sẽ ném lỗi nếu bị gọi sai lượt.
 */
export function chooseHardMove(state: GameState, seat: Seat, rng: Rng, personality: Personality = 'balanced'): HardDecision | null {
  const moves = legalMoves(state, seat);
  if (moves.length === 0) return null;
  const options: ScoreOptions = { seesCaptures: true, fullDanger: true, pressure: true };
  const ctx = buildContext(state, seat, { weights: weightsFor(personality), targetStrategy: targetStrategyFor(personality) });

  // Bước 1 (PLAN 9.3): top-K theo điểm chấm 1 nước, y hệt Thường. Tất định: đồng điểm giữ nguyên thứ tự trong
  // `moves`, không dùng RNG ở bước này. Giữ lại `danger` (đe doạ ước lượng 0,9× của `scoreMove`, docs/bot.md) để
  // bỏ ra ở bước 2 — xem chú thích dưới, tránh đếm hai lần cùng một khoản mất mát.
  const ranked = moves
    .map((move, index) => {
      const breakdown = scoreMove(ctx, move, options);
      return { move, index, score: total(breakdown), danger: breakdown.danger };
    })
    .sort((a, b) => b.score - a.score || a.index - b.index)
    .slice(0, HARD_TOP_K);

  // Bước 2 (PLAN 9.3): với mỗi ứng viên, áp dụng thật rồi mô phỏng phản đòn của đối thủ, trừ vật chất mất đi.
  // `candidate.score` đã trừ sẵn MỘT lần ước lượng đe doạ (`danger`, chiết khấu 0,9×, chỉ 1 đối thủ/quân, PLAN 9.2)
  // để xếp hạng ở bước 1 — cộng lại đúng khoản đó rồi trừ THẬT bằng `lost` (mô phỏng đủ tối đa 5 đối thủ theo đúng
  // thứ tự lượt, không chiết khấu), thay vì cộng dồn cả hai khoản phạt cho cùng một rủi ro (sẽ khiến Khó né tránh
  // quá tay mọi nước có rủi ro thật, chơi thụ động hơn cả Thường — thấy rõ qua đấu thử thật, docs/bot.md mục M9).
  let bestMove: Move | undefined;
  let bestFinal = Number.NEGATIVE_INFINITY;
  for (const candidate of ranked) {
    const afterMine = applyMove(state, candidate.move).state;
    const final = simulateReplies(afterMine, seat);
    const lost = materialLost(afterMine, final, seat);
    // Nhiễu nhỏ chỉ để phá đồng điểm chính xác (cùng cách bot Thường làm, `docs/bot.md`), không đổi thứ hạng rõ ràng.
    const finalScore = candidate.score + candidate.danger - lost + rng.next() * HARD_NOISE;
    if (finalScore > bestFinal) {
      bestFinal = finalScore;
      bestMove = candidate.move;
    }
  }
  return bestMove === undefined ? null : { move: bestMove, score: bestFinal, considered: moves.length };
}
