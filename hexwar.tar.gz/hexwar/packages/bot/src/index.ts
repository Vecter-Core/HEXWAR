// @hexwar/bot — AI dùng chung engine luật (PLAN 9). Dễ + Thường (M4), Khó + tính cách (M9), chấm 1 nước
// (Khó: top-K + mô phỏng phản đòn), tất định theo seed. Bot KHÔNG được "gian lận": chỉ đọc trạng thái công khai
// và chỉ đi nước có trong `legalMoves` (PLAN 9.1).
export { attackersOf, attackersInState, buildOccupancy, type Attacker, type Occupancy } from './attacks';
export {
  WEIGHTS,
  buildContext,
  collapseRisk,
  pieceValue,
  scoreMove,
  total,
  type BotWeights,
  type BuildContextOptions,
  type EvalContext,
  type MoveScore,
  type ScoreOptions,
  type TargetStrategy,
} from './evaluate';
export { HARD_TOP_K, chooseHardMove, type HardDecision } from './hard';
export { PERSONALITIES, targetStrategyFor, weightsFor, type Personality } from './personality';
export { DIFFICULTIES, botRngFor, chooseMove, type Decision, type Difficulty } from './choose';
export {
  BOT_PHRASE_IDS,
  botChatRngFor,
  chatRatesFor,
  decideBotChat,
  type BotChatChannel,
  type BotChatDecision,
  type BotPhraseId,
  type ChatRates,
} from './chat';
