// Tính cách bot (PLAN 9.4). Dùng lại đúng bộ đánh giá `evaluate.ts`: mỗi tính cách chỉ đổi hệ số `WEIGHTS`
// (nhân lên, không thay công thức) và cách chọn Vua đối thủ mục tiêu (`TargetStrategy`) — không tách riêng logic
// `scoreMove` ba lần (xem docs/decisions.md mục M9).
import { WEIGHTS, type BotWeights, type TargetStrategy } from './evaluate';

/**
 * 'balanced' = đúng hành vi hiện có từ M4 (nhân mọi trọng số với 1), để mọi lời gọi `chooseMove` cũ không truyền
 * `personality` giữ nguyên kết quả, đúng từng bit (M9 yêu cầu không đổi hành vi Dễ/Thường khi không chọn tính cách).
 */
export type Personality = 'balanced' | 'aggressive' | 'defensive' | 'opportunist';

export const PERSONALITIES: readonly Personality[] = ['balanced', 'aggressive', 'defensive', 'opportunist'];

type Multiplier = Partial<Record<keyof typeof WEIGHTS, number>>;

/**
 * Hệ số nhân lên `WEIGHTS` cho từng tính cách (PLAN 9.4). Đây là điểm khởi đầu hiệu chỉnh bằng đấu thử
 * (`docs/bot.md` mục M9), không phải số "đúng tuyệt đối" — xem docs/questions.md.
 */
const MULTIPLIERS: Record<Personality, Multiplier> = {
  balanced: {},
  // Hung hăng (tấn công sớm): săn Vua đối thủ và gây sức ép mạnh hơn hẳn, chấp nhận rủi ro hơn (threatFactor thấp
  // hơn = coi nhẹ đe doạ vào quân mình hơn), bớt thận trọng vị trí/Hề để dồn lực tấn công.
  aggressive: {
    hunt: 2,
    pressure: 1.6,
    eliminate: 1.15,
    kingHitSaved: 1.3,
    threatFactor: 0.7,
    center: 0.6,
    jesterFar: 0.6,
  },
  // Thủ thế (giữ Vua và Hề, thu hẹp phòng thủ): coi trọng đe doạ vào quân mình, giữ Hề trong tầm hồi sinh (R-51),
  // ưu tiên dọn lối thoát quanh Vua khi sắp thu hẹp; gần như không chủ động săn đuổi.
  defensive: {
    threatFactor: 1.4,
    jesterGuard: 1.6,
    kingEscape: 1.7,
    jesterFar: 2,
    hunt: 0.35,
    pressure: 0.5,
  },
  // Cơ hội (chờ hai người khác đánh nhau rồi nhặt quân): không tự khơi mào (hunt rất thấp), nhưng tận dụng sức ép
  // và cẩn trọng hơn một chút để sống sót tới lúc "nhặt"; mục tiêu đổi sang đối thủ YẾU NHẤT (không phải gần nhất,
  // xem `targetStrategyFor`), đúng nghĩa "nhặt quân của kẻ đã suy yếu" thay vì lao vào ai gần mình nhất.
  opportunist: {
    hunt: 0.2,
    pressure: 1.5,
    threatFactor: 1.15,
    kingEscape: 1.2,
  },
};

/** Bản `WEIGHTS` đã nhân hệ số của tính cách (PLAN 9.4), truyền vào `buildContext` — không đổi công thức chấm điểm. */
export function weightsFor(personality: Personality): BotWeights {
  const mult = MULTIPLIERS[personality];
  const out = {} as Record<string, number>;
  for (const key of Object.keys(WEIGHTS) as (keyof typeof WEIGHTS)[]) {
    out[key] = WEIGHTS[key] * (mult[key] ?? 1);
  }
  return out as BotWeights;
}

/** PLAN 9.4 "Cơ hội": nhắm Vua đối thủ YẾU NHẤT (ít vật chất nhất), không phải gần nhất như các tính cách khác. */
export function targetStrategyFor(personality: Personality): TargetStrategy {
  return personality === 'opportunist' ? 'weakest' : 'nearest';
}
