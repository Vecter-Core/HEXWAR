// Bản đồ đe doạ của bot phải khớp TUYỆT ĐỐI với luật ăn quân của engine (PLAN 9.1: bot không được "gian lận" hay
// hiểu sai luật). Đối chiếu từng quân trên hàng trăm thế cờ thật với `legalMoves` của engine.
import { describe, expect, it } from 'vitest';
import {
  configWith,
  createPiece,
  legalMoves,
  makeState,
  type GameState,
  type Piece,
  type PieceType,
  type Seat,
} from '@hexwar/rules';
import { attackersInState } from '../src';
import { allOf, playBotGame } from './play';

/** Tập "id quân ra đòn|trưng dụng?" mà engine cho phép ăn quân `victim`. */
function engineAttackers(state: GameState, victim: Piece): Set<string> {
  const out = new Set<string>();
  for (const seat of state.order) {
    if (seat === victim.owner) continue;
    for (const m of legalMoves(state, seat)) {
      if (m.to.q === victim.cell.q && m.to.r === victim.cell.r) out.add(`${m.pieceId}|${m.conscript === true}`);
    }
  }
  return out;
}

function botAttackers(state: GameState, victim: Piece): Set<string> {
  return new Set(attackersInState(state, victim.cell, victim.owner).map((a) => `${a.piece.id}|${a.conscript}`));
}

interface Coverage {
  checked: number;
  withAttackers: number;
  conscriptAttackers: number;
  byType: Map<PieceType, number>;
}

function crossCheck(states: readonly GameState[], coverage: Coverage): void {
  for (const state of states) {
    for (const victim of state.pieces) {
      if (victim.status !== 'active') continue;
      const expected = engineAttackers(state, victim);
      const actual = botAttackers(state, victim);
      expect([...actual].sort(), `quân ${victim.id} tại ${victim.cell.q},${victim.cell.r}, hiệp ${state.round}`).toEqual([...expected].sort());
      coverage.checked++;
      if (expected.size > 0) coverage.withAttackers++;
      for (const key of expected) {
        if (key.endsWith('|true')) coverage.conscriptAttackers++;
        const attacker = state.pieces.find((p) => p.id === key.split('|')[0]);
        if (attacker !== undefined) coverage.byType.set(attacker.type, (coverage.byType.get(attacker.type) ?? 0) + 1);
      }
    }
  }
}

describe('attackersOf khớp luật ăn quân của engine', () => {
  it('trên các thế cờ của ván bot thật (luật mặc định, R=24), mọi loại quân đều từng là kẻ ra đòn', () => {
    const coverage: Coverage = { checked: 0, withAttackers: 0, conscriptAttackers: 0, byType: new Map() };
    for (const seed of [11, 12]) {
      const { states } = playBotGame({ ...allOf('easy'), 1: 'normal' }, seed, { keepStates: true, maxActions: 700 });
      crossCheck(states.filter((_, i) => i % 3 === 0), coverage);
    }
    expect(coverage.checked).toBeGreaterThan(10_000);
    expect(coverage.withAttackers).toBeGreaterThan(100);
    expect(coverage.conscriptAttackers, 'phải gặp tù binh trưng dụng ra đòn (R-32)').toBeGreaterThan(0);
    for (const type of ['P', 'N', 'B', 'R', 'Q', 'K'] as const) {
      expect(coverage.byType.get(type) ?? 0, `loại ${type} phải từng ra đòn`).toBeGreaterThan(0);
    }
    expect(coverage.byType.get('J') ?? 0, 'Hề không bao giờ ăn quân (R-50)').toBe(0);
  });

  it('với tầm đo bằng "hops" (D-03 phương án khác) và bàn nhỏ R=12 vẫn khớp', () => {
    const config = configWith({
      board: { radius: 12, seatCornerRing: 11 },
      reach: { metric: 'hops', R: 4, B: 3, Q: 4, J: 2 },
      collapse: { rounds: [20, 40], extension: { enabled: true, firstRound: 50, every: 5, minRadius: 3 }, hardCapRound: 120 },
    });
    const coverage: Coverage = { checked: 0, withAttackers: 0, conscriptAttackers: 0, byType: new Map() };
    const { states } = playBotGame({ ...allOf('easy'), 0: 'normal' }, 5, { keepStates: true, config, maxActions: 500 });
    crossCheck(states, coverage);
    expect(coverage.withAttackers).toBeGreaterThan(50);
  });

  it('ô chỉ có tù binh vẫn chặn quân trượt (R-20); tù binh chưa tới hạn không ra đòn', () => {
    const pieces = [
      createPiece('k0', 0, 'K', { q: 0, r: 5 }),
      createPiece('r1', 1, 'R', { q: 0, r: -3 }),
      // ô (0,0): quân giữ của ghế 2 + tù binh (của ghế 3) do ghế 2 giữ, chưa armed
      createPiece('n2', 2, 'N', { q: 0, r: 0 }),
      { ...createPiece('q3', 3, 'Q', { q: 0, r: 0 }), status: 'captive', holder: 2 as Seat, armed: false },
    ] satisfies Piece[];
    const state = makeState({ pieces, radius: 10 });
    expect(botAttackers(state, pieces[0])).toEqual(engineAttackers(state, pieces[0]));
    expect(botAttackers(state, pieces[0]).size).toBe(0);
  });
});
