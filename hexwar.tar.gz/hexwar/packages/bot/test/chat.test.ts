// Chat của bot (PLAN 9.4, mục hoãn từ M9 — "bot phải đôi khi nhắn cho người chơi, kể cả thao túng tâm lý"): `chat.ts`.
// Test bằng một `Rng` giả (hàng đợi giá trị cố định) để chốt đúng nhánh muốn kiểm, thay vì dò seed thật —
// giữ ý định của từng test rõ ràng (feed gì → nhánh nào). `decideBotChat` với `createRng` thật cũng được test
// riêng để xác nhận tính tất định (X-11) trên một dòng ngẫu nhiên thật.
import { describe, expect, it } from 'vitest';
import { createPiece, createRng, makeState, type GameEvent, type GameState, type Piece, type Rng, type Seat } from '@hexwar/rules';
import { BOT_PHRASE_IDS, PERSONALITIES, botChatRngFor, botRngFor, chatRatesFor, decideBotChat } from '../src';

const P = (id: string, owner: Seat, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });

/** `Rng` giả: trả lần lượt từng giá trị trong `values` (lặp lại giá trị cuối nếu gọi nhiều hơn), để ép đúng
 * nhánh của `decideBotChat` muốn kiểm mà không phải dò seed thật của `createRng`. */
function fakeRng(values: readonly number[]): Rng {
  let i = 0;
  return {
    next: () => values[Math.min(i++, values.length - 1)] ?? 0,
    int: (max: number) => Math.floor((values[Math.min(i++, values.length - 1)] ?? 0) * max),
  };
}

function twoKingsState(extra: readonly Piece[] = []): GameState {
  return makeState({ pieces: [P('k0', 0, 'K', -10, -10), P('k1', 1, 'K', 10, 10), ...extra], seats: [0, 1] });
}

describe('chatRatesFor (PLAN 9.4)', () => {
  it("'balanced' = đúng tỉ lệ nền, không nhân hệ số nào", () => {
    expect(chatRatesFor('balanced')).toEqual({
      tauntOnElimination: 0.5,
      captureReaction: 0.3,
      deceiveVictimShare: 0.4,
      threatenedReaction: 0.25,
      inciteVsPlead: 0.5,
      inciteLeaderAmbient: 0.04,
      collapseHeadsUp: 0.15,
      openingGreeting: 0.6,
    });
  });

  it('mọi tính cách đều đủ khoá và mọi giá trị nằm trong [0, 1]', () => {
    for (const p of PERSONALITIES) {
      const rates = chatRatesFor(p);
      expect(Object.keys(rates).sort()).toEqual(Object.keys(chatRatesFor('balanced')).sort());
      for (const v of Object.values(rates)) {
        expect(v).toBeGreaterThanOrEqual(0);
        expect(v).toBeLessThanOrEqual(1);
      }
    }
  });
});

describe('BOT_PHRASE_IDS', () => {
  it('không trùng lặp và đúng dạng "nhóm.tên" (khớp PhraseId thật của packages/protocol)', () => {
    expect(new Set(BOT_PHRASE_IDS).size).toBe(BOT_PHRASE_IDS.length);
    for (const id of BOT_PHRASE_IDS) expect(id).toMatch(/^[a-z]+\.[a-zA-Z]+$/);
  });
});

describe('decideBotChat: loại được Vua đối thủ → trêu chọc công khai (ưu tiên cao nhất)', () => {
  const events: GameEvent[] = [{ type: 'KING_CAPTURED', kingId: 'k1', owner: 1, by: 0, cell: { q: 0, r: 0 } }];
  const state = twoKingsState();

  it('rng cho qua ngưỡng: trả về emote công khai', () => {
    const d = decideBotChat(state, 0, events, 'balanced', fakeRng([0, 0]));
    expect(d).toEqual({ phraseId: 'emote.gg', channel: 'all' });
  });

  it('rng KHÔNG qua ngưỡng: im lặng (không phải lượt nào cũng chat)', () => {
    const d = decideBotChat(state, 0, events, 'balanced', fakeRng([0.99]));
    expect(d).toBeNull();
  });

  it('ưu tiên hơn mọi kịch bản khác dù cùng lúc có sự kiện khác (vd. cảnh báo thu hẹp)', () => {
    const withWarning: GameEvent[] = [...events, { type: 'RING_WARNING', ring: 20, roundsLeft: 1, level: 'red' }];
    const d = decideBotChat(state, 0, withWarning, 'balanced', fakeRng([0, 0.9]));
    expect(d).toEqual({ phraseId: 'emote.haha', channel: 'all' });
  });
});

describe('decideBotChat: vừa ăn quân → thao túng bằng cách trấn an giả NẠN NHÂN (nhắn riêng)', () => {
  const events: GameEvent[] = [{ type: 'CAPTURED', attackerId: 'x', victimId: 'y', seat: 0, victimOwner: 1, cell: { q: 0, r: 0 }, conscript: false }];
  const state = twoKingsState();

  it('nhắn riêng "không có ý gây hại" cho đúng ghế vừa bị ăn quân', () => {
    const d = decideBotChat(state, 0, events, 'balanced', fakeRng([0, 0]));
    expect(d).toEqual({ phraseId: 'diplomacy.noHarmIntended', channel: 'whisper', to: 1 });
  });

  it('khi không chọn thao túng riêng: trêu công khai thay vì im lặng', () => {
    const d = decideBotChat(state, 0, events, 'balanced', fakeRng([0, 0.99, 0.9]));
    expect(d).toEqual({ phraseId: 'emote.tooBad', channel: 'all' });
  });

  it('chỉ tính quân của SEAT vừa đi (không phải bất kỳ ai bị ăn quân trong sự kiện)', () => {
    const otherSeatCaptured: GameEvent[] = [{ type: 'CAPTURED', attackerId: 'x', victimId: 'y', seat: 1, victimOwner: 0, cell: { q: 0, r: 0 }, conscript: false }];
    // Ngưỡng cao cho mọi kịch bản còn lại (kích động chủ động) để khẳng định KHÔNG kịch bản nào kích hoạt,
    // kể cả kịch bản "vừa ăn quân" (sự kiện thuộc ghế 1, không phải ghế 0 đang được hỏi).
    expect(decideBotChat(state, 0, otherSeatCaptured, 'balanced', fakeRng([0.99]))).toBeNull();
  });
});

describe('decideBotChat: Vua của mình bị đe doạ → thao túng bằng kích động đánh người dẫn đầu, hoặc cầu hoà riêng', () => {
  /** Vua địch (ghế 1) đứng cạnh Vua mình (ghế 0) → đe doạ ăn ngay lượt tới (Vua ăn 1 bước, mọi hướng). */
  function threatenedState(): GameState {
    return makeState({ pieces: [P('k0', 0, 'K', 0, 0), P('k1', 1, 'K', 0, -1)], seats: [0, 1] });
  }

  it('kích động cả bàn đánh người dẫn đầu (đổ hướng chú ý khỏi mình) khi rng chọn nhánh kích động', () => {
    const d = decideBotChat(threatenedState(), 0, [], 'balanced', fakeRng([0, 0]));
    expect(d).toEqual({ phraseId: 'diplomacy.attackLeader', channel: 'all' });
  });

  it('nếu không chọn kích động: nhắn riêng cầu hoà với đúng kẻ đang đe doạ mình', () => {
    const d = decideBotChat(threatenedState(), 0, [], 'balanced', fakeRng([0, 0.99]));
    expect(d).toEqual({ phraseId: 'diplomacy.dontAttackMe', channel: 'whisper', to: 1 });
  });

  it('không bị đe doạ thì kịch bản này không kích hoạt (nhường cho kịch bản khác)', () => {
    const d = decideBotChat(twoKingsState(), 0, [], 'balanced', fakeRng([0.99]));
    // Không có đe doạ, không có sự kiện gì → rơi xuống kích động chủ động (ambient); ngưỡng 0.99 cũng trượt luôn.
    expect(d).toBeNull();
  });
});

describe('decideBotChat: kích động chủ động đánh người dẫn đầu, dù không bị đe doạ gì (thao túng chủ động)', () => {
  it('xác suất nền nhỏ vẫn có thể trúng và trỏ đúng người đang dẫn đầu (khác mình)', () => {
    const d = decideBotChat(twoKingsState(), 0, [], 'balanced', fakeRng([0]));
    expect(d).toEqual({ phraseId: 'diplomacy.attackLeader', channel: 'all' });
  });
});

describe('decideBotChat: cảnh báo thu hẹp mức đỏ — không thao túng, thiện chí thật', () => {
  const events: GameEvent[] = [{ type: 'RING_WARNING', ring: 20, roundsLeft: 1, level: 'red' }];

  it('báo công khai khi rng chọn (sau khi kịch bản kích động chủ động trượt)', () => {
    const d = decideBotChat(twoKingsState(), 0, events, 'balanced', fakeRng([0.99, 0]));
    expect(d).toEqual({ phraseId: 'warning.ringVanishing', channel: 'all' });
  });

  it('cảnh báo mức VÀNG (chưa gấp) không kích hoạt kịch bản này', () => {
    const yellow: GameEvent[] = [{ type: 'RING_WARNING', ring: 20, roundsLeft: 5, level: 'yellow' }];
    // round: 2 để loại kịch bản "chào hỏi hiệp 1" khỏi phép thử — chỉ muốn cô lập đúng một điều: mức vàng
    // không đủ để kích hoạt collapseHeadsUp (chỉ mức đỏ mới đủ).
    const state = makeState({ pieces: [P('k0', 0, 'K', -10, -10), P('k1', 1, 'K', 10, 10)], seats: [0, 1], round: 2 });
    expect(decideBotChat(state, 0, yellow, 'balanced', fakeRng([0.99, 0]))).toBeNull();
  });
});

describe('decideBotChat: chào hỏi khi còn ở hiệp 1 (không chiến thuật, chỉ cho sinh động)', () => {
  // Cố tình KHÔNG dùng `TURN_STARTED` để dò "lượt đầu tiên của mình": xem chú thích `openingGreeting` (chat.ts)
  // — sự kiện đó (nếu có trong đợt này) luôn là của LƯỢT KẾ TIẾP, không phải của chính lượt vừa đi.
  it('trạng thái sau nước đi còn ở hiệp 1: có thể chào', () => {
    const d = decideBotChat(twoKingsState(), 0, [], 'balanced', fakeRng([0.99, 0, 0.9]));
    expect(d).toEqual({ phraseId: 'greeting.hello', channel: 'all' });
  });

  it('trạng thái sau nước đi đã sang hiệp 2: không chào nữa', () => {
    const state = makeState({ pieces: [P('k0', 0, 'K', -10, -10), P('k1', 1, 'K', 10, 10)], seats: [0, 1], round: 2 });
    expect(decideBotChat(state, 0, [], 'balanced', fakeRng([0.99, 0.99]))).toBeNull();
  });
});

describe('decideBotChat: tất định (X-11 phát lại, X-10 ván lưu) và không đổi nước đi', () => {
  it('cùng trạng thái + cùng dòng rng thật (createRng) → luôn ra đúng một quyết định', () => {
    const state = twoKingsState();
    const events: GameEvent[] = [{ type: 'KING_CAPTURED', kingId: 'k1', owner: 1, by: 0, cell: { q: 0, r: 0 } }];
    const a = decideBotChat(state, 0, events, 'aggressive', createRng(777));
    const b = decideBotChat(state, 0, events, 'aggressive', createRng(777));
    expect(a).toEqual(b);
  });

  it('botChatRngFor tạo dòng ngẫu nhiên KHÁC botRngFor cho cùng (state, seat, actionIndex)', () => {
    const state = twoKingsState();
    const chatSeq = botChatRngFor(state, 0, 3);
    const moveSeq = botRngFor(state, 0, 3);
    expect([chatSeq.next(), chatSeq.next()]).not.toEqual([moveSeq.next(), moveSeq.next()]);
  });
});
