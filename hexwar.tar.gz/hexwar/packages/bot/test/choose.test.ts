// Hành vi của bot Dễ / Thường theo PLAN 9.3 trên các thế cờ dựng tay, và tính tất định (PLAN 9.1).
import { describe, expect, it } from 'vitest';
import {
  createPiece,
  createRng,
  defaultConfig,
  legalMoves,
  makeState,
  ring,
  type GameState,
  type Move,
  type Piece,
  type Seat,
} from '@hexwar/rules';
import { attackersInState, chooseMove, type Difficulty } from '../src';
import { allOf, percentile, playBotGame } from './play';

const P = (id: string, owner: Seat, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });

function decide(state: GameState, seat: Seat, difficulty: Difficulty, seed: number): Move {
  const d = chooseMove(state, seat, difficulty, createRng(seed));
  if (d === null) throw new Error('bot không có nước đi');
  return d.move;
}

const isAt = (m: Move, q: number, r: number): boolean => m.to.q === q && m.to.r === r;

/** Ô của Vua `seat` sau nước đi `move` (Vua có thể là quân vừa đi). */
function kingCellAfter(state: GameState, seat: Seat, move: Move): { q: number; r: number } {
  const king = state.pieces.find((p) => p.owner === seat && p.type === 'K') as Piece;
  return move.pieceId === king.id ? move.to : king.cell;
}

/** Hai ghế ở xa nhau, mỗi ghế một Vua và vài quân, ghế 0 tới lượt. */
function duel(extra: readonly Piece[], round = 1): GameState {
  return makeState({
    pieces: [P('k0', 0, 'K', 0, 8), P('k1', 1, 'K', -8, -4), ...extra],
    seats: [0, 1],
    round,
  });
}

describe('bot Thường (PLAN 9.3)', () => {
  it('ăn Hậu miễn phí khi có', () => {
    // Xe ghế 0 ở (0,4) nhìn thẳng lên (0,0) có Hậu ghế 1, không ai bảo vệ Hậu.
    const state = duel([P('r0', 0, 'R', 0, 4), P('q1', 1, 'Q', 0, 0)]);
    const move = decide(state, 0, 'normal', 1);
    expect(move.pieceId).toBe('r0');
    expect(isAt(move, 0, 0)).toBe(true);
  });

  it('ăn Vua địch (loại cả đội, R-60) dù quân ăn sẽ bị phản đòn', () => {
    // Mã ghế 0 nhảy được vào Vua ghế 1; Hề ghế 1 ở quá xa để cứu (R-51); Xe ghế 2 sẽ ăn lại Mã.
    const pieces = [P('k0', 0, 'K', 0, 8), P('k1', 1, 'K', 1, -2), P('j1', 1, 'J', -8, 4), P('n0', 0, 'N', 0, 1), P('k2', 2, 'K', 8, -8), P('r2', 2, 'R', 5, -2)];
    const state = makeState({ pieces, seats: [0, 1, 2] });
    const move = decide(state, 0, 'normal', 3);
    expect(move.pieceId).toBe('n0');
    expect(isAt(move, 1, -2)).toBe(true);
  });

  it('không để Hậu đứng vào ô bị ăn lại khi có nước an toàn', () => {
    // Hậu ghế 0 ở (0,4); nếu ăn Tốt ở (0,0) thì Xe ghế 1 ở (0,-5) ăn lại (Tốt 1 < Hậu 9).
    const state = duel([P('q0', 0, 'Q', 0, 4), P('p1', 1, 'P', 0, 0), P('r1', 1, 'R', 0, -5)]);
    const move = decide(state, 0, 'normal', 2);
    const after: GameState = { ...state, pieces: state.pieces.map((p) => (p.id === move.pieceId ? { ...p, cell: move.to } : p)).filter((p) => !(p.cell.q === move.to.q && p.cell.r === move.to.r && p.owner === 1)) };
    const queen = after.pieces.find((p) => p.id === 'q0') as Piece;
    expect(attackersInState(after, queen.cell, 0)).toHaveLength(0);
  });

  it('trưng dụng tù binh để ăn Vua địch khi đó là nước thắng (R-32)', () => {
    // Ghế 0 giữ Hậu (của ghế 2) đã tới hạn ở ô (0,2) cùng Tốt ghế 0; Hậu nhìn thẳng tới Vua ghế 1 ở (0,-3).
    const pieces: Piece[] = [
      P('k0', 0, 'K', 6, 6),
      P('p0', 0, 'P', 0, 2),
      { ...P('q2', 2, 'Q', 0, 2), status: 'captive', holder: 0, armed: true },
      P('k1', 1, 'K', 0, -3),
      P('k2', 2, 'K', -9, 9),
    ];
    const state = makeState({ pieces, seats: [0, 1, 2] });
    const move = decide(state, 0, 'normal', 4);
    expect(move).toEqual({ pieceId: 'q2', to: { q: 0, r: -3 }, conscript: true });
  });
});

describe.each<Difficulty>(['easy', 'normal'])('bot %s: an toàn Vua và thu hẹp', (difficulty) => {
  it('đưa Vua ra khỏi ô bị Xe địch nhắm (PLAN 9.3 Dễ: "tránh để Vua bị ăn ngay")', () => {
    // Xe ghế 1 ở (0,-1) nhìn thẳng xuống Vua ghế 0 ở (0,8) (cách 9 ô, đường trống). Hề ghế 0 ở xa nên không cứu được.
    const state = makeState({
      pieces: [P('k0', 0, 'K', 0, 8), P('j0', 0, 'J', -9, 12), P('p0', 0, 'P', 7, 5), P('k1', 1, 'K', -12, 2), P('r1', 1, 'R', 0, -1)],
      seats: [0, 1],
    });
    for (let seed = 1; seed <= 40; seed++) {
      const move = decide(state, 0, difficulty, seed);
      const king = kingCellAfter(state, 0, move);
      const after: GameState = { ...state, pieces: state.pieces.map((p) => (p.id === move.pieceId ? { ...p, cell: move.to } : p)) };
      expect(attackersInState(after, king, 0), `seed ${seed}: ${JSON.stringify(move)}`).toHaveLength(0);
    }
  });

  it('đưa Vua ra khỏi vòng sắp biến mất ở đầu hiệp sau (R-70; D-09: Hề không cứu)', () => {
    // Hiệp 49, thu hẹp hạng 24 ở đầu hiệp 50 (bảng 3.5). Vua ghế 0 đứng trên hạng 24.
    const state = makeState({
      pieces: [P('k0', 0, 'K', 0, 24), P('j0', 0, 'J', -1, 23), P('r0', 0, 'R', 10, 5), P('k1', 1, 'K', 0, -20)],
      seats: [0, 1],
      round: 49,
      config: defaultConfig,
    });
    for (let seed = 1; seed <= 30; seed++) {
      const move = decide(state, 0, difficulty, seed);
      expect(ring(kingCellAfter(state, 0, move)), `seed ${seed}`).toBeLessThan(24);
    }
  });

  it('tất định: cùng thế cờ + cùng seed → cùng nước đi (PLAN 9.1)', () => {
    const { final } = playBotGame(allOf(difficulty), 21, { maxActions: 120 });
    const seat = final.turnSeat as Seat;
    const a = chooseMove(final, seat, difficulty, createRng(99));
    const b = chooseMove(final, seat, difficulty, createRng(99));
    expect(a).toEqual(b);
    expect(legalMoves(final, seat)).toContainEqual(a?.move);
  });
});

describe('bot Dễ', () => {
  it('ăn quân miễn phí khoảng 60% số lượt (PLAN 9.3), không phải lúc nào cũng ăn', () => {
    const state = duel([P('r0', 0, 'R', 0, 4), P('q1', 1, 'Q', 0, 0)]);
    let captures = 0;
    const trials = 300;
    for (let seed = 1; seed <= trials; seed++) if (isAt(decide(state, 0, 'easy', seed), 0, 0)) captures++;
    const rate = captures / trials;
    expect(rate).toBeGreaterThan(0.5);
    expect(rate).toBeLessThan(0.75);
  });
});

describe('ván trọn chỉ gồm bot (PLAN 9.5, thu nhỏ để chạy trong CI)', () => {
  it('1 Thường + 5 Dễ chơi tới khi kết thúc, mọi trạng thái hợp lệ, thời gian nghĩ trong ngân sách 1,5 giây', () => {
    const game = playBotGame({ ...allOf('easy'), 3: 'normal' }, 2026, { validate: true });
    expect(game.final.phase).toBe('over');
    expect(game.final.result?.ranking).toHaveLength(6);
    expect(percentile(game.thinkMs, 0.95)).toBeLessThan(1500);
  });
});
