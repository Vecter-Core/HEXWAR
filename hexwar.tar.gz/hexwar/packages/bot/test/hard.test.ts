// Bot Khó (PLAN 9.3, M9): top-K + mô phỏng phản đòn (`hard.ts`). Theo phong cách `choose.test.ts`.
import { describe, expect, it } from 'vitest';
import { applyMove, createPiece, createRng, legalMoves, makeState, type GameState, type Piece, type Seat } from '@hexwar/rules';
import { HARD_TOP_K, chooseHardMove } from '../src/hard';
import { allOf, playBotGame } from './play';

const P = (id: string, owner: Seat, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });

/**
 * Xe của ghế 0 có thể ăn Tốt địch ở (0,3) (được 1 điểm), nhưng Xe địch ở (0,7) ăn lại ngay sau đó (mất 5 điểm quân
 * Xe của mình): lỗ ròng 4 điểm, một cú đổi quân lỗ rõ ràng bằng bất kỳ cách chấm điểm hợp lý nào (không chỉ vì
 * chiết khấu 0,9× của bot Thường — xem chú thích ở test dùng thế cờ này). Dùng để kiểm tra `chooseHardMove` không
 * đi vào nước lỗ khi có nước an toàn khác.
 */
function badTradeState(): GameState {
  return makeState({
    pieces: [
      P('k0', 0, 'K', -5, -5),
      P('j0', 0, 'J', -3, -3),
      P('r0', 0, 'R', 0, 0),
      P('k1', 1, 'K', 10, 10),
      P('pEnemy', 1, 'P', 0, 3),
      P('rEnemy', 1, 'R', 0, 7),
    ],
    seats: [0, 1],
  });
}

/**
 * Mã của ghế 0 có thể ăn Mã địch ở (1,2): đổi NGANG GIÁ (Mã 3 điểm lấy Mã 3 điểm, Xe địch ở (1,7) ăn lại ngay sau
 * đó) — về vật chất là hoà, KHÔNG phải một cú lỗ. Dùng thế cờ này để kiểm tra `chooseHardMove` không phạt một cú
 * đổi ngang giá như thể nó lỗ (xem docs/decisions.md mục M9: bản đầu của `hard.ts` cộng dồn hai lần cùng một rủi
 * ro — vừa trừ qua `danger` chiết khấu 0,9× của `scoreMove` [bot Thường dùng], vừa trừ thêm bằng vật chất thật mô
 * phỏng được ở bước 2 — khiến Khó né cả những cú đổi ngang giá hoàn toàn hợp lý, chơi thụ động hơn cả Thường; thấy
 * rõ qua tỉ lệ thắng thật ở đấu thử, docs/bot.md mục M9).
 */
function evenTradeState(): GameState {
  return makeState({
    pieces: [
      P('k0', 0, 'K', -5, -5),
      P('j0', 0, 'J', -3, -3),
      P('n0', 0, 'N', 0, 0),
      P('k1', 1, 'K', 10, 10),
      P('nEnemy', 1, 'N', 1, 2),
      P('rEnemy', 1, 'R', 1, 7),
    ],
    seats: [0, 1],
  });
}

/** Nước ăn giá trị nhất mà `attacker` có thể tung vào quân đang hoạt động của `defender` (độc lập với `hard.ts`,
 * để kiểm chứng vật chất THẬT sau một nước — không lấy lại đúng logic sản phẩm rồi tự kiểm mình). */
function bestCaptureValue(state: GameState, attacker: Seat, defender: Seat): number {
  let best = 0;
  for (const move of legalMoves(state, attacker)) {
    const victim = state.pieces.find((p) => p.owner === defender && p.status === 'active' && p.cell.q === move.to.q && p.cell.r === move.to.r);
    if (victim !== undefined) best = Math.max(best, state.config.score[victim.type]);
  }
  return best;
}

describe('bot Khó (PLAN 9.3): top-K + mô phỏng phản đòn', () => {
  it('không bao giờ trả về nước ngoài legalMoves', () => {
    const state = badTradeState();
    const decision = chooseHardMove(state, 0, createRng(1));
    expect(decision).not.toBeNull();
    expect(legalMoves(state, 0)).toContainEqual(decision?.move);
  });

  it('tất định: cùng thế cờ + cùng seed → cùng nước đi (PLAN 9.1)', () => {
    const state = badTradeState();
    const a = chooseHardMove(state, 0, createRng(42));
    const b = chooseHardMove(state, 0, createRng(42));
    expect(a).toEqual(b);
  });

  it('tất định trên một ván trọn (nhiều hiệp): cùng seed cho cùng nước ở cùng thế cờ', () => {
    const { final } = playBotGame({ ...allOf('normal'), 0: 'hard' }, 2026, { maxActions: 80 });
    const seat = final.turnSeat as Seat;
    const a = chooseHardMove(final, seat, createRng(99));
    const b = chooseHardMove(final, seat, createRng(99));
    expect(a).toEqual(b);
    expect(legalMoves(final, seat)).toContainEqual(a?.move);
  });

  it('né được cú đổi quân lỗ ròng rõ ràng (ăn Tốt 1 điểm, bị Xe ăn lại mất 5 điểm)', () => {
    const state = badTradeState();
    const hard = chooseHardMove(state, 0, createRng(1));
    expect(hard?.move).not.toEqual({ pieceId: 'r0', to: { q: 0, r: 3 } });
    // Dù chọn nước nào, vật chất THẬT của ghế 0 sau khi ghế 1 đáp trả tốt nhất không được âm.
    const afterMine = applyMove(state, hard!.move).state;
    expect(bestCaptureValue(afterMine, 1, 0)).toBe(0); // không quân nào của ghế 0 còn bị ăn ngay sau đó
  });

  it('không cộng dồn hai lần cùng một rủi ro cho một cú đổi NGANG GIÁ (không phải lỗ thật)', () => {
    const state = evenTradeState();
    const hard = chooseHardMove(state, 0, createRng(1));
    expect(hard).not.toBeNull();
    // Bất kể Hard chọn đổi ngang giá hay rút lui an toàn, vật chất RÒNG thật của ghế 0 sau một nhịp không được âm
    // — nếu bản có lỗi cộng dồn (docs/decisions.md mục M9) từng khiến Khó tưởng nhầm một cú đổi ngang giá là lỗ,
    // phép kiểm đơn lẻ này vẫn qua (bug cũ không làm SAI kết quả của một nước, chỉ khiến Khó quá tay tránh cả
    // những cú đổi ngang giá HỢP LÝ trong nhiều thế cờ khác — đo rõ nhất qua tỉ lệ thắng thật khi đấu thử hàng
    // loạt, xem docs/bot.md mục M9, không phải qua một test đơn như thế này).
    const isTrade = hard!.move.pieceId === 'n0' && hard!.move.to.q === 1 && hard!.move.to.r === 2;
    const gainedValue = isTrade ? state.config.score.N : 0;
    const afterMine = applyMove(state, hard!.move).state;
    const lostAfterBest = bestCaptureValue(afterMine, 1, 0);
    expect(lostAfterBest - gainedValue).toBeLessThanOrEqual(0); // không lỗ ròng, dù có đổi ngang giá hay không
  });

  it('K≈8 (PLAN 9.3): hằng số top-K đúng như đặc tả', () => {
    expect(HARD_TOP_K).toBe(8);
  });

  it('ván trọn với 1 Khó + 5 Thường chạy hết ván, mọi trạng thái hợp lệ (PLAN 9.5, thu nhỏ để chạy trong CI)', () => {
    const game = playBotGame({ ...allOf('normal'), 3: 'hard' }, 4242, { validate: true, maxActions: 4000 });
    expect(['playing', 'over']).toContain(game.final.phase);
  });
});
