// Tính cách bot (PLAN 9.4, M9): `personality.ts`. Xác nhận (a) mặc định 'balanced' không đổi hành vi Dễ/Thường
// hiện có (M9 yêu cầu), (b) mỗi tính cách chọn nước ĐO ĐƯỢC khác nhau trên ít nhất một thế cờ dựng tay.
import { describe, expect, it } from 'vitest';
import { createPiece, createRng, makeState, type GameState, type Piece, type Seat } from '@hexwar/rules';
import { WEIGHTS, buildContext, chooseMove, scoreMove, total } from '../src';
import { PERSONALITIES, targetStrategyFor, weightsFor } from '../src/personality';
import { allOf, playBotGame } from './play';

const P = (id: string, owner: Seat, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });

describe('weightsFor / targetStrategyFor (PLAN 9.4)', () => {
  it("'balanced' = đúng WEIGHTS hiện có (nhân 1), không đổi hành vi khi không chọn tính cách", () => {
    expect(weightsFor('balanced')).toEqual(WEIGHTS);
  });

  it('mọi tính cách đều đủ các khoá của WEIGHTS (không rớt trọng số nào)', () => {
    for (const p of PERSONALITIES) {
      expect(Object.keys(weightsFor(p)).sort()).toEqual(Object.keys(WEIGHTS).sort());
    }
  });

  it("chỉ 'Cơ hội' nhắm Vua đối thủ YẾU NHẤT; các tính cách khác nhắm gần nhất (PLAN 9.4)", () => {
    expect(targetStrategyFor('balanced')).toBe('nearest');
    expect(targetStrategyFor('aggressive')).toBe('nearest');
    expect(targetStrategyFor('defensive')).toBe('nearest');
    expect(targetStrategyFor('opportunist')).toBe('weakest');
  });
});

describe("chooseMove với personality mặc định = hệt hành vi trước M9 (an toàn ngược, 'balanced')", () => {
  it('cùng thế cờ + cùng seed: có/không truyền personality cho CÙNG một nước (bit-for-bit)', () => {
    const { final } = playBotGame(allOf('normal'), 21, { maxActions: 120 });
    const seat = final.turnSeat as Seat;
    const withDefault = chooseMove(final, seat, 'normal', createRng(99));
    const explicitBalanced = chooseMove(final, seat, 'normal', createRng(99), 'balanced');
    expect(explicitBalanced).toEqual(withDefault);
  });
});

/**
 * Mã ghế 0 có thể ăn Mã địch ở (1,2) — bị Xe địch ở (1,7) ăn lại (đổi quân lỗ) — hoặc lùi về ô an toàn (2,1),
 * gần Vua + Hề của mình hơn. PLAN 9.4: "Hung hăng" chấp nhận đổi quân sớm; "Thủ thế"/"Cơ hội" không mạo hiểm.
 */
function tradeOrRetreatState(): GameState {
  return makeState({
    pieces: [
      P('k0', 0, 'K', -5, -5),
      P('j0', 0, 'J', -3, -3),
      P('n0', 0, 'N', 0, 0),
      P('k1', 1, 'K', 10, 10),
      P('nEnemy', 1, 'N', 1, 2),
      P('rEnemy', 1, 'R', 1, 7),
    ],
    seats: [0, 1],
  });
}

describe('Hung hăng vs Thủ thế / Cơ hội (PLAN 9.4): chọn nước khác nhau đo được', () => {
  const state = tradeOrRetreatState();

  it("Hung hăng chấp nhận đổi quân sớm (tấn công), đi vào ô (1,2)", () => {
    const move = chooseMove(state, 0, 'normal', createRng(1), 'aggressive');
    expect(move?.move).toEqual({ pieceId: 'n0', to: { q: 1, r: 2 } });
  });

  it("Thủ thế lùi về an toàn gần Vua/Hề thay vì đổi quân, đi vào ô (2,1)", () => {
    const move = chooseMove(state, 0, 'normal', createRng(1), 'defensive');
    expect(move?.move).toEqual({ pieceId: 'n0', to: { q: 2, r: 1 } });
  });

  it("Cơ hội cũng không mạo hiểm đổi quân sớm (không tự khơi mào), khác Hung hăng", () => {
    const move = chooseMove(state, 0, 'normal', createRng(1), 'opportunist');
    expect(move?.move).not.toEqual({ pieceId: 'n0', to: { q: 1, r: 2 } });
  });
});

/**
 * Đối thủ ghế 1 (Vua + Hậu, mạnh) đứng GẦN, đối thủ ghế 2 (chỉ Vua, yếu) đứng XA hơn — cố tình lệch hướng để
 * "gần nhất" và "yếu nhất" khác nhau. PLAN 9.4 "Cơ hội": nhắm kẻ yếu để nhặt quân, dù nó ở xa hơn.
 */
function nearestVsWeakestState(): GameState {
  return makeState({
    pieces: [P('r0', 0, 'R', 0, 0), P('k1', 1, 'K', 2, 10), P('q1', 1, 'Q', 6, 10), P('k2', 2, 'K', 2, -20)],
    seats: [0, 1, 2],
  });
}

describe("Cơ hội nhắm Vua YẾU NHẤT thay vì gần nhất (PLAN 9.4)", () => {
  const state = nearestVsWeakestState();
  const south = { pieceId: 'r0', to: { q: 0, r: 9 } }; // tiến gần ghế 1 (mạnh, gần)
  const north = { pieceId: 'r0', to: { q: 0, r: -9 } }; // tiến gần ghế 2 (yếu, xa)
  const options = { seesCaptures: true, fullDanger: true, pressure: true };

  it.each(['balanced', 'aggressive', 'defensive'] as const)('%s: thích tiến gần ghế 1 (mạnh nhưng gần) hơn', (personality) => {
    const ctx = buildContext(state, 0, { weights: weightsFor(personality), targetStrategy: targetStrategyFor(personality) });
    expect(total(scoreMove(ctx, south, options))).toBeGreaterThan(total(scoreMove(ctx, north, options)));
  });

  it("opportunist: thích tiến gần ghế 2 (yếu, dù xa hơn) hơn — khác 3 tính cách còn lại", () => {
    const ctx = buildContext(state, 0, { weights: weightsFor('opportunist'), targetStrategy: targetStrategyFor('opportunist') });
    expect(total(scoreMove(ctx, north, options))).toBeGreaterThan(total(scoreMove(ctx, south, options)));
  });
});
