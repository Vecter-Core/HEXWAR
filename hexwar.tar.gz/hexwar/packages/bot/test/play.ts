// Chơi một ván chỉ gồm bot, không giao diện, qua đúng engine (PLAN 9.5). Dùng cho test và đấu thử hàng loạt.
import {
  SEATS,
  applyMove,
  assertValidState,
  defaultConfig,
  newGame,
  rollDice,
  timeoutTurn,
  type GameState,
  type RulesConfig,
  type Seat,
} from '@hexwar/rules';
import { botRngFor, chooseMove, type Difficulty, type Personality } from '../src';

export interface PlayedGame {
  readonly final: GameState;
  readonly actions: number;
  /** Thời gian nghĩ của từng quyết định (ms). */
  readonly thinkMs: readonly number[];
  /** Trạng thái sau mỗi hành động (chỉ khi `keepStates`). */
  readonly states: readonly GameState[];
}

export interface PlayOptions {
  readonly config?: RulesConfig;
  readonly validate?: boolean;
  readonly keepStates?: boolean;
  /** Dừng sớm sau số hành động này (mặc định: tới khi hết ván). */
  readonly maxActions?: number;
}

/** Cấu hình một ghế bot: độ khó bắt buộc, tính cách tuỳ chọn (mặc định 'balanced', PLAN 9.4, M9). */
export interface SeatBotConfig {
  readonly difficulty: Difficulty;
  readonly personality?: Personality;
}

/** Nhận cả dạng cũ (M4: chỉ `Difficulty`, tương đương `personality: 'balanced'`) lẫn dạng mới (`SeatBotConfig`). */
export type SeatsConfig = Readonly<Record<Seat, Difficulty | SeatBotConfig>>;

function configOf(entry: Difficulty | SeatBotConfig): SeatBotConfig {
  return typeof entry === 'string' ? { difficulty: entry } : entry;
}

export function playBotGame(seatsConfig: SeatsConfig, seed: number, options: PlayOptions = {}): PlayedGame {
  let state = rollDice(newGame(options.config ?? defaultConfig, SEATS, seed)).state;
  const thinkMs: number[] = [];
  const states: GameState[] = [];
  let actions = 0;
  const limit = options.maxActions ?? Number.POSITIVE_INFINITY;
  while (state.phase === 'playing' && actions < limit) {
    const seat = state.turnSeat as Seat;
    const { difficulty, personality } = configOf(seatsConfig[seat]);
    const t0 = performance.now();
    const decision = chooseMove(state, seat, difficulty, botRngFor(state, seat, actions), personality);
    thinkMs.push(performance.now() - t0);
    state = decision === null ? timeoutTurn(state).state : applyMove(state, decision.move).state;
    actions++;
    if (options.validate === true) assertValidState(state);
    if (options.keepStates === true) states.push(state);
  }
  return { final: state, actions, thinkMs, states };
}

export function allOf(difficulty: Difficulty, personality?: Personality): Record<Seat, SeatBotConfig> {
  const one: SeatBotConfig = { difficulty, ...(personality !== undefined ? { personality } : {}) };
  return { 0: one, 1: one, 2: one, 3: one, 4: one, 5: one };
}

export function percentile(values: readonly number[], p: number): number {
  const sorted = [...values].sort((a, b) => a - b);
  return sorted[Math.min(sorted.length - 1, Math.floor((sorted.length - 1) * p))] ?? 0;
}
