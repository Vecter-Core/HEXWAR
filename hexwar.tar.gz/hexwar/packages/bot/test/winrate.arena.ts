// Đấu thử hàng loạt (PLAN 9.3, 9.5) — KHÔNG chạy trong CI. `pnpm --filter @hexwar/bot arena` (tuỳ chọn ARENA_GAMES=n,
// ARENA_FAIRNESS_GAMES=n cho riêng lượt "6 Khó" đo công bằng ghế, PLAN 9.5).
// Ghi báo cáo Markdown vào ARENA_OUT (mặc định: in ra console) để chép vào docs/bot.md.
//
// M9: PLAN 9.5 muốn 1000 ván (sai số chuẩn ≈ 1,2%), nhưng một ván chạy hết (không giới hạn hành động) trên bàn
// 1801 ô tốn tới chục giây thật — 1000 ván một lần vượt quá thời gian một lệnh có thể chạy trong sandbox này.
// Ba biến môi trường dưới đây cho phép CHẠY THEO ĐỢT rồi CỘNG DỒN kết quả thật giữa nhiều lần gọi (xem
// `tools/arena_combine.py` và docs/decisions.md mục M9), thay vì phải chạy 1000 ván trong một lần gọi duy nhất:
// - `ARENA_SEED_OFFSET` (mặc định 0): dịch dải seed của mọi mục — đợt sau dùng offset khác để lấy ván MỚI, không
//   lặp lại đúng những ván đợt trước (seed vẫn suy ra tất định từ offset, replay được).
// - `ARENA_ONLY` (mặc định: cả 4 mục, phân cách bằng dấu phẩy): chỉ chạy các mục nêu tên trong số
//   `hardVsNormal,fairness,normalVsEasy,easyFairness` — dồn ngân sách thời gian vào đúng mục cần nhiều ván.
// - `ARENA_RAW_OUT` (tuỳ chọn): ghi số liệu thô (chưa gộp thành phần trăm) của đúng những mục vừa chạy ra JSON,
//   để `tools/arena_combine.py` gộp nhiều file từ nhiều đợt thành một báo cáo Markdown duy nhất, số liệu CHÍNH XÁC
//   (cộng thẳng số ván/số thắng, không lấy trung bình của trung bình).
import { test } from 'vitest';
import { writeFileSync } from 'node:fs';
import type { Seat } from '@hexwar/rules';
import { allOf, percentile, playBotGame, type SeatBotConfig } from './play';
import type { Difficulty, Personality } from '../src';

interface Tally {
  games: number;
  wins: number;
  hardCap: number;
  collapseDeaths: number;
  rounds: number[];
  think: number[];
}

const SEED_OFFSET = Number(process.env['ARENA_SEED_OFFSET'] ?? 0);

function emptyTally(): Tally {
  return { games: 0, wins: 0, hardCap: 0, collapseDeaths: 0, rounds: [], think: [] };
}

function runTally(focus: SeatBotConfig, rest: SeatBotConfig, games: number): Tally {
  const t = emptyTally();
  for (let i = 1; i <= games; i++) {
    const seed = i + SEED_OFFSET;
    const focusSeat = ((seed - 1) % 6) as Seat; // xoay ghế để không lệch vì vị trí
    const g = playBotGame({ ...allOf(rest.difficulty, rest.personality), [focusSeat]: focus }, seed * 7919);
    t.games++;
    if (g.final.result?.winner === focusSeat) t.wins++;
    if (g.final.result?.reason === 'hardCap') t.hardCap++;
    t.collapseDeaths += g.final.eliminated.filter((e) => e.reason === 'collapse').length;
    t.rounds.push(g.final.round);
    t.think.push(...g.thinkMs);
  }
  return t;
}

function reportTally(label: string, t: Tally): string {
  const pct = (x: number): string => `${((100 * x) / t.games).toFixed(1)}%`;
  return [
    `### ${label} (${t.games} ván)`,
    '',
    `| Chỉ số | Giá trị |`,
    `|---|--:|`,
    `| Tỉ lệ thắng (ngẫu nhiên = 16,7%) | ${pct(t.wins)} (${t.wins}/${t.games}) |`,
    `| Ván kết thúc ở hiệp giới hạn 450 | ${pct(t.hardCap)} |`,
    `| Số người bị loại vì thu hẹp (tổng, mọi ván) | ${t.collapseDeaths} |`,
    `| Số hiệp khi kết thúc: trung vị / p90 | ${percentile(t.rounds, 0.5)} / ${percentile(t.rounds, 0.9)} |`,
    `| Thời gian nghĩ mỗi nước: p50 / p95 / max (ms) | ${percentile(t.think, 0.5).toFixed(1)} / ${percentile(t.think, 0.95).toFixed(1)} / ${Math.max(...t.think).toFixed(1)} |`,
    '',
  ].join('\n');
}

function run(label: string, focus: SeatBotConfig, rest: SeatBotConfig, games: number): { report: string; tally: Tally } {
  const t = runTally(focus, rest, games);
  return { report: reportTally(`${label} (bot "${focus.difficulty}")`, t), tally: t };
}

interface FairnessTally {
  games: number;
  wins: number[]; // theo ghế 0..5
  hardCap: number;
  rounds: number[];
}

function emptyFairnessTally(): FairnessTally {
  return { games: 0, wins: [0, 0, 0, 0, 0, 0], hardCap: 0, rounds: [] };
}

function fairnessTally(config: SeatBotConfig, games: number): FairnessTally {
  const f = emptyFairnessTally();
  for (let i = 1; i <= games; i++) {
    const seed = i + SEED_OFFSET;
    const g = playBotGame(allOf(config.difficulty, config.personality), seed * 104729);
    f.games++;
    const w = g.final.result?.winner;
    if (w !== null && w !== undefined) f.wins[w] = (f.wins[w] ?? 0) + 1;
    if (g.final.result?.reason === 'hardCap') f.hardCap++;
    f.rounds.push(g.final.round);
  }
  return f;
}

/** PLAN 9.5: "cả 6 ghế cùng độ khó": tỉ lệ thắng mỗi ghế trong 16,7% ± 3%. */
function reportFairness(label: string, f: FairnessTally): string {
  const pct = (x: number): string => `${((100 * x) / f.games).toFixed(1)}%`;
  const se = (100 * Math.sqrt(0.5 / 6 / f.games)).toFixed(2); // xấp xỉ sai số chuẩn nhị thức quanh p=1/6 (PLAN 9.5)
  const rows = f.wins.map((w, seat) => `| Ghế ${seat} | ${pct(w)} (${w}/${f.games}) |`).join('\n');
  return [
    `### ${label} (${f.games} ván, PLAN 9.5: mục tiêu 16,7% ± 3%, sai số chuẩn ước lượng ≈ ${se}%)`,
    '',
    `| Ghế | Tỉ lệ thắng |`,
    `|---|--:|`,
    rows,
    '',
    `Ván kết thúc ở hiệp giới hạn 450: ${pct(f.hardCap)}. Số hiệp khi kết thúc: trung vị ${percentile(f.rounds, 0.5)} / p90 ${percentile(f.rounds, 0.9)}.`,
    '',
  ].join('\n');
}

function fairness(label: string, config: SeatBotConfig, games: number): { report: string; tally: FairnessTally } {
  const f = fairnessTally(config, games);
  return { report: reportFairness(label, f), tally: f };
}

type SectionKey = 'hardVsNormal' | 'fairness' | 'normalVsEasy' | 'easyFairness';
const ALL_SECTIONS: readonly SectionKey[] = ['hardVsNormal', 'fairness', 'normalVsEasy', 'easyFairness'];

function wanted(): ReadonlySet<SectionKey> {
  const raw = process.env['ARENA_ONLY'];
  if (raw === undefined || raw.trim() === '') return new Set(ALL_SECTIONS);
  return new Set(raw.split(',').map((s) => s.trim()) as SectionKey[]);
}

test('đấu thử M9: 1 Khó vs 5 Thường, 6 Khó (công bằng ghế), + hồi quy M4 (1 Thường vs 5 Dễ, 6 Dễ)', () => {
  const games = Number(process.env['ARENA_GAMES'] ?? 30);
  const fairnessGames = Number(process.env['ARENA_FAIRNESS_GAMES'] ?? games);
  const balanced: Personality = 'balanced';
  const easy: Difficulty = 'easy';
  const normal: Difficulty = 'normal';
  const hard: Difficulty = 'hard';
  const only = wanted();

  const sections: string[] = [];
  const raw: Record<string, unknown> = { seedOffset: SEED_OFFSET };

  if (only.has('hardVsNormal')) {
    const r = run('1 Khó vs 5 Thường (M9, PLAN 9.3: ≥ 30%)', { difficulty: hard, personality: balanced }, { difficulty: normal, personality: balanced }, games);
    sections.push(r.report);
    raw['hardVsNormal'] = r.tally;
  }
  if (only.has('fairness')) {
    const r = fairness('6 Khó — công bằng ghế (M9, PLAN 9.5)', { difficulty: hard, personality: balanced }, fairnessGames);
    sections.push(r.report);
    raw['fairness'] = r.tally;
  }
  if (only.has('normalVsEasy')) {
    const r = run('1 Thường vs 5 Dễ (hồi quy M4, PLAN 9.3: ≥ 35%)', { difficulty: normal, personality: balanced }, { difficulty: easy, personality: balanced }, games);
    sections.push(r.report);
    raw['normalVsEasy'] = r.tally;
  }
  if (only.has('easyFairness')) {
    const r = run('6 Dễ — đo công bằng ghế thô (hồi quy M4)', { difficulty: easy, personality: balanced }, { difficulty: easy, personality: balanced }, games);
    sections.push(r.report);
    raw['easyFairness'] = r.tally;
  }

  const report = sections.join('\n');
  const out = process.env['ARENA_OUT'];
  if (out !== undefined) writeFileSync(out, report);
  else console.log(report);

  const rawOut = process.env['ARENA_RAW_OUT'];
  if (rawOut !== undefined) writeFileSync(rawOut, JSON.stringify(raw));
});
