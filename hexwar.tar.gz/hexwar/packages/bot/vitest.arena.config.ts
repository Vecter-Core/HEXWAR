import { defineConfig } from 'vitest/config';

// Đấu thử hàng loạt để đo tỉ lệ thắng theo độ khó (PLAN 9.3, 9.5). Không chạy trong CI: chậm, chỉ để đo và ghi số liệu.
export default defineConfig({
  test: { include: ['test/**/*.arena.ts'], environment: 'node', testTimeout: 3_600_000 },
});
