import { defineConfig } from 'vitest/config';

// Test đơn vị của bot. Đấu thử hàng loạt (chậm) nằm riêng ở test/arena.bench.ts, chạy bằng `pnpm --filter @hexwar/bot arena`.
export default defineConfig({
  test: { include: ['test/**/*.test.ts'], environment: 'node', testTimeout: 120_000 },
});
