// PLAN M3 nghiệm thu ("Chơi được ván hotseat trên một máy") — giữ nguyên ở M4, nay ván chạy trong Web Worker thật
// qua GameSession (6 ghế người). e2e THẬT: trình duyệt thật (Chromium headless, xem playwright.config.ts +
// docs/perf.md), renderer THREE thật, Worker + engine thật. Bấm chuột dùng đúng toạ độ camera thật đang chạy trong
// trang (support.ts), không giả lập tuỳ tiện.
import { expect, test } from '@playwright/test';
import { autoPlay, collectConsoleErrors, debugSeq, debugState, findMovablePiece, openHotseat, screenPointOfCell, waitForSeq } from './support';

test('bấm chuột thật: nút tung xúc xắc → chọn quân → bấm ô đích thật sự đưa quân đi (qua Worker, không lỗi console)', async ({ page }) => {
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openHotseat(page, 20260924);

  expect((await debugState(page))?.phase).toBe('dice');
  await page.locator('.hud-dice').click();
  await waitForSeq(page, 1);
  await expect(page.locator('.hud-dice')).toBeHidden();
  expect((await debugState(page))?.phase).toBe('playing');

  const target = await findMovablePiece(page);
  expect(target, 'thế cờ đầu phải có ít nhất một quân đi được').not.toBeNull();
  const { pieceId, from, to } = target!;

  const fromPoint = await screenPointOfCell(page, from);
  await page.mouse.click(fromPoint.x, fromPoint.y);
  const selected = await page.evaluate(() => window.__hexwar?.selection()?.pieceId ?? null);
  expect(selected, 'bấm đúng vào quân của mình phải chọn được nó').toBe(pieceId);

  const seq = await debugSeq(page);
  const toPoint = await screenPointOfCell(page, to);
  await page.mouse.click(toPoint.x, toPoint.y);
  await waitForSeq(page, seq + 1);

  const moved = (await debugState(page))?.pieces.find((p) => p.id === pieceId);
  expect(moved?.cell).toEqual(to);
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('chơi hết một ván hotseat (qua đúng GameController + Worker thật) tới khi kết thúc, không lỗi, không kẹt', async ({ page }) => {
  test.setTimeout(600_000);
  const errors = collectConsoleErrors(page);
  await openHotseat(page, 7);

  const result = await autoPlay(page, 8000);
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
  expect(result.over, `chưa kết thúc sau ${result.actions} hành động`).toBe(true);

  const state = await debugState(page);
  expect(state?.phase).toBe('over');
  expect(state?.result?.ranking).toHaveLength(6);
  const ranks = (state?.result?.ranking ?? []).map((r) => r.rank);
  expect(Math.min(...ranks)).toBe(1);
  await expect(page.locator('.hud-result')).toBeVisible();

  // M5: mỗi hàng kết quả nay có thêm số quân còn lại + trạng thái còn sống/bị loại hiệp nào (RankEntry đã có sẵn
  // từ M2, chỉ là chưa hiển thị ở M4 — PLAN 11.6).
  const rows = await page.locator('.hud-result-row').allTextContents();
  expect(rows).toHaveLength(6);
  for (const row of rows) {
    expect(row).toMatch(/\d+ quân/);
    expect(row).toMatch(/còn sống|bị loại ở hiệp \d+/);
  }
});

test('vòng đời hoạt ảnh: sau khi mô phỏng, mọi quân trên bàn có toạ độ hữu hạn — không quân nào kẹt giữa hai ô', async ({ page }) => {
  // Hotseat: mọi lượt đều là "người" nên mỗi hành động chờ một vòng Worker ↔ khung hình (SwiftShader ~7 FPS).
  test.setTimeout(240_000);
  await openHotseat(page, 99);
  await autoPlay(page, 300);
  const settled = await page.evaluate(() => window.__hexwar?.state()?.pieces.every((p) => Number.isFinite(p.cell.q) && Number.isFinite(p.cell.r)) ?? null);
  expect(settled).toBe(true);
});
