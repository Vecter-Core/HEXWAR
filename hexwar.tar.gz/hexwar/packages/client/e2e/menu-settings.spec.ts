// M5 nghiệm thu (PLAN 15): "Đi hết luồng menu → ván → kết quả không lỗi; kiểm tra chữ Việt có dấu". e2e THẬT
// (trình duyệt thật, không autostart — đi đúng luồng người chơi thật sẽ bấm): menu chính → Cài đặt (ngôn ngữ, đồ
// hoạ, tuỳ chọn) → đóng → bắt đầu ván → HUD đầy đủ (bản đồ nhỏ, thông tin quân đang chọn, xác nhận nước đi X-14).
import { expect, test } from '@playwright/test';
import { collectConsoleErrors, findMovablePiece, openPage, screenPointOfCell, waitForSeq } from './support';

const SHOT_DIR = 'test-results/screenshots';

test('menu chính: chữ tiếng Việt có dấu hiển thị đúng (PLAN 11.7, nghiệm thu M5)', async ({ page }) => {
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, '', false); // không autostart: đúng màn bắt đầu thật, chưa vào ván

  // .menu-title cũng dùng ở tiêu đề bảng Cài đặt (ẩn qua CSS, vẫn có mặt trong DOM) — chỉ nhắm menu chính.
  await expect(page.locator('.menu.main .menu-title')).toHaveText('HEXWAR');
  await expect(page.locator('.menu.main .menu-subtitle')).toHaveText('Cờ lục giác 6 người · Bạn đấu với 5 bot');
  await expect(page.locator('.menu-hotseat')).toHaveText('Hotseat: 6 người chơi chung một máy');
  await page.screenshot({ path: `${SHOT_DIR}/8-menu-vi.png` });
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('Cài đặt: đổi ngôn ngữ sang English (tải lại trang), đồ hoạ, tuỳ chọn — lưu lại đúng qua localStorage', async ({ page }) => {
  // M10: mức đồ hoạ "Cao" bật SSAO + bloom qua `EffectComposer` (PLAN 12.5) — trên phần cứng render bằng phần mềm
  // của môi trường này (SwiftShader, không GPU thật, xem docs/perf.md), MỘT khung hình ở mức đó có thể mất hơn 1
  // giây, nên vòng lặp vẽ chiếm phần lớn luồng chính và làm mọi thao tác chuột/phím sau đó (kể cả sau khi tải lại,
  // vì mức đồ hoạ đã lưu) chậm hẳn đi — không phải một lỗi chức năng, chỉ là môi trường không có GPU thật để tăng
  // tốc hậu kỳ. Cho bài kiểm này nhiều thời gian hơn mức mặc định (60s) thay vì hạ mức đồ hoạ xuống để "test cho
  // qua" (CLAUDE.md cấm sửa test để né lỗi thật) — trên máy có GPU thật, một khung hình ở mức Cao vẫn rất ngắn nên
  // giới hạn mặc định là đủ; xem docs/decisions.md mục M10.
  test.setTimeout(180_000);
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, '', false);

  await page.locator('.menu-settings').click();
  await expect(page.locator('.settings-title')).toBeVisible();
  await expect(page.locator('.settings-title')).toHaveText('Cài đặt');

  // Đồ hoạ: chọn "Cao".
  await page.locator('.settings .menu-choices').nth(1).getByText('Cao').click();
  await expect(page.locator('.settings .menu-choices').nth(1).getByText('Cao')).toHaveClass(/menu-choice-on/);

  // Giảm chuyển động: bật.
  const reduceMotion = page.locator('.settings-toggle input').nth(0);
  await reduceMotion.check();
  await expect(reduceMotion).toBeChecked();

  // M10 (PLAN 11.5 "Âm thanh: Tổng, nhạc, hiệu ứng"): kéo thanh trượt âm lượng tổng xuống 30%.
  const volumeMaster = page.locator('.settings-slider input').nth(0);
  await volumeMaster.fill('30');
  await volumeMaster.dispatchEvent('input');
  await expect(volumeMaster).toHaveValue('30');

  await page.screenshot({ path: `${SHOT_DIR}/9-settings.png` });

  // Ngôn ngữ: English — trang tải lại (docs/decisions.md: đơn giản và chắc chắn hơn làm mọi thứ phản ứng theo locale).
  await page.locator('.settings .menu-choices').first().getByText('English').click();
  await page.waitForFunction(() => document.querySelector('.menu-title')?.textContent === 'HEXWAR');
  await expect(page.locator('.menu.main .menu-subtitle')).toHaveText('Six-player hex chess · You versus 5 bots');

  // Mở lại Cài đặt: mức đồ hoạ + giảm chuyển động + âm lượng tổng phải còn nguyên (đã lưu ở localStorage trước khi tải lại).
  await page.locator('.menu-settings').click();
  await expect(page.locator('.settings .menu-choices').nth(1).getByText('High')).toHaveClass(/menu-choice-on/);
  await expect(page.locator('.settings-toggle input').nth(0)).toBeChecked();
  await expect(page.locator('.settings-slider input').nth(0)).toHaveValue('30');

  // Đổi lại tiếng Việt để không ảnh hưởng các test khác chạy sau (mỗi test là một trang mới nên thực ra không cần,
  // nhưng làm rõ ý rằng đổi qua đổi lại không kẹt trạng thái).
  await page.locator('.settings .menu-choices').first().getByText('Tiếng Việt').click();
  await page.waitForFunction(() => document.querySelector('.menu-title')?.textContent === 'HEXWAR');
  await expect(page.locator('.menu.main .menu-subtitle')).toHaveText('Cờ lục giác 6 người · Bạn đấu với 5 bot');

  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('X-14 (xác nhận nước đi): bật ở Cài đặt rồi vào ván hotseat — bấm ô đích lần 1 CHƯA đi, bấm "Xác nhận" mới đi', async ({ page }) => {
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, 'fast=1', false);

  await page.locator('.menu-settings').click();
  const confirmMoves = page.locator('.settings-toggle input').nth(2); // thứ tự dựng: giảm chuyển động, đe doạ, xác nhận nước đi
  await confirmMoves.check();
  await page.locator('.settings-close').click();

  await page.locator('.menu-hotseat').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  await page.locator('.hud-dice').click();
  await waitForSeq(page, 1);

  const target = await findMovablePiece(page);
  expect(target, 'thế cờ đầu phải có ít nhất một quân đi được').not.toBeNull();
  const { pieceId, from, to } = target!;
  const before = await page.evaluate(() => window.__hexwar?.state()?.pieces ?? null);

  const fromPoint = await screenPointOfCell(page, from);
  await page.mouse.click(fromPoint.x, fromPoint.y);
  const toPoint = await screenPointOfCell(page, to);
  await page.mouse.click(toPoint.x, toPoint.y);

  // X-14: lần bấm đầu chỉ ĐẶT ô đích đang chờ — bàn cờ CHƯA đổi, bảng thông tin hiện nút Xác nhận/Hủy.
  await expect(page.locator('.hud-selection-actions')).toBeVisible();
  const afterFirstClick = await page.evaluate(() => window.__hexwar?.state()?.pieces ?? null);
  expect(afterFirstClick).toEqual(before);

  const seq = await page.evaluate(() => window.__hexwar?.seq() ?? 0);
  await page.locator('.hud-selection-actions .hud-btn-primary').click(); // nút "Xác nhận"
  await waitForSeq(page, seq + 1);

  const moved = await page.evaluate((id) => window.__hexwar?.state()?.pieces.find((p) => p.id === id) ?? null, pieceId);
  expect(moved?.cell).toEqual(to);
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});
