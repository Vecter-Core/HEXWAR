// PLAN M6.4 nghiệm thu: client THẬT (trình duyệt thật) nói chuyện với SERVER THẬT (@hexwar/server) qua WebSocket
// thật — không mock ở tầng nào. Server chạy ngay trong tiến trình test Playwright (Node), lắng nghe trên một cổng
// cố định khác với Vite (4310, playwright.config.ts) để client mở qua `?server=ws://127.0.0.1:<cổng>` kết nối tới
// (xem src/net/websocket-transport.ts: `resolveServerUrl`).
import { expect, test } from '@playwright/test';
import { HexwarServer } from '@hexwar/server';
import { defaultConfig } from '@hexwar/rules';
import { collectConsoleErrors, debugSeq, debugState, findMovablePiece, openPage, screenPointOfCell, waitForSeq } from './support';

const SERVER_PORT = 4311;
/** Giống `?fast=1` phía client (main.ts) — bot đi ngay, không hoạt ảnh, để test chạy trong vài giây thật. */
const FAST_TIMING = { botDelayMinMs: 0, botDelayMaxMs: 0, spectatorBotDelayMs: 0, autoDiceMs: 0, graceMoveMs: 0, graceCollapseMs: 0 };

let server: HexwarServer | null = null;

test.afterEach(async () => {
  await server?.close();
  server = null;
});

test('menu → Chơi online → Ghép nhanh: bot lấp 5 ghế, ván tự bắt đầu và chơi được qua WebSocket thật (PLAN 7.2)', async ({ page }) => {
  test.setTimeout(60_000);
  const errors = collectConsoleErrors(page);
  server = new HexwarServer({ rulesVersion: defaultConfig.rulesVersion, botFillDelayMs: 200, timing: FAST_TIMING }, { port: SERVER_PORT });
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, `server=ws://127.0.0.1:${SERVER_PORT}`, false);

  await page.locator('.menu-online').click();
  await expect(page.locator('.menu.online')).toBeVisible();
  await page.locator('.online-quick').click();

  await expect(page.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('.lobby-seat')).toHaveCount(6);

  // Bot lấp đủ 6 ghế sau botFillDelayMs -> phòng tự bắt đầu -> HUD hiện ra, phòng chờ ẩn đi.
  await page.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 10_000 });
  await expect(page.locator('.menu.lobby')).toBeHidden();
  await expect(page.locator('.hud-player')).toHaveCount(6);
  await expect(page.locator('.hud-player-you')).toHaveCount(1);

  await waitForSeq(page, 1); // autoDiceMs=0 -> tự tung xúc xắc ngay

  // Đợi tới đúng lượt của mình (thứ tự đi do xúc xắc quyết, không đoán trước được) rồi đi thật một nước qua server.
  await page.waitForFunction(
    () => {
      const state = window.__hexwar?.state();
      const you = window.__hexwar?.you() ?? [];
      return state !== null && state !== undefined && you.length === 1 && state.turnSeat === you[0];
    },
    undefined,
    { timeout: 20_000 },
  );
  const seq = await debugSeq(page);
  const target = await findMovablePiece(page);
  expect(target, 'tới lượt mình phải tìm được ít nhất một nước đi hợp lệ trong khung hình').not.toBeNull();
  const from = await screenPointOfCell(page, target!.from);
  await page.mouse.click(from.x, from.y);
  const to = await screenPointOfCell(page, target!.to);
  await page.mouse.click(to.x, to.y);
  await waitForSeq(page, seq + 1);
  const moved = (await debugState(page))?.pieces.find((p) => p.id === target!.pieceId);
  expect(moved?.cell).toEqual(target!.to);

  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('tạo phòng riêng, vào bằng mã ở tab khác, chủ phòng thêm bot, cả hai Sẵn sàng -> ván bắt đầu ở cả hai tab (PLAN 7.2)', async ({
  page,
  context,
}) => {
  test.setTimeout(60_000);
  server = new HexwarServer({ rulesVersion: defaultConfig.rulesVersion, timing: FAST_TIMING }, { port: SERVER_PORT });
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, `server=ws://127.0.0.1:${SERVER_PORT}`, false);

  await page.locator('.menu-online').click();
  await page.locator('.online-create').click();
  await expect(page.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  const codeText = (await page.locator('.lobby-code').textContent()) ?? '';
  const code = codeText.split(': ')[1]?.trim() ?? '';
  expect(code).toHaveLength(6);

  const page2 = await context.newPage();
  await page2.setViewportSize({ width: 1280, height: 720 });
  await openPage(page2, `server=ws://127.0.0.1:${SERVER_PORT}`, false);
  await page2.locator('.menu-online').click();
  await page2.locator('.online-code-input').fill(code);
  await page2.locator('.online-join').click();
  await expect(page2.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('.lobby-seat')).toHaveCount(6); // room.state cập nhật cho chủ phòng khi có người vào

  for (let i = 0; i < 4; i++) await page.locator('.lobby-add-bot').click();
  await page.locator('.lobby-ready').click();
  await page2.locator('.lobby-ready').click();

  await page.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 10_000 });
  await page2.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 10_000 });
  await expect(page.locator('.hud-player')).toHaveCount(6);
  await expect(page2.locator('.hud-player')).toHaveCount(6);
  // Vá lỗi "you" cho nhiều kết nối (docs/decisions.md M6): hai tab phải thấy đúng hai ghế KHÁC nhau.
  const seatA = await page.evaluate(() => window.__hexwar?.you() ?? []);
  const seatB = await page2.evaluate(() => window.__hexwar?.you() ?? []);
  expect(seatA).toHaveLength(1);
  expect(seatB).toHaveLength(1);
  expect(seatA[0]).not.toBe(seatB[0]);

  await page2.close();
});
