// M3.4 (PLAN M3 nghiệm thu: "60 FPS mức Thấp") + PLAN 12.5: "Đo và ghi vào docs/perf.md ở mỗi milestone đồ hoạ".
// QUAN TRỌNG: môi trường này dùng Chromium headless + SwiftShader (raster hoá bằng phần mềm, xem docs/perf.md) —
// số FPS đo được ở đây KHÔNG đại diện cho GPU thật. Test chỉ khẳng định vòng lặp vẽ không bị treo (còn chạy được),
// không khẳng định đạt 60 FPS trên phần cứng thật. Số đo được chép tay vào docs/perf.md sau khi chạy.
//
// M10: ngưỡng "còn sống" hạ từ 5 xuống 2 — mức đồ hoạ mặc định "Vừa" nay bật bóng đổ + bloom qua `EffectComposer`
// (PLAN 12.5), đo thật dưới SwiftShader chỉ còn ~3,2-3,3 FPS (trước M10 là ~7 FPS, không hậu kỳ). Đây KHÔNG phải
// treo — vẫn tiến đều theo thời gian thật, chỉ là một khung hình có hậu kỳ tốn nhiều hơn trên phần cứng không có
// GPU thật; trên máy có GPU thật chi phí này gần như không đáng kể. Hạ ngưỡng thay vì tắt bóng/bloom mặc định để
// "test cho qua" (CLAUDE.md cấm sửa test để né lỗi thật — hành vi PLAN 12.5 muốn đúng là bật hậu kỳ nhẹ ở mức Vừa).
import { expect, test, type Page } from '@playwright/test';
import { openHotseat, waitForSeq } from './support';

async function measureFps(page: Page, seconds: number): Promise<number> {
  return page.evaluate(async (durationMs) => {
    let frames = 0;
    const start = performance.now();
    await new Promise<void>((resolve) => {
      function tick(): void {
        frames++;
        if (performance.now() - start >= durationMs) resolve();
        else requestAnimationFrame(tick);
      }
      requestAnimationFrame(tick);
    });
    const elapsed = (performance.now() - start) / 1000;
    return frames / elapsed;
  }, seconds * 1000);
}

test('vòng lặp vẽ chạy ổn định ở thế cờ đầu (1801 ô + 108 quân), không treo', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await openHotseat(page, 1);
  await page.waitForTimeout(300);
  const fps = await measureFps(page, 2);
  console.log(`[perf] thế cờ đầu (đứng yên): ${fps.toFixed(1)} FPS (SwiftShader phần mềm — xem docs/perf.md)`);
  expect(fps, 'vòng lặp vẽ phải còn sống (không treo hoàn toàn)').toBeGreaterThan(2);
});

test('vòng lặp vẽ vẫn chạy khi đang có hoạt ảnh + tô ô đi được', async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await openHotseat(page, 1);
  await page.locator('.hud-dice').click();
  await waitForSeq(page, 1);
  await expect(page.locator('.hud-dice')).toBeHidden();
  await page.evaluate(() => {
    const hook = window.__hexwar!;
    const state = hook.state();
    const piece = state?.pieces.find((p) => p.status === 'active' && p.owner === state.turnSeat);
    if (piece !== undefined) hook.select(piece.id);
  });
  const fps = await measureFps(page, 2);
  console.log(`[perf] đang tô ô đi được: ${fps.toFixed(1)} FPS (SwiftShader phần mềm — xem docs/perf.md)`);
  expect(fps).toBeGreaterThan(2);
});
