// M3.4 (PLAN M3 nghiệm thu: "ảnh chụp Playwright"). Chụp 4 cảnh chuẩn của renderer thật (không phải ảnh tĩnh vẽ
// tay): thế cờ đầu, quân đang chọn (tô ô đi được), vừa ăn quân (có tù binh), và bàn đã thu hẹp một vòng. Ảnh lưu
// vào test-results/ qua `page.screenshot`; đây là bằng chứng render được, KHÔNG so khớp điểm ảnh (môi trường này
// dùng SwiftShader phần mềm, xem docs/perf.md — so khớp điểm ảnh tuyệt đối giữa các máy sẽ không ổn định).
import { expect, test } from '@playwright/test';
import { openHotseat, playUntil, waitForSeq } from './support';

const SHOT_DIR = 'test-results/screenshots';

test.describe('Ảnh chụp cảnh chuẩn (renderer thật)', () => {
  test('1. Thế cờ đầu (pha tung xúc xắc, đủ 6 màu ghế)', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 720 });
    await openHotseat(page, 1);
    await page.waitForTimeout(300); // một khung hình cho renderer vẽ xong lần đầu.
    await expect(page.locator('.hud-dice')).toBeVisible();
    await page.screenshot({ path: `${SHOT_DIR}/1-initial-position.png` });
  });

  test('2. Quân đang chọn: ô đi được tô xanh, ô ăn được tô đỏ (PLAN 11.2)', async ({ page }) => {
    await page.setViewportSize({ width: 1280, height: 720 });
    await openHotseat(page, 1);
    await page.locator('.hud-dice').click();
    await waitForSeq(page, 1);
    await expect(page.locator('.hud-dice')).toBeHidden();

    const picked = await page.evaluate(() => {
      const hook = window.__hexwar;
      const state = hook?.state();
      if (hook === undefined || state === null || state === undefined) return null;
      const seat = state.turnSeat;
      const piece = state.pieces.find((p) => p.status === 'active' && p.owner === seat && p.type === 'P');
      if (piece === undefined) return null;
      hook.select(piece.id);
      return { id: piece.id, moveCount: hook.selection()?.moves.size ?? 0 };
    });
    expect(picked?.moveCount ?? 0).toBeGreaterThan(0);
    await page.waitForTimeout(150);
    await page.screenshot({ path: `${SHOT_DIR}/2-piece-selected.png` });
  });

  test('3. Vừa ăn quân: có ít nhất một tù binh trên bàn', async ({ page }) => {
    // M10: mức đồ hoạ mặc định "Vừa" nay bật bóng đổ + bloom qua `EffectComposer` (PLAN 12.5) — chậm hơn hẳn so với
    // trước M10 trên phần cứng render bằng phần mềm của môi trường này (không GPU thật, xem docs/perf.md), nên cần
    // nhiều thời gian hơn 90s cũ để chạy đủ số hành động tới khi có nước ăn quân. Không hạ mức đồ hoạ mặc định để
    // "test cho qua" (CLAUDE.md cấm sửa test để né lỗi thật) vì hành vi PLAN 12.5 muốn đúng là bật bóng/bloom ở mức
    // Vừa; trên máy có GPU thật việc này vẫn nhanh như trước.
    test.setTimeout(180_000);
    await page.setViewportSize({ width: 1280, height: 720 });
    await openHotseat(page, 3);
    const result = await playUntil(page, (agg) => agg.captured || agg.over, 400, 1);
    expect(result.captured, `không xảy ra nước ăn quân nào trong ${result.actions} hành động`).toBe(true);

    const hasCaptive = await page.evaluate(() => window.__hexwar?.state()?.pieces.some((p) => p.status === 'captive') ?? false);
    expect(hasCaptive).toBe(true);
    await page.waitForTimeout(150);
    await page.screenshot({ path: `${SHOT_DIR}/3-captured-captive.png` });
  });

  test('4. Bàn đã thu hẹp: bán kính nhỏ hơn bán kính ban đầu (R-70..R-72)', async ({ page }) => {
    test.setTimeout(300_000);
    await page.setViewportSize({ width: 1280, height: 720 });
    await openHotseat(page, 5);
    const initialRadius = await page.evaluate(() => window.__hexwar?.state()?.radius ?? -1);

    const result = await playUntil(page, (agg) => agg.collapsed || agg.over, 3000, 25);
    expect(result.collapsed || result.over, `chưa thu hẹp lần nào sau ${result.actions} hành động`).toBe(true);

    const radius = await page.evaluate(() => window.__hexwar?.state()?.radius ?? -1);
    expect(radius).toBeLessThan(initialRadius);
    await page.waitForTimeout(150);
    await page.screenshot({ path: `${SHOT_DIR}/4-ring-collapsed.png` });
  });
});
