// PLAN M4 nghiệm thu: "Chơi trọn ván 1 vs 5 bot từ đầu tới kết thúc, thoát và vào lại được". e2e THẬT: trình
// duyệt thật, bấm nút trên màn bắt đầu/HUD thật, ván chạy trong Web Worker thật (GameSession + bot), lưu vào
// localStorage thật, "thoát" = tải lại hẳn trang (Worker cũ bị huỷ). Nước đi của người chơi đi qua đúng GameController
// (móc gỡ lỗi chỉ thay bước chuột → ô; bấm chuột thật có test riêng bên dưới và ở hotseat.spec.ts).
import { expect, test } from '@playwright/test';
import {
  autoPlay,
  collectConsoleErrors,
  debugHash,
  debugSeq,
  debugState,
  findMovablePiece,
  openPage,
  openSolo,
  screenPointOfCell,
  waitForSeq,
} from './support';

const SHOT_DIR = 'test-results/screenshots';

test('màn bắt đầu → ván mới 1 vs 5 bot → chơi → "Lưu & thoát" → tải lại trang → "Tiếp tục" đúng thế cờ (X-10)', async ({ page }) => {
  test.setTimeout(300_000);
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });

  // Màn bắt đầu thật (không autostart). Xoá ván lưu cũ nếu có để test độc lập.
  await openPage(page, 'seed=424242&fast=1', false);
  await page.evaluate(() => localStorage.clear());
  await page.reload();
  await page.waitForFunction(() => window.__hexwar !== undefined);
  await expect(page.locator('.menu.main')).toBeVisible();
  await expect(page.locator('.menu-continue')).toBeDisabled();
  await page.screenshot({ path: `${SHOT_DIR}/5-menu.png` });

  await page.locator('.menu-choice[data-difficulty="normal"]').click();
  await page.locator('.menu-new').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  await expect(page.locator('.menu.main')).toBeHidden();

  // HUD tối thiểu (PLAN 15 M4): 6 người, đúng 1 "Bạn", 5 BOT.
  await expect(page.locator('.hud-player')).toHaveCount(6);
  await expect(page.locator('.hud-player-you')).toHaveCount(1);
  await expect(page.locator('.hud-player .hud-tag', { hasText: 'BOT' })).toHaveCount(5);
  expect(await page.evaluate(() => window.__hexwar?.you())).toEqual([424242 % 6]);

  // Chơi một đoạn: nước của mình qua controller, bot đi trong Worker.
  await autoPlay(page, 120);
  const state = await debugState(page);
  expect(state?.phase).toBe('playing');
  await page.screenshot({ path: `${SHOT_DIR}/6-solo-hud.png` });

  // Đợi bản tự lưu của hành động mới nhất, rồi "Lưu & thoát".
  const seq = await debugSeq(page);
  const hashBefore = await debugHash(page);
  await page.waitForFunction((n) => (JSON.parse(localStorage.getItem('hexwar.solo.v1') ?? '{}') as { save?: { actions?: unknown[] } }).save?.actions?.length === n, seq);
  await page.locator('.hud-exit').click();
  await expect(page.locator('.menu.main')).toBeVisible();
  await expect(page.locator('.menu-continue')).toBeEnabled();
  await expect(page.locator('.menu.main .menu-info')).toContainText(`hiệp ${state?.round}`);

  // "Thoát" hẳn: tải lại trang (Worker và mọi trạng thái trong bộ nhớ mất). Vào lại từ màn bắt đầu.
  await page.reload();
  await page.waitForFunction(() => window.__hexwar !== undefined);
  await expect(page.locator('.menu-continue')).toBeEnabled();
  await page.locator('.menu-continue').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  expect(await debugHash(page)).toBe(hashBefore);
  expect(await debugSeq(page)).toBe(seq);

  // Chơi tiếp được sau khi vào lại.
  const more = await autoPlay(page, 30);
  expect(more.actions).toBeGreaterThanOrEqual(30);
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('chơi TRỌN ván 1 vs 5 bot tới khi kết thúc; màn kết quả; bản lưu bị xoá (không còn gì để tiếp tục)', async ({ page }) => {
  test.setTimeout(900_000);
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openSolo(page, 777, { difficulty: 'mixed' });

  const result = await autoPlay(page, 100_000);
  expect(result.over, `chưa kết thúc sau ${result.actions} hành động`).toBe(true);
  const state = await debugState(page);
  expect(state?.phase).toBe('over');
  expect(state?.result?.ranking).toHaveLength(6);

  console.log(`[m4] ván trọn 1 vs 5 bot: ${result.actions} hành động, kết thúc ở hiệp ${state?.round} (${state?.result?.reason})`);
  await expect(page.locator('.hud-result')).toBeVisible();
  await expect(page.locator('.hud-result-row')).toHaveCount(6);
  await expect(page.locator('.hud-exit')).toBeHidden();
  await page.waitForTimeout(200);
  await page.screenshot({ path: `${SHOT_DIR}/7-solo-result.png` });

  await page.waitForFunction(() => localStorage.getItem('hexwar.solo.v1') === null);
  await page.locator('.hud-result-actions .hud-btn:not(.hud-btn-primary)').click();
  await expect(page.locator('.menu.main')).toBeVisible();
  await expect(page.locator('.menu-continue')).toBeDisabled();
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('bấm chuột thật trong ván solo: đi quân của mình qua Worker; đồng hồ lượt thật chạy trên HUD (R-12)', async ({ page }) => {
  test.setTimeout(180_000);
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  // Không `fast`: bot "nghĩ" 1–6 giây như thật (PLAN 9.1); người chơi có 60 giây.
  await openSolo(page, 12, { fast: false });
  await page.locator('.hud-dice').click();
  await waitForSeq(page, 1);

  await expect(page.locator('.hud-turn-mine')).toBeVisible({ timeout: 60_000 });
  await expect(page.locator('.hud-clock')).toHaveText(/^\d+ giây$/);
  const seconds = Number((await page.locator('.hud-clock').textContent())?.split(' ')[0]);
  expect(seconds).toBeGreaterThan(50);
  expect(seconds).toBeLessThanOrEqual(61);

  const target = await findMovablePiece(page);
  expect(target).not.toBeNull();
  const seq = await debugSeq(page);
  const from = await screenPointOfCell(page, target!.from);
  await page.mouse.click(from.x, from.y);
  expect(await page.evaluate(() => window.__hexwar?.selection()?.pieceId ?? null)).toBe(target!.pieceId);
  const to = await screenPointOfCell(page, target!.to);
  await page.mouse.click(to.x, to.y);
  await waitForSeq(page, seq + 1);
  const moved = (await debugState(page))?.pieces.find((p) => p.id === target!.pieceId);
  expect(moved?.cell).toEqual(target!.to);

  // Ngay sau đó là lượt bot: không có đồng hồ của mình, bấm vào quân mình không chọn được.
  await expect(page.locator('.hud-turn-mine')).toBeHidden();
  const back = await screenPointOfCell(page, target!.to);
  await page.mouse.click(back.x, back.y);
  expect(await page.evaluate(() => window.__hexwar?.selection() ?? null)).toBeNull();
  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});

test('bản lưu hỏng: màn bắt đầu báo lỗi bằng chữ, xoá bản lưu, không treo', async ({ page }) => {
  await openPage(page, 'seed=5', false);
  await page.evaluate(() => localStorage.setItem('hexwar.solo.v1', JSON.stringify({ save: { format: 'hexwar-save', version: 1 }, meta: { round: 9, savedAt: 1 } })));
  await page.reload();
  await page.waitForFunction(() => window.__hexwar !== undefined);
  await expect(page.locator('.menu.main .menu-info')).toContainText('hiệp 9');
  await page.locator('.menu-continue').click();
  await expect(page.locator('.menu.main .menu-error')).toContainText('sai định dạng');
  await expect(page.locator('.menu-continue')).toBeDisabled();
});
