// Tiện ích dùng chung cho các spec Playwright. Không phải test, không có `test()`/`expect()` ở đây.
// Từ M4 ván chạy trong Web Worker thật: mọi thao tác qua móc gỡ lỗi đều bất đồng bộ (xem src/app/e2e-hook.ts).
import type { Page } from '@playwright/test';
import type { Cell } from '@hexwar/rules';
import { FOV_DEG, cameraPose, projectToNdc } from '../src/core/camera';
import type { DebugHook } from '../src/app/e2e-hook';
import { cellCenter } from '../src/core/layout';

declare global {
  interface Window {
    __hexwar?: DebugHook;
  }
}

export function collectConsoleErrors(page: Page): string[] {
  const errors: string[] = [];
  page.on('console', (msg) => {
    if (msg.type() === 'error') errors.push(msg.text());
  });
  page.on('pageerror', (err) => errors.push(`pageerror: ${err.message}`));
  return errors;
}

/** Mở trang với móc gỡ lỗi và đợi tới khi ván (nếu có `autostart`) đã nhận trạng thái đầu từ Worker. */
export async function openPage(page: Page, query: string, waitForGame = true): Promise<void> {
  await page.goto(`/?${query}&e2e=1`);
  await page.waitForFunction(() => window.__hexwar !== undefined);
  if (waitForGame) await page.waitForFunction(() => window.__hexwar?.state() !== null);
}

/** Ván hotseat 6 người (chế độ M3), bot không tham gia; `fast` để hạn lượt không chen vào. */
export async function openHotseat(page: Page, seed: number): Promise<void> {
  await openPage(page, `autostart=hotseat&seed=${seed}&fast=1`);
}

/** Ván solo 1 người + 5 bot (M4). `fast`: bot đi ngay (chỉ cho kiểm thử). */
export async function openSolo(page: Page, seed: number, options: { difficulty?: string; fast?: boolean } = {}): Promise<void> {
  const fast = options.fast ?? true ? '&fast=1' : '';
  await openPage(page, `autostart=solo&seed=${seed}&difficulty=${options.difficulty ?? 'mixed'}${fast}`);
}

export async function debugState(page: Page) {
  return page.evaluate(() => window.__hexwar?.state() ?? null);
}

export async function debugSeq(page: Page): Promise<number> {
  return page.evaluate(() => window.__hexwar?.seq() ?? 0);
}

export async function debugHash(page: Page): Promise<string | null> {
  return page.evaluate(() => window.__hexwar?.hash() ?? null);
}

export async function waitForSeq(page: Page, target: number): Promise<void> {
  const ok = await page.evaluate((n) => window.__hexwar?.waitForSeq(n) ?? Promise.resolve(false), target);
  if (!ok) throw new Error(`waitForSeq: không tới được seq ${target}`);
}

export async function autoPlay(page: Page, maxActions: number) {
  return page.evaluate((n) => {
    const hook = window.__hexwar;
    if (hook === undefined) throw new Error('__hexwar chưa sẵn sàng');
    return hook.autoPlay(n);
  }, maxActions);
}

/**
 * Chơi theo từng đợt `batchSize` hành động tới khi `captured`/`collapsed` (gộp dồn qua các đợt) hoặc kết thúc ván.
 * Đợt nhỏ (mặc định 1) để không "đi lố" qua mất trạng thái muốn chụp (ví dụ tù binh có thể được cứu/hết hạn ở
 * ngay hành động kế); thu hẹp bàn thì không cần vì bán kính không bao giờ tăng lại — có thể dùng đợt lớn hơn.
 */
export async function playUntil(
  page: Page,
  stopWhen: (agg: { captured: boolean; collapsed: boolean; over: boolean }) => boolean,
  maxTotal: number,
  batchSize = 1,
): Promise<{ actions: number; captured: boolean; collapsed: boolean; over: boolean }> {
  const agg = { actions: 0, captured: false, collapsed: false, over: false };
  while (agg.actions < maxTotal && !stopWhen(agg)) {
    const step = await autoPlay(page, batchSize);
    agg.actions += step.actions;
    agg.captured ||= step.captured;
    agg.collapsed ||= step.collapsed;
    agg.over = step.over;
    if (step.actions === 0 || step.over) break;
  }
  return agg;
}

/**
 * Toạ độ pixel (CSS) trên trang của tâm một ô, dùng ĐÚNG công thức camera thật (core/camera.ts) đang chạy trong
 * trang — để test bấm chuột thật (không phải giả lập sự kiện DOM tuỳ tiện) tại đúng vị trí quân/ô hiển thị.
 */
export async function screenPointOfCell(page: Page, cell: Cell): Promise<{ x: number; y: number }> {
  const viewport = page.viewportSize();
  if (viewport === null) throw new Error('screenPointOfCell: thiếu viewport');
  const orbit = await page.evaluate(() => window.__hexwar?.getOrbit() ?? null);
  if (orbit === null) throw new Error('__hexwar chưa sẵn sàng');
  const pose = cameraPose(orbit);
  const center = cellCenter(cell);
  const ndc = projectToNdc(pose, { x: center.x, y: 0, z: center.z }, FOV_DEG, viewport.width / viewport.height);
  if (ndc === null) throw new Error('screenPointOfCell: ô nằm sau camera (chỉnh lại orbit hoặc chọn ô khác)');
  return { x: ((ndc.x + 1) / 2) * viewport.width, y: ((1 - ndc.y) / 2) * viewport.height };
}

/**
 * Một quân của người đang tới lượt có nước đi hợp lệ, cùng ô đích, mà CẢ HAI ô đều nằm trong khung hình camera
 * hiện tại (xem `DebugHook.findMovablePiece`, src/app/e2e-hook.ts) — dùng phép chiếu camera THẬT của trang, không
 * phải mọi ô hợp lệ đều nhìn thấy được ở góc camera "toàn cảnh" hotseat, nên không thể bấm chuột thật vào đó.
 */
export async function findMovablePiece(page: Page): Promise<{ pieceId: string; from: Cell; to: Cell } | null> {
  return page.evaluate(() => window.__hexwar?.findMovablePiece() ?? null);
}
