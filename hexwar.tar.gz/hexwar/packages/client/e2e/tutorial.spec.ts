// M8 (PLAN mục 10.1): màn tân thủ chạy trên đúng TutorialTransport + GameLink/Hud/BoardScene thật, không mô
// phỏng riêng. e2e THẬT: trình duyệt thật, bấm chuột thật vào toạ độ camera thật đang chạy trong trang (giống
// hotseat.spec.ts/solo.spec.ts), chỉ dùng móc gỡ lỗi (`window.__hexwar`) để chọn quân/đọc lại trạng thái, không
// để nó "chơi hộ" nước đi.
import { expect, test, type Page } from '@playwright/test';
import { collectConsoleErrors, openPage, screenPointOfCell, waitForSeq } from './support';

interface StoredTutorialProgress {
  readonly completed?: readonly string[];
  readonly started?: boolean;
}

async function readProgress(page: Page): Promise<StoredTutorialProgress | null> {
  const raw = await page.evaluate(() => localStorage.getItem('hexwar.tutorial.v1'));
  return raw === null ? null : (JSON.parse(raw) as StoredTutorialProgress);
}

test('menu → tân thủ → hoàn thành T1 bằng bấm chuột thật; "Bỏ qua" không đánh dấu hoàn thành; tiến độ bền qua tải lại trang', async ({ page }) => {
  const errors = collectConsoleErrors(page);
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, '', false); // màn bắt đầu bình thường (e2e=1 luôn tắt tự mở tân thủ lần đầu, xem main.ts)

  await expect(page.locator('.menu.main')).toBeVisible();
  await page.locator('.menu-tutorial').click();
  await expect(page.locator('.tutorial-picker')).toBeVisible();

  // ---- T1: hai bước lời thoại rồi tới bước "đi 1 nước bất kỳ" ------------------------------------------------
  await page.locator('.tutorial-lesson-btn[data-lesson="T1"]').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  await expect(page.locator('.tutorial-picker')).toBeHidden();
  await expect(page.locator('.tutorial-step-title')).toHaveText('Làm quen bàn cờ');

  await page.locator('.tutorial-continue').click();
  await expect(page.locator('.tutorial-step-text')).toContainText('Bản đồ nhỏ');
  await page.locator('.tutorial-continue').click();
  await expect(page.locator('.tutorial-continue')).toHaveCount(0); // bước 'move': không còn nút "Tiếp tục"
  await expect(page.locator('.tutorial-step-text')).toContainText('Chọn Vua');

  const king = 't1-king';
  await page.evaluate((id) => window.__hexwar?.select(id), king);
  expect(await page.evaluate(() => window.__hexwar?.selection()?.pieceId ?? null)).toBe(king);
  const moves = await page.evaluate((id) => window.__hexwar?.legalMovesOf(id) ?? [], king);
  expect(moves.length, 'Vua ở giữa bàn trống phải có nước đi').toBeGreaterThan(0);

  const seqBefore = await page.evaluate(() => window.__hexwar?.seq() ?? 0);
  const target = await screenPointOfCell(page, moves[0]!.to);
  await page.mouse.click(target.x, target.y);
  await waitForSeq(page, seqBefore + 1);

  // Mục tiêu T1 là "đi nước nào cũng được" nên thoả ngay — bài kết thúc, tiến độ được ghi nhận.
  await expect(page.locator('.tutorial-step-text')).toHaveText('Xong bài! Bạn có thể học tiếp bài kế hoặc quay lại danh sách.');
  await expect(page.locator('.tutorial-next')).toBeVisible();

  const afterT1 = await readProgress(page);
  expect(afterT1?.completed).toEqual(['T1']);
  expect(afterT1?.started).toBe(true);

  // ---- Về danh sách, chọn T2 rồi "Bỏ qua": sang T3, KHÔNG đánh dấu T2 hoàn thành -------------------------------
  await page.locator('.tutorial-done-back').click();
  await expect(page.locator('.tutorial-picker')).toBeVisible();
  await expect(page.locator('.tutorial-lesson-btn[data-lesson="T1"].tutorial-lesson-completed')).toBeVisible();

  await page.locator('.tutorial-lesson-btn[data-lesson="T2"]').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  await expect(page.locator('.tutorial-step-title')).toHaveText('Quân Tốt');
  await page.locator('.tutorial-skip').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null);
  await expect(page.locator('.tutorial-step-title')).toHaveText('Quân Xe');

  const afterSkip = await readProgress(page);
  expect(afterSkip?.completed).toEqual(['T1']); // T2 bị bỏ qua, không nằm trong danh sách đã hoàn thành

  // ---- Tải lại trang: tiến độ vẫn còn (đọc từ localStorage, không phải bộ nhớ trong của trang) ------------------
  await page.reload();
  await page.waitForFunction(() => window.__hexwar !== undefined);
  await expect(page.locator('.menu.main')).toBeVisible(); // đã từng mở tân thủ trong phiên này rồi -> không tự mở lại
  await page.locator('.menu-tutorial').click();
  await expect(page.locator('.tutorial-lesson-btn[data-lesson="T1"].tutorial-lesson-completed')).toBeVisible();
  await expect(page.locator('.tutorial-lesson-btn[data-lesson="T2"].tutorial-lesson-completed')).toHaveCount(0);

  expect(errors, `lỗi console: ${errors.join('\n')}`).toEqual([]);
});
