// M7.5 nghiệm thu M7 ("6 client nghe nhau", PLAN mục 15): trình duyệt THẬT (2 tab rồi 6 tab), mic giả
// (`--use-fake-device-for-media-stream`/`--use-fake-ui-for-media-stream`: Chromium tự cấp quyền micro và phát một
// nguồn âm giả thay vì hỏi phần cứng thật, xem docs/perf.md cho lý do môi trường này không có thiết bị âm thanh
// thật), qua SERVER thật (@hexwar/server) — kiểm tra mesh WebRTC (PLAN 8.5) THẬT SỰ đàm phán xong
// (`RTCPeerConnection.connectionState === 'connected'`) giữa những người bật cả Mic lẫn Nghe, không mock ở tầng nào.
import { existsSync } from 'node:fs';
import { expect, test } from '@playwright/test';
import { HexwarServer } from '@hexwar/server';
import { defaultConfig } from '@hexwar/rules';
import { collectConsoleErrors, openPage } from './support';

const SERVER_PORT = 4312;
const FAST_TIMING = { botDelayMinMs: 0, botDelayMaxMs: 0, spectatorBotDelayMs: 0, autoDiceMs: 0, graceMoveMs: 0, graceCollapseMs: 0 };

/** Cùng Chromium dựng sẵn của playwright.config.ts — `test.use({ launchOptions })` THAY THẾ (không gộp) cấu hình
 * gốc, nên phải khai báo lại `executablePath` ở đây, không thì Playwright quay về tải bản Chromium mặc định (không
 * có trong môi trường này, xem playwright.config.ts). */
const PREBUILT_CHROMIUM = '/opt/pw-browsers/chromium';

// Mic/loa giả (PLAN 7.7 không có TURN/thiết bị thật ở đây) — chỉ cần đủ để RTCPeerConnection có track thật để đàm
// phán; không kiểm tra nội dung âm thanh ở test này (xem net/voice-manager.ts `debugPeerStates()`).
//
// M10: mức đồ hoạ mặc định "Vừa" nay vẽ bóng đổ + bloom qua `EffectComposer` cho MỖI tab (PLAN 12.5) — nhiều tab
// cùng vẽ trên renderer phần mềm (SwiftShader, không GPU thật) tranh CPU với chính việc đàm phán WebRTC, nên các
// hạn chờ `.voicebar-mic`/'connected' vốn đủ trước M10 nay có thể không đủ. Nới hạn thay vì hạ mức đồ hoạ mặc định
// để "test cho qua" (CLAUDE.md cấm sửa test để né lỗi thật — trên máy có GPU thật, chi phí vẽ mỗi tab không đáng kể
// so với việc đàm phán mạng, nên không cần nới ở đó).
test.use({
  permissions: ['microphone'],
  launchOptions: {
    ...(existsSync(PREBUILT_CHROMIUM) ? { executablePath: PREBUILT_CHROMIUM } : {}),
    args: ['--use-fake-device-for-media-stream', '--use-fake-ui-for-media-stream'],
  },
});

let server: HexwarServer | null = null;

test.afterEach(async () => {
  await server?.close();
  server = null;
});

test('hai người bật Mic+Nghe trong cùng phòng -> WebRTC mesh đàm phán xong thật sự (PLAN 8.5)', async ({ page, context }) => {
  test.setTimeout(120_000);
  const errorsA = collectConsoleErrors(page);
  server = new HexwarServer({ rulesVersion: defaultConfig.rulesVersion, timing: FAST_TIMING }, { port: SERVER_PORT });
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, `server=ws://127.0.0.1:${SERVER_PORT}`, false);

  await page.locator('.menu-online').click();
  await page.locator('.online-create').click();
  await expect(page.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  const codeText = (await page.locator('.lobby-code').textContent()) ?? '';
  const code = codeText.split(': ')[1]?.trim() ?? '';
  expect(code).toHaveLength(6);

  const page2 = await context.newPage();
  const errorsB = collectConsoleErrors(page2);
  await page2.setViewportSize({ width: 1280, height: 720 });
  await openPage(page2, `server=ws://127.0.0.1:${SERVER_PORT}`, false);
  await page2.locator('.menu-online').click();
  await page2.locator('.online-code-input').fill(code);
  await page2.locator('.online-join').click();
  await expect(page2.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('.lobby-seat')).toHaveCount(6);

  for (let i = 0; i < 4; i++) await page.locator('.lobby-add-bot').click();
  await page.locator('.lobby-ready').click();
  await page2.locator('.lobby-ready').click();

  await page.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 20_000 });
  await page2.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 20_000 });
  await expect(page.locator('.voicebar')).toBeVisible();
  await expect(page2.locator('.voicebar')).toBeVisible();

  // Bật Mic (xin quyền lần đầu -> hộp thoại giải thích -> "Cho phép") rồi bật Nghe, ở CẢ HAI tab.
  for (const p of [page, page2]) {
    await p.locator('.voicebar-mic').click();
    await expect(p.locator('.voicebar-permission-dialog')).toBeVisible();
    await p.locator('.voicebar-permission-allow').click();
    await expect(p.locator('.voicebar-mic')).toHaveClass(/voicebar-btn-active/, { timeout: 25_000 });
    await p.locator('.voicebar-listen').click();
    await expect(p.locator('.voicebar-listen')).toHaveClass(/voicebar-btn-active/);
  }

  // Cả hai bên đều có mic+nghe bật -> mesh tự dựng một RTCPeerConnection giữa hai ghế người, đàm phán tới 'connected'.
  const connected = (page_: typeof page) =>
    page_.waitForFunction(() => Object.values(window.__hexwar?.voicePeerStates() ?? {}).includes('connected'), undefined, { timeout: 30_000 });
  await connected(page);
  await connected(page2);

  await page2.close();
  expect(errorsA, `lỗi console tab 1: ${errorsA.join('\n')}`).toEqual([]);
  expect(errorsB, `lỗi console tab 2: ${errorsB.join('\n')}`).toEqual([]);
});

test('sáu người thật cùng bật Mic+Nghe trong một phòng -> mesh đầy đủ (15 kết nối) đàm phán xong ở CẢ SÁU tab (PLAN 8.5 "nếu bật thì cả 6 người cùng nghe"; nghiệm thu M7)', async ({
  page,
  context,
}) => {
  // 6 người x tối đa 5 kết nối/người (15 cặp) VÀ 6 cảnh 3D thật cùng vẽ song song bằng renderer phần mềm
  // (SwiftShader, xem docs/perf.md) trong môi trường này — chậm hơn hẳn phép thử 2 tab ở trên, cần hạn rộng hơn nhiều.
  test.setTimeout(360_000);
  server = new HexwarServer({ rulesVersion: defaultConfig.rulesVersion, timing: FAST_TIMING }, { port: SERVER_PORT });

  // Viewport nhỏ hơn hẳn các phép thử khác (không cần bấm chuột vào cảnh 3D ở đây, chỉ cần thấy DOM của menu/HUD) —
  // 6 cảnh 3D thật vẽ song song bằng renderer phần mềm nên càng ít điểm ảnh càng đỡ tải CPU (docs/perf.md).
  await page.setViewportSize({ width: 640, height: 480 });
  await openPage(page, `server=ws://127.0.0.1:${SERVER_PORT}`, false);
  await page.locator('.menu-online').click();
  await page.locator('.online-create').click();
  await expect(page.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  const codeText = (await page.locator('.lobby-code').textContent()) ?? '';
  const code = codeText.split(': ')[1]?.trim() ?? '';
  expect(code).toHaveLength(6);

  const pages = [page];
  for (let i = 1; i < 6; i++) {
    const p = await context.newPage();
    await p.setViewportSize({ width: 640, height: 480 });
    await openPage(p, `server=ws://127.0.0.1:${SERVER_PORT}`, false);
    await p.locator('.menu-online').click();
    await p.locator('.online-code-input').fill(code);
    await p.locator('.online-join').click();
    await expect(p.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
    pages.push(p);
  }
  await expect(page.locator('.lobby-seat')).toHaveCount(6);

  // Đủ 6 người thật, không cần bot lấp chỗ (PLAN 7.2) — mọi người Sẵn sàng thì ván bắt đầu ngay ở cả sáu tab.
  for (const p of pages) await p.locator('.lobby-ready').click();
  for (const p of pages) await p.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 30_000 });
  for (const p of pages) await expect(p.locator('.voicebar')).toBeVisible();

  // Bật Mic (xin quyền lần đầu -> hộp thoại giải thích -> "Cho phép") rồi bật Nghe, tuần tự ở cả sáu tab.
  for (const p of pages) {
    await p.locator('.voicebar-mic').click();
    await expect(p.locator('.voicebar-permission-dialog')).toBeVisible();
    await p.locator('.voicebar-permission-allow').click();
    await expect(p.locator('.voicebar-mic')).toHaveClass(/voicebar-btn-active/, { timeout: 25_000 });
    await p.locator('.voicebar-listen').click();
    await expect(p.locator('.voicebar-listen')).toHaveClass(/voicebar-btn-active/);
  }

  // Cả 6 người đều bật Mic+Nghe -> đúng PLAN 8.5 "nếu bật thì cả 6 người cùng nghe": mỗi tab phải có ĐÚNG 5 kết nối
  // (một tới mỗi người còn lại), TẤT CẢ đều 'connected' — không chỉ "có ít nhất một" như phép thử 2 tab ở trên.
  const fullMeshConnected = (p: (typeof pages)[number]) =>
    p.waitForFunction(
      () => {
        const states = Object.values(window.__hexwar?.voicePeerStates() ?? {});
        return states.length === 5 && states.every((s) => s === 'connected');
      },
      undefined,
      { timeout: 90_000 },
    );
  await Promise.all(pages.map((p) => fullMeshConnected(p)));

  for (const p of pages.slice(1)) await p.close();
});

test('tuỳ chọn "Chỉ đi qua TURN" (ẩn IP, PLAN 8.5) áp đúng iceTransportPolicy="relay" lên kết nối mới tạo', async ({ page, context }) => {
  // Môi trường này không có TURN server thật (coturn, PLAN 7.7 — việc triển khai hạ tầng của bạn, xem
  // docs/questions.md), nên kết nối bật "chỉ TURN" sẽ KHÔNG BAO GIỜ tới 'connected' thật (không có STUN/host nào
  // được phép qua bộ lọc `relay`) — test này chỉ xác nhận CODE nối đúng dây: bật tuỳ chọn trước khi bật Mic thì
  // `RTCPeerConnection` mới tạo phải mang đúng `iceTransportPolicy: 'relay'`.
  test.setTimeout(120_000);
  server = new HexwarServer({ rulesVersion: defaultConfig.rulesVersion, timing: FAST_TIMING }, { port: SERVER_PORT });
  await page.setViewportSize({ width: 1280, height: 720 });
  await openPage(page, `server=ws://127.0.0.1:${SERVER_PORT}`, false);

  await page.locator('.menu-online').click();
  await page.locator('.online-create').click();
  await expect(page.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  const codeText = (await page.locator('.lobby-code').textContent()) ?? '';
  const code = codeText.split(': ')[1]?.trim() ?? '';

  const page2 = await context.newPage();
  await page2.setViewportSize({ width: 1280, height: 720 });
  await openPage(page2, `server=ws://127.0.0.1:${SERVER_PORT}`, false);
  await page2.locator('.menu-online').click();
  await page2.locator('.online-code-input').fill(code);
  await page2.locator('.online-join').click();
  await expect(page2.locator('.menu.lobby')).toBeVisible({ timeout: 5000 });
  await expect(page.locator('.lobby-seat')).toHaveCount(6);

  for (let i = 0; i < 4; i++) await page.locator('.lobby-add-bot').click();
  await page.locator('.lobby-ready').click();
  await page2.locator('.lobby-ready').click();
  await page.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 20_000 });
  await page2.waitForFunction(() => window.__hexwar?.state() !== null, undefined, { timeout: 20_000 });

  // Bật "chỉ đi qua TURN" ở CẢ HAI bên TRƯỚC khi bật Mic (PLAN 11.5 — settings-manager.ts áp dụng cho kết nối MỚI).
  for (const p of [page, page2]) {
    await p.locator('.voicebar-settings-toggle').click();
    await p.locator('.voicebar-turnonly-checkbox').check();
  }

  for (const p of [page, page2]) {
    await p.locator('.voicebar-mic').click();
    await expect(p.locator('.voicebar-permission-dialog')).toBeVisible();
    await p.locator('.voicebar-permission-allow').click();
    await expect(p.locator('.voicebar-mic')).toHaveClass(/voicebar-btn-active/, { timeout: 25_000 });
    await p.locator('.voicebar-listen').click();
  }

  // Không đợi 'connected' (sẽ không bao giờ tới, xem ghi chú đầu test) — chỉ đợi tới khi mesh đã TẠO kết nối.
  for (const p of [page, page2]) {
    await p.waitForFunction(() => Object.keys(window.__hexwar?.voicePeerStates() ?? {}).length > 0, undefined, { timeout: 20_000 });
  }
  const otherSeatOf = (p: typeof page) => p.evaluate(() => Number(Object.keys(window.__hexwar?.voicePeerStates() ?? {})[0]));
  const policyA = await page.evaluate((seat) => window.__hexwar?.voiceIcePolicy(seat) ?? null, await otherSeatOf(page));
  const policyB = await page2.evaluate((seat) => window.__hexwar?.voiceIcePolicy(seat) ?? null, await otherSeatOf(page2));
  expect(policyA).toBe('relay');
  expect(policyB).toBe('relay');

  await page2.close();
});
