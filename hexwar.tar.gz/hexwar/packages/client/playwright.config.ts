// Cấu hình Playwright (M3: hotseat + ảnh chụp; M4: solo 1 vs 5 bot, thoát/vào lại). Môi trường phát triển hiện tại
// dựng sẵn Chromium ở /opt/pw-browsers/chromium (SwiftShader phần mềm) — dùng thẳng bản đó nếu có; CI thì cài bằng
// `playwright install chromium` (.github/workflows/ci.yml). FPS đo ở đây không đại diện cho GPU thật (docs/perf.md).
import { existsSync } from 'node:fs';
import { defineConfig } from '@playwright/test';

const PORT = 4310;
/** Chromium dựng sẵn của môi trường phát triển hiện tại; trên CI (GitHub Actions) dùng bản `playwright install`. */
const PREBUILT_CHROMIUM = '/opt/pw-browsers/chromium';

export default defineConfig({
  testDir: './e2e',
  timeout: 60_000,
  expect: { timeout: 15_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: `http://localhost:${PORT}`,
    trace: 'off',
    video: 'off',
    launchOptions: existsSync(PREBUILT_CHROMIUM) ? { executablePath: PREBUILT_CHROMIUM } : {},
  },
  webServer: {
    command: `npx vite --port ${PORT} --strictPort`,
    url: `http://localhost:${PORT}`,
    reuseExistingServer: true,
    timeout: 30_000,
  },
});
