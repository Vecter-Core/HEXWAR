// Bảng chat (PLAN mục 8): toàn phòng, nhắn riêng (nhóm theo tab, PLAN 8.2), câu có sẵn (PLAN 8.3), và các nút
// tắt tiếng/chặn/báo cáo theo từng người (PLAN 8.4). Chỉ hiển thị ở ván ONLINE (main.ts quyết định show/hide) —
// hotseat/solo không có server để chat qua.
//
// Mặc định GẤP LẠI (chỉ còn nút nổi góc màn hình) chứ không chiếm sẵn một vùng bàn cờ: bài học từ M5
// (`.hud-selection` từng chặn nhầm cú bấm vào bàn cờ bên dưới, xem docs/decisions.md) — một bảng lớn luôn mở sẽ lặp
// lại đúng rủi ro đó trên một bàn 1801 ô vốn đã chật hẹp.
//
// M7.4: mỗi hàng trong bảng người chơi cũng là chỗ hợp lý cho các điều khiển VOICE riêng từng người (âm lượng, tắt
// tiếng để NGHE, chấm "đang nói") — cùng chỗ với nút chặn/báo cáo, đỡ phải mở thêm một bảng nổi khác cho voice
// (xem docs/decisions.md M7). "Chặn" (PLAN 8.5 "người bị chặn không nghe nhau") dùng chung cho cả chat lẫn voice
// nên callback báo cả trạng thái mới, để main.ts biết mà báo cho VoiceManager.
import type { ChatErrorCode, ChatMessage, PhraseId, ReportReason } from '@hexwar/protocol';
import { PHRASE_GROUPS, REPORT_REASONS } from '@hexwar/protocol';
import type { Seat } from '@hexwar/rules';
import type { Translator } from '../core/i18n';
import { isHiddenBySeatFilter, phraseLocaleKey, tabIdFor, targetForTab, whisperTabId, type ChatSendTarget, type ChatTabId } from '../core/chat-model';

export type { ChatSendTarget } from '../core/chat-model';

export interface ChatRosterEntry {
  readonly seat: Seat;
  readonly name: string;
  readonly kind: 'human' | 'bot' | 'empty';
  readonly isSelf: boolean;
}

export interface ChatPanelCallbacks {
  readonly onSendText: (target: ChatSendTarget, text: string) => void;
  readonly onSendPhrase: (target: ChatSendTarget, phraseId: PhraseId) => void;
  readonly onMuteToggle: (seat: Seat) => void;
  /** `blocked`: trạng thái MỚI sau khi bấm — dùng chung cho chat lẫn voice (PLAN 8.5), main.ts báo lại cho VoiceManager. */
  readonly onBlockToggle: (seat: Seat, blocked: boolean) => void;
  readonly onReport: (seat: Seat, reason: ReportReason) => void;
  /** M7.4: thanh trượt âm lượng riêng từng người (PLAN 8.5), `volume` trong khoảng 0..1. */
  readonly onSeatVolume: (seat: Seat, volume: number) => void;
  /** M7.4: tắt tiếng riêng người này ở voice (khác với `onMuteToggle` — đó là ẩn tin CHỮ, PLAN 8.4). */
  readonly onSeatListenMute: (seat: Seat, muted: boolean) => void;
}

interface TabState {
  readonly id: ChatTabId;
  label: string;
  readonly entries: { readonly mine: boolean; readonly fromName: string; readonly text: string }[];
  unread: number;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.className = className;
  parent?.appendChild(node);
  return node;
}

function button(label: string, className: string, onClick: () => void, parent: HTMLElement): HTMLButtonElement {
  const b = el('button', className, parent);
  b.type = 'button';
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

export class ChatPanel {
  private readonly root: HTMLElement;
  private readonly toggleButton: HTMLButtonElement;
  private readonly toggleBadge: HTMLElement;
  private readonly body: HTMLElement;
  private readonly tabsBar: HTMLElement;
  private readonly messagesEl: HTMLElement;
  private readonly errorEl: HTMLElement;
  private readonly textInput: HTMLInputElement;
  private readonly phrasesPopup: HTMLElement;
  private readonly rosterEl: HTMLElement;
  private readonly reportDialog: HTMLElement;

  private readonly tabs = new Map<ChatTabId, TabState>([['all', { id: 'all', label: '', entries: [], unread: 0 }]]);
  private activeTab: ChatTabId = 'all';
  private expanded = false;
  private mySeat: Seat | null = null;
  private eliminated = false;
  private roster: readonly ChatRosterEntry[] = [];
  private readonly mutedSeats = new Set<Seat>();
  private readonly blockedSeats = new Set<Seat>();
  private readonly listenMutedSeats = new Set<Seat>();
  private reportTarget: Seat | null = null;
  /** Chấm "đang nói" (M7.4) cập nhật liên tục — giữ riêng tham chiếu để KHÔNG phải vẽ lại cả bảng người mỗi lần. */
  private readonly speakingDots = new Map<Seat, HTMLElement>();

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    private readonly callbacks: ChatPanelCallbacks,
  ) {
    this.root = el('div', 'chatpanel hud-hidden', parent);

    this.toggleButton = button('💬', 'chatpanel-toggle', () => this.setExpanded(!this.expanded), this.root);
    this.toggleBadge = el('span', 'chatpanel-toggle-badge hud-hidden', this.toggleButton);

    this.body = el('div', 'chatpanel-body hud-hidden', this.root);
    this.tabsBar = el('div', 'chatpanel-tabs', this.body);
    this.messagesEl = el('div', 'chatpanel-messages', this.body);
    this.errorEl = el('div', 'menu-error chatpanel-error', this.body);

    const inputRow = el('div', 'chatpanel-input-row', this.body);
    this.textInput = el('input', 'chatpanel-text-input', inputRow);
    this.textInput.type = 'text';
    this.textInput.maxLength = 200; // PLAN 8.4
    this.textInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') this.sendText();
    });
    button(t('chat.send'), 'chatpanel-send', () => this.sendText(), inputRow);
    const phrasesToggle = button('☺', 'chatpanel-phrases-toggle', () => this.togglePhrases(), inputRow);
    phrasesToggle.title = t('chat.phrases');

    this.phrasesPopup = el('div', 'chatpanel-phrases hud-hidden', this.body);
    for (const group of PHRASE_GROUPS) {
      const groupEl = el('div', 'chatpanel-phrase-group', this.phrasesPopup);
      for (const phraseId of group.phraseIds) {
        const b = button(t(phraseLocaleKey(phraseId)), 'chatpanel-phrase-btn', () => {
          this.callbacks.onSendPhrase(targetForTab(this.activeTab), phraseId);
          this.phrasesPopup.classList.add('hud-hidden');
        }, groupEl);
        b.dataset['phrase'] = phraseId;
      }
    }

    el('div', 'chatpanel-roster-title', this.body).textContent = t('chat.roster.title');
    this.rosterEl = el('div', 'chatpanel-roster', this.body);

    this.reportDialog = el('div', 'hud-confirm-dialog chatpanel-report-dialog hud-hidden', this.root);
    el('p', '', this.reportDialog).textContent = t('chat.report.question');
    const reasons = el('div', 'chatpanel-report-reasons', this.reportDialog);
    for (const reason of REPORT_REASONS) {
      const b = button(t(`chat.report.reason.${reason}`), 'chatpanel-report-reason', () => {
        if (this.reportTarget !== null) this.callbacks.onReport(this.reportTarget, reason);
        this.closeReportDialog();
      }, reasons);
      b.dataset['reason'] = reason;
    }
    button(t('hud.resign.cancel'), 'hud-btn', () => this.closeReportDialog(), this.reportDialog);

    window.addEventListener('keydown', (e) => {
      if (this.root.classList.contains('hud-hidden')) return;
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return; // đang gõ, không cướp phím T
      if (e.key.toLowerCase() === 't') this.togglePhrases(); // PLAN 8.3 "phím tắt mở vòng chọn câu nhanh"
    });

    this.tabs.get('all')!.label = t('chat.tab.all');
    this.renderTabs();
  }

  // ---- Điều khiển từ main.ts ----------------------------------------------------------------------------------

  show(): void {
    this.root.classList.remove('hud-hidden');
  }

  /** Rời ván online: gấp lại + xoá sạch trạng thái phòng cũ (mute/block/hội thoại chỉ có nghĩa TRONG một phòng — xem
   * docs/questions.md, Q-30). */
  hide(): void {
    this.root.classList.add('hud-hidden');
    this.setExpanded(false);
    this.tabs.clear();
    this.tabs.set('all', { id: 'all', label: this.t('chat.tab.all'), entries: [], unread: 0 });
    this.activeTab = 'all';
    this.mutedSeats.clear();
    this.blockedSeats.clear();
    this.listenMutedSeats.clear();
    this.speakingDots.clear();
    this.eliminated = false;
    this.roster = [];
  }

  /** M7.4: VoiceManager báo trạng thái "đang nói" của một ghế đổi — chỉ cập nhật đúng chấm đó, không vẽ lại cả bảng
   * (gọi mỗi ~120ms, xem net/voice-manager.ts). */
  setSpeaking(seat: Seat, speaking: boolean): void {
    this.speakingDots.get(seat)?.classList.toggle('chatpanel-speaking-on', speaking);
  }

  setMySeat(seat: Seat | null): void {
    this.mySeat = seat;
  }

  setRoster(roster: readonly ChatRosterEntry[]): void {
    this.roster = roster;
    this.renderRoster();
  }

  setEliminated(value: boolean): void {
    if (value === this.eliminated) return;
    this.eliminated = value;
    if (value && !this.tabs.has('dead')) this.tabs.set('dead', { id: 'dead', label: this.t('chat.tab.dead'), entries: [], unread: 0 });
    this.renderTabs();
  }

  /** PLAN 8.2 "bấm tên một người chơi → mở khung nhắn riêng" — gọi từ Hud khi bấm tên trong bảng người chơi. */
  openWhisper(seat: Seat): void {
    if (seat === this.mySeat) return;
    const id = whisperTabId(seat);
    if (!this.tabs.has(id)) this.tabs.set(id, { id, label: this.nameFor(seat), entries: [], unread: 0 });
    this.setExpanded(true);
    this.switchTab(id);
  }

  receive(message: ChatMessage): void {
    if (isHiddenBySeatFilter(message, this.mySeat, this.mutedSeats, this.blockedSeats)) return;
    const id = tabIdFor(message, this.mySeat);
    if (!this.tabs.has(id)) {
      const other = message.from === this.mySeat ? (message.to as Seat) : message.from;
      const label = id === 'all' ? this.t('chat.tab.all') : id === 'dead' ? this.t('chat.tab.dead') : this.nameFor(other);
      this.tabs.set(id, { id, label, entries: [], unread: 0 });
    }
    const tab = this.tabs.get(id)!;
    const mine = message.from === this.mySeat;
    const fromName = this.nameFor(message.from);
    const text = message.kind === 'text' ? message.text : this.t(phraseLocaleKey(message.phraseId));
    tab.entries.push({ mine, fromName, text });
    if (id !== this.activeTab || !this.expanded) tab.unread += 1; // PLAN 8.2 "dấu hiệu chưa đọc"
    this.renderTabs();
    if (id === this.activeTab) this.renderMessages();
  }

  showError(code: ChatErrorCode): void {
    this.errorEl.textContent = this.t(`chat.error.${code}`);
  }

  showReportAck(): void {
    this.errorEl.textContent = this.t('chat.report.ack');
  }

  // ---- Nội bộ --------------------------------------------------------------------------------------------------

  private nameFor(seat: Seat): string {
    return this.roster.find((r) => r.seat === seat)?.name ?? this.t('seat.label', { seat });
  }

  private setExpanded(value: boolean): void {
    this.expanded = value;
    this.body.classList.toggle('hud-hidden', !value);
    if (value) {
      const tab = this.tabs.get(this.activeTab);
      if (tab !== undefined) tab.unread = 0;
      this.renderTabs();
    }
  }

  private togglePhrases(): void {
    if (!this.expanded) this.setExpanded(true);
    this.phrasesPopup.classList.toggle('hud-hidden');
  }

  private switchTab(id: ChatTabId): void {
    this.activeTab = id;
    const tab = this.tabs.get(id);
    if (tab !== undefined) tab.unread = 0;
    this.renderTabs();
    this.renderMessages();
  }

  private sendText(): void {
    const text = this.textInput.value.trim();
    if (text.length === 0) return;
    this.callbacks.onSendText(targetForTab(this.activeTab), text);
    this.textInput.value = '';
  }

  private renderTabs(): void {
    this.tabsBar.replaceChildren();
    let totalUnread = 0;
    for (const tab of this.tabs.values()) {
      const b = el('button', 'chatpanel-tab' + (tab.id === this.activeTab ? ' chatpanel-tab-active' : ''), this.tabsBar);
      b.type = 'button';
      b.dataset['tab'] = tab.id;
      b.textContent = tab.label;
      b.addEventListener('click', () => this.switchTab(tab.id));
      if (tab.unread > 0) el('span', 'chatpanel-tab-unread', b).textContent = String(tab.unread);
      totalUnread += tab.unread;
    }
    // Bảng đang gấp lại (nút nổi): dấu hiệu chưa đọc phải hiện NGAY TRÊN nút đó, vì tabsBar bị ẩn cùng `body`.
    this.toggleBadge.classList.toggle('hud-hidden', totalUnread === 0);
    this.toggleBadge.textContent = String(totalUnread);
  }

  private renderMessages(): void {
    this.messagesEl.replaceChildren();
    const tab = this.tabs.get(this.activeTab);
    if (tab === undefined) return;
    for (const entry of tab.entries) {
      const row = el('div', 'chatpanel-msg' + (entry.mine ? ' chatpanel-msg-mine' : ''), this.messagesEl);
      if (this.activeTab === 'all' || this.activeTab === 'dead') el('span', 'chatpanel-msg-from', row).textContent = `${entry.fromName}: `;
      el('span', 'chatpanel-msg-text', row).textContent = entry.text;
    }
    this.messagesEl.scrollTop = this.messagesEl.scrollHeight;
  }

  private renderRoster(): void {
    this.rosterEl.replaceChildren();
    this.speakingDots.clear();
    for (const entry of this.roster) {
      if (entry.kind !== 'human' || entry.isSelf) continue; // chỉ người chơi khác mới tắt tiếng/chặn/báo cáo được
      const row = el('div', 'chatpanel-roster-row', this.rosterEl);
      const dot = el('span', 'chatpanel-speaking-dot', row); // M7.4 (PLAN 8.5 "biểu tượng đang nói")
      dot.title = this.t('voice.speaking');
      this.speakingDots.set(entry.seat, dot);
      el('span', 'chatpanel-roster-name', row).textContent = entry.name;
      const whisperBtn = button(this.t('chat.roster.whisper'), 'chatpanel-roster-btn', () => this.openWhisper(entry.seat), row);
      whisperBtn.dataset['seat'] = String(entry.seat);
      const muted = this.mutedSeats.has(entry.seat);
      const muteBtn = button(this.t(muted ? 'chat.roster.unmute' : 'chat.roster.mute'), 'chatpanel-roster-btn chatpanel-mute-btn', () => {
        if (this.mutedSeats.has(entry.seat)) this.mutedSeats.delete(entry.seat);
        else this.mutedSeats.add(entry.seat);
        this.callbacks.onMuteToggle(entry.seat);
        this.renderRoster();
      }, row);
      muteBtn.classList.toggle('chatpanel-roster-btn-active', muted);
      const blocked = this.blockedSeats.has(entry.seat);
      const blockBtn = button(this.t(blocked ? 'chat.roster.unblock' : 'chat.roster.block'), 'chatpanel-roster-btn chatpanel-block-btn', () => {
        const nowBlocked = !this.blockedSeats.has(entry.seat);
        if (nowBlocked) this.blockedSeats.add(entry.seat);
        else this.blockedSeats.delete(entry.seat);
        this.callbacks.onBlockToggle(entry.seat, nowBlocked);
        this.renderRoster();
      }, row);
      blockBtn.classList.toggle('chatpanel-roster-btn-active', blocked);
      const reportBtn = button(this.t('chat.roster.report'), 'chatpanel-roster-btn chatpanel-report-btn', () => this.openReportDialog(entry.seat), row);
      reportBtn.dataset['seat'] = String(entry.seat);

      // M7.4: âm lượng/tắt tiếng riêng người này ở VOICE (khác nút "tắt tiếng" chữ ở trên) — cùng hàng cho gọn.
      const listenMuted = this.listenMutedSeats.has(entry.seat);
      const listenMuteBtn = button(listenMuted ? '🔇' : '🔊', 'chatpanel-roster-btn chatpanel-voice-mute-btn', () => {
        if (this.listenMutedSeats.has(entry.seat)) this.listenMutedSeats.delete(entry.seat);
        else this.listenMutedSeats.add(entry.seat);
        this.callbacks.onSeatListenMute(entry.seat, this.listenMutedSeats.has(entry.seat));
        this.renderRoster();
      }, row);
      listenMuteBtn.title = this.t(listenMuted ? 'voice.roster.unmute' : 'voice.roster.mute');
      listenMuteBtn.classList.toggle('chatpanel-roster-btn-active', listenMuted);
      const volume = el('input', 'chatpanel-roster-volume', row);
      volume.type = 'range';
      volume.min = '0';
      volume.max = '1';
      volume.step = '0.05';
      volume.value = '1';
      volume.title = this.t('voice.roster.volume');
      volume.addEventListener('input', () => this.callbacks.onSeatVolume(entry.seat, Number(volume.value)));
    }
  }

  private openReportDialog(seat: Seat): void {
    this.reportTarget = seat;
    this.reportDialog.classList.remove('hud-hidden');
  }

  private closeReportDialog(): void {
    this.reportTarget = null;
    this.reportDialog.classList.add('hud-hidden');
  }
}
