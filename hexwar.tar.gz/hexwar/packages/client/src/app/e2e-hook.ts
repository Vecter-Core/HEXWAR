// Móc gỡ lỗi CHỈ dùng cho kiểm thử Playwright (bật bằng `?e2e=1`, xem packages/client/e2e/*.spec.ts).
// Từ M4 ván chạy trong Web Worker thật, nên mọi thao tác là BẤT ĐỒNG BỘ: `autoPlay` chọn quân + bấm ô đích qua đúng
// `GameController` (như bấm chuột, chỉ bỏ bước chuột → tia → ô vốn có test riêng), gửi ý định sang Worker và CHỜ nơi
// chạy ván trả kết quả; lượt của bot thì chỉ chờ. Không phải một "chế độ giả" tách biệt.
import { hash, legalMovesOfPiece, type Cell, type GameState, type Move, type Seat } from '@hexwar/rules';
import type { AnimationDirector } from '../core/animation';
import { FOV_DEG, cameraPose, projectToNdc, type OrbitState } from '../core/camera';
import type { Selection } from '../core/controller';
import type { GameLink } from '../core/game-link';
import { cellCenter } from '../core/layout';
import type { VoiceManager } from '../net/voice-manager';

export interface AutoPlayResult {
  /** Số hành động (của mọi ghế, kể cả bot) đã diễn ra trong lần gọi này. */
  readonly actions: number;
  readonly captured: boolean;
  readonly collapsed: boolean;
  readonly over: boolean;
}

interface GameView {
  readonly link: GameLink;
  readonly animator: AnimationDirector;
}

/** Ưu tiên một nước ăn quân nếu có (để test dễ tạo ra cảnh "vừa ăn quân"); không thì đi nước hợp lệ đầu tiên. */
function chooseMove(state: GameState): { pieceId: string; move: Move } | null {
  const seat = state.turnSeat;
  if (seat === null) return null;
  let anyMove: { pieceId: string; move: Move } | null = null;
  for (const piece of state.pieces) {
    const owns = piece.status === 'active' ? piece.owner === seat : piece.holder === seat;
    if (!owns) continue;
    for (const move of legalMovesOfPiece(state, piece.id)) {
      const isCapture = state.pieces.some((p) => p.status === 'active' && p.cell.q === move.to.q && p.cell.r === move.to.r);
      if (isCapture) return { pieceId: piece.id, move };
      anyMove ??= { pieceId: piece.id, move };
    }
  }
  return anyMove;
}

export interface DebugHook {
  /** Ván đang mở (null ở màn bắt đầu hoặc trước khi Worker gửi trạng thái đầu). */
  state(): GameState | null;
  selection(): Selection | null;
  seq(): number;
  /** Các ghế máy này điều khiển (solo: 1 ghế; hotseat: 6). */
  you(): readonly number[];
  hash(): string | null;
  select(pieceId: string): void;
  /** Chơi tối đa `maxActions` hành động (mọi ghế). Dừng sớm nếu ván kết thúc. */
  autoPlay(maxActions: number): Promise<AutoPlayResult>;
  /** Đợi tới khi `seq` ≥ `target` (hành động đã về từ Worker). */
  waitForSeq(target: number, timeoutMs?: number): Promise<boolean>;
  /** Trạng thái camera hiện tại — dùng để tính toạ độ màn hình thật cho test bấm chuột (PLAN 6.6 công thức nghịch đảo). */
  getOrbit(): OrbitState;
  /** Nước đi hợp lệ của một quân ở trạng thái HIỆN TẠI (tính trong trang, không import engine ở phía Node). */
  legalMovesOf(pieceId: string): Move[];
  /**
   * Một quân của người đang tới lượt, cùng một nước đi hợp lệ, mà CẢ ô xuất phát lẫn ô đích đều nằm trong khung
   * hình camera hiện tại — dùng cho test bấm chuột thật (`e2e/support.ts`). Không phải mọi ô hợp lệ đều hiện trên
   * màn hình ở mọi góc camera (bàn 1801 ô, camera "toàn cảnh" của hotseat không nhìn thấy hết mọi góc); bấm chuột
   * thật vào một ô nằm ngoài khung hình chỉ trúng khoảng trống/không trúng gì, làm test chập chờn tuỳ hạt giống
   * ngẫu nhiên (đã thấy chập chờn thật khi kiểm thử X-14 — sửa tại đây thay vì lặp lại phép chiếu ở support.ts).
   */
  findMovablePiece(): { pieceId: string; from: Cell; to: Cell } | null;
  /** M7.5: trạng thái RTCPeerConnection thật tới từng ghế (`connectionState`) — chỉ để test voice mesh nhìn vào,
   * xem net/voice-manager.ts `debugPeerStates()`. `{}` khi chưa có voice manager (chưa vào ván online). */
  voicePeerStates(): Partial<Record<number, RTCPeerConnectionState>>;
  /** M7.5: `iceTransportPolicy` thật của kết nối tới một ghế — chỉ để test xác nhận tuỳ chọn "chỉ đi qua TURN" (ẩn
   * IP, PLAN 8.5) áp đúng vào cấu hình, xem net/voice-manager.ts `debugIceTransportPolicy()`. */
  voiceIcePolicy(seat: number): RTCIceTransportPolicy | null;
}

const tick = (): Promise<void> => new Promise((resolve) => setTimeout(resolve, 0));

export function installDebugHook(getGame: () => GameView | null, getOrbit: () => OrbitState, getVoiceManager: () => VoiceManager | null = () => null): void {
  const ready = (): GameView | null => {
    const g = getGame();
    return g !== null && g.link.ready ? g : null;
  };

  async function waitForSeq(target: number, timeoutMs = 60_000): Promise<boolean> {
    const until = performance.now() + timeoutMs;
    while (performance.now() < until) {
      const g = ready();
      if (g !== null && (g.link.seq >= target || g.link.state.phase === 'over')) return true;
      await tick();
    }
    return false;
  }

  const hook: DebugHook = {
    state: () => ready()?.link.state ?? null,
    selection: () => ready()?.link.controller.selection ?? null,
    seq: () => ready()?.link.seq ?? 0,
    you: () => ready()?.link.you ?? [],
    hash: () => {
      const g = ready();
      return g === null ? null : hash(g.link.state);
    },
    select: (pieceId) => ready()?.link.controller.select(pieceId),
    getOrbit,
    legalMovesOf: (pieceId) => {
      const g = ready();
      return g === null ? [] : legalMovesOfPiece(g.link.state, pieceId);
    },
    findMovablePiece: () => {
      const g = ready();
      if (g === null) return null;
      const state = g.link.state;
      const seat = state.turnSeat;
      if (seat === null) return null;
      const pose = cameraPose(getOrbit());
      const aspect = window.innerWidth / window.innerHeight;
      // Biên 0.9 (không phải 1.0): chừa mép màn hình cho HUD cố định (bảng người chơi, nút góc…) — PLAN 11.1.
      const onScreen = (cell: Cell): boolean => {
        const center = cellCenter(cell);
        const ndc = projectToNdc(pose, { x: center.x, y: 0, z: center.z }, FOV_DEG, aspect);
        return ndc !== null && Math.abs(ndc.x) <= 0.9 && Math.abs(ndc.y) <= 0.9;
      };
      for (const piece of state.pieces) {
        const owns = piece.status === 'active' ? piece.owner === seat : piece.holder === seat;
        if (!owns || !onScreen(piece.cell)) continue;
        for (const move of legalMovesOfPiece(state, piece.id)) {
          if (onScreen(move.to)) return { pieceId: piece.id, from: piece.cell, to: move.to };
        }
      }
      return null;
    },
    waitForSeq,
    voicePeerStates: () => getVoiceManager()?.debugPeerStates() ?? {},
    voiceIcePolicy: (seat) => getVoiceManager()?.debugIceTransportPolicy(seat as Seat) ?? null,
    async autoPlay(maxActions) {
      let captured = false;
      let collapsed = false;
      let actions = 0;
      if (!(await waitForSeq(0))) throw new Error('autoPlay: ván chưa sẵn sàng');
      while (actions < maxActions) {
        const g = ready();
        if (g === null) throw new Error('autoPlay: ván đã đóng');
        const { link } = g;
        const state = link.state;
        if (state.phase === 'over') break;
        const seq = link.seq;
        const radiusBefore = state.radius;
        const capturedBefore = state.pieces.filter((p) => p.status === 'captive').length;
        if (state.phase === 'dice' && link.you.length > 0) {
          link.rollDice();
        } else if (link.isMyTurn()) {
          const choice = chooseMove(state);
          if (choice === null) throw new Error('autoPlay: tới lượt mình mà không có nước đi (R-13 lẽ ra đã bỏ lượt)');
          link.controller.select(choice.pieceId);
          link.controller.handlePick({ kind: 'cell', cell: choice.move.to });
        }
        // Lượt của bot (hoặc vừa gửi nước đi của mình): đợi Worker trả kết quả.
        if (!(await waitForSeq(seq + 1))) throw new Error(`autoPlay: không có hành động mới sau seq ${seq}`);
        g.animator.flush(); // bỏ qua thời lượng hoạt ảnh thật để mô phỏng nhanh
        actions += link.seq - seq;
        if (link.state.pieces.filter((p) => p.status === 'captive').length > capturedBefore) captured = true;
        if (link.state.radius < radiusBefore) collapsed = true;
      }
      const state = ready()?.link.state;
      return { actions, captured, collapsed, over: state?.phase === 'over' };
    },
  };
  (window as unknown as { __hexwar?: DebugHook }).__hexwar = hook;
}
