// Dịch một GameEvent thành các dòng thông báo ngắn cho HUD (PLAN 11.2: "Thông báo ngắn" giữa màn hình).
// THUẦN (không DOM) nên kiểm bằng Node; `hud.ts` chỉ lo hiển thị các dòng này.
import type { DisplayModel } from '../core/display-model';
import type { Translator } from '../core/i18n';
import type { GameEvent, PieceType, Seat } from '@hexwar/rules';

const seatLabel = (t: Translator, seat: Seat): string => t('seat.label', { seat });
const pieceLabel = (t: Translator, type: PieceType): string => t(`piece.${type}`);

/** Loại quân của một quân TRƯỚC KHI sự kiện này áp dụng lên mô hình (gọi ở `onStart`, xem app/main.ts). */
function typeOf(model: DisplayModel, pieceId: string): PieceType | null {
  return model.get(pieceId)?.type ?? null;
}

/**
 * Các dòng thông báo cho một sự kiện, hoặc mảng rỗng nếu sự kiện đó không đáng thông báo riêng (ví dụ MOVED đã có
 * hoạt ảnh trượt quân, TURN_STARTED/ROUND_STARTED đã hiện ở thanh trên cùng — PLAN 11.2 "Trên giữa").
 */
export function describeEvent(event: GameEvent, model: DisplayModel, t: Translator): string[] {
  switch (event.type) {
    case 'DICE_ROLLED': {
      const lines = event.rolls.map((roll) => t('dice.rolled', { seat: seatLabel(t, roll.seat), total: roll.total }));
      lines.push(
        event.winner !== null
          ? t('dice.winner', { seat: seatLabel(t, event.winner) })
          : t('dice.tie', { seats: event.rolls.map((roll) => seatLabel(t, roll.seat)).join(', ') }),
      );
      return lines;
    }
    case 'TURN_SKIPPED':
      return [t(`turn.skipped.${event.reason}`, { seat: seatLabel(t, event.seat) })];
    case 'CAPTURED': {
      const attackerType = typeOf(model, event.attackerId);
      return [t('event.captured', { piece: attackerType === null ? '?' : pieceLabel(t, attackerType), owner: seatLabel(t, event.victimOwner) })];
    }
    case 'CAPTIVE_CREATED':
      return [t('event.captiveCreated', { owner: seatLabel(t, event.owner), holder: seatLabel(t, event.holder) })];
    case 'CAPTIVE_CONSCRIPTED':
      return [t('event.captiveConscripted', { owner: seatLabel(t, event.owner), holder: seatLabel(t, event.holder) })];
    case 'CAPTIVE_TRANSFERRED':
      return [t('event.captiveTransferred', { owner: seatLabel(t, event.owner), holder: seatLabel(t, event.to) })];
    case 'CAPTIVE_RELEASED':
      return [t('event.captiveReleased', { owner: seatLabel(t, event.owner) })];
    case 'CAPTIVE_EXPIRED':
      return [t('event.captiveExpired', { owner: seatLabel(t, event.owner) })];
    case 'PROMOTED':
      return [t('event.promoted', { piece: pieceLabel(t, event.from), owner: seatLabel(t, event.owner), to: pieceLabel(t, event.to) })];
    case 'KING_CAPTURED':
      return [t('event.kingCaptured', { owner: seatLabel(t, event.owner) })];
    case 'JESTER_REVIVED':
      return [t('event.jesterRevived', { owner: seatLabel(t, event.owner) })];
    case 'PLAYER_ELIMINATED':
      return [t('event.playerEliminated', { seat: seatLabel(t, event.seat) })];
    case 'RING_WARNING':
      return [t(`event.ringWarning.${event.level}`, { ring: event.ring, rounds: event.roundsLeft })];
    case 'RING_COLLAPSED':
      return [t('event.ringCollapsed', { ring: event.ring })];
    case 'GAME_OVER':
      return [t(`event.gameOver.${event.reason}`, event.winner === null ? {} : { seat: seatLabel(t, event.winner) })];
    case 'MOVED':
    case 'ROUND_STARTED':
    case 'TURN_STARTED':
      return [];
  }
}
