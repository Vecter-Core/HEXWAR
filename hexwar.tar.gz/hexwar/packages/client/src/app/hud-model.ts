// Dữ liệu hiển thị của HUD tối thiểu M4 (PLAN 15 M4: "lượt, hiệp, đồng hồ, danh sách người"; PLAN 11.2). THUẦN —
// không DOM — để kiểm bằng Node; `hud.ts` chỉ vẽ lại kết quả của hàm này.
import type { SeatStatus } from '@hexwar/protocol';
import { nextCollapse, scoreOf, type GameState, type Seat } from '@hexwar/rules';
import type { Translator } from '../core/i18n';
import { seatColor, toCss } from '../core/palette';

export interface PlayerRow {
  readonly seat: Seat;
  readonly name: string;
  /** "Ghế N" — luôn hiện kèm tên để khớp với thông báo sự kiện. */
  readonly seatLabel: string;
  readonly color: string;
  readonly pieces: number;
  readonly kills: number;
  readonly score: number;
  readonly alive: boolean;
  readonly isTurn: boolean;
  readonly isYou: boolean;
  /** Nhãn ngắn: BOT, bot đang lái tạm (X-04), bị loại (hiệp N). */
  readonly tags: readonly string[];
  /** M7.4 (PLAN 8.5 "biểu tượng đang nói"): ghế online có mic đang thật sự phát ra âm ngay lúc này. Luôn false ở
   * solo/hotseat (không có voice) — `HudInput.speakingSeats` không truyền vào thì coi như không ai đang nói. */
  readonly speaking: boolean;
}

export interface HudView {
  readonly phaseText: string;
  readonly turnText: string;
  /** Đếm ngược lượt (R-12); null khi không có đồng hồ (lượt của bot, pha xúc xắc, hết ván). */
  readonly clockText: string | null;
  /** Còn ≤ 10 giây (PLAN 12.6: đếm ngược 10 giây cuối). */
  readonly clockUrgent: boolean;
  readonly yourTurn: boolean;
  /** PLAN 11.2 "Trên giữa": vòng ngoài biến mất sau X hiệp; null nếu còn xa hoặc lịch đã hết. */
  readonly collapseText: string | null;
  readonly collapseLevel: 'yellow' | 'red' | null;
  readonly showDice: boolean;
  /** Nút "Lưu & thoát": ẩn khi ván đã kết thúc (bảng kết quả có nút riêng, không còn gì để lưu). */
  readonly showExit: boolean;
  readonly players: readonly PlayerRow[];
}

export interface HudInput {
  readonly state: GameState;
  readonly seats: readonly SeatStatus[];
  readonly you: readonly Seat[];
  readonly deadline: number | null;
  readonly now: number;
  /** M7.4: ghế nào đang có tiếng voice thật sự phát ra (từ VoiceManager, xem net/voice-manager.ts) — bỏ trống ở
   * solo/hotseat/ván online chưa bật voice. */
  readonly speakingSeats?: ReadonlySet<Seat>;
}

/** Tên hiển thị của một ghế: "Bạn", "Bot Dễ", hoặc "Ghế N" (hotseat / người khác). */
export function seatName(seat: Seat, seats: readonly SeatStatus[], you: readonly Seat[], t: Translator): string {
  const status = seats.find((s) => s.seat === seat);
  if (status?.kind === 'bot') return t('player.bot', { difficulty: t(`difficulty.${status.difficulty ?? 'normal'}`) });
  if (you.length === 1 && you[0] === seat) return t('seat.you');
  return t('seat.label', { seat });
}

/** Chỉ hiện đếm ngược thu hẹp khi đã vào vùng cảnh báo hoặc còn ít hơn chừng này hiệp. */
const COLLAPSE_HORIZON = 10;

export function buildHudView(input: HudInput, t: Translator): HudView {
  const { state, seats, you, deadline, now, speakingSeats } = input;
  const turn = state.turnSeat;
  const playing = state.phase === 'playing';
  const yourTurn = playing && turn !== null && you.includes(turn);

  const phaseText = state.phase === 'dice' ? t('phase.dice') : state.phase === 'over' ? t('phase.over') : t('phase.playing', { round: state.round });
  let turnText = '';
  if (playing && turn !== null) {
    turnText = yourTurn && you.length === 1 ? t('hud.yourTurn') : t('turn.of', { seat: seatName(turn, seats, you, t) });
  }

  let clockText: string | null = null;
  let clockUrgent = false;
  if (playing && deadline !== null) {
    const seconds = Math.max(0, Math.ceil((deadline - now) / 1000));
    clockText = t('hud.seconds', { seconds });
    clockUrgent = seconds <= 10;
  }

  let collapseText: string | null = null;
  let collapseLevel: 'yellow' | 'red' | null = null;
  const upcoming = state.phase === 'over' ? undefined : nextCollapse(state);
  if (upcoming !== undefined && (upcoming.level !== null || upcoming.roundsLeft <= COLLAPSE_HORIZON)) {
    collapseText = t('hud.collapseIn', { ring: upcoming.event.ring, rounds: upcoming.roundsLeft });
    collapseLevel = upcoming.level;
  }

  const players: PlayerRow[] = state.order
    .slice()
    .sort((a, b) => a - b)
    .map((seat) => {
      const status = seats.find((s) => s.seat === seat);
      const elimination = state.eliminated.find((e) => e.seat === seat);
      const tags: string[] = [];
      if (status?.kind === 'bot') tags.push(t('hud.tag.bot'));
      if (status?.botControlled === true) tags.push(t('hud.tag.botControlled'));
      if (elimination !== undefined) tags.push(t('hud.tag.eliminated', { round: elimination.round }));
      return {
        seat,
        name: seatName(seat, seats, you, t),
        seatLabel: t('seat.label', { seat }),
        color: toCss(seatColor(seat)),
        pieces: state.pieces.filter((p) => p.owner === seat && p.status === 'active').length,
        kills: state.playerKills[seat] ?? 0,
        score: elimination !== undefined ? elimination.score : scoreOf(state, seat),
        alive: elimination === undefined,
        isTurn: playing && turn === seat,
        isYou: you.length === 1 && you[0] === seat,
        tags,
        speaking: speakingSeats?.has(seat) ?? false,
      };
    });

  return {
    phaseText,
    turnText,
    clockText,
    clockUrgent,
    yourTurn,
    collapseText,
    collapseLevel,
    showDice: state.phase === 'dice' && you.length > 0,
    showExit: state.phase !== 'over',
    players,
  };
}
