// HUD phủ lên canvas bằng HTML/CSS (PLAN 6.2: "không dùng UI trong WebGL"). M4 = HUD tối thiểu (PLAN 15): thanh trên
// (hiệp, lượt, đồng hồ, đếm ngược thu hẹp), bảng người chơi, nút tung xúc xắc, thông báo ngắn, nút lưu & thoát, và
// bảng kết quả. HUD đầy đủ (chat, bản đồ nhỏ, thông tin quân đang chọn…) là việc của M5.
// Mọi chữ lấy từ `buildHudView` (thuần, có test) hoặc qua `t(...)` — không chữ cứng.
import type { SeatStatus } from '@hexwar/protocol';
import type { GameEvent, GameResult, IllegalReason, Seat } from '@hexwar/rules';
import type { Selection } from '../core/controller';
import type { DisplayModel } from '../core/display-model';
import type { Translator } from '../core/i18n';
import { buildSelectionView, type SelectionView } from '../core/selection-model';
import { describeEvent } from './event-text';
import { seatName, type HudInput as BaseHudInput, type HudView, type PlayerRow } from './hud-model';
import { buildHudView } from './hud-model';

export interface HudInput extends BaseHudInput {
  /** Quân đang chọn (PLAN 11.2 "Dưới giữa"); null nếu chưa chọn gì. */
  readonly selection: Selection | null;
}

export interface HudCallbacks {
  readonly onRollDice: () => void;
  /** Lưu & thoát về màn bắt đầu (X-10: ván đã tự lưu sau mỗi lượt, nút này chỉ rời ván). */
  readonly onExit: () => void;
  readonly onNewGame: () => void;
  readonly onMenu: () => void;
  readonly onOpenSettings: () => void;
  /** X-05: đã xác nhận đầu hàng qua hộp thoại của chính HUD. */
  readonly onResign: () => void;
  /** X-14: nút Xác nhận/Hủy trên bảng thông tin quân đang chọn. */
  readonly onConfirmMove: () => void;
  readonly onCancelMove: () => void;
  /** PLAN 8.2 "bấm tên một người chơi (ở bảng người chơi...) → mở khung nhắn riêng" — chỉ có tác dụng ở ván online
   * (main.ts bỏ qua khi solo/hotseat, không có chat thật để mở). */
  readonly onPlayerClick: (seat: Seat) => void;
}

/** Bao nhiêu thông báo giữ lại cùng lúc trên màn hình trước khi cái cũ nhất bị dọn. */
const MAX_TOASTS = 6;
const TOAST_LIFETIME_MS = 6000;

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.className = className;
  parent?.appendChild(node);
  return node;
}

function button(label: string, className: string, onClick: () => void, parent: HTMLElement): HTMLButtonElement {
  const b = el('button', className, parent);
  b.type = 'button';
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

export class Hud {
  private readonly root: HTMLElement;
  private readonly phase: HTMLElement;
  private readonly turn: HTMLElement;
  private readonly clock: HTMLElement;
  private readonly collapse: HTMLElement;
  private readonly diceButton: HTMLButtonElement;
  private readonly players: HTMLElement;
  private readonly toasts: HTMLElement;
  private readonly result: HTMLElement;
  private readonly exitButton: HTMLButtonElement;
  private readonly resignButton: HTMLButtonElement;
  private readonly selectionPanel: HTMLElement;
  private readonly resignDialog: HTMLElement;
  private lastRender = '';
  private lastSelectionRender = '';
  private shownResult: GameResult | null = null;
  private resultSeats: { seats: readonly SeatStatus[]; you: readonly Seat[] } = { seats: [], you: [] };

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    private readonly callbacks: HudCallbacks,
  ) {
    this.root = el('div', 'hud', parent);

    const top = el('div', 'hud-topbar', this.root);
    this.phase = el('span', 'hud-phase', top);
    this.turn = el('span', 'hud-turn', top);
    this.clock = el('span', 'hud-clock', top);
    this.collapse = el('div', 'hud-collapse hud-hidden', this.root);

    this.diceButton = button(t('app.rollDice'), 'hud-dice', callbacks.onRollDice, this.root);
    this.players = el('div', 'hud-players', this.root);
    this.toasts = el('div', 'hud-toasts', this.root);
    this.selectionPanel = el('div', 'hud-selection hud-hidden', this.root);

    const corner = el('div', 'hud-corner', this.root);
    this.exitButton = button(t('hud.exit'), 'hud-exit', callbacks.onExit, corner);

    // PLAN 11.2 "Dưới phải": Cài đặt, Đầu hàng (voice là việc của M7).
    const cornerBr = el('div', 'hud-corner-br', this.root);
    button(t('hud.settings'), 'hud-btn', callbacks.onOpenSettings, cornerBr);
    this.resignButton = button(t('control.resign'), 'hud-btn hud-btn-danger', () => this.openResignDialog(), cornerBr);

    const hint = el('div', 'hud-hint', this.root);
    hint.textContent = (
      ['control.rotateCamera', 'control.zoomCamera', 'control.panCamera', 'control.rotateSeat', 'control.jumpToSeat', 'control.topDown', 'control.cancel'] as const
    )
      .map((key) => t(key))
      .join('  ·  ');

    this.result = el('div', 'hud-result hud-hidden', this.root);

    // X-05: đầu hàng có hộp xác nhận (PLAN mục 5).
    this.resignDialog = el('div', 'hud-confirm-dialog hud-hidden', this.root);
    el('p', '', this.resignDialog).textContent = t('hud.resign.question');
    const resignActions = el('div', 'hud-confirm-actions', this.resignDialog);
    button(t('control.resign'), 'hud-btn hud-btn-danger', () => {
      this.resignDialog.classList.add('hud-hidden');
      callbacks.onResign();
    }, resignActions);
    button(t('hud.resign.cancel'), 'hud-btn', () => this.resignDialog.classList.add('hud-hidden'), resignActions);
  }

  private openResignDialog(): void {
    this.resignDialog.classList.remove('hud-hidden');
  }

  /** Gọi mỗi khung hình (đồng hồ chạy); chỉ đụng DOM khi nội dung thật sự đổi. */
  update(input: HudInput): void {
    const view = buildHudView(input, this.t);
    const key = JSON.stringify(view);
    if (key !== this.lastRender) {
      this.lastRender = key;
      this.render(view);
    }
    this.resultSeats = { seats: input.seats, you: input.you };
    const result = input.state.phase === 'over' ? (input.state.result ?? null) : null;
    if (result !== this.shownResult) {
      this.shownResult = result;
      if (result === null) this.result.classList.add('hud-hidden');
      else this.showResult(result);
    }
    this.resignButton.classList.toggle('hud-hidden', !view.showExit); // ẩn cùng lúc với "Lưu & thoát" khi ván kết thúc

    const selectionView = input.selection === null ? null : buildSelectionView(input.state, input.selection, this.t);
    const selectionKey = JSON.stringify(selectionView);
    if (selectionKey !== this.lastSelectionRender) {
      this.lastSelectionRender = selectionKey;
      this.renderSelection(selectionView);
    }
  }

  private renderSelection(view: SelectionView | null): void {
    this.selectionPanel.classList.toggle('hud-hidden', view === null);
    if (view === null) return;
    this.selectionPanel.replaceChildren();
    el('div', 'hud-selection-title', this.selectionPanel).textContent = view.pieceLabel;
    el('div', '', this.selectionPanel).textContent = view.reachText;
    if (view.captiveText !== null) el('div', '', this.selectionPanel).textContent = view.captiveText;
    if (view.killsText !== null) el('div', '', this.selectionPanel).textContent = view.killsText;
    if (view.promotionProgress !== null) {
      const bar = el('div', 'hud-selection-progress', this.selectionPanel);
      el('div', 'hud-selection-progress-bar', bar).style.width = `${Math.round(view.promotionProgress * 100)}%`;
    }
    if (view.promotionText !== null) el('div', '', this.selectionPanel).textContent = view.promotionText;
    if (view.hasPending) {
      const actions = el('div', 'hud-selection-actions', this.selectionPanel);
      button(this.t('hud.confirmMove'), 'hud-btn hud-btn-primary', this.callbacks.onConfirmMove, actions);
      button(this.t('hud.cancelMove'), 'hud-btn', this.callbacks.onCancelMove, actions);
    }
  }

  private render(view: HudView): void {
    this.phase.textContent = view.phaseText;
    this.turn.textContent = view.turnText;
    this.turn.classList.toggle('hud-turn-mine', view.yourTurn);
    this.clock.textContent = view.clockText ?? '';
    this.clock.classList.toggle('hud-hidden', view.clockText === null);
    this.clock.classList.toggle('hud-clock-urgent', view.clockUrgent);
    this.collapse.textContent = view.collapseText ?? '';
    this.collapse.classList.toggle('hud-hidden', view.collapseText === null);
    this.collapse.dataset['level'] = view.collapseLevel ?? 'none';
    this.diceButton.classList.toggle('hud-hidden', !view.showDice);
    this.exitButton.classList.toggle('hud-hidden', !view.showExit);
    this.players.replaceChildren(...view.players.map((row) => this.playerRow(row)));
  }

  private playerRow(row: PlayerRow): HTMLElement {
    const node = el('div', 'hud-player');
    node.dataset['seat'] = String(row.seat);
    node.classList.toggle('hud-player-turn', row.isTurn);
    node.classList.toggle('hud-player-you', row.isYou);
    node.classList.toggle('hud-player-out', !row.alive);
    const swatch = el('span', 'hud-swatch', node);
    swatch.style.background = row.color;
    const name = el('span', 'hud-player-name', node);
    name.textContent = row.name;
    if (!row.isYou) name.addEventListener('click', () => this.callbacks.onPlayerClick(row.seat));
    if (row.speaking) el('span', 'hud-player-speaking', node).title = this.t('voice.speaking'); // M7.4, PLAN 8.5
    const seat = el('span', 'hud-player-seat', node);
    seat.textContent = row.seatLabel;
    const stats = el('span', 'hud-player-stats', node);
    stats.textContent = this.t('hud.stats', { pieces: row.pieces, kills: row.kills, score: row.score });
    for (const tag of row.tags) el('span', 'hud-tag', node).textContent = tag;
    return node;
  }

  /** Một sự kiện engine bắt đầu chạy hoạt ảnh (PLAN 11.2: thông báo đi kèm lúc sự kiện diễn ra, không phải tức thời). */
  announceEvent(event: GameEvent, model: DisplayModel): void {
    for (const line of describeEvent(event, model, this.t)) this.pushToast(line);
  }

  announceRejected(reason: IllegalReason | string): void {
    this.pushToast(this.t(`illegal.${reason}`));
  }

  announce(text: string): void {
    this.pushToast(text);
  }

  clearToasts(): void {
    this.toasts.replaceChildren();
  }

  private pushToast(text: string): void {
    const node = el('div', 'hud-toast', this.toasts);
    node.textContent = text;
    while (this.toasts.childElementCount > MAX_TOASTS) this.toasts.firstElementChild?.remove();
    setTimeout(() => node.remove(), TOAST_LIFETIME_MS);
  }

  private showResult(result: GameResult): void {
    const { seats, you } = this.resultSeats;
    this.clearToasts();
    this.result.classList.remove('hud-hidden');
    this.result.replaceChildren();
    el('h2', '', this.result).textContent = this.t('app.result.title');
    for (const entry of [...result.ranking].sort((a, b) => a.rank - b.rank)) {
      const row = el('div', 'hud-result-row', this.result);
      row.dataset['seat'] = String(entry.seat);
      const status = entry.eliminatedRound === null ? this.t('app.result.alive') : this.t('app.result.eliminatedRound', { round: entry.eliminatedRound });
      row.textContent = this.t('app.result.row', {
        rank: entry.rank,
        seat: `${seatName(entry.seat, seats, you, this.t)} (${this.t('seat.label', { seat: entry.seat })})`,
        score: entry.score,
        kills: entry.kills,
        pieces: entry.pieces,
        status,
      });
    }
    const actions = el('div', 'hud-result-actions', this.result);
    button(this.t('app.result.newGame'), 'hud-btn hud-btn-primary', this.callbacks.onNewGame, actions);
    button(this.t('app.result.menu'), 'hud-btn', this.callbacks.onMenu, actions);
  }

  setVisible(visible: boolean): void {
    this.root.classList.toggle('hud-hidden', !visible);
    if (!visible) this.resignDialog.classList.add('hud-hidden'); // không để hộp xác nhận đầu hàng còn mở khi vào ván khác
  }

  dispose(): void {
    this.root.remove();
  }
}
