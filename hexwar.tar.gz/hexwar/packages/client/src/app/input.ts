// Chuột + bàn phím → camera (core/camera.ts) và chọn ô (core/picking.ts + core/controller.ts). Đây là NƠI DUY
// NHẤT trong M3 gọi `addEventListener` trên canvas/`window` — mọi toán học đều gọi lại các hàm thuần đã có test
// riêng, file này chỉ nối dây (PLAN 11.3: chuột phải xoay, cuộn zoom, Shift+kéo dịch chuyển; WASD/Q/E/F/Esc).
import type { Seat } from '@hexwar/rules';
import { FOV_DEG, cameraPose, clampOrbit, panOrbit, rayFromNdc, rotateOrbit, seatOrbit, topDownOrbit, zoomOrbit, type OrbitState } from '../core/camera';
import type { GameController } from '../core/controller';
import { pickCell, type PickablePiece } from '../core/picking';

export interface InputHost {
  readonly canvas: HTMLCanvasElement;
  getOrbit(): OrbitState;
  setOrbit(next: OrbitState): void;
  getRadius(): number;
  getPieces(): readonly PickablePiece[];
  getTurnSeat(): Seat | null;
  readonly seatCornerRing: number;
}

/** Quá ngưỡng này (px, tổng |dx| + |dy|) thì coi là kéo camera chứ không phải bấm chọn ô (PLAN 11.3). */
const DRAG_THRESHOLD = 4;
const ROTATE_SPEED = 0.008;
const PAN_SPEED = 0.05;
/** Hệ số zoom mỗi đơn vị `deltaY` của cuộn chuột (mượt, không giật ở cả trackpad lẫn chuột lăn). */
const ZOOM_STEP = 1.0015;
const KEY_PAN_STEP = 1.5;
const KEY_ROTATE_STEP = Math.PI / 3; // 60°, xoay theo ghế (PLAN 11.4)

/**
 * Nối input DOM vào một `InputHost` + bộ điều khiển của ván hiện tại (`getController`: null khi đang ở màn bắt đầu —
 * vẫn xoay/zoom được bàn cờ nền nhưng không chọn quân). Trả về hàm gỡ toàn bộ listener (dùng khi dọn dẹp/test).
 */
export function attachInput(host: InputHost, getController: () => GameController | null): () => void {
  const canvas = host.canvas;
  let dragButton: number | null = null;
  let lastX = 0;
  let lastY = 0;
  let moved = 0;

  const onContextMenu = (e: MouseEvent): void => e.preventDefault();

  const onPointerDown = (e: PointerEvent): void => {
    dragButton = e.button;
    lastX = e.clientX;
    lastY = e.clientY;
    moved = 0;
    canvas.setPointerCapture(e.pointerId);
  };

  const onPointerMove = (e: PointerEvent): void => {
    if (dragButton === null) return;
    const dx = e.clientX - lastX;
    const dy = e.clientY - lastY;
    lastX = e.clientX;
    lastY = e.clientY;
    moved += Math.abs(dx) + Math.abs(dy);
    const radius = host.getRadius();
    if (dragButton === 2) {
      host.setOrbit(rotateOrbit(host.getOrbit(), -dx * ROTATE_SPEED, dy * ROTATE_SPEED, radius));
    } else if (dragButton === 1 || e.shiftKey) {
      host.setOrbit(panOrbit(host.getOrbit(), -dx * PAN_SPEED, dy * PAN_SPEED, radius));
    }
  };

  const pick = (e: PointerEvent): void => {
    const rect = canvas.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) return;
    const ndcX = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const ndcY = 1 - ((e.clientY - rect.top) / rect.height) * 2;
    const pose = cameraPose(host.getOrbit());
    const ray = rayFromNdc(pose, ndcX, ndcY, FOV_DEG, rect.width / rect.height);
    getController()?.handlePick(pickCell(ray, host.getPieces(), host.getRadius()));
  };

  const onPointerUp = (e: PointerEvent): void => {
    if (dragButton === 0 && moved < DRAG_THRESHOLD) pick(e);
    dragButton = null;
  };

  const onWheel = (e: WheelEvent): void => {
    e.preventDefault();
    host.setOrbit(zoomOrbit(host.getOrbit(), Math.pow(ZOOM_STEP, e.deltaY), host.getRadius()));
  };

  const onKeyDown = (e: KeyboardEvent): void => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLSelectElement) return; // đang gõ/chọn trong menu
    const radius = host.getRadius();
    switch (e.key.toLowerCase()) {
      case 'escape': {
        // X-14: nếu đang có nước chờ xác nhận thì Esc chỉ huỷ nước đó (PLAN 11.3 "Esc Hủy"); bấm Esc lần nữa mới
        // bỏ chọn quân hẳn — không mất luôn cả lựa chọn quân chỉ vì đổi ý về ô đích.
        const controller = getController();
        if (controller?.selection?.pendingMove !== undefined) controller?.cancelPending();
        else controller?.clearSelection();
        break;
      }
      case ' ':
        // X-14 (PLAN 11.3 "Space xác nhận"): không làm gì nếu chưa có nước nào đang chờ.
        getController()?.confirmPending();
        break;
      case 'q':
        host.setOrbit(rotateOrbit(host.getOrbit(), -KEY_ROTATE_STEP, 0, radius));
        break;
      case 'e':
        host.setOrbit(rotateOrbit(host.getOrbit(), KEY_ROTATE_STEP, 0, radius));
        break;
      case 'w':
        host.setOrbit(panOrbit(host.getOrbit(), 0, KEY_PAN_STEP, radius));
        break;
      case 's':
        host.setOrbit(panOrbit(host.getOrbit(), 0, -KEY_PAN_STEP, radius));
        break;
      case 'a':
        host.setOrbit(panOrbit(host.getOrbit(), -KEY_PAN_STEP, 0, radius));
        break;
      case 'd':
        host.setOrbit(panOrbit(host.getOrbit(), KEY_PAN_STEP, 0, radius));
        break;
      case 'f': {
        const seat = host.getTurnSeat();
        if (seat !== null) host.setOrbit(seatOrbit(seat, host.seatCornerRing));
        break;
      }
      case 'm':
        host.setOrbit(clampOrbit(topDownOrbit(host.getOrbit()), radius));
        break;
      default:
        break;
    }
  };

  canvas.addEventListener('contextmenu', onContextMenu);
  canvas.addEventListener('pointerdown', onPointerDown);
  canvas.addEventListener('pointermove', onPointerMove);
  canvas.addEventListener('pointerup', onPointerUp);
  canvas.addEventListener('wheel', onWheel, { passive: false });
  window.addEventListener('keydown', onKeyDown);

  return () => {
    canvas.removeEventListener('contextmenu', onContextMenu);
    canvas.removeEventListener('pointerdown', onPointerDown);
    canvas.removeEventListener('pointermove', onPointerMove);
    canvas.removeEventListener('pointerup', onPointerUp);
    canvas.removeEventListener('wheel', onWheel);
    window.removeEventListener('keydown', onKeyDown);
  };
}
