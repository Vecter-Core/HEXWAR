// Màn chờ trong phòng (PLAN 7.2): danh sách 6 ghế (người/bot/trống, ai sẵn sàng, ai vừa mất kết nối), mã phòng
// (phòng riêng), đếm ngược lấp bot (ghép nhanh). Chỉ đọc/hiển thị `room.state` — không tự quyết gì, server quyết
// khi nào ván bắt đầu (PLAN 7.6, "không tin client"): mọi nút ở đây chỉ gửi Ý ĐỊNH rồi vẽ lại đúng cái server trả về.
import { DIFFICULTIES, PERSONALITIES, type Difficulty, type Personality, type RoomSeatView } from '@hexwar/protocol';
import type { Seat } from '@hexwar/rules';
import type { Translator } from '../core/i18n';

export interface LobbyCallbacks {
  readonly onReady: (ready: boolean) => void;
  /** PLAN 9.4, M9: chủ phòng chọn độ khó + tính cách cho bot mới trước khi thêm (menu.ts có cùng hai lựa chọn này). */
  readonly onAddBot: (difficulty: Difficulty, personality: Personality) => void;
  readonly onRemoveBot: (seat: Seat) => void;
  readonly onLeave: () => void;
}

export interface LobbyView {
  readonly code: string | null;
  readonly seats: readonly RoomSeatView[];
  readonly host: Seat | null;
  readonly quickMatch: boolean;
  readonly botFillInMs: number | null;
}

export class Lobby {
  private readonly root: HTMLElement;
  private readonly codeLine: HTMLElement;
  private readonly noteLine: HTMLElement;
  private readonly seatsList: HTMLElement;
  private readonly readyButton: HTMLButtonElement;
  private readonly addBotRow: HTMLElement;
  private readonly addBotButton: HTMLButtonElement;
  private readonly addBotDifficulty: HTMLSelectElement;
  private readonly addBotPersonality: HTMLSelectElement;

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    private readonly callbacks: LobbyCallbacks,
  ) {
    this.root = document.createElement('div');
    this.root.className = 'menu lobby hud-hidden';
    const card = document.createElement('div');
    card.className = 'menu-card';
    this.root.appendChild(card);

    const title = document.createElement('h1');
    title.className = 'menu-title lobby-title';
    title.textContent = t('lobby.title');
    card.appendChild(title);

    this.codeLine = document.createElement('div');
    this.codeLine.className = 'menu-info lobby-code';
    card.appendChild(this.codeLine);
    this.noteLine = document.createElement('div');
    this.noteLine.className = 'menu-info lobby-note';
    card.appendChild(this.noteLine);

    this.seatsList = document.createElement('div');
    this.seatsList.className = 'lobby-seats';
    card.appendChild(this.seatsList);

    const addBotRow = document.createElement('div');
    addBotRow.className = 'lobby-add-bot-row';
    this.addBotDifficulty = document.createElement('select');
    this.addBotDifficulty.className = 'lobby-add-bot-difficulty';
    for (const difficulty of DIFFICULTIES) {
      const opt = document.createElement('option');
      opt.value = difficulty;
      opt.textContent = t(`difficulty.${difficulty}`);
      this.addBotDifficulty.appendChild(opt);
    }
    this.addBotDifficulty.value = 'normal';
    addBotRow.appendChild(this.addBotDifficulty);

    // PLAN 9.4 (M9): tính cách chỉ có ý nghĩa với Thường/Khó, nhưng để đơn giản (giống client menu solo) luôn cho
    // chọn — 'balanced' (mặc định) ứng với hành vi hệt như không chọn tính cách.
    this.addBotPersonality = document.createElement('select');
    this.addBotPersonality.className = 'lobby-add-bot-personality';
    for (const personality of PERSONALITIES) {
      const opt = document.createElement('option');
      opt.value = personality;
      opt.textContent = t(`personality.${personality}`);
      this.addBotPersonality.appendChild(opt);
    }
    this.addBotPersonality.value = 'balanced';
    addBotRow.appendChild(this.addBotPersonality);

    this.addBotButton = document.createElement('button');
    this.addBotButton.type = 'button';
    this.addBotButton.className = 'menu-btn menu-btn-quiet lobby-add-bot';
    this.addBotButton.textContent = t('lobby.addBot');
    this.addBotButton.addEventListener('click', () =>
      callbacks.onAddBot(this.addBotDifficulty.value as Difficulty, this.addBotPersonality.value as Personality),
    );
    addBotRow.appendChild(this.addBotButton);
    card.appendChild(addBotRow);
    this.addBotRow = addBotRow;

    this.readyButton = document.createElement('button');
    this.readyButton.type = 'button';
    this.readyButton.className = 'menu-btn menu-btn-primary lobby-ready';
    this.readyButton.textContent = t('lobby.readyAction');
    this.readyButton.addEventListener('click', () => callbacks.onReady(this.readyButton.dataset['ready'] !== 'true'));
    card.appendChild(this.readyButton);

    const leave = document.createElement('button');
    leave.type = 'button';
    leave.className = 'menu-btn menu-btn-quiet lobby-leave';
    leave.textContent = t('lobby.leave');
    leave.addEventListener('click', () => callbacks.onLeave());
    card.appendChild(leave);

    parent.appendChild(this.root);
  }

  show(view: LobbyView): void {
    this.root.classList.remove('hud-hidden');
    this.codeLine.textContent = view.code !== null ? this.t('lobby.codeLabel', { code: view.code }) : '';
    this.noteLine.textContent =
      view.botFillInMs !== null
        ? this.t('lobby.botFillIn', { seconds: String(Math.ceil(view.botFillInMs / 1000)) })
        : view.quickMatch
          ? this.t('lobby.quickMatchNote')
          : '';

    const mine = view.seats.find((s) => s.you);
    const amHost = mine !== undefined && view.host === mine.seat;
    const mineReady = mine !== undefined && mine.ready;
    this.readyButton.dataset['ready'] = String(mineReady);
    this.readyButton.textContent = this.t(mineReady ? 'lobby.notReadyAction' : 'lobby.readyAction');
    this.readyButton.classList.toggle('hud-hidden', view.quickMatch);
    this.addBotRow.classList.toggle('hud-hidden', view.quickMatch || !amHost);

    this.seatsList.textContent = '';
    for (const seat of view.seats) {
      this.seatsList.appendChild(this.seatRow(seat, view, amHost));
    }
  }

  /** PLAN 9.4 (M9): thêm tên tính cách vào nhãn ghế bot khi khác 'balanced' (mặc định không nói gì, đỡ rối cho ghế thường). */
  private botSeatLabel(seat: RoomSeatView): string {
    const difficulty = this.t(`difficulty.${seat.difficulty}`);
    if (seat.personality === undefined || seat.personality === 'balanced') return this.t('lobby.seatBot', { difficulty });
    return this.t('lobby.seatBotPersonality', { difficulty, personality: this.t(`personality.${seat.personality}`) });
  }

  private seatRow(seat: RoomSeatView, view: LobbyView, amHost: boolean): HTMLElement {
    const row = document.createElement('div');
    row.className = 'lobby-seat' + (seat.you ? ' lobby-seat-you' : '');
    const label = document.createElement('span');
    label.className = 'lobby-seat-label';
    label.textContent =
      seat.kind === 'empty'
        ? this.t('lobby.seatEmpty')
        : seat.kind === 'bot'
          ? this.botSeatLabel(seat)
          : (seat.name ?? '');
    row.appendChild(label);

    if (view.host === seat.seat) {
      const host = document.createElement('span');
      host.className = 'lobby-seat-tag';
      host.textContent = this.t('lobby.host');
      row.appendChild(host);
    }
    if (seat.you) {
      const you = document.createElement('span');
      you.className = 'lobby-seat-tag';
      you.textContent = this.t('lobby.you');
      row.appendChild(you);
    }
    if (seat.kind === 'human' && !view.quickMatch) {
      const status = document.createElement('span');
      status.className = 'lobby-seat-status';
      status.textContent = !seat.connected ? this.t('lobby.disconnected') : seat.ready ? this.t('lobby.ready') : this.t('lobby.notReady');
      row.appendChild(status);
    }
    if (seat.kind === 'bot' && amHost && !view.quickMatch) {
      const remove = document.createElement('button');
      remove.type = 'button';
      remove.className = 'lobby-seat-remove';
      remove.textContent = this.t('lobby.removeBot');
      remove.addEventListener('click', () => this.callbacks.onRemoveBot(seat.seat));
      row.appendChild(remove);
    }
    return row;
  }

  hide(): void {
    this.root.classList.add('hud-hidden');
  }
}
