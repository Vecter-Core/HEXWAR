// Điểm vào ứng dụng (M4): màn bắt đầu → ván solo 1 người + 5 bot chạy trong Web Worker (hoặc hotseat 6 người) →
// kết quả; thoát và vào lại từ bản tự lưu (PLAN 15 M4, X-10). File này CHỦ Ý mỏng: chỉ lắp ráp các lớp đã có test
// riêng (core/*, scene/*, net/*, app/hud-model.ts) với DOM/THREE/Worker thật. Không luật, không toán camera ở đây.
import * as THREE from 'three';
import { EffectComposer } from 'three/addons/postprocessing/EffectComposer.js';
import { OutputPass } from 'three/addons/postprocessing/OutputPass.js';
import { RenderPass } from 'three/addons/postprocessing/RenderPass.js';
import { SSAOPass } from 'three/addons/postprocessing/SSAOPass.js';
import { UnrealBloomPass } from 'three/addons/postprocessing/UnrealBloomPass.js';
import { SEATS, defaultConfig, newGame, nextCollapse, type GameState, type Seat } from '@hexwar/rules';
import type { ChatSend, Personality, PhraseId, SeatStatus, SessionTiming } from '@hexwar/protocol';
import type { ScenarioLesson } from '@hexwar/tutorial';
import './style.css';
import { AnimationDirector } from '../core/animation';
import { DEFAULT_DISTANCE, DEFAULT_ELEVATION, FOV_DEG, MIN_DISTANCE, cameraPose, clampOrbit, seatOrbit, type OrbitState } from '../core/camera';
import type { ChatRosterEntry, ChatSendTarget } from './chat-panel';
import { DisplayModel } from '../core/display-model';
import { GameLink } from '../core/game-link';
import { graphicsProfileFor } from '../core/graphics-quality';
import { translatorFor } from '../core/i18n';
import { boardExtent } from '../core/layout';
import { buildMinimapView } from '../core/minimap-model';
import type { PickablePiece } from '../core/picking';
import { NO_THREATS, threatsFor } from '../core/threats';
import { AudioManager } from '../net/audio-manager';
import { hotseatSeats, soloSeats } from '../net/seats';
import { LocalStorageSaveStore } from '../net/save-store';
import { LocalStorageSettingsStore, type GraphicsQuality, type Settings } from '../net/settings-store';
import { LocalStorageTutorialProgressStore } from '../net/tutorial-progress-store';
import { TutorialTransport } from '../net/tutorial-transport';
import type { Transport } from '../net/transport';
import { WorkerTransport } from '../net/transport';
import { DEFAULT_ICE_SERVERS, VoiceManager } from '../net/voice-manager';
import { resolveServerUrl, WebSocketTransport } from '../net/websocket-transport';
import { BoardScene } from '../scene/board-scene';
import { ChatPanel } from './chat-panel';
import { installDebugHook } from './e2e-hook';
import { Hud } from './hud';
import { seatName } from './hud-model';
import { attachInput, type InputHost } from './input';
import { Lobby } from './lobby';
import { Menu, type SoloDifficulty } from './menu';
import { Minimap } from './minimap';
import { OnlineMenu } from './online-menu';
import { SettingsPanel } from './settings-panel';
import { TutorialPanel } from './tutorial-panel';
import { VoiceBar } from './voice-bar';

const params = new URLSearchParams(window.location.search);

/** `?seed=N` cho kết quả tái lập được (ảnh chụp Playwright, gỡ lỗi); mặc định mỗi ván mới một seed. */
function pickSeed(): number {
  const fromUrl = Number(params.get('seed'));
  return Number.isFinite(fromUrl) && fromUrl > 0 ? fromUrl >>> 0 : Date.now() >>> 0;
}

/** `?fast=1` (chỉ cho kiểm thử): bot đi ngay, không chờ hoạt ảnh — để Playwright chơi hết ván trong vài phút. */
const FAST_TIMING: Partial<SessionTiming> = {
  botDelayMinMs: 0,
  botDelayMaxMs: 0,
  spectatorBotDelayMs: 0,
  graceMoveMs: 0,
  graceCollapseMs: 0,
};
const timing = params.has('fast') ? FAST_TIMING : undefined;

/** Hàng đợi hoạt ảnh dài hơn mức này (bot đi dồn dập khi xem tiếp) thì bỏ qua hoạt ảnh cho kịp trạng thái thật. */
const MAX_ANIMATION_BACKLOG = 40;

interface ActiveGame {
  readonly link: GameLink;
  model: DisplayModel;
  animator: AnimationDirector;
  /** M8: 'tutorial' = một bài kịch bản (`ScenarioLesson`) chạy qua `TutorialTransport` — vẫn dùng NGUYÊN
   * GameLink/Hud/BoardScene như ba chế độ kia (T13 "Trận tập" tự nó dùng thẳng 'solo', xem `pickLesson`). */
  readonly mode: 'solo' | 'hotseat' | 'online' | 'tutorial';
  readonly difficulty: SoloDifficulty;
  /** PLAN 9.4, M9: tính cách bot của ván solo hiện tại (chỉ có ý nghĩa ở `mode === 'solo'`). */
  readonly personality: Personality;
  /** X-06: đã báo "Vua đang bị ăn được" cho lần nguy hiểm HIỆN TẠI chưa (báo lại nếu thoát nguy rồi lại gặp). */
  kingWarned: boolean;
}

/** Mức đồ hoạ → pixelRatio hiệu dụng (PLAN 11.5; chưa có bóng đổ/SSAO/bloom, đó là việc của M10 — docs/decisions.md). */
function pixelRatioFor(quality: GraphicsQuality): number {
  const dpr = window.devicePixelRatio || 1;
  return quality === 'low' ? 1 : quality === 'medium' ? Math.min(dpr, 1.5) : Math.min(dpr, 2);
}

function main(): void {
  const app = document.getElementById('app');
  if (app === null) throw new Error('main: thiếu #app trong index.html');

  const settingsStore = new LocalStorageSettingsStore();
  let settings: Settings = settingsStore.load();
  const t = translatorFor(settings.locale);
  const store = new LocalStorageSaveStore();
  const seatCornerRing = defaultConfig.board.seatCornerRing;

  // M10 (PLAN 12.6): tổng hợp SFX/nhạc nền bằng Web Audio. `unlock()` chỉ được phép chạy sau CỬ CHỈ NGƯỜI DÙNG
  // THẬT đầu tiên (chính sách autoplay của trình duyệt) — nghe một lần trên `window` rồi tự gỡ, không quan trọng
  // bấm ở đâu (menu, HUD, canvas), miễn là một sự kiện con trỏ/phím thật đã xảy ra.
  const audio = new AudioManager();
  audio.setVolumes(settings.volumeMaster, settings.volumeMusic, settings.volumeSfx);
  const unlockAudioOnce = (): void => {
    audio.unlock();
    window.removeEventListener('pointerdown', unlockAudioOnce);
    window.removeEventListener('keydown', unlockAudioOnce);
  };
  window.addEventListener('pointerdown', unlockAudioOnce);
  window.addEventListener('keydown', unlockAudioOnce);

  const canvas = document.createElement('canvas');
  canvas.className = 'hexwar-canvas'; // style.css: chỉ canvas cảnh 3D chính mới ăn theo kích thước toàn màn hình
  app.appendChild(canvas);
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
  renderer.setPixelRatio(pixelRatioFor(settings.graphics));
  const camera = new THREE.PerspectiveCamera(FOV_DEG, 1, 1, 500);
  const boardScene = new BoardScene(defaultConfig.board.radius);

  // M10 (PLAN 12.5): hậu kỳ nhẹ theo mức đồ hoạ. `RenderPass` luôn có (nó CHÍNH LÀ phép vẽ cảnh bình thường khi
  // qua composer); `SSAOPass`/`UnrealBloomPass` chỉ thêm vào khi mức đồ hoạ cần, `OutputPass` luôn ở CUỐI (chuyển
  // không gian màu tuyến tính → sRGB đúng như `renderer.render()` tự làm — thiếu nó ảnh sẽ nhợt màu khi qua composer).
  const composer = new EffectComposer(renderer);
  const renderPass = new RenderPass(boardScene.scene, camera);
  const ssaoPass = new SSAOPass(boardScene.scene, camera, 1, 1);
  ssaoPass.kernelRadius = 0.4;
  const bloomPass = new UnrealBloomPass(new THREE.Vector2(1, 1), 0.4, 0.5, 0.82);
  composer.addPass(renderPass);
  composer.addPass(ssaoPass);
  composer.addPass(bloomPass);
  composer.addPass(new OutputPass());

  /** Áp một mức đồ hoạ lên renderer/composer thật (PLAN 12.5) — gọi lúc khởi động và mỗi lần đổi cài đặt (main.ts
   * `settingsPanel.onChange`, giống cách `pixelRatioFor` đã áp dụng ngay từ M5, không cần tải lại trang). */
  function applyGraphicsQuality(quality: Settings['graphics']): void {
    const profile = graphicsProfileFor(quality);
    renderer.shadowMap.enabled = profile.shadows;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    boardScene.applyGraphicsProfile(profile, renderer);
    ssaoPass.enabled = profile.ssao;
    bloomPass.enabled = profile.bloom;
    bloomPass.strength = profile.bloomStrength;
    // `pixelRatioFor` đã đổi `renderer`'s pixelRatio TRƯỚC lệnh gọi này (xem `settingsPanel.onChange`) — composer
    // giữ bản sao riêng, không tự đọc lại, nên phải đồng bộ tay rồi cấp lại kích thước buffer nội bộ cho khớp.
    composer.setPixelRatio(renderer.getPixelRatio());
    resize();
  }
  applyGraphicsQuality(settings.graphics);

  // Bàn cờ nền cho màn bắt đầu: thế cờ đầu ván, nhìn toàn cảnh.
  const previewState: GameState = newGame(defaultConfig, SEATS, 0);
  const preview = { model: DisplayModel.fromState(previewState), animator: new AnimationDirector(DisplayModel.fromState(previewState)) };
  const overview = (): OrbitState =>
    clampOrbit({ azimuth: Math.PI / 2, elevation: (75 * Math.PI) / 180, distance: 100, targetX: 0, targetZ: 0 }, defaultConfig.board.radius);
  let orbit: OrbitState = overview();
  let pickables: readonly PickablePiece[] = [];
  let game: ActiveGame | null = null;
  let lastError: string | null = null;
  /** M10 (PLAN 12.6 "chọn quân"): quân đang chọn ở khung hình TRƯỚC, để chỉ phát tiếng khi vừa đổi lựa chọn. */
  let lastSelectedPieceId: string | null = null;
  /** M10 (PLAN 12.6 "đếm ngược 10 giây cuối"): giây nguyên gần nhất đã phát tiếng tích tắc, tránh phát lại mỗi khung hình. */
  let lastTickSecond: number | null = null;
  /** Kết nối online hiện tại (nếu có) — chỉ để gửi message tầng phòng (PLAN 7.1-7.3); tầng ván đi qua `game.link`
   * như mọi transport khác. Đóng cùng lúc với `game` qua `closeGame()` (transport dùng chung, xem `openGame`). */
  let onlineTransport: WebSocketTransport | null = null;
  /** M7.4 (PLAN 8.5): ghế nào đang phát ra tiếng NGAY LÚC NÀY — vẽ lại mỗi khung hình vào bảng người chơi. */
  const speakingSeats = new Set<Seat>();

  const hud = new Hud(app, t, {
    onRollDice: () => game?.link.rollDice(),
    onExit: () => (game?.mode === 'tutorial' ? showTutorial() : showMenu()),
    // M8: một bài tân thủ (T7/T9) có thể tự kết thúc bằng ăn Vua thật — Hud hiện màn kết quả CHUNG của nó, hai
    // nút của màn đó được định tuyến lại sang "bài kế tiếp"/"về danh sách bài" thay vì "ván mới"/"về menu chính"
    // (xem docs/decisions.md mục M8, và `TutorialPanel.handleGameOverNewGame/Menu`).
    onNewGame: () =>
      game?.mode === 'tutorial' ? tutorialPanel.handleGameOverNewGame() : game?.mode === 'hotseat' ? startHotseat() : startSolo(game?.difficulty ?? 'mixed', game?.personality ?? 'balanced'),
    onMenu: () => (game?.mode === 'tutorial' ? tutorialPanel.handleGameOverMenu() : showMenu()),
    onOpenSettings: () => settingsPanel.show(settings),
    onResign: () => game?.link.resign(),
    onConfirmMove: () => game?.link.controller.confirmPending(),
    onCancelMove: () => game?.link.controller.cancelPending(),
    onPlayerClick: (seat) => {
      if (game?.mode === 'online') chatPanel.openWhisper(seat); // PLAN 8.2 "bấm tên → mở khung nhắn riêng"
    },
  });
  const menu = new Menu(app, t, {
    onNewSolo: (difficulty, personality) => startSolo(difficulty, personality),
    onContinue: () => continueSaved(),
    onHotseat: () => startHotseat(),
    onOnline: () => showOnlineMenu(),
    onTutorial: () => showTutorial(),
    onSettings: () => settingsPanel.show(settings),
  });
  const onlineMenu = new OnlineMenu(app, t, {
    onQuickMatch: () => startOnlineFlow((transport) => transport.sendLobby({ type: 'queue.join', preset: 'classic' })),
    onCreateRoom: () => startOnlineFlow((transport) => transport.sendLobby({ type: 'room.create', preset: 'classic' })),
    onJoinRoom: (code) => startOnlineFlow((transport) => transport.sendLobby({ type: 'room.join', code })),
    onBack: () => showMenu(),
  });
  const lobby = new Lobby(app, t, {
    onReady: (ready) => onlineTransport?.sendLobby({ type: 'room.ready', ready }),
    onAddBot: (difficulty, personality) => onlineTransport?.sendLobby({ type: 'room.addBot', difficulty, personality }),
    onRemoveBot: (seat) => onlineTransport?.sendLobby({ type: 'room.removeBot', seat }),
    onLeave: () => {
      onlineTransport?.sendLobby({ type: 'room.leave' });
      showMenu();
    },
  });
  const minimap = new Minimap(app, t, {
    onJump: (worldX, worldZ) => {
      orbit = clampOrbit({ ...orbit, targetX: worldX, targetZ: worldZ }, game?.model.radius ?? defaultConfig.board.radius);
    },
  });
  minimap.setExtent(boardExtent(defaultConfig.board.radius));
  const settingsPanel = new SettingsPanel(app, t, settings, {
    onChange: (next) => {
      const graphicsChanged = next.graphics !== settings.graphics;
      settings = next;
      settingsStore.save(next);
      renderer.setPixelRatio(pixelRatioFor(next.graphics));
      if (graphicsChanged) applyGraphicsQuality(next.graphics);
      game?.animator.setSpeed(next.reduceMotion ? 2 : 1);
      audio.setVolumes(next.volumeMaster, next.volumeMusic, next.volumeSfx);
    },
    onLocaleChange: (next) => {
      settingsStore.save(next);
      // Đổi ngôn ngữ cần dựng lại toàn bộ chữ trên trang; tải lại là cách đơn giản và chắc chắn nhất (docs/decisions.md).
      // M10: DỪNG vòng lặp vẽ NGAY (không đợi `setTimeout`) trước khi xin tải lại — ở mức đồ hoạ Cao, một khung hình
      // qua `EffectComposer` (SSAO+bloom) có thể mất hơn 1 giây trên phần cứng render bằng phần mềm (không GPU thật,
      // xem docs/perf.md); nếu vòng lặp còn chạy, `window.location.reload()` có thể rơi đúng lúc một khung hình như
      // vậy đang dở dang, khiến trang không phản hồi trong lúc điều hướng (gặp thật khi chạy Playwright ở mức Cao,
      // xem docs/decisions.md mục M10). Dừng trước, tải lại sau — không đổi hành vi trên máy có GPU thật (khung hình
      // ở đó luôn rất ngắn nên trước đây không lộ ra).
      renderer.setAnimationLoop(null);
      const notice = document.createElement('div');
      notice.className = 'menu';
      notice.textContent = t('settings.reloadNotice');
      document.body.appendChild(notice);
      window.setTimeout(() => window.location.reload(), 60);
    },
    onClose: () => settingsPanel.hide(),
  });
  // M8 (PLAN 10.1): tiến độ bài tân thủ + màn danh sách/lời thoại. `getController` hỏi lại `game` mỗi lần (không
  // giữ tham chiếu) vì `GameLink`/`GameController` bị thay mới ở mỗi bài hoặc mỗi lần "Làm lại" — cùng cách
  // `attachInput` bên dưới lấy controller của ván đang mở.
  const tutorialProgressStore = new LocalStorageTutorialProgressStore();
  const tutorialPanel = new TutorialPanel(app, t, tutorialProgressStore, {
    getController: () => game?.link.controller ?? null,
    onPickScenario: (lesson) => startTutorialLesson(lesson),
    onPickRealGame: () => {
      tutorialPanel.hideStep();
      tutorialPanel.hideList();
      startSolo('easy', 'balanced'); // PLAN 10.2 T13: ván solo thật 1 người + 5 bot Dễ; giới hạn hiệp 50 không áp (docs/questions.md)
    },
    onBackToMenu: () => showMenu(),
    onExitLesson: () => showTutorial(),
    onNarrate: (text) => hud.announce(text),
  });
  // M7.4 (PLAN 8.5): mesh WebRTC voice. Tín hiệu SDP/ICE đi qua CÙNG kết nối chat (`voice.signal`, server chỉ relay).
  const voiceManager = new VoiceManager(
    DEFAULT_ICE_SERVERS,
    (to, data) => onlineTransport?.sendChat({ type: 'voice.signal', to, data }),
    {
      onSpeaking: (seat, speaking) => {
        if (speaking) speakingSeats.add(seat);
        else speakingSeats.delete(seat);
        chatPanel.setSpeaking(seat, speaking);
      },
      onMicError: (message) => hud.announce(t('voice.error.mic', { message })),
    },
  );
  const chatPanel = new ChatPanel(app, t, {
    onSendText: (target, text) => onlineTransport?.sendChat(chatSendMessage(target, { kind: 'text', text })),
    onSendPhrase: (target, phraseId) => onlineTransport?.sendChat(chatSendMessage(target, { kind: 'phrase', phraseId })),
    onMuteToggle: () => {
      /* Tắt tiếng chỉ cục bộ, ChatPanel tự lưu/lọc (PLAN 8.4) — không cần báo server hay đâu khác. */
    },
    // PLAN 8.5 "người bị chặn không nghe nhau": chặn dùng chung cho chat lẫn voice, báo luôn cho VoiceManager.
    onBlockToggle: (seat, blocked) => voiceManager.setBlocked(seat, blocked),
    onReport: (seat, reason) => onlineTransport?.sendChat({ type: 'report.player', seat, reason }),
    onSeatVolume: (seat, volume) => voiceManager.setSeatVolume(seat, volume),
    onSeatListenMute: (seat, muted) => voiceManager.setSeatMuted(seat, muted),
  });
  const voiceBar = new VoiceBar(app, t, {
    onMicToggle: async (on) => {
      const ok = await voiceManager.setMicEnabled(on);
      if (ok && on) {
        // Nhãn thiết bị chỉ đọc được SAU khi đã cấp quyền lần đầu (giới hạn của enumerateDevices) — cập nhật lại danh sách.
        const devices = await navigator.mediaDevices.enumerateDevices();
        voiceBar.setDevices(devices, settings.voiceMicDeviceId);
      }
      return ok;
    },
    onListenToggle: (on) => voiceManager.setListenEnabled(on),
    onDeviceChange: (deviceId) => {
      settings = { ...settings, voiceMicDeviceId: deviceId };
      settingsStore.save(settings);
      void voiceManager.setMicDevice(deviceId);
    },
    onTurnOnlyToggle: (on) => {
      settings = { ...settings, voiceTurnOnly: on };
      settingsStore.save(settings);
      voiceManager.setTurnOnly(on);
    },
    onTestMicStart: (onLevel) => voiceManager.testMic(onLevel),
    onPushToTalk: (active) => voiceManager.setPushToTalk(active),
  });
  voiceManager.setTurnOnly(settings.voiceTurnOnly);
  voiceBar.setTurnOnly(settings.voiceTurnOnly);
  navigator.mediaDevices?.enumerateDevices().then((devices) => voiceBar.setDevices(devices, settings.voiceMicDeviceId)).catch(() => {});

  function closeGame(): void {
    game?.link.close();
    game = null;
    onlineTransport = null;
    hud.clearToasts();
    minimap.setVisible(false);
    chatPanel.hide();
    voiceBar.hide();
    voiceManager.dispose(); // PLAN 8.5 "không ghi âm, không lưu": không để mic bật ngầm sang phòng/màn khác
    speakingSeats.clear();
    tutorialPanel.hideStep();
    audio.stopAmbience(); // M10: không để nhạc nền của ván vừa thoát còn kêu ở màn menu/ván kế tiếp
    lastSelectedPieceId = null;
    lastTickSecond = null;
  }

  function showMenu(): void {
    closeGame();
    orbit = overview();
    hud.setVisible(false);
    settingsPanel.hide();
    onlineMenu.hide();
    lobby.hide();
    tutorialPanel.hideList();
    menu.show({ saved: store.load()?.meta ?? null, error: lastError });
  }

  function showOnlineMenu(): void {
    closeGame();
    orbit = overview();
    hud.setVisible(false);
    settingsPanel.hide();
    menu.hide();
    lobby.hide();
    tutorialPanel.hideList();
    onlineMenu.show();
  }

  /** M8 (PLAN 10.1): màn danh sách 13 bài tân thủ (menu chính → "Tân thủ", nút "Về danh sách bài" trong lúc học,
   * và "lần đầu vào game" ở cuối file). Đóng ván đang mở (nếu có) y như mọi lần chuyển màn khác. */
  function showTutorial(): void {
    closeGame();
    orbit = overview();
    hud.setVisible(false);
    settingsPanel.hide();
    onlineMenu.hide();
    lobby.hide();
    menu.hide();
    tutorialPanel.showList();
  }

  /** `mode`/`difficulty`/`useStore` mô tả CÁCH TRÌNH BÀY ván (tự lưu chỉ ván solo, X-10) — không quyết ai chạy ván:
   * đó là việc của `transport` (Worker cục bộ hay WebSocket, PLAN 6.1 nguyên tắc 3; M8: `TutorialTransport` cho
   * bài tân thủ). Trả về bundle để gọi tiếp (`transport.startNew/resume` cho ván cục bộ, `pushInitialSnapshot`
   * cho bài tân thủ; ván online không cần vì server tự đẩy `game.snapshot`, PLAN 7.2). */
  function openGame(
    mode: 'solo' | 'hotseat' | 'online' | 'tutorial',
    difficulty: SoloDifficulty,
    transport: Transport,
    useStore: boolean,
    personality: Personality = 'balanced',
  ): ActiveGame {
    closeGame();
    lastError = null;
    const bundle: ActiveGame = {
      mode,
      difficulty,
      personality,
      model: preview.model,
      animator: preview.animator,
      kingWarned: false,
      link: new GameLink({
        transport,
        ...(useStore ? { store } : {}),
        confirmMoves: settings.confirmMoves,
        controllerListener: { onRejected: (reason) => hud.announceRejected(reason) },
        listener: {
          onSnapshot: (state) => {
            bundle.model = DisplayModel.fromState(state);
            const model = bundle.model;
            bundle.animator = new AnimationDirector(model, {
              onStart: (event) => {
                hud.announceEvent(event, model);
                audio.onEvent(event); // M10 (PLAN 12.6): cùng chỗ HUD đọc dòng sự kiện, không nghe engine ở nơi thứ hai
              },
            });
            bundle.animator.setSpeed(settings.reduceMotion ? 2 : 1);
            bundle.kingWarned = false;
            const you = bundle.link.you;
            // PLAN 3.3: ghế mình ở đáy — ĐÚNG cho ván thật (quân của ghế mình luôn ở góc "hạng seatCornerRing").
            // Bài tân thủ dựng bàn RIÊNG, nhỏ (bán kính 3–6) với quân đặt gần tâm (0,0) chứ không theo quy ước góc
            // ghế (xem packages/tutorial/src/scenarios/*.ts) — dùng `seatOrbit` ở đó sẽ chĩa camera ra một điểm
            // cách xa 20 đơn vị, ngoài mọi quân trên bàn. Tutorial vì vậy nhìn thẳng vào tâm bàn, khoảng cách co
            // theo đúng bán kính ván đang mở (docs/decisions.md mục "M8 (client)").
            orbit =
              mode === 'tutorial'
                ? clampOrbit({ azimuth: Math.PI / 2, elevation: DEFAULT_ELEVATION, distance: Math.min(DEFAULT_DISTANCE, Math.max(MIN_DISTANCE, state.radius * 8)), targetX: 0, targetZ: 0 }, state.radius)
                : you.length === 1
                  ? seatOrbit(you[0] as Seat, seatCornerRing)
                  : overview();
            menu.hide();
            onlineMenu.hide();
            lobby.hide();
            hud.setVisible(true);
            minimap.setVisible(true);
            if (mode === 'online') {
              const roster = buildChatRoster(state, bundle.link.seats, you);
              chatPanel.show();
              chatPanel.setMySeat(you[0] ?? null);
              chatPanel.setRoster(roster);
              voiceBar.show();
              voiceManager.setMySeat(you[0] ?? null);
              voiceManager.setRoster(roster.filter((r) => r.kind === 'human').map((r) => r.seat));
            }
          },
          onAction: (result) => {
            bundle.animator.enqueue(result.events);
            if (bundle.animator.pending > MAX_ANIMATION_BACKLOG) bundle.animator.flush();
          },
          onRejected: (reason) => hud.announceRejected(reason),
          onError: (code) => {
            lastError = t(`save.error.${code}`);
            if (code === 'BAD_FORMAT' || code === 'REPLAY_FAILED' || code === 'HASH_MISMATCH') store.clear(); // bản lưu khác phiên bản luật thì giữ lại
            showMenu();
          },
        },
      }),
    };
    game = bundle;
    return bundle;
  }

  function startSolo(difficulty: SoloDifficulty, personality: Personality = 'balanced'): void {
    const seed = pickSeed();
    const transport = new WorkerTransport();
    openGame('solo', difficulty, transport, true, personality);
    transport.startNew(seed, soloSeats(seed, difficulty, personality), timing);
  }

  function startHotseat(): void {
    const seed = pickSeed();
    const transport = new WorkerTransport();
    openGame('hotseat', 'mixed', transport, false);
    transport.startNew(seed, hotseatSeats(), timing);
  }

  function continueSaved(): void {
    const stored = store.load();
    if (stored === null) {
      showMenu();
      return;
    }
    const transport = new WorkerTransport();
    openGame('solo', 'mixed', transport, true);
    transport.resume(stored.save, timing);
  }

  /** M8: bắt đầu (hoặc "Làm lại" — `startLesson()` của gói tutorial tất định nên gọi lại từ đầu ra cùng thế cờ)
   * một bài kịch bản. Không tự lưu (`useStore=false`, X-10 chỉ áp cho ván solo thật). */
  function startTutorialLesson(lesson: ScenarioLesson): void {
    const transport = new TutorialTransport(lesson, { onStepNarration: (key) => hud.announce(t(key)) });
    openGame('tutorial', 'mixed', transport, false);
    tutorialPanel.enterLesson(lesson, transport);
    transport.pushInitialSnapshot();
  }

  /** Tên khách hiển thị cho tới khi có hồ sơ/Steam thật (M11, xem docs/questions.md) — đủ để phân biệt nhiều tab. */
  function guestName(): string {
    return `Khách${Math.floor(100 + Math.random() * 900)}`;
  }

  /** Dựng `chat.send` từ nơi gửi (suy ra từ tab đang mở, PLAN 8.2) + nội dung — tách hộ ChatPanel khỏi hình dạng
   * chính xác của message giao thức (PLAN mục 8). */
  function chatSendMessage(target: ChatSendTarget, payload: { kind: 'text'; text: string } | { kind: 'phrase'; phraseId: PhraseId }): ChatSend {
    return target.channel === 'whisper'
      ? ({ type: 'chat.send', channel: 'whisper', to: target.to, ...payload } as ChatSend)
      : ({ type: 'chat.send', channel: target.channel, ...payload } as ChatSend);
  }

  /** Danh sách người để hiện trong bảng chat (PLAN 8.4 tắt tiếng/chặn/báo cáo) — chỉ người thật, bot/ghế trống
   * không cần các nút đó (ChatPanel tự lọc `kind !== 'human'`, đây chỉ cần đưa đủ dữ kiện). */
  function buildChatRoster(state: GameState, seats: readonly SeatStatus[], you: readonly Seat[]): ChatRosterEntry[] {
    return state.order.map((seat) => {
      const status = seats.find((s) => s.seat === seat);
      return {
        seat,
        name: seatName(seat, seats, you, t),
        kind: status?.kind ?? 'bot',
        isSelf: you.includes(seat),
      };
    });
  }

  /** Mở một kết nối online mới: bắt tay (`hello`), rồi `afterHello` xin vào hàng chờ/tạo/vào phòng (PLAN 7.1-7.3).
   * `GameLink` được gắn NGAY (qua `openGame`) dù chưa có ván nào — để sẵn sàng nhận `game.snapshot` bất cứ lúc nào
   * server tự đẩy khi phòng đủ người/bot lấp chỗ (PLAN 7.2, 7.5), không phải đợi client xin bắt đầu. */
  function startOnlineFlow(afterHello: (transport: WebSocketTransport) => void): void {
    const transport = new WebSocketTransport(resolveServerUrl(params, window.location));
    openGame('online', 'mixed', transport, false);
    onlineTransport = transport;
    let helloSent = false;
    transport.subscribeConnection((state) => {
      if (onlineTransport !== transport) return; // phiên đã bị thay/đóng — bỏ qua sự kiện trễ
      if (state.kind === 'open' && !helloSent) {
        helloSent = true;
        transport.sendLobby({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name: guestName(), locale: settings.locale });
      } else if (state.kind === 'closed') {
        lastError = t('online.error.connectionLost');
        showOnlineMenu();
      }
    });
    transport.subscribeLobby((message) => {
      if (onlineTransport !== transport) return;
      switch (message.type) {
        case 'hello.ack':
          afterHello(transport);
          return;
        case 'room.state':
          if (game?.link.ready) return; // ván đã bắt đầu: không phủ lại HUD bằng phòng chờ (xem docs/decisions.md)
          onlineMenu.hide();
          lobby.show(message);
          return;
        case 'room.closed':
          showOnlineMenu();
          return;
        case 'lobby.error':
          onlineMenu.showError(t(`online.error.${message.code}`));
          lobby.hide();
          onlineMenu.show();
          return;
      }
    });
    transport.subscribeChat((message) => {
      if (onlineTransport !== transport) return;
      switch (message.type) {
        case 'chat.message':
          chatPanel.receive(message);
          audio.play('chat'); // M10, PLAN 12.6 "tin nhắn"
          return;
        case 'chat.error':
          chatPanel.showError(message.code);
          return;
        case 'report.ack':
          chatPanel.showReportAck();
          return;
        case 'voice.signal':
          voiceManager.handleSignal(message.from, message.data);
          return;
      }
    });
  }

  const inputHost: InputHost = {
    canvas,
    getOrbit: () => orbit,
    setOrbit: (next) => {
      orbit = next;
    },
    getRadius: () => game?.model.radius ?? defaultConfig.board.radius,
    getPieces: () => pickables,
    getTurnSeat: (): Seat | null => game?.link.state.turnSeat ?? null,
    seatCornerRing,
  };
  attachInput(inputHost, () => game?.link.controller ?? null);

  // Móc gỡ lỗi cho Playwright (e2e thật qua Worker thật). Chỉ bật bằng ?e2e=1; không ảnh hưởng đường chơi bình thường.
  if (params.has('e2e')) installDebugHook(() => game, () => orbit, () => voiceManager);

  function resize(): void {
    const { clientWidth, clientHeight } = canvas;
    if (clientWidth === 0 || clientHeight === 0) return;
    renderer.setSize(clientWidth, clientHeight, false);
    composer.setSize(clientWidth, clientHeight);
    camera.aspect = clientWidth / clientHeight;
    camera.updateProjectionMatrix();
  }
  window.addEventListener('resize', resize);
  resize();

  let lastTime: number | null = null;
  renderer.setAnimationLoop((now) => {
    const dt = lastTime === null ? 0 : Math.min(0.05, (now - lastTime) / 1000);
    lastTime = now;

    const view = game !== null && game.link.ready ? game : null;
    if (view !== null) {
      view.animator.update(dt);
      const state = view.link.state;
      const selection = view.link.controller.selection;
      // X-06: chỉ tính đe doạ lên quân của người TỚI LƯỢT khi đó thật sự là lượt của "mình" (PLAN 11.2).
      const threatSeat = settings.threatWarnings && view.link.isMyTurn() ? state.turnSeat : null;
      const threats = threatSeat === null ? NO_THREATS : threatsFor(state, threatSeat);
      if (threats.kingThreatened && !view.kingWarned) {
        view.kingWarned = true;
        hud.announce(t('hud.threat.king'));
      } else if (!threats.kingThreatened) {
        view.kingWarned = false; // thoát nguy rồi lại gặp lại thì báo lại
      }
      pickables = boardScene.sync(state, view.model, view.animator, selection, threats, now / 1000);
      hud.update({ state, seats: view.link.seats, you: view.link.you, deadline: view.link.deadline, now: Date.now(), selection, speakingSeats });
      minimap.render(buildMinimapView(state, defaultConfig.board.radius));
      if (view.mode === 'online') {
        const you = view.link.you;
        chatPanel.setEliminated(you.length === 1 && state.eliminated.some((e) => e.seat === you[0]));
      }
      if (view.mode === 'tutorial') tutorialPanel.tick(now); // PLAN 10.1: chữ bước hiện tại + đồng hồ gợi ý 15s/30s

      // M10 (PLAN 12.6): "chọn quân" — chỉ phát khi lựa chọn vừa ĐỔI (không phải mỗi khung hình đang giữ lựa chọn).
      const selectedId = selection?.pieceId ?? null;
      if (selectedId !== null && selectedId !== lastSelectedPieceId) audio.play('select');
      lastSelectedPieceId = selectedId;

      // M10 (PLAN 12.6): "đếm ngược 10 giây cuối" — một tiếng tích mỗi khi giây nguyên còn lại đổi, trong cửa sổ ≤10s.
      const deadline = view.link.deadline;
      const secondsLeft = deadline === null ? null : Math.ceil((deadline - Date.now()) / 1000);
      if (secondsLeft !== null && secondsLeft > 0 && secondsLeft <= 10) {
        if (secondsLeft !== lastTickSecond) audio.play('tick');
        lastTickSecond = secondsLeft;
      } else {
        lastTickSecond = null; // ngoài cửa sổ 10s (lượt vừa đổi/hết giờ) — sẵn sàng đếm lại từ đầu ở lượt sau
      }

      // M10 (PLAN 12.6 "nhạc nền theo pha"): "kết thúc" khi ván xong, "căng thẳng" khi có cảnh báo thu hẹp
      // (dùng lại chính tín hiệu X-01 mà `board-mesh.ts::pulseWarning` đã đọc), còn lại "bình thường".
      const upcomingCollapse = state.phase === 'over' ? undefined : nextCollapse(state);
      audio.setAmbiencePhase(state.phase === 'over' ? 'end' : upcomingCollapse !== undefined ? 'tense' : 'normal');
    } else {
      pickables = boardScene.sync(previewState, preview.model, preview.animator, null);
    }

    const pose = cameraPose(orbit);
    const shake = boardScene.cameraShake;
    camera.position.set(pose.position.x + shake.x, pose.position.y + shake.y, pose.position.z + shake.z);
    camera.up.set(0, 1, 0);
    camera.lookAt(orbit.targetX, 0, orbit.targetZ);
    if (settings.graphics === 'low') renderer.render(boardScene.scene, camera);
    else composer.render();
  });

  // `?autostart=solo|hotseat|continue` (kiểm thử, liên kết trực tiếp): bỏ qua màn bắt đầu.
  const autostart = params.get('autostart');
  const firstLesson = tutorialPanel.firstScenarioLesson();
  if (autostart === 'solo') startSolo((params.get('difficulty') as SoloDifficulty | null) ?? 'mixed', (params.get('personality') as Personality | null) ?? 'balanced');
  else if (autostart === 'hotseat') startHotseat();
  else if (autostart === 'continue') continueSaved();
  // PLAN 10.1 "Lần đầu vào game tự mở bài 1": chỉ một lần trong đời trình duyệt (`hasStarted()`), không có
  // `?autostart=` nào khác đang xin bỏ qua màn bắt đầu, và KHÔNG bật `?e2e=1` — mọi kịch bản Playwright hiện có
  // đều mở trang bằng `e2e=1` (packages/client/e2e/support.ts `openPage`) và trông đợi thấy menu chính trước
  // (đã xác nhận bằng cách chạy lại toàn bộ bộ e2e sau khi thêm nhánh này, xem docs/decisions.md mục "M8 (client)").
  else if (!params.has('e2e') && !tutorialProgressStore.hasStarted() && firstLesson !== null) startTutorialLesson(firstLesson);
  else showMenu();
}

main();
