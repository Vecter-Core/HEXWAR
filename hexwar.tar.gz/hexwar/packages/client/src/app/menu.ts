// Màn bắt đầu tối thiểu của M4: ván mới 1 người + 5 bot (chọn độ khó + tính cách, M9), tiếp tục ván đã lưu (X-10),
// hotseat. Menu chính đầy đủ (PLAN 11.1: online, tân thủ, hồ sơ, cài đặt) là việc của M5. Chữ đều qua i18n.
import { PERSONALITIES, type Personality } from '@hexwar/protocol';
import type { Translator } from '../core/i18n';
import type { SaveMeta } from '../net/save-store';

export type SoloDifficulty = 'easy' | 'normal' | 'hard' | 'mixed';

export interface MenuCallbacks {
  /** `personality` (PLAN 9.4, M9): áp dụng cho mọi bot của ván solo; 'balanced' = hành vi mặc định. */
  readonly onNewSolo: (difficulty: SoloDifficulty, personality: Personality) => void;
  readonly onContinue: () => void;
  readonly onHotseat: () => void;
  readonly onOnline: () => void;
  /** M8 (PLAN 10.1): mở màn tân thủ (danh sách 13 bài). */
  readonly onTutorial: () => void;
  readonly onSettings: () => void;
}

export interface MenuState {
  /** null = không có ván lưu. */
  readonly saved: SaveMeta | null;
  /** Lỗi khi đọc ván lưu lần trước (đã được dịch). */
  readonly error: string | null;
}

const DIFFICULTY_CHOICES: readonly SoloDifficulty[] = ['easy', 'normal', 'hard', 'mixed'];

export class Menu {
  private readonly root: HTMLElement;
  private readonly continueButton: HTMLButtonElement;
  private readonly continueInfo: HTMLElement;
  private readonly error: HTMLElement;
  private difficulty: SoloDifficulty = 'mixed';
  private personality: Personality = 'balanced';

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    callbacks: MenuCallbacks,
  ) {
    this.root = document.createElement('div');
    // 'main' phân biệt với các bảng phủ khác cũng dùng chung khung `.menu`/`.menu-card` (cài đặt, chơi online, phòng
    // chờ — xem docs/decisions.md M5/M6): test/CSS chọn đúng menu chính qua `.menu.main`, không phải đoán bằng cách
    // loại trừ từng bảng mới thêm sau này.
    this.root.className = 'menu main';
    const card = document.createElement('div');
    card.className = 'menu-card';
    this.root.appendChild(card);

    const title = document.createElement('h1');
    title.className = 'menu-title';
    title.textContent = t('menu.title');
    card.appendChild(title);
    const subtitle = document.createElement('p');
    subtitle.className = 'menu-subtitle';
    subtitle.textContent = t('menu.subtitle');
    card.appendChild(subtitle);

    const label = document.createElement('div');
    label.className = 'menu-label';
    label.textContent = t('menu.difficulty');
    card.appendChild(label);
    const choices = document.createElement('div');
    choices.className = 'menu-choices';
    card.appendChild(choices);
    for (const choice of DIFFICULTY_CHOICES) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'menu-choice';
      b.dataset['difficulty'] = choice;
      b.textContent = t(`difficulty.${choice}`);
      b.addEventListener('click', () => {
        this.difficulty = choice;
        for (const other of choices.querySelectorAll('button')) other.classList.toggle('menu-choice-on', other === b);
      });
      b.classList.toggle('menu-choice-on', choice === this.difficulty);
      choices.appendChild(b);
    }

    // PLAN 9.4 (M9): tính cách bot áp dụng cho mọi bot của ván solo. Cùng khuôn DOM với chọn độ khó ở trên.
    const personalityLabel = document.createElement('div');
    personalityLabel.className = 'menu-label';
    personalityLabel.textContent = t('menu.personality');
    card.appendChild(personalityLabel);
    const personalityChoices = document.createElement('div');
    personalityChoices.className = 'menu-choices';
    card.appendChild(personalityChoices);
    for (const choice of PERSONALITIES) {
      const b = document.createElement('button');
      b.type = 'button';
      b.className = 'menu-choice';
      b.dataset['personality'] = choice;
      b.textContent = t(`personality.${choice}`);
      b.addEventListener('click', () => {
        this.personality = choice;
        for (const other of personalityChoices.querySelectorAll('button')) other.classList.toggle('menu-choice-on', other === b);
      });
      b.classList.toggle('menu-choice-on', choice === this.personality);
      personalityChoices.appendChild(b);
    }

    const start = document.createElement('button');
    start.type = 'button';
    start.className = 'menu-btn menu-btn-primary menu-new';
    start.textContent = t('menu.newSolo');
    start.addEventListener('click', () => callbacks.onNewSolo(this.difficulty, this.personality));
    card.appendChild(start);

    this.continueButton = document.createElement('button');
    this.continueButton.type = 'button';
    this.continueButton.className = 'menu-btn menu-continue';
    this.continueButton.textContent = t('menu.continue');
    this.continueButton.addEventListener('click', () => callbacks.onContinue());
    card.appendChild(this.continueButton);
    this.continueInfo = document.createElement('div');
    this.continueInfo.className = 'menu-info';
    card.appendChild(this.continueInfo);

    const hotseat = document.createElement('button');
    hotseat.type = 'button';
    hotseat.className = 'menu-btn menu-btn-quiet menu-hotseat';
    hotseat.textContent = t('menu.hotseat');
    hotseat.addEventListener('click', () => callbacks.onHotseat());
    card.appendChild(hotseat);

    const online = document.createElement('button');
    online.type = 'button';
    online.className = 'menu-btn menu-btn-quiet menu-online';
    online.textContent = t('menu.online');
    online.addEventListener('click', () => callbacks.onOnline());
    card.appendChild(online);

    const tutorial = document.createElement('button');
    tutorial.type = 'button';
    tutorial.className = 'menu-btn menu-btn-quiet menu-tutorial';
    tutorial.textContent = t('menu.tutorial');
    tutorial.addEventListener('click', () => callbacks.onTutorial());
    card.appendChild(tutorial);

    const settings = document.createElement('button');
    settings.type = 'button';
    settings.className = 'menu-btn menu-btn-quiet menu-settings';
    settings.textContent = t('menu.settings');
    settings.addEventListener('click', () => callbacks.onSettings());
    card.appendChild(settings);

    this.error = document.createElement('div');
    this.error.className = 'menu-error';
    card.appendChild(this.error);

    parent.appendChild(this.root);
  }

  show(state: MenuState): void {
    this.root.classList.remove('hud-hidden');
    this.continueButton.disabled = state.saved === null;
    this.continueInfo.textContent = state.saved === null ? this.t('menu.noSave') : this.t('menu.savedRound', { round: state.saved.round });
    this.error.textContent = state.error ?? '';
  }

  hide(): void {
    this.root.classList.add('hud-hidden');
  }
}
