// Bản đồ nhỏ (PLAN 11.2, 11.4 "bấm để dịch camera"): canvas 2D vẽ lại `MinimapView` (core/minimap-model.ts, thuần).
// File này CHỈ có DOM/canvas — không toán hình học bàn cờ, không luật.
import type { MinimapView } from '../core/minimap-model';
import type { Translator } from '../core/i18n';

export interface MinimapCallbacks {
  /** Bấm vào bản đồ: toạ độ THẾ GIỚI (x, z) tương ứng, để main.ts dịch camera tới đó (PLAN 11.4). */
  readonly onJump: (worldX: number, worldZ: number) => void;
}

const SIZE = 148;

export class Minimap {
  private readonly canvas: HTMLCanvasElement;
  private readonly ctx: CanvasRenderingContext2D;
  private extent = 1;

  constructor(parent: HTMLElement, t: Translator, callbacks: MinimapCallbacks) {
    this.canvas = document.createElement('canvas');
    this.canvas.className = 'hud-minimap hud-hidden';
    this.canvas.width = SIZE;
    this.canvas.height = SIZE;
    this.canvas.title = t('hud.minimap.label');
    parent.appendChild(this.canvas);
    const ctx = this.canvas.getContext('2d');
    if (ctx === null) throw new Error('Minimap: trình duyệt không hỗ trợ canvas 2D');
    this.ctx = ctx;
    this.canvas.addEventListener('click', (e) => {
      const rect = this.canvas.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      const nx = ((e.clientX - rect.left) / rect.width) * 2 - 1;
      const ny = ((e.clientY - rect.top) / rect.height) * 2 - 1;
      callbacks.onJump(nx * this.extent, ny * this.extent);
    });
  }

  /** Nửa kích thước bàn (thế giới) ứng với mép bản đồ — dùng để đổi ngược điểm bấm ra toạ độ thế giới. */
  setExtent(extent: number): void {
    this.extent = extent;
  }

  setVisible(visible: boolean): void {
    this.canvas.classList.toggle('hud-hidden', !visible);
  }

  render(view: MinimapView): void {
    const { ctx } = this;
    ctx.clearRect(0, 0, SIZE, SIZE);
    const cx = SIZE / 2;
    const cy = SIZE / 2;
    const r = SIZE / 2 - 4;

    ctx.beginPath();
    ctx.arc(cx, cy, r * view.boardFraction, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(70, 95, 130, 0.4)';
    ctx.fill();

    if (view.warnFraction !== null && view.warnLevel !== null) {
      ctx.beginPath();
      ctx.arc(cx, cy, r * view.warnFraction, 0, Math.PI * 2);
      ctx.strokeStyle = view.warnLevel === 'red' ? '#ff3030' : '#ffd60a';
      ctx.lineWidth = 2;
      ctx.stroke();
    }

    for (const dot of view.dots) {
      ctx.beginPath();
      ctx.arc(cx + dot.x * r, cy + dot.y * r, dot.isKing ? 3 : 1.6, 0, Math.PI * 2);
      ctx.fillStyle = dot.color;
      ctx.fill();
    }
  }

  dispose(): void {
    this.canvas.remove();
  }
}
