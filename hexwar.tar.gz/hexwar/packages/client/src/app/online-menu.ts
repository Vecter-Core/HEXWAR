// Màn "Chơi online" (PLAN 7.2): 3 lựa chọn tối thiểu đúng đặc tả — Ghép nhanh / Tạo phòng riêng / Vào bằng mã. Chưa
// có bộ chọn luật chơi (preset X-09) ở đây — mặc định Cổ điển; bộ chọn đầy đủ để dành khi M9 có thêm giao diện tân
// thủ/độ khó cần trình bày cùng lúc, tránh làm rối màn chọn chế độ chơi (xem docs/decisions.md, M6).
import type { Translator } from '../core/i18n';

export interface OnlineMenuCallbacks {
  readonly onQuickMatch: () => void;
  readonly onCreateRoom: () => void;
  readonly onJoinRoom: (code: string) => void;
  readonly onBack: () => void;
}

export class OnlineMenu {
  private readonly root: HTMLElement;
  private readonly codeInput: HTMLInputElement;
  private readonly error: HTMLElement;

  constructor(parent: HTMLElement, t: Translator, callbacks: OnlineMenuCallbacks) {
    this.root = document.createElement('div');
    this.root.className = 'menu online hud-hidden';
    const card = document.createElement('div');
    card.className = 'menu-card';
    this.root.appendChild(card);

    const title = document.createElement('h1');
    title.className = 'menu-title online-title';
    title.textContent = t('online.title');
    card.appendChild(title);
    const subtitle = document.createElement('p');
    subtitle.className = 'menu-subtitle';
    subtitle.textContent = t('online.subtitle');
    card.appendChild(subtitle);

    const quick = document.createElement('button');
    quick.type = 'button';
    quick.className = 'menu-btn menu-btn-primary online-quick';
    quick.textContent = t('online.quickMatch');
    quick.addEventListener('click', () => callbacks.onQuickMatch());
    card.appendChild(quick);

    const create = document.createElement('button');
    create.type = 'button';
    create.className = 'menu-btn online-create';
    create.textContent = t('online.createRoom');
    create.addEventListener('click', () => callbacks.onCreateRoom());
    card.appendChild(create);

    const joinLabel = document.createElement('div');
    joinLabel.className = 'menu-label';
    joinLabel.textContent = t('online.joinCode');
    card.appendChild(joinLabel);
    const joinRow = document.createElement('div');
    joinRow.className = 'online-join-row';
    card.appendChild(joinRow);
    this.codeInput = document.createElement('input');
    this.codeInput.type = 'text';
    this.codeInput.className = 'online-code-input';
    this.codeInput.maxLength = 6;
    this.codeInput.placeholder = t('online.joinCodePlaceholder');
    joinRow.appendChild(this.codeInput);
    const join = document.createElement('button');
    join.type = 'button';
    join.className = 'menu-btn online-join';
    join.textContent = t('online.join');
    join.addEventListener('click', () => {
      const code = this.codeInput.value.trim().toUpperCase();
      if (code.length === 6) callbacks.onJoinRoom(code);
    });
    joinRow.appendChild(join);

    const back = document.createElement('button');
    back.type = 'button';
    back.className = 'menu-btn menu-btn-quiet online-back';
    back.textContent = t('online.back');
    back.addEventListener('click', () => callbacks.onBack());
    card.appendChild(back);

    this.error = document.createElement('div');
    this.error.className = 'menu-error online-error';
    card.appendChild(this.error);

    parent.appendChild(this.root);
  }

  show(): void {
    this.root.classList.remove('hud-hidden');
    this.error.textContent = '';
    this.codeInput.value = '';
  }

  hide(): void {
    this.root.classList.add('hud-hidden');
  }

  showError(message: string): void {
    this.error.textContent = message;
  }
}
