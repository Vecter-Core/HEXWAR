// Màn Cài đặt (PLAN 11.5). Mở được từ menu chính và từ trong ván (nút ở góc HUD). Đổi áp dụng ngay, trừ ngôn ngữ
// (xem net/settings-store.ts) — người dùng được báo trước khi bấm đổi ngôn ngữ rằng trang sẽ tải lại.
//
// M5 phạm vi thật (ghi rõ để không hứa hão — docs/decisions.md): mức đồ hoạ chỉ đổi `devicePixelRatio` hiệu dụng
// (chưa có bóng đổ/SSAO/bloom — đó là việc của M10, PLAN 12.5); "giảm chuyển động" dùng `AnimationDirector.setSpeed`
// đã có sẵn từ M3 (PLAN 12.4); gán lại phím (PLAN 11.3 "tất cả gán lại được") chưa làm, để M11.
import type { Translator } from '../core/i18n';
import type { GraphicsQuality, Settings } from '../net/settings-store';

export interface SettingsPanelCallbacks {
  /** Một mục vừa đổi (trừ ngôn ngữ, xem `onLocaleChange`). Áp dụng ngay, không cần đóng bảng. */
  readonly onChange: (settings: Settings) => void;
  /** Ngôn ngữ vừa đổi: cần dựng lại toàn bộ chữ trên trang (main.ts xử lý bằng tải lại trang). */
  readonly onLocaleChange: (settings: Settings) => void;
  readonly onClose: () => void;
}

const GRAPHICS_CHOICES: readonly GraphicsQuality[] = ['low', 'medium', 'high'];
const LOCALE_CHOICES: readonly Settings['locale'][] = ['vi', 'en'];

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.className = className;
  parent?.appendChild(node);
  return node;
}

/** Một hàng "nút chọn 1 trong N" kiểu `.menu-choice` (đã dùng ở menu.ts cho độ khó bot). */
function choiceRow<V extends string>(parent: HTMLElement, values: readonly V[], label: (v: V) => string, onPick: (v: V) => void): (current: V) => void {
  const row = el('div', 'menu-choices', parent);
  const buttons = values.map((value) => {
    const b = el('button', 'menu-choice', row);
    b.type = 'button';
    b.textContent = label(value);
    b.addEventListener('click', () => onPick(value));
    return { value, b };
  });
  return (current: V) => {
    for (const { value, b } of buttons) b.classList.toggle('menu-choice-on', value === current);
  };
}

export class SettingsPanel {
  private readonly root: HTMLElement;
  private readonly reflectLocale: (v: Settings['locale']) => void;
  private readonly reflectGraphics: (v: GraphicsQuality) => void;
  private readonly reduceMotion: HTMLInputElement;
  private readonly threatWarnings: HTMLInputElement;
  private readonly confirmMoves: HTMLInputElement;
  private readonly volumeMaster: HTMLInputElement;
  private readonly volumeMusic: HTMLInputElement;
  private readonly volumeSfx: HTMLInputElement;
  private current: Settings;

  constructor(
    parent: HTMLElement,
    t: Translator,
    initial: Settings,
    private readonly callbacks: SettingsPanelCallbacks,
  ) {
    this.current = initial;
    this.root = el('div', 'menu settings hud-hidden', parent);
    const card = el('div', 'menu-card', this.root);

    el('h1', 'menu-title settings-title', card).textContent = t('settings.title');

    el('div', 'menu-label', card).textContent = t('settings.language');
    this.reflectLocale = choiceRow(card, LOCALE_CHOICES, (l) => t(`settings.language.${l}`), (locale) => this.update({ locale }, true));

    el('div', 'menu-label', card).textContent = t('settings.graphics');
    this.reflectGraphics = choiceRow(card, GRAPHICS_CHOICES, (g) => t(`settings.graphics.${g}`), (graphics) => this.update({ graphics }));

    this.reduceMotion = this.checkboxRow(card, t, 'settings.reduceMotion', (checked) => this.update({ reduceMotion: checked }));
    this.threatWarnings = this.checkboxRow(card, t, 'settings.threatWarnings', (checked) => this.update({ threatWarnings: checked }));
    this.confirmMoves = this.checkboxRow(card, t, 'settings.confirmMoves', (checked) => this.update({ confirmMoves: checked }));

    // M10 (PLAN 11.5 "Âm thanh: Tổng, nhạc, hiệu ứng"). "voice" của cùng dòng PLAN đã có công tắc mic/nghe riêng ở
    // VoiceBar từ M7 — không lặp lại ở đây (một thanh trượt âm lượng cho voice sẽ không có gì để điều khiển: âm
    // lượng thoại đến từ WebRTC, không đi qua AudioManager, xem docs/questions.md).
    el('div', 'menu-label', card).textContent = t('settings.volume');
    this.volumeMaster = this.volumeRow(card, t, 'settings.volume.master', (v) => this.update({ volumeMaster: v }));
    this.volumeMusic = this.volumeRow(card, t, 'settings.volume.music', (v) => this.update({ volumeMusic: v }));
    this.volumeSfx = this.volumeRow(card, t, 'settings.volume.sfx', (v) => this.update({ volumeSfx: v }));

    const close = el('button', 'menu-btn menu-btn-primary settings-close', card);
    close.type = 'button';
    close.textContent = t('settings.close');
    close.addEventListener('click', () => callbacks.onClose());

    this.reflect();
  }

  private checkboxRow(parent: HTMLElement, t: Translator, key: string, onChange: (checked: boolean) => void): HTMLInputElement {
    const row = el('label', 'settings-toggle', parent);
    const input = document.createElement('input');
    input.type = 'checkbox';
    input.addEventListener('change', () => onChange(input.checked));
    row.appendChild(input);
    el('span', '', row).textContent = t(key);
    return input;
  }

  /** Một thanh trượt âm lượng 0..100% (PLAN 11.5). Đơn vị lưu trong `Settings` là 0..1 (xem net/settings-store.ts);
   * `<input type="range">` chỉ nhận số nguyên gọn nên quy đổi ở biên của hàm này, không rò ra ngoài. */
  private volumeRow(parent: HTMLElement, t: Translator, key: string, onChange: (value: number) => void): HTMLInputElement {
    const row = el('label', 'settings-slider', parent);
    el('span', '', row).textContent = t(key);
    const input = document.createElement('input');
    input.type = 'range';
    input.min = '0';
    input.max = '100';
    input.step = '1';
    input.addEventListener('input', () => onChange(Number(input.value) / 100));
    row.appendChild(input);
    return input;
  }

  private update(partial: Partial<Settings>, isLocaleChange = false): void {
    this.current = { ...this.current, ...partial };
    this.reflect();
    if (isLocaleChange) this.callbacks.onLocaleChange(this.current);
    else this.callbacks.onChange(this.current);
  }

  private reflect(): void {
    this.reflectLocale(this.current.locale);
    this.reflectGraphics(this.current.graphics);
    this.reduceMotion.checked = this.current.reduceMotion;
    this.threatWarnings.checked = this.current.threatWarnings;
    this.confirmMoves.checked = this.current.confirmMoves;
    this.volumeMaster.value = String(Math.round(this.current.volumeMaster * 100));
    this.volumeMusic.value = String(Math.round(this.current.volumeMusic * 100));
    this.volumeSfx.value = String(Math.round(this.current.volumeSfx * 100));
  }

  show(settings: Settings): void {
    this.current = settings;
    this.reflect();
    this.root.classList.remove('hud-hidden');
  }

  hide(): void {
    this.root.classList.add('hud-hidden');
  }
}
