// Màn tân thủ (M8, PLAN mục 10): danh sách 13 bài + bảng lời thoại/nút nổi trên HUD khi đang học một bài kịch bản
// (`ScenarioLesson`). Đây là lớp UI THUẦN theo đúng khuôn mẫu `Menu`/`SettingsPanel` (tự dựng DOM một lần, `show`/
// `hide` bật tắt `hud-hidden`, mọi quyết định "bắt đầu ván nào, đóng ván ra sao" giao lại cho main.ts qua callback
// — file này không tự tạo `GameLink`/`Transport`). Việc thật sự lái bài học (đọc `RunnerState`, gợi ý theo thời
// gian) nằm ở `tick()`, gọi mỗi khung hình từ vòng lặp vẽ của main.ts, giống cách `Hud.update()` đã làm.
import { currentStep, findHintMove, isScenarioLesson, LESSONS, type Lesson, type RunnerState, type ScenarioLesson } from '@hexwar/tutorial';
import type { GameController } from '../core/controller';
import type { Translator } from '../core/i18n';
import type { TutorialProgressStore } from '../net/tutorial-progress-store';
import type { TutorialTransport } from '../net/tutorial-transport';

/** 15s: làm nổi bật quân/nước gợi ý. 30s: nhắc mạnh hơn (PLAN 10.1). Không phải luật ván (không thuộc rules.config.json,
 * đây là nhịp trình bày của UI tân thủ, giống `SessionTiming` ở protocol/session.ts) nên đặt hằng số ở đây, không rải. */
const HINT_HIGHLIGHT_MS = 15_000;
const HINT_STRONG_MS = 30_000;

export interface TutorialPanelCallbacks {
  /** `GameController` của ván tân thủ đang mở (để tô sáng quân/nước gợi ý) — null nếu chưa có ván nào (giống
   * `attachInput` ở main.ts: luôn hỏi lại thay vì giữ tham chiếu, vì `GameLink` bị thay mới ở mỗi bài/lần "Làm lại"). */
  readonly getController: () => GameController | null;
  readonly onPickScenario: (lesson: ScenarioLesson) => void;
  readonly onPickRealGame: () => void;
  /** Từ màn danh sách: quay lại menu chính. */
  readonly onBackToMenu: () => void;
  /** Từ trong một bài: đóng ván đang học, quay lại màn danh sách. */
  readonly onExitLesson: () => void;
  /** Lời dẫn ngắn của một bước 'auto'/'roll' (PLAN 10.1) — hiện y như một thông báo sự kiện thật. */
  readonly onNarrate: (text: string) => void;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.className = className;
  parent?.appendChild(node);
  return node;
}

function button(label: string, className: string, onClick: () => void, parent: HTMLElement): HTMLButtonElement {
  const b = el('button', className, parent);
  b.type = 'button';
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

/** Bài kế tiếp trong danh sách 13 bài theo đúng thứ tự PLAN 10.2 (dùng cho "Bỏ qua" và "Bài kế tiếp"). */
function nextLessonAfter(lesson: Lesson): Lesson | null {
  const index = LESSONS.findIndex((l) => l.id === lesson.id);
  return index < 0 || index + 1 >= LESSONS.length ? null : (LESSONS[index + 1] ?? null);
}

export class TutorialPanel {
  private readonly listRoot: HTMLElement;
  private readonly lessonList: HTMLElement;
  private readonly stepRoot: HTMLElement;
  private readonly stepTitle: HTMLElement;
  private readonly stepText: HTMLElement;
  private readonly stepActions: HTMLElement;
  private readonly stepFooter: HTMLElement;

  private transport: TutorialTransport | null = null;
  private currentLesson: ScenarioLesson | null = null;
  private doneHandled = false;
  /** "Dấu vân tay" của lần đọc runner gần nhất — đổi (bước khác, hoặc một nước vừa được thử dù đúng hay sai) thì
   * coi như "vừa có hoạt động", cần đặt lại đồng hồ gợi ý (PLAN 10.1: "xoá bộ đếm khi người chơi đi bất kỳ nước nào"). */
  private lastStepIndex = -1;
  private lastLog: RunnerState['log'] | null = null;
  private lastRejection: RunnerState['lastRejection'] = null;
  private hintAnchorMs = 0;
  private hinted15 = false;
  private hinted30 = false;

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    private readonly progressStore: TutorialProgressStore,
    private readonly callbacks: TutorialPanelCallbacks,
  ) {
    this.listRoot = el('div', 'menu tutorial-picker hud-hidden', parent);
    const card = el('div', 'menu-card', this.listRoot);
    el('h1', 'menu-title', card).textContent = t('tutorial.picker.title');
    el('p', 'menu-subtitle', card).textContent = t('tutorial.picker.subtitle');
    this.lessonList = el('div', 'tutorial-lesson-list', card);
    button(t('tutorial.backToMenu'), 'menu-btn menu-btn-quiet tutorial-back', () => callbacks.onBackToMenu(), card);

    this.stepRoot = el('div', 'tutorial-step hud-hidden', parent);
    this.stepTitle = el('div', 'tutorial-step-title', this.stepRoot);
    this.stepText = el('div', 'tutorial-step-text', this.stepRoot);
    this.stepActions = el('div', 'tutorial-step-actions', this.stepRoot);
    this.stepFooter = el('div', 'tutorial-step-footer', this.stepRoot);
    button(t('tutorial.skip'), 'menu-btn menu-btn-quiet tutorial-skip', () => this.skip(), this.stepFooter);
    button(t('tutorial.redo'), 'menu-btn menu-btn-quiet tutorial-redo', () => this.redo(), this.stepFooter);
    button(t('tutorial.backToList'), 'menu-btn menu-btn-quiet tutorial-back-to-list', () => callbacks.onExitLesson(), this.stepFooter);
  }

  /** Hiện màn danh sách 13 bài. Đánh dấu "đã từng mở màn tân thủ" NGAY tại đây (PLAN 10.1: chỉ tự mở bài 1 một
   * lần duy nhất trong đời trình duyệt) — dù màn này được mở tự động hay do người tự bấm. */
  showList(): void {
    this.progressStore.markStarted();
    this.renderList();
    this.listRoot.classList.remove('hud-hidden');
  }

  hideList(): void {
    this.listRoot.classList.add('hud-hidden');
  }

  /** Bài đầu tiên (T1) — dùng cho "lần đầu vào game tự mở bài 1" (main.ts gọi thẳng, không qua danh sách). */
  firstScenarioLesson(): ScenarioLesson | null {
    const first = LESSONS[0];
    return first !== undefined && isScenarioLesson(first) ? first : null;
  }

  /** Bắt đầu (hoặc bắt đầu lại) một bài kịch bản: `transport` đã được `main.ts` tạo và gắn vào `GameLink`. */
  enterLesson(lesson: ScenarioLesson, transport: TutorialTransport): void {
    // Cũng đánh dấu ở đây (không chỉ `showList`): "lần đầu vào game tự mở bài 1" (main.ts) đi thẳng vào bài,
    // không qua màn danh sách — `markStarted()` idempotent nên gọi ở cả hai chỗ không sao.
    this.progressStore.markStarted();
    this.hideList();
    this.currentLesson = lesson;
    this.transport = transport;
    this.doneHandled = false;
    this.lastStepIndex = -1;
    this.lastLog = null;
    this.lastRejection = null;
    this.hinted15 = false;
    this.hinted30 = false;
    this.hintAnchorMs = Date.now();
    this.stepRoot.classList.remove('hud-hidden');
    this.refresh();
  }

  hideStep(): void {
    this.stepRoot.classList.add('hud-hidden');
    this.transport = null;
    this.currentLesson = null;
  }

  /** Gọi mỗi khung hình (vòng lặp vẽ của main.ts) khi một bài kịch bản đang mở — đọc lại `RunnerState`, cập nhật
   * chữ hiện tại, và (bước 'move') tính giờ gợi ý. Không làm gì nếu chưa vào bài nào (T13/không có ván tân thủ). */
  tick(nowMs: number): void {
    if (this.transport === null) return;
    this.refresh();
    const runner = this.transport.getRunner();
    if (runner.done) return;
    const step = currentStep(runner);
    if (step === undefined || step.kind !== 'move') return;
    const controller = this.callbacks.getController();
    if (controller === null) return;
    const elapsed = nowMs - this.hintAnchorMs;
    if (elapsed >= HINT_HIGHLIGHT_MS && !this.hinted15) {
      this.hinted15 = true;
      const move = findHintMove(runner.game, step.seat, step.goal);
      if (move !== undefined) controller.select(move.pieceId);
    }
    if (elapsed >= HINT_STRONG_MS && !this.hinted30) {
      this.hinted30 = true;
      // Bóng mờ đường đi đầy đủ (PLAN 10.1) không có trong mô hình chọn quân hiện tại (chỉ tô "quân + mọi nước đi
      // của nó", không phải "đúng MỘT ô đích") — nhắc lại bằng chữ là đơn giản hoá đã ghi ở docs/questions.md.
      const move = findHintMove(runner.game, step.seat, step.goal);
      if (move !== undefined) {
        controller.select(move.pieceId);
        this.callbacks.onNarrate(this.t('tutorial.hint.strong'));
      }
    }
  }

  /** Chỉ đụng DOM khi nội dung THẬT SỰ đổi (bước khác, hoặc một nước vừa được thử) — `tick()` gọi hàm này mỗi
   * khung hình, dựng lại nút bấm mỗi lần như vậy sẽ lãng phí và có thể làm phần tử đang được bấm biến mất giữa
   * chừng (cùng nguyên tắc "chỉ vẽ lại khi đổi" của `Hud.update`, packages/client/src/app/hud.ts). */
  private refresh(): void {
    const transport = this.transport;
    const lesson = this.currentLesson;
    if (transport === null || lesson === null) return;
    const runner = transport.getRunner();
    const changed = runner.stepIndex !== this.lastStepIndex || runner.log !== this.lastLog || runner.lastRejection !== this.lastRejection;
    if (!changed) return;
    this.lastStepIndex = runner.stepIndex;
    this.lastLog = runner.log;
    this.lastRejection = runner.lastRejection;
    this.hintAnchorMs = Date.now();
    this.hinted15 = false;
    this.hinted30 = false;
    if (runner.done) {
      if (!this.doneHandled) {
        this.doneHandled = true;
        this.progressStore.markCompleted(lesson.id);
        // Bài kết thúc bằng ăn Vua thật (T7, T9) tự nhiên đưa `phase` sang 'over' — Hud đã tự hiện màn kết quả
        // của NÓ (packages/client/src/app/hud.ts `showResult`); không phủ thêm một bảng "hoàn thành" khác đè lên,
        // chỉ định tuyến lại hai nút của màn đó (xem `handleGameOverNewGame/Menu`, main.ts) — đơn giản hơn viết
        // logic ẩn/hiện tranh nhau giữa hai bảng, ghi ở docs/questions.md.
        if (runner.game.phase !== 'over') this.renderCompletion(lesson);
      }
      return;
    }
    const step = currentStep(runner);
    if (step === undefined) return;
    this.renderStep(lesson, step);
  }

  // Bước 'move' bị từ chối (`runner.lastRejection`) không cần xử lý riêng ở đây: lý do đã đi qua HUD y như ván
  // thật (`illegal.<reason>`, xem main.ts `controllerListener.onRejected`/`hud.announceRejected`) — bảng này chỉ
  // luôn hiện lại đúng chữ hướng dẫn của bước hiện tại, không lặp lại lý do để khỏi trùng thông báo.
  private renderStep(lesson: ScenarioLesson, step: NonNullable<ReturnType<typeof currentStep>>): void {
    this.stepTitle.textContent = this.t(lesson.titleKey);
    this.stepText.textContent = step.kind === 'info' || step.kind === 'move' ? this.t(step.textKey) : '';
    this.stepActions.replaceChildren();
    this.stepFooter.classList.remove('hud-hidden');
    if (step.kind === 'info') {
      button(this.t('tutorial.continue'), 'menu-btn menu-btn-primary tutorial-continue', () => transportAcknowledge(this.transport), this.stepActions);
    }
  }

  private renderCompletion(lesson: ScenarioLesson): void {
    this.stepTitle.textContent = this.t(lesson.titleKey);
    this.stepText.textContent = this.t('tutorial.done.message');
    this.stepFooter.classList.add('hud-hidden');
    this.stepActions.replaceChildren();
    button(this.t('tutorial.done.next'), 'menu-btn menu-btn-primary tutorial-next', () => this.goNext(lesson), this.stepActions);
    button(this.t('tutorial.backToList'), 'menu-btn menu-btn-quiet tutorial-done-back', () => this.callbacks.onExitLesson(), this.stepActions);
  }

  private skip(): void {
    const lesson = this.currentLesson;
    if (lesson === null) return;
    this.goNext(lesson);
  }

  private redo(): void {
    const lesson = this.currentLesson;
    if (lesson === null) return;
    this.callbacks.onPickScenario(lesson);
  }

  private goNext(lesson: Lesson): void {
    const next = nextLessonAfter(lesson);
    if (next === null) {
      this.callbacks.onExitLesson();
      return;
    }
    if (isScenarioLesson(next)) this.callbacks.onPickScenario(next);
    else this.callbacks.onPickRealGame();
  }

  /** Nút "Ván mới" của màn kết quả CHUNG (Hud, khi bài kết thúc bằng ăn Vua thật) — đi tiếp bài kế tiếp. */
  handleGameOverNewGame(): void {
    const lesson = this.currentLesson;
    if (lesson !== null) this.goNext(lesson);
  }

  /** Nút "Về menu" của màn kết quả CHUNG trong bối cảnh tân thủ — về danh sách bài, không về menu chính. */
  handleGameOverMenu(): void {
    this.callbacks.onExitLesson();
  }

  private renderList(): void {
    const progress = this.progressStore.load();
    const completed = new Set(progress.completed);
    this.lessonList.replaceChildren();
    for (const lesson of LESSONS) {
      const b = button(this.t(lesson.titleKey), 'menu-btn menu-btn-quiet tutorial-lesson-btn', () => {
        if (isScenarioLesson(lesson)) this.callbacks.onPickScenario(lesson);
        else this.callbacks.onPickRealGame();
      }, this.lessonList);
      b.dataset['lesson'] = lesson.id;
      const isDone = completed.has(lesson.id);
      b.classList.toggle('tutorial-lesson-completed', isDone);
      if (isDone) {
        const tag = el('span', 'tutorial-lesson-tag', b);
        tag.textContent = ` — ${this.t('tutorial.picker.completed')}`;
      }
    }
  }
}

/** `acknowledgeInfo()` là phương thức riêng của `TutorialTransport` (ngoài giao diện `Transport` chung) —
 * hàm nhỏ này chỉ để tránh lặp kiểm tra null ở nút "Tiếp tục" phía trên. */
function transportAcknowledge(transport: TutorialTransport | null): void {
  transport?.acknowledgeInfo();
}
