// Điều khiển voice CHUNG cho cả phòng (PLAN 11.2 "Dưới phải: Voice (mic/loa)", PLAN 8.5): hai công tắc Mic/Nghe,
// chọn micro, "chỉ qua TURN" (ẩn IP), nút thử mic. Điều khiển RIÊNG từng người (âm lượng, tắt tiếng, đang nói) nằm
// trong bảng người chơi của ChatPanel (app/chat-panel.ts) — cùng chỗ với chặn/báo cáo, xem ghi chú ở đó.
//
// Xếp CHỒNG lên trên nút nổi của ChatPanel ở góc phải (.chatpanel: bottom 96px; xem style.css) chứ không đụng
// `.hud-corner-br` (Cài đặt/Đầu hàng) — tránh lặp lại rủi ro chật chội đã gặp ở M5 (xem chat-panel.ts).
import type { Translator } from '../core/i18n';

export interface VoiceBarCallbacks {
  /** PLAN 8.5 "lần đầu bật: hộp thoại giải thích và xin quyền micro" — main.ts hiện hộp thoại TRƯỚC khi việc bật
   * mic thật sự xảy ra; hàm này CHỈ gọi khi người dùng đã đồng ý (hoặc đã từng đồng ý trong phiên này). Trả về
   * false nếu xin quyền thất bại (bị từ chối, không có thiết bị…), để nút không hiện sai trạng thái "đã bật". */
  readonly onMicToggle: (on: boolean) => Promise<boolean>;
  readonly onListenToggle: (on: boolean) => void;
  readonly onDeviceChange: (deviceId: string | null) => void;
  readonly onTurnOnlyToggle: (on: boolean) => void;
  /** Bắt đầu đo mức mic để vẽ đồng hồ mức (nút "Thử mic"); trả về hàm dừng đo. */
  readonly onTestMicStart: (onLevel: (level: number) => void) => () => void;
  /** PLAN 8.5/11.3: giữ phím `V` để nói (push-to-talk) — chỉ có tác dụng khi Mic đang bật (VoiceManager tự bỏ qua
   * lúc khác). */
  readonly onPushToTalk: (active: boolean) => void;
}

function el<K extends keyof HTMLElementTagNameMap>(tag: K, className: string, parent?: HTMLElement): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  node.className = className;
  parent?.appendChild(node);
  return node;
}

function toggleButton(label: string, className: string, onClick: () => void, parent: HTMLElement): HTMLButtonElement {
  const b = el('button', className, parent);
  b.type = 'button';
  b.textContent = label;
  b.addEventListener('click', onClick);
  return b;
}

export class VoiceBar {
  private readonly root: HTMLElement;
  private readonly micButton: HTMLButtonElement;
  private readonly listenButton: HTMLButtonElement;
  private readonly settingsPopup: HTMLElement;
  private readonly deviceSelect: HTMLSelectElement;
  private readonly turnOnlyCheckbox: HTMLInputElement;
  private readonly testMicButton: HTMLButtonElement;
  private readonly testMicMeter: HTMLElement;
  private readonly permissionDialog: HTMLElement;
  private readonly pushToTalkHint: HTMLElement;

  private micOn = false;
  private listenOn = false;
  private hasExplainedMic = false;
  private stopTestMic: (() => void) | null = null;

  constructor(
    parent: HTMLElement,
    private readonly t: Translator,
    private readonly callbacks: VoiceBarCallbacks,
  ) {
    this.root = el('div', 'voicebar hud-hidden', parent);

    this.micButton = toggleButton('🎤', 'voicebar-btn voicebar-mic', () => void this.toggleMic(), this.root);
    this.micButton.title = this.t('voice.mic');
    this.listenButton = toggleButton('🔊', 'voicebar-btn voicebar-listen', () => this.toggleListen(), this.root);
    this.listenButton.title = this.t('voice.listen');
    const settingsToggle = toggleButton('⚙', 'voicebar-btn voicebar-settings-toggle', () => this.settingsPopup.classList.toggle('hud-hidden'), this.root);
    settingsToggle.title = this.t('voice.settings');

    this.pushToTalkHint = el('div', 'voicebar-hint', this.root);
    this.pushToTalkHint.textContent = t('voice.pushToTalkHint');

    this.settingsPopup = el('div', 'voicebar-settings hud-hidden', this.root);
    el('label', 'voicebar-settings-label', this.settingsPopup).textContent = t('voice.device');
    this.deviceSelect = el('select', 'voicebar-device-select', this.settingsPopup);
    this.deviceSelect.addEventListener('change', () => this.callbacks.onDeviceChange(this.deviceSelect.value === '' ? null : this.deviceSelect.value));

    const turnRow = el('label', 'voicebar-turn-row', this.settingsPopup);
    this.turnOnlyCheckbox = el('input', 'voicebar-turnonly-checkbox', turnRow);
    this.turnOnlyCheckbox.type = 'checkbox';
    this.turnOnlyCheckbox.addEventListener('change', () => this.callbacks.onTurnOnlyToggle(this.turnOnlyCheckbox.checked));
    turnRow.append(document.createTextNode(' ' + t('voice.turnOnly')));

    const testRow = el('div', 'voicebar-test-row', this.settingsPopup);
    this.testMicButton = toggleButton(t('voice.testMic'), 'voicebar-test-btn', () => this.toggleTestMic(), testRow);
    const meterTrack = el('div', 'voicebar-meter-track', testRow);
    this.testMicMeter = el('div', 'voicebar-meter-bar', meterTrack);

    // PLAN 8.5 "hộp thoại giải thích và xin quyền micro" (lần đầu bật Mic).
    this.permissionDialog = el('div', 'hud-confirm-dialog voicebar-permission-dialog hud-hidden', parent);
    el('p', '', this.permissionDialog).textContent = t('voice.permission.explain');
    const actions = el('div', 'hud-confirm-actions', this.permissionDialog);
    toggleButton(t('voice.permission.allow'), 'hud-btn hud-btn-primary voicebar-permission-allow', () => {
      this.permissionDialog.classList.add('hud-hidden');
      this.hasExplainedMic = true;
      void this.enableMic();
    }, actions);
    toggleButton(t('hud.resign.cancel'), 'hud-btn voicebar-permission-cancel', () => this.permissionDialog.classList.add('hud-hidden'), actions);

    // PLAN 8.5/11.3 "giữ phím V để nói" — cùng kiểu bảo vệ khỏi cướp phím lúc đang gõ như ChatPanel's 'T' (chat-panel.ts).
    let holding = false;
    const isTyping = (target: EventTarget | null): boolean => target instanceof HTMLInputElement || target instanceof HTMLSelectElement;
    window.addEventListener('keydown', (e) => {
      if (this.root.classList.contains('hud-hidden') || isTyping(e.target) || e.key.toLowerCase() !== 'v' || holding) return;
      holding = true;
      this.callbacks.onPushToTalk(true);
    });
    window.addEventListener('keyup', (e) => {
      if (e.key.toLowerCase() !== 'v' || !holding) return;
      holding = false;
      this.callbacks.onPushToTalk(false);
    });
    window.addEventListener('blur', () => {
      if (!holding) return;
      holding = false;
      this.callbacks.onPushToTalk(false); // mất focus cửa sổ khi đang giữ V (đổi app) — nhả ngay, không kẹt mic mở
    });
  }

  // ---- Điều khiển từ main.ts ----------------------------------------------------------------------------------

  show(): void {
    this.root.classList.remove('hud-hidden');
  }

  /** Rời ván online: tắt hẳn (không để mic bật ngầm sang phòng khác), xoá trạng thái CHỈ CÓ NGHĨA trong phòng cũ. */
  hide(): void {
    this.root.classList.add('hud-hidden');
    this.settingsPopup.classList.add('hud-hidden');
    this.permissionDialog.classList.add('hud-hidden');
    this.stopTestMic?.();
    this.stopTestMic = null;
    this.micOn = false;
    this.listenOn = false;
    this.hasExplainedMic = false;
    this.render();
  }

  /** `deviceId` rỗng cho "mặc định hệ thống" (PLAN 11.5 "chọn micro") — nhãn thiết bị chỉ có SAU khi đã cấp quyền
   * micro ít nhất một lần trong phiên trình duyệt này (giới hạn của `enumerateDevices`, không phải lỗi ở đây). */
  setDevices(devices: readonly MediaDeviceInfo[], selectedId: string | null): void {
    this.deviceSelect.replaceChildren();
    const def = el('option', '', this.deviceSelect);
    def.value = '';
    def.textContent = this.t('voice.deviceDefault');
    for (const d of devices) {
      if (d.kind !== 'audioinput') continue;
      const opt = el('option', '', this.deviceSelect);
      opt.value = d.deviceId;
      opt.textContent = d.label.length > 0 ? d.label : this.t('voice.deviceUnnamed');
    }
    this.deviceSelect.value = selectedId ?? '';
  }

  setTurnOnly(on: boolean): void {
    this.turnOnlyCheckbox.checked = on;
  }

  private async toggleMic(): Promise<void> {
    if (this.micOn) {
      this.micOn = false;
      await this.callbacks.onMicToggle(false);
      this.render();
      return;
    }
    if (this.hasExplainedMic) {
      await this.enableMic();
    } else {
      this.permissionDialog.classList.remove('hud-hidden');
    }
  }

  private async enableMic(): Promise<void> {
    const ok = await this.callbacks.onMicToggle(true);
    this.micOn = ok;
    this.render();
  }

  private toggleListen(): void {
    this.listenOn = !this.listenOn;
    this.callbacks.onListenToggle(this.listenOn);
    this.render();
  }

  private toggleTestMic(): void {
    if (this.stopTestMic !== null) {
      this.stopTestMic();
      this.stopTestMic = null;
      this.testMicMeter.style.width = '0%';
      this.testMicButton.classList.remove('chatpanel-roster-btn-active', 'voicebar-btn-active');
      return;
    }
    this.stopTestMic = this.callbacks.onTestMicStart((level) => {
      this.testMicMeter.style.width = `${Math.min(100, Math.round(level * 220))}%`;
    });
    this.testMicButton.classList.add('voicebar-btn-active');
  }

  private render(): void {
    this.micButton.classList.toggle('voicebar-btn-active', this.micOn);
    this.listenButton.classList.toggle('voicebar-btn-active', this.listenOn);
    this.pushToTalkHint.classList.toggle('hud-hidden', !this.micOn);
  }
}
