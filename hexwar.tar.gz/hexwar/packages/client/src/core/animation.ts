// Đạo diễn hoạt ảnh: nhận sự kiện engine, xếp hàng, chạy TUẦN TỰ từng sự kiện (PLAN 6.1 nguyên tắc 5, 12.4).
// Thuần số và tất định: không đọc đồng hồ (nhận `dt` từ vòng lặp vẽ), không chạm THREE/DOM, nên kiểm thử bằng Node.
//
// Hợp đồng với mô hình hiển thị: mô hình chỉ bị đổi (`model.apply(event)`) khi bước hoạt ảnh của sự kiện đó KẾT THÚC.
// Trong lúc bước chạy, `motions()` cho biết từng quân đang bị "bẻ" khỏi vị trí gốc của mô hình như thế nào.
import { dist, type Cell, type GameEvent, type PieceType } from '@hexwar/rules';
import type { DisplayModel } from './display-model';
import { cellCenter } from './layout';

/** Ghi đè hiển thị tạm thời của một quân trong lúc một bước hoạt ảnh đang chạy. Trường vắng = dùng giá trị gốc. */
export interface Motion {
  /** Vị trí trên mặt bàn (thế giới). */
  readonly pos?: { readonly x: number; readonly z: number };
  /** Nâng thêm theo trục đứng (nhảy, rơi). */
  readonly lift?: number;
  /** Hệ số phóng (0 = biến mất). */
  readonly scale?: number;
  /** Độ sáng nhấn 0..1 (va chạm, phong cấp). */
  readonly glow?: number;
}

/** Hiệu ứng gắn với ô / vòng, không thuộc một quân cụ thể. `progress` chạy 0 → 1. */
export type Effect =
  | { readonly kind: 'impact'; readonly cell: Cell; readonly progress: number }
  | { readonly kind: 'kingHit'; readonly cell: Cell; readonly progress: number }
  | { readonly kind: 'collapse'; readonly ring: number; readonly progress: number }
  /** M10 (PLAN 12.4 "hết hạn tù binh: tan thành hạt sáng"). */
  | { readonly kind: 'dissolve'; readonly cell: Cell; readonly progress: number }
  /** M10 (PLAN 12.4 "phong cấp: ánh sáng từ dưới lên"). */
  | { readonly kind: 'promote'; readonly cell: Cell; readonly progress: number }
  /** M10 (PLAN 12.4 "hồi sinh Vua: vệt sáng nối Hề và Vua"). */
  | { readonly kind: 'beam'; readonly from: Cell; readonly to: Cell; readonly progress: number };

/** Thời lượng (giây, ở tốc độ 1×) của từng loại sự kiện. Nước đi thường không quá ~1,2 giây (PLAN 12.4). */
export const DURATION = {
  moveBase: 0.22,
  movePerCell: 0.045,
  moveMin: 0.25,
  moveMax: 1.0,
  captured: 0.28,
  captiveCreated: 0.3,
  captiveConscripted: 0.35,
  captiveTransferred: 0.2,
  captiveReleased: 0.5,
  captiveExpired: 0.4,
  promoted: 0.6,
  kingCaptured: 0.4,
  jesterRevived: 0.7,
  eliminatedBase: 0.6,
  eliminatedPerPiece: 0.03,
  eliminatedMax: 1.2,
  ringCollapsed: 1.6,
  diceRolled: 1.2,
  turnSkipped: 0.5,
} as const;

/** Độ cao cung nhảy: Mã nhảy qua đầu quân khác; Tốt/Vua nhấc nhẹ; quân trượt (Xe, Tượng, Hậu, Hề) lướt sát mặt bàn. */
const ARC: Readonly<Record<PieceType, number>> = { P: 0.2, N: 1.6, B: 0, R: 0, Q: 0, K: 0.25, J: 0 };

const easeInOut = (t: number): number => (t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2);
const clamp01 = (t: number): number => Math.min(1, Math.max(0, t));
const bump = (t: number): number => Math.sin(Math.PI * clamp01(t));

interface Step {
  readonly event: GameEvent;
  readonly duration: number;
  motions(t: number, out: Map<string, Motion>): void;
  effects(t: number): Effect[];
}

const NONE = (): Effect[] => [];
const noMotion = (): void => {};

function slide(from: Cell, to: Cell, t: number, arc: number): Motion {
  const a = cellCenter(from);
  const b = cellCenter(to);
  const e = easeInOut(t);
  return { pos: { x: a.x + (b.x - a.x) * e, z: a.z + (b.z - a.z) * e }, lift: arc * bump(t) };
}

/** Dựng bước hoạt ảnh cho một sự kiện, dựa trên mô hình ở thời điểm bước BẮT ĐẦU. */
function planStep(event: GameEvent, model: DisplayModel): Step {
  const still = (duration: number): Step => ({ event, duration, motions: noMotion, effects: NONE });
  switch (event.type) {
    case 'MOVED': {
      const type = model.get(event.pieceId)?.type ?? 'P';
      const d = dist(event.from, event.to);
      const duration = Math.min(DURATION.moveMax, Math.max(DURATION.moveMin, DURATION.moveBase + DURATION.movePerCell * d));
      return {
        event,
        duration,
        motions: (t, out) => out.set(event.pieceId, slide(event.from, event.to, t, ARC[type])),
        effects: NONE,
      };
    }
    case 'CAPTURED':
      return {
        event,
        duration: DURATION.captured,
        motions: (t, out) => out.set(event.victimId, { glow: bump(t) }),
        effects: (t) => [{ kind: 'impact', cell: event.cell, progress: t }],
      };
    case 'CAPTIVE_CREATED':
      return { event, duration: DURATION.captiveCreated, motions: (t, out) => out.set(event.pieceId, { glow: bump(t) }), effects: NONE };
    case 'CAPTIVE_CONSCRIPTED':
      return { event, duration: DURATION.captiveConscripted, motions: (t, out) => out.set(event.pieceId, { glow: bump(t) }), effects: NONE };
    case 'CAPTIVE_TRANSFERRED':
      return { event, duration: DURATION.captiveTransferred, motions: (t, out) => out.set(event.pieceId, { glow: bump(t) }), effects: NONE };
    case 'CAPTIVE_RELEASED':
      return {
        event,
        duration: DURATION.captiveReleased,
        motions: (t, out) => out.set(event.pieceId, { ...slide(event.from, event.to, t, 0.5), glow: bump(t) }),
        effects: NONE,
      };
    case 'CAPTIVE_EXPIRED':
      // M10 (PLAN 12.4 "tan thành hạt sáng"): scale/glow giữ nguyên như từ M3 (đã đúng "tan biến"), thêm hiệu ứng
      // hạt sáng ở effects-layer.ts đọc `dissolve` để hoàn thiện đúng mô tả PLAN, không đổi hoạt ảnh quân đã có.
      return {
        event,
        duration: DURATION.captiveExpired,
        motions: (t, out) => out.set(event.pieceId, { scale: 1 - easeInOut(t), glow: bump(t) }),
        effects: (t) => [{ kind: 'dissolve', cell: event.cell, progress: t }],
      };
    case 'PROMOTED': {
      // M10 (PLAN 12.4 "ánh sáng từ dưới lên"): quân đứng yên tại chỗ lúc phong cấp (không MOVED kèm theo), nên lấy
      // ô hiện tại của nó từ mô hình LÚC BƯỚC BẮT ĐẦU (đúng hợp đồng planStep, xem đầu file).
      const cell = model.get(event.pieceId)?.cell ?? { q: 0, r: 0 };
      return {
        event,
        duration: DURATION.promoted,
        motions: (t, out) => out.set(event.pieceId, { scale: 1 + 0.45 * bump(t), glow: bump(t) }),
        effects: (t) => [{ kind: 'promote', cell, progress: t }],
      };
    }
    case 'KING_CAPTURED':
      return { event, duration: DURATION.kingCaptured, motions: noMotion, effects: (t) => [{ kind: 'kingHit', cell: event.cell, progress: t }] };
    case 'JESTER_REVIVED':
      return {
        event,
        duration: DURATION.jesterRevived,
        motions: (t, out) => {
          out.set(event.kingId, { ...slide(event.from, event.to, t, 0.6), glow: bump(t) });
          out.set(event.jesterId, { scale: 1 - easeInOut(t), glow: bump(t) });
        },
        effects: (t) => [{ kind: 'beam', from: event.from, to: event.to, progress: t }],
      };
    case 'PLAYER_ELIMINATED': {
      const ids = event.removedPieceIds;
      const duration = Math.min(DURATION.eliminatedMax, DURATION.eliminatedBase + DURATION.eliminatedPerPiece * ids.length);
      return {
        event,
        duration,
        motions: (t, out) => {
          const spread = ids.length <= 1 ? 0 : 0.5; // phần thời lượng dùng để so le các quân
          ids.forEach((id, i) => {
            const delay = (i / Math.max(1, ids.length - 1)) * spread;
            const local = clamp01((t - delay) / (1 - spread));
            out.set(id, { scale: 1 - local, lift: 0.8 * local, glow: bump(local) });
          });
        },
        effects: NONE,
      };
    }
    case 'RING_COLLAPSED':
      return {
        event,
        duration: DURATION.ringCollapsed,
        motions: (t, out) => {
          for (const id of event.removedPieceIds) out.set(id, { lift: -9 * t * t, scale: 1 - 0.6 * t });
        },
        effects: (t) => [{ kind: 'collapse', ring: event.ring, progress: t }],
      };
    case 'DICE_ROLLED':
      return still(DURATION.diceRolled);
    case 'TURN_SKIPPED':
      return still(DURATION.turnSkipped);
    case 'ROUND_STARTED':
    case 'TURN_STARTED':
    case 'RING_WARNING':
    case 'GAME_OVER':
      return still(0);
  }
}

export interface DirectorListener {
  /** Bước của sự kiện vừa bắt đầu (HUD: thông báo, âm thanh). */
  onStart?(event: GameEvent): void;
  /** Bước của sự kiện vừa kết thúc và mô hình đã cập nhật. */
  onDone?(event: GameEvent): void;
}

export class AnimationDirector {
  private readonly queue: GameEvent[] = [];
  private current: { step: Step; elapsed: number } | null = null;
  private speed = 1;
  private readonly moving = new Map<string, Motion>();
  private activeEffects: Effect[] = [];

  constructor(
    readonly model: DisplayModel,
    private readonly listener: DirectorListener = {},
  ) {}

  /** Hệ số tốc độ (1 = thường, 2 = nhanh). `Infinity` = bỏ qua hoạt ảnh (áp dụng ngay). */
  setSpeed(speed: number): void {
    if (!(speed > 0)) throw new RangeError('speed phải > 0');
    this.speed = speed;
    if (speed === Number.POSITIVE_INFINITY) this.flush();
  }

  get busy(): boolean {
    return this.current !== null || this.queue.length > 0;
  }

  /** Số sự kiện chưa hoàn tất (kể cả sự kiện đang chạy). */
  get pending(): number {
    return this.queue.length + (this.current === null ? 0 : 1);
  }

  enqueue(events: readonly GameEvent[]): void {
    this.queue.push(...events);
    if (this.speed === Number.POSITIVE_INFINITY) this.flush();
  }

  /** Chạy tiếp `dt` giây thực (đã nhân tốc độ bên trong). Sự kiện nào hết hạn thì áp lên mô hình rồi sang sự kiện kế. */
  update(dt: number): void {
    let budget = Math.max(0, dt) * this.speed;
    for (let guard = 0; guard < 100_000; guard++) {
      if (this.current === null) {
        const next = this.queue.shift();
        if (next === undefined) break;
        this.current = { step: planStep(next, this.model), elapsed: 0 };
        this.listener.onStart?.(next);
      }
      const { step } = this.current;
      const remaining = step.duration - this.current.elapsed;
      if (budget < remaining) {
        this.current.elapsed += budget;
        break;
      }
      budget -= remaining;
      this.finishCurrent();
    }
    this.refresh();
  }

  /** Hoàn tất mọi thứ ngay lập tức (bỏ qua hoạt ảnh, vào lại ván, đổi tốc độ vô hạn). */
  flush(): void {
    for (let guard = 0; guard < 1_000_000 && this.busy; guard++) {
      if (this.current === null) {
        const next = this.queue.shift();
        if (next === undefined) break;
        this.current = { step: planStep(next, this.model), elapsed: 0 };
        this.listener.onStart?.(next);
      }
      this.finishCurrent();
    }
    this.refresh();
  }

  private finishCurrent(): void {
    if (this.current === null) return;
    const { event } = this.current.step;
    this.current = null;
    this.model.apply(event);
    this.listener.onDone?.(event);
  }

  private refresh(): void {
    this.moving.clear();
    this.activeEffects = [];
    if (this.current === null) return;
    const { step, elapsed } = this.current;
    const t = step.duration === 0 ? 1 : clamp01(elapsed / step.duration);
    step.motions(t, this.moving);
    this.activeEffects = step.effects(t);
  }

  /** Ghi đè hiển thị của các quân đang chuyển động ở khung hình hiện tại. */
  motions(): ReadonlyMap<string, Motion> {
    return this.moving;
  }

  effects(): readonly Effect[] {
    return this.activeEffects;
  }

  /** Sự kiện đang chạy (HUD/âm thanh cần biết), null nếu rảnh. */
  get currentEvent(): GameEvent | null {
    return this.current?.step.event ?? null;
  }
}
