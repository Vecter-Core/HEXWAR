// M10 (PLAN 12.6): bảng "nhạc phổ" THUẦN cho từng hiệu ứng âm thanh — chỉ số vào/ra (tần số, dạng sóng, thời
// lượng, độ trễ), không chạm `AudioContext`/`OscillatorNode` (đó là việc của `net/audio-manager.ts`, xem
// docs/decisions.md mục M10: cùng ranh giới core/ thuần — net/ chạm API trình duyệt thật đã dùng cho voice-model.ts
// / voice-manager.ts). Tách ra để `sfxForEvent` (bảng tra cứu sự kiện → hiệu ứng) và hình dạng từng tiếng động có
// test đơn vị, không cần dựng `AudioContext` giả trong Vitest.
import type { GameEvent } from '@hexwar/rules';

export type SfxId = 'select' | 'move' | 'capture' | 'kingHit' | 'captive' | 'promote' | 'revive' | 'collapse' | 'dice' | 'chat' | 'eliminated' | 'gameEnd' | 'tick';

export type OscType = 'sine' | 'square' | 'triangle' | 'sawtooth';

/** Một nốt bằng dao động (đa số hiệu ứng): bắt đầu sau `delay` giây, kéo dài `duration` giây, đỉnh âm lượng `gain`
 * (0..1, TRƯỚC khi nhân với âm lượng cài đặt), có thể trượt cao độ dần tới `slideTo` (Hz, tuỳ chọn). */
export interface ToneCue {
  readonly kind: 'tone';
  readonly type: OscType;
  readonly freq: number;
  readonly slideTo?: number;
  readonly delay: number;
  readonly duration: number;
  readonly gain: number;
}

/** Một tiếng động bằng nhiễu trắng lọc qua bộ lọc thông thấp `filterHz` (va chạm, thu hẹp) — không có cao độ rõ. */
export interface NoiseCue {
  readonly kind: 'noise';
  readonly filterHz: number;
  readonly delay: number;
  readonly duration: number;
  readonly gain: number;
}

export type Cue = ToneCue | NoiseCue;

const tone = (partial: Omit<ToneCue, 'kind'>): ToneCue => ({ kind: 'tone', ...partial });
const noise = (partial: Omit<NoiseCue, 'kind'>): NoiseCue => ({ kind: 'noise', ...partial });

/** Bảng hiệu ứng — mỗi mục là MỘT dãy nốt/tiếng động để tạo âm sắc riêng biệt cho từng sự kiện (PLAN 12.6). Không
 * dùng file âm thanh ngoài (đặt hàng ở `docs/credits.md`: đây là placeholder tổng hợp bằng mã, chưa có giấy phép
 * âm nhạc thật — CLAUDE.md "không dùng tài nguyên chưa rõ giấy phép"). */
export const SFX_CUES: Readonly<Record<SfxId, readonly Cue[]>> = {
  select: [tone({ type: 'triangle', freq: 660, delay: 0, duration: 0.06, gain: 0.5 })],
  move: [tone({ type: 'sine', freq: 300, slideTo: 420, delay: 0, duration: 0.12, gain: 0.4 })],
  capture: [noise({ filterHz: 900, delay: 0, duration: 0.14, gain: 0.6 }), tone({ type: 'square', freq: 180, delay: 0, duration: 0.1, gain: 0.35 })],
  kingHit: [
    noise({ filterHz: 400, delay: 0, duration: 0.35, gain: 0.8 }),
    tone({ type: 'sawtooth', freq: 120, slideTo: 55, delay: 0, duration: 0.4, gain: 0.5 }),
  ],
  captive: [tone({ type: 'triangle', freq: 520, delay: 0, duration: 0.09, gain: 0.4 }), tone({ type: 'triangle', freq: 400, delay: 0.09, duration: 0.09, gain: 0.35 })],
  promote: [
    tone({ type: 'sine', freq: 440, delay: 0, duration: 0.1, gain: 0.4 }),
    tone({ type: 'sine', freq: 554, delay: 0.1, duration: 0.1, gain: 0.4 }),
    tone({ type: 'sine', freq: 660, delay: 0.2, duration: 0.18, gain: 0.45 }),
  ],
  revive: [
    tone({ type: 'sine', freq: 300, slideTo: 900, delay: 0, duration: 0.5, gain: 0.35 }),
    tone({ type: 'sine', freq: 900, delay: 0.5, duration: 0.2, gain: 0.4 }),
  ],
  collapse: [
    noise({ filterHz: 220, delay: 0, duration: 0.7, gain: 0.7 }),
    tone({ type: 'sawtooth', freq: 90, slideTo: 40, delay: 0, duration: 0.7, gain: 0.4 }),
  ],
  dice: [
    tone({ type: 'square', freq: 800, delay: 0, duration: 0.04, gain: 0.3 }),
    tone({ type: 'square', freq: 760, delay: 0.12, duration: 0.04, gain: 0.3 }),
    tone({ type: 'square', freq: 820, delay: 0.24, duration: 0.05, gain: 0.3 }),
  ],
  chat: [tone({ type: 'sine', freq: 700, delay: 0, duration: 0.05, gain: 0.3 }), tone({ type: 'sine', freq: 900, delay: 0.05, duration: 0.05, gain: 0.3 })],
  eliminated: [tone({ type: 'sawtooth', freq: 260, slideTo: 90, delay: 0, duration: 0.5, gain: 0.4 })],
  gameEnd: [
    tone({ type: 'sine', freq: 523, delay: 0, duration: 0.2, gain: 0.4 }),
    tone({ type: 'sine', freq: 659, delay: 0.15, duration: 0.2, gain: 0.4 }),
    tone({ type: 'sine', freq: 784, delay: 0.3, duration: 0.4, gain: 0.45 }),
  ],
  tick: [tone({ type: 'square', freq: 900, delay: 0, duration: 0.05, gain: 0.25 })],
};

/** Sự kiện engine nào phát ra hiệu ứng gì (PLAN 12.6) — null = sự kiện đó không có âm thanh riêng (ví dụ đổi lượt
 * im lặng, cảnh báo vòng đã có nhấp nháy hình ảnh X-01 riêng). Thuần: không phụ thuộc AudioContext, test được. */
export function sfxForEvent(event: GameEvent): SfxId | null {
  switch (event.type) {
    case 'MOVED':
      return 'move';
    case 'CAPTURED':
      return 'capture';
    case 'KING_CAPTURED':
      return 'kingHit';
    case 'CAPTIVE_CREATED':
    case 'CAPTIVE_CONSCRIPTED':
      return 'captive';
    case 'PROMOTED':
      return 'promote';
    case 'JESTER_REVIVED':
      return 'revive';
    case 'RING_COLLAPSED':
      return 'collapse';
    case 'DICE_ROLLED':
      return 'dice';
    case 'PLAYER_ELIMINATED':
      return 'eliminated';
    case 'GAME_OVER':
      return 'gameEnd';
    case 'CAPTIVE_TRANSFERRED':
    case 'CAPTIVE_RELEASED':
    case 'CAPTIVE_EXPIRED':
    case 'ROUND_STARTED':
    case 'TURN_STARTED':
    case 'TURN_SKIPPED':
    case 'RING_WARNING':
      return null;
  }
}

/** PLAN 12.6 "nhạc nền theo pha": tần số gốc của đệm nền (tam giác trầm, lặp) cho từng pha — `tense` cao/nhanh hơn
 * một chút để tạo cảm giác căng thẳng, `end` thấp hẳn xuống cho cảm giác lắng lại. Thuần số, test được. */
export type AmbiencePhase = 'normal' | 'tense' | 'end';

export const AMBIENCE: Readonly<Record<AmbiencePhase, { readonly freq: number; readonly beatHz: number; readonly gain: number }>> = {
  normal: { freq: 110, beatHz: 0.15, gain: 0.05 },
  tense: { freq: 146.83, beatHz: 0.55, gain: 0.07 },
  end: { freq: 82.41, beatHz: 0.08, gain: 0.04 },
};
