// M10 (PLAN 12.3, 11.5): "6 biểu tượng hình học khác nhau trên đế quân (tròn, tam giác, vuông, thoi, sao, lục giác)"
// để nhận ra chủ quân KHÔNG CẦN màu (hỗ trợ người mù màu). Ánh xạ ghế → hình THUẦN (không THREE/DOM) để test được
// bằng Node, giống mọi bảng tra cứu khác ở `core/` (xem `palette.ts`: SEAT_COLORS). Dựng hình học thật ở `scene/badge-geometry.ts`.
import type { Seat } from '@hexwar/rules';

export type BadgeShape = 'circle' | 'triangle' | 'square' | 'diamond' | 'star' | 'hexagon';

/** Đúng thứ tự ghế 0…5 (PLAN 12.3, khớp thứ tự liệt kê "tròn, tam giác, vuông, thoi, sao, lục giác"). */
export const BADGE_SHAPES: readonly BadgeShape[] = ['circle', 'triangle', 'square', 'diamond', 'star', 'hexagon'];

export function badgeShapeForSeat(seat: Seat): BadgeShape {
  return BADGE_SHAPES[seat] as BadgeShape;
}
