// Toán camera quỹ đạo (thuần số). Camera nhìn về một điểm trên mặt bàn (target), quay quanh trục đứng (azimuth)
// và nghiêng (elevation). Cùng bộ toán này dùng cho: đặt camera THREE, chọn ô bằng tia, và test.
import { boardExtent, seatAzimuth, wrapAngle } from './layout';
import { cross, dot, normalize, scale, sub, vec, add, type Vec3 } from './vec';
import type { Seat } from '@hexwar/rules';

export interface OrbitState {
  /** Hướng từ target tới camera trong mặt phẳng x–z: (cos a, sin a). 90° = camera ở phía z dương (ghế 0 ở đáy). */
  readonly azimuth: number;
  /** Góc nâng so với mặt bàn (rad). */
  readonly elevation: number;
  readonly distance: number;
  readonly targetX: number;
  readonly targetZ: number;
}

export const FOV_DEG = 40;
export const MIN_ELEVATION = (12 * Math.PI) / 180;
export const MAX_ELEVATION = (88 * Math.PI) / 180;
export const DEFAULT_ELEVATION = (50 * Math.PI) / 180;
export const MIN_DISTANCE = 5;
export const MAX_DISTANCE = 140;
export const DEFAULT_DISTANCE = 70;
/**
 * Camera mặc định nhìn vào điểm cách tâm bàn 20 đơn vị về phía ghế của mình: tìm bằng cách quét lưới sao cho cả 18 quân
 * xuất phát của ghế nằm trong khung (16:9 và 4:3, lề ≥ 35%) mà tâm bàn vẫn còn trong khung. Nhìn thẳng vào tâm thì
 * quân của chính mình (ở vòng 23, gần mép bàn) bị đẩy ra ngoài đáy màn hình.
 */
export const SEAT_FOCUS = 20;

const clamp = (v: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, v));

/** Giữ camera trong giới hạn hợp lý: góc nâng, khoảng cách, và target không rời khỏi bàn cờ. */
export function clampOrbit(s: OrbitState, radius: number): OrbitState {
  const limit = boardExtent(radius);
  const r = Math.hypot(s.targetX, s.targetZ);
  const k = r > limit ? limit / r : 1;
  return {
    azimuth: wrapAngle(s.azimuth),
    elevation: clamp(s.elevation, MIN_ELEVATION, MAX_ELEVATION),
    distance: clamp(s.distance, MIN_DISTANCE, MAX_DISTANCE),
    targetX: s.targetX * k,
    targetZ: s.targetZ * k,
  };
}

/** Camera "ghế của tôi ở đáy màn hình", nhìn về tâm bàn (PLAN 3.3, 11.4). */
export function seatOrbit(seat: Seat, seatCornerRing: number): OrbitState {
  const azimuth = seatAzimuth(seat, seatCornerRing);
  return {
    azimuth,
    elevation: DEFAULT_ELEVATION,
    distance: DEFAULT_DISTANCE,
    targetX: Math.cos(azimuth) * SEAT_FOCUS,
    targetZ: Math.sin(azimuth) * SEAT_FOCUS,
  };
}

export interface CameraPose {
  readonly position: Vec3;
  readonly forward: Vec3;
  readonly right: Vec3;
  readonly up: Vec3;
}

export function cameraPose(s: OrbitState): CameraPose {
  const horizontal = Math.cos(s.elevation);
  const offset = vec(horizontal * Math.cos(s.azimuth), Math.sin(s.elevation), horizontal * Math.sin(s.azimuth));
  const target = vec(s.targetX, 0, s.targetZ);
  const position = add(target, scale(offset, s.distance));
  const forward = normalize(sub(target, position));
  const right = normalize(cross(forward, vec(0, 1, 0)));
  const up = cross(right, forward);
  return { position, forward, right, up };
}

export interface Ray {
  readonly origin: Vec3;
  readonly dir: Vec3;
}

/** Tia đi qua điểm chuẩn hoá màn hình (ndcX sang phải, ndcY lên trên, cả hai trong [−1, 1]). */
export function rayFromNdc(pose: CameraPose, ndcX: number, ndcY: number, fovDeg: number, aspect: number): Ray {
  const tanHalf = Math.tan((fovDeg * Math.PI) / 360);
  const dir = normalize(add(add(pose.forward, scale(pose.right, ndcX * tanHalf * aspect)), scale(pose.up, ndcY * tanHalf)));
  return { origin: pose.position, dir };
}

/** Chiếu điểm thế giới lên màn hình; null nếu nằm sau camera. Nghịch đảo của `rayFromNdc`. */
export function projectToNdc(pose: CameraPose, p: Vec3, fovDeg: number, aspect: number): { x: number; y: number; depth: number } | null {
  const v = sub(p, pose.position);
  const depth = dot(v, pose.forward);
  if (depth <= 0) return null;
  const tanHalf = Math.tan((fovDeg * Math.PI) / 360);
  return { x: dot(v, pose.right) / (depth * tanHalf * aspect), y: dot(v, pose.up) / (depth * tanHalf), depth };
}

export function rotateOrbit(s: OrbitState, dAzimuth: number, dElevation: number, radius: number): OrbitState {
  return clampOrbit({ ...s, azimuth: s.azimuth + dAzimuth, elevation: s.elevation + dElevation }, radius);
}

/** factor > 1 = ra xa. */
export function zoomOrbit(s: OrbitState, factor: number, radius: number): OrbitState {
  return clampOrbit({ ...s, distance: s.distance * factor }, radius);
}

/** Dịch target trên mặt bàn theo hướng "phải" và "tiến" của camera (đơn vị thế giới). */
export function panOrbit(s: OrbitState, dRight: number, dForward: number, radius: number): OrbitState {
  const pose = cameraPose(s);
  const right = normalize(vec(pose.right.x, 0, pose.right.z));
  const forward = normalize(vec(pose.forward.x, 0, pose.forward.z));
  return clampOrbit({ ...s, targetX: s.targetX + right.x * dRight + forward.x * dForward, targetZ: s.targetZ + right.z * dRight + forward.z * dForward }, radius);
}

/** Nội suy giữa hai trạng thái camera; góc phương vị đi theo đường ngắn nhất. */
export function lerpOrbit(a: OrbitState, b: OrbitState, t: number): OrbitState {
  const mix = (x: number, y: number): number => x + (y - x) * t;
  return {
    azimuth: wrapAngle(a.azimuth + wrapAngle(b.azimuth - a.azimuth) * t),
    elevation: mix(a.elevation, b.elevation),
    distance: mix(a.distance, b.distance),
    targetX: mix(a.targetX, b.targetX),
    targetZ: mix(a.targetZ, b.targetZ),
  };
}

/** Nhìn thẳng từ trên xuống (PLAN 11.4), giữ hướng xoay hiện tại. */
export const topDownOrbit = (s: OrbitState): OrbitState => ({ ...s, elevation: MAX_ELEVATION });
