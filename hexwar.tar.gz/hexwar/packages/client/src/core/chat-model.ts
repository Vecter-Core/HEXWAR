// Phần THUẦN của chat (PLAN mục 8): tab hội thoại một message thuộc về, và việc lọc theo tắt tiếng/chặn cục bộ
// (PLAN 8.4). Tách khỏi DOM để test được (giống hud-model.ts/selection-model.ts) — `ChatPanel` (app/chat-panel.ts)
// còn lại tự quản lý DOM/mảng tin nhắn trực tiếp, không cần một reducer đầy đủ cho một tính năng nhỏ như chat.
import type { ChatChannel, ChatMessage, PhraseId } from '@hexwar/protocol';
import type { Seat } from '@hexwar/rules';

export type ChatTabId = 'all' | 'dead' | `whisper:${number}`;

export function whisperTabId(otherSeat: Seat): ChatTabId {
  return `whisper:${otherSeat}`;
}

/** Ghế "đối phương" của một tab whisper, hoặc null cho 'all'/'dead'. */
export function seatOfTab(tab: ChatTabId): Seat | null {
  if (tab === 'all' || tab === 'dead') return null;
  return Number(tab.slice('whisper:'.length)) as Seat;
}

/** Nơi một `chat.send` sẽ gửi tới, suy từ tab đang mở (PLAN 8.1, 8.2). */
export type ChatSendTarget = { readonly channel: 'all' } | { readonly channel: 'dead' } | { readonly channel: 'whisper'; readonly to: Seat };

export function targetForTab(tab: ChatTabId): ChatSendTarget {
  if (tab === 'all') return { channel: 'all' };
  if (tab === 'dead') return { channel: 'dead' };
  return { channel: 'whisper', to: seatOfTab(tab) as Seat };
}

/** Tab mà một `chat.message` NHẬN ĐƯỢC thuộc về, xét theo góc nhìn của `mySeat` — hội thoại riêng nhóm theo NGƯỜI
 * CÒN LẠI trong cuộc trò chuyện, không phải theo hướng gửi/nhận (PLAN 8.2: một khung "Nhắn riêng cho Tên" duy nhất
 * cho mỗi người, dùng chung dù mình gửi hay nhận). */
export function tabIdFor(message: ChatMessage, mySeat: Seat | null): ChatTabId {
  const channel: ChatChannel = message.channel;
  if (channel === 'all') return 'all';
  if (channel === 'dead') return 'dead';
  const other = message.from === mySeat ? (message.to as Seat) : message.from;
  return whisperTabId(other);
}

/** PLAN 8.4 "tắt tiếng (ẩn tin từ người đó), chặn" — cả hai lọc phía người XEM, cục bộ (không có tác dụng ở server
 * hay ở người khác, xem docs/decisions.md M7). Không lọc tin của CHÍNH MÌNH (mới tự tắt tiếng chính mình thì vô lý). */
export function isHiddenBySeatFilter(message: ChatMessage, mySeat: Seat | null, mutedSeats: ReadonlySet<Seat>, blockedSeats: ReadonlySet<Seat>): boolean {
  if (message.from === mySeat) return false;
  return mutedSeats.has(message.from) || blockedSeats.has(message.from);
}

export function phraseLocaleKey(phraseId: PhraseId): string {
  return `phrase.${phraseId}`;
}
