// M10 (PLAN 12.2 "rung → nứt → rơi", 12.4 "thu hẹp: như 12.2"): toán THUẦN cho hoạt ảnh của một Ô đang biến mất,
// tách khỏi `scene/board-mesh.ts` (THREE thật, không kiểm bằng Node được) để có test đơn vị. Không phụ thuộc
// DOM/THREE — chỉ số vào, số ra, giống mọi hàm khác ở `core/` (PLAN 6.1 nguyên tắc 5: hoạt ảnh tách khỏi trạng thái).
export const COLLAPSE_SHAKE_FRACTION = 0.4;
export const COLLAPSE_SHAKE_AMPLITUDE = 0.05;
export const COLLAPSE_FALL_DISTANCE = 3.2;
export const COLLAPSE_MIN_SCALE = 0.05;

export interface CollapseTileTransform {
  /** Lệch vị trí (đơn vị thế giới) so với tâm ô gốc. */
  readonly dx: number;
  readonly dy: number;
  readonly dz: number;
  /** Hệ số phóng đều 3 trục — nhỏ dần về `COLLAPSE_MIN_SCALE` khi rơi (không về 0 tuyệt đối để tránh suy biến ma trận). */
  readonly scale: number;
  /** 0 = màu ô gốc, 1 = màu nứt/cảnh báo hoàn toàn — trộn vào `TILE_TONES` bằng `mixColor` ở `board-mesh.ts`. */
  readonly crack: number;
  readonly phase: 'shake' | 'fall';
}

/**
 * `progress`: 0 → 1 trong suốt hiệu ứng `'collapse'` của `AnimationDirector` (cùng thời lượng `DURATION.ringCollapsed`
 * mà quân trên vòng đó đã dùng để rơi từ M3 — chỉ thêm hoạt ảnh cho chính CÁI Ô, không đổi thời lượng).
 * `seed`: một số nguyên khác nhau cho mỗi ô (chỉ số instance) để cả vòng không rung đồng bộ y hệt (trông giả).
 */
export function collapseTileTransform(progress: number, seed: number): CollapseTileTransform {
  const p = Math.min(1, Math.max(0, progress));
  if (p < COLLAPSE_SHAKE_FRACTION) {
    const t = p / COLLAPSE_SHAKE_FRACTION;
    const amp = COLLAPSE_SHAKE_AMPLITUDE * Math.sin(t * Math.PI); // tăng dần rồi giảm dần biên độ rung
    const phaseSeed = seed * 12.9898;
    return {
      dx: amp * Math.sin(phaseSeed * 3.1 + t * 60),
      dy: 0,
      dz: amp * Math.cos(phaseSeed * 4.7 + t * 50),
      scale: 1,
      crack: t * 0.5, // "nứt" bắt đầu lộ dần trong lúc rung
      phase: 'shake',
    };
  }
  const t = (p - COLLAPSE_SHAKE_FRACTION) / (1 - COLLAPSE_SHAKE_FRACTION);
  return {
    dx: 0,
    dy: -COLLAPSE_FALL_DISTANCE * t * t, // rơi nhanh dần (gia tốc không đổi, t² của quãng đường)
    dz: 0,
    scale: Math.max(COLLAPSE_MIN_SCALE, 1 - t),
    crack: 0.5 + 0.5 * t,
    phase: 'fall',
  };
}

/** Pha hiện tại của CẢ VÒNG tại `progress` (không phụ thuộc `seed` — chỉ biên độ rung lệch theo từng ô, không phải
 * mốc chuyển pha). `board-mesh.ts` dùng để biết KHI NÀO cả vòng vừa chuyển rung→rơi (sinh bụi một lần, PLAN 12.2). */
export function collapsePhaseAt(progress: number): 'shake' | 'fall' {
  return progress < COLLAPSE_SHAKE_FRACTION ? 'shake' : 'fall';
}
