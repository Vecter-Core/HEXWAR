// Bộ điều khiển ván hotseat (PLAN M3: "chơi được ván hotseat trên một máy"; PLAN 11.3 chọn quân/ô đích).
// Thuần logic: không THREE, không DOM. Nhận một "pick" (ô hoặc quân, từ picking.ts) và quyết định phải làm gì,
// dùng ĐÚNG engine (`checkMove`, `applyMove`) làm trọng tài — không tự đoán luật ở đây (PLAN 6.1 nguyên tắc 2).
//
// Luồng mặc định (không có xác nhận, X-14 tắt theo mặc định): chọn quân của mình → bấm ô đích → áp dụng ngay.
// Bấm lại quân đang chọn: bỏ chọn. Bấm quân khác của mình: đổi chọn. Bấm ô không hợp lệ: giữ nguyên chọn, báo lý do.
import {
  IllegalMoveError,
  applyMove,
  checkMove,
  legalMovesOfPiece,
  resign,
  rollDice,
  timeoutTurn,
  type ActionResult,
  type Cell,
  type GameState,
  type IllegalReason,
  type Move,
  type Piece,
  type Rng,
  type Seat,
} from '@hexwar/rules';
import type { CellPick } from './picking';

export interface Selection {
  readonly pieceId: string;
  /** true nếu đây là tù binh đang được trưng dụng (R-32); quyết định `conscript` khi thử đi tới ô không hợp lệ. */
  readonly conscript: boolean;
  /** Nước đi hợp lệ của quân đang chọn, theo khoá "q,r" của ô đích (PLAN 11.2: tô ô đi được / ăn được). */
  readonly moves: ReadonlyMap<string, Move>;
  /**
   * X-14 (chỉ có khi `ControllerOptions.confirmMoves` bật): ô đích vừa bấm, CHỜ xác nhận — chưa áp dụng/gửi đi.
   * Bấm lại đúng ô này (hoặc gọi `confirmPending`) mới thật sự đi; `cancelPending` xoá lựa chọn này, vẫn giữ quân.
   */
  readonly pendingMove?: Move;
}

export type MoveKind = 'move' | 'capture' | 'conscriptMove' | 'conscriptCapture';

const cellKeyOf = (c: Cell): string => `${c.q},${c.r}`;

/** Loại nước đi để tô màu đúng (PLAN 11.2 xanh/đỏ; conscript thêm màu riêng, palette.ts `HIGHLIGHT`). */
export function classifyMove(state: GameState, move: Move): MoveKind {
  const capture = state.pieces.some((p) => p.status === 'active' && p.cell.q === move.to.q && p.cell.r === move.to.r);
  if (move.conscript === true) return capture ? 'conscriptCapture' : 'conscriptMove';
  return capture ? 'capture' : 'move';
}

export interface ControllerListener {
  /** Trạng thái vừa đổi vì một hành động (nước đi, hết giờ, đầu hàng, xúc xắc). */
  onAction?(result: ActionResult): void;
  onSelectionChanged?(selection: Selection | null): void;
  /** Người dùng bấm một ô/quân không hợp lệ trong tình huống hiện tại; `reason` dịch qua i18n (`illegal.<reason>`). */
  onRejected?(reason: IllegalReason, attempted: Move): void;
}

export interface ControllerOptions {
  /**
   * Có nơi chạy ván (M4+: Worker cục bộ; M6: server): KHÔNG tự áp dụng nước đi mà gửi ý định đi (PLAN 6.1 nguyên tắc
   * 2); trạng thái mới trở về qua `receive`. Không có `submit` = chế độ tự áp dụng (test thuần, công cụ).
   */
  readonly submit?: (move: Move) => void;
  /** Ghế mà người dùng máy này được điều khiển (solo: ghế của mình; hotseat: mọi ghế). Mặc định: mọi ghế. */
  readonly controls?: (seat: Seat) => boolean;
  /**
   * X-14 (PLAN 11.2, "tuỳ chọn"): bấm ô đích lần đầu chỉ ĐẶT thành `selection.pendingMove`, chưa đi; phải bấm lại
   * đúng ô đó (hoặc gọi `confirmPending`) mới thật sự áp dụng/gửi nước đi. Mặc định false (đi ngay, hành vi M3/M4).
   */
  readonly confirmMoves?: boolean;
}

/**
 * Ai đang "sở hữu" quân này để CHỌN nó ở lượt của `seat` (PLAN R-11, R-32): quân hoạt động của chính mình, hoặc
 * tù binh của mình do mình đang giữ (kể cả chưa tới hạn trưng dụng — chọn vẫn được, chỉ là chưa có nước nào).
 */
function ownsForSelection(piece: Piece, seat: Seat): boolean {
  return piece.status === 'active' ? piece.owner === seat : piece.holder === seat;
}

export class GameController {
  private current: GameState;
  private currentSelection: Selection | null = null;

  constructor(
    initialState: GameState,
    private readonly listener: ControllerListener = {},
    private readonly options: ControllerOptions = {},
  ) {
    this.current = initialState;
  }

  /** Người dùng máy này có điều khiển ghế `seat` không (để biết có phải "lượt của bạn"). */
  controls(seat: Seat): boolean {
    return this.options.controls?.(seat) ?? true;
  }

  /** Kết quả một hành động do nơi chạy ván gửi về (chế độ có `submit`). */
  receive(result: ActionResult): void {
    this.clearSelection(); // thế cờ đã đổi: nước đi đã tô của lựa chọn cũ không còn đúng
    this.advance(result);
  }

  /** Thay toàn bộ trạng thái (bắt đầu / tiếp tục ván đã lưu / vào lại) — không có sự kiện để diễn hoạt ảnh. */
  reset(state: GameState): void {
    this.clearSelection();
    this.current = state;
  }

  get state(): GameState {
    return this.current;
  }

  get selection(): Selection | null {
    return this.currentSelection;
  }

  /** R-02: tung xúc xắc để vào pha chơi. Chỉ gọi được khi ván còn ở pha 'dice'. */
  rollDice(rng: Rng): void {
    if (this.current.phase !== 'dice') throw new Error('rollDice: ván không còn ở pha tung xúc xắc');
    this.advance(rollDice(this.current, rng));
  }

  timeoutCurrentTurn(): void {
    this.advance(timeoutTurn(this.current));
  }

  resignSeat(seat: Seat): void {
    this.clearSelection();
    this.advance(resign(this.current, seat));
  }

  /** Bỏ chọn quân hiện tại (Esc, hoặc bấm ra ngoài bàn cờ — PLAN 11.3). */
  clearSelection(): void {
    if (this.currentSelection === null) return;
    this.currentSelection = null;
    this.listener.onSelectionChanged?.(null);
  }

  /**
   * Xử lý một điểm được bấm tới (từ `pickCell`). Trả về true nếu đã LÀM gì đó (chọn, đổi chọn, đi quân); false nếu
   * bấm vào ô/quân không liên quan (giữ nguyên trạng thái chọn).
   */
  handlePick(pick: CellPick | null): boolean {
    if (pick === null || this.current.phase !== 'playing' || this.current.turnSeat === null) return false;
    const seat = this.current.turnSeat;
    if (!this.controls(seat)) return false; // lượt của bot/người khác: chỉ xem

    if (pick.kind === 'piece') {
      if (this.currentSelection?.pieceId === pick.pieceId) {
        this.clearSelection(); // bấm lại quân đang chọn: bỏ chọn
        return true;
      }
      const piece = this.current.pieces.find((p) => p.id === pick.pieceId);
      if (piece !== undefined && ownsForSelection(piece, seat)) {
        this.select(pick.pieceId);
        return true;
      }
      // Quân của người khác: không phải mục tiêu chọn được, nhưng có thể là Ô ĐÍCH của quân đang chọn (ăn quân).
      return this.tryMoveTo(pick.cell);
    }

    if (this.currentSelection?.pieceId === undefined) return false;
    return this.tryMoveTo(pick.cell);
  }

  /** Chọn thẳng một quân theo id (bỏ qua bước "bấm tới"), dùng khi UI có danh sách quân riêng (Tab, PLAN 11.3). */
  select(pieceId: string): void {
    const piece = this.current.pieces.find((p) => p.id === pieceId);
    const conscript = piece?.status === 'captive';
    const moves = new Map(legalMovesOfPiece(this.current, pieceId).map((m) => [cellKeyOf(m.to), m]));
    this.currentSelection = { pieceId, conscript, moves };
    this.listener.onSelectionChanged?.(this.currentSelection);
  }

  private tryMoveTo(to: Cell): boolean {
    const selection = this.currentSelection;
    if (selection === null) return false;
    const move = selection.moves.get(cellKeyOf(to));
    if (move === undefined) {
      const seat = this.current.turnSeat;
      if (seat === null) return false;
      const attempted: Move = selection.conscript ? { pieceId: selection.pieceId, to, conscript: true } : { pieceId: selection.pieceId, to };
      const reason = checkMove(this.current, seat, attempted) ?? 'NOT_ALLOWED';
      this.listener.onRejected?.(reason, attempted);
      return true; // đã xử lý (báo lỗi), dù không đổi trạng thái ván
    }
    if (this.options.confirmMoves === true) {
      const confirmingSamePending = selection.pendingMove !== undefined && cellKeyOf(selection.pendingMove.to) === cellKeyOf(to);
      if (!confirmingSamePending) {
        // Lần bấm đầu (hoặc đổi sang ô đích khác): chỉ đặt ô đích đang chờ, chưa đi (PLAN 11.2 "bấm lại để xác nhận").
        this.currentSelection = { ...selection, pendingMove: move };
        this.listener.onSelectionChanged?.(this.currentSelection);
        return true;
      }
    }
    this.applyOrSubmit(move);
    return true;
  }

  /** X-14: xác nhận nước đang chờ (PLAN 11.2 nút "Xác nhận"). Không làm gì nếu không có nước nào đang chờ. */
  confirmPending(): void {
    const pending = this.currentSelection?.pendingMove;
    if (pending !== undefined) this.applyOrSubmit(pending);
  }

  /** X-14: huỷ nước đang chờ (PLAN 11.2 nút "Hủy") — vẫn giữ quân đang chọn để chọn ô đích khác. */
  cancelPending(): void {
    const selection = this.currentSelection;
    if (selection?.pendingMove === undefined) return;
    this.currentSelection = { pieceId: selection.pieceId, conscript: selection.conscript, moves: selection.moves };
    this.listener.onSelectionChanged?.(this.currentSelection);
  }

  private applyOrSubmit(move: Move): void {
    this.clearSelection();
    if (this.options.submit !== undefined) {
      this.options.submit(move); // nơi chạy ván kiểm lại bằng engine rồi mới phát kết quả (PLAN 7.6)
      return;
    }
    try {
      this.advance(applyMove(this.current, move));
    } catch (error) {
      // Không nên xảy ra vì `move` tới từ `legalMovesOfPiece` của chính trạng thái hiện tại, nhưng không tin tưởng
      // mù quáng (PLAN 6.1 nguyên tắc 2: chỉ engine quyết luật, kể cả khi chính client là người gọi).
      if (error instanceof IllegalMoveError) this.listener.onRejected?.(error.reason, move);
      else throw error;
    }
  }

  private advance(result: ActionResult): void {
    this.current = result.state;
    this.listener.onAction?.(result);
  }
}
