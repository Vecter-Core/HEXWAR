// Mô hình hiển thị: quân trên màn hình, dựng lại CHỈ từ dòng sự kiện của engine (PLAN 6.1 nguyên tắc 5: hoạt ảnh
// chỉ đọc sự kiện; trạng thái logic luôn cập nhật ngay, hoạt ảnh chạy sau).
//
// Mỗi sự kiện có một hiệu ứng tức thời lên mô hình (`apply`); lớp hoạt ảnh gọi `apply` khi sự kiện kết thúc, nên
// giữa các sự kiện mô hình vẫn là trạng thái "đã ổn định" nhất quán. `reconcile` so với trạng thái engine để bắt
// mọi sai lệch (dùng trong test: dòng sự kiện phải đủ để dựng lại trạng thái; và ở runtime như lưới an toàn).
import { sameCell, type Cell, type GameEvent, type GameState, type Piece, type PieceType, type Seat } from '@hexwar/rules';

export interface PieceView {
  readonly id: string;
  readonly type: PieceType;
  readonly owner: Seat;
  readonly cell: Cell;
  readonly status: 'active' | 'captive';
  /** Người giữ (chỉ khi status = 'captive'). */
  readonly holder: Seat | null;
}

const viewOf = (p: Piece): PieceView => ({ id: p.id, type: p.type, owner: p.owner, cell: p.cell, status: p.status, holder: p.holder ?? null });

export class DisplayModel {
  radius: number;
  private readonly byId = new Map<string, PieceView>();

  private constructor(radius: number) {
    this.radius = radius;
  }

  static fromState(state: GameState): DisplayModel {
    const model = new DisplayModel(state.radius);
    for (const p of state.pieces) model.byId.set(p.id, viewOf(p));
    return model;
  }

  get(id: string): PieceView | undefined {
    return this.byId.get(id);
  }

  /** Mọi quân đang hiển thị, theo thứ tự ổn định (thứ tự tạo). */
  all(): PieceView[] {
    return [...this.byId.values()];
  }

  get size(): number {
    return this.byId.size;
  }

  clone(): DisplayModel {
    const copy = new DisplayModel(this.radius);
    for (const [id, view] of this.byId) copy.byId.set(id, view);
    return copy;
  }

  private set(id: string, patch: Partial<PieceView>): void {
    const view = this.byId.get(id);
    if (view !== undefined) this.byId.set(id, { ...view, ...patch });
  }

  private remove(ids: readonly string[]): void {
    for (const id of ids) this.byId.delete(id);
  }

  /** Hiệu ứng tức thời của một sự kiện lên mô hình. Sự kiện không đổi bố cục quân (xúc xắc, lượt, cảnh báo…) bị bỏ qua. */
  apply(event: GameEvent): void {
    switch (event.type) {
      case 'MOVED':
        this.set(event.pieceId, { cell: event.to });
        break;
      case 'CAPTURED': {
        // Trưng dụng (R-32): quân bị ăn (không phải Vua) bị loại ngay, không có sự kiện riêng. Vua thì chờ
        // JESTER_REVIVED / PLAYER_ELIMINATED. Ăn thường: CAPTIVE_CREATED / KING_CAPTURED theo sau.
        const victim = this.byId.get(event.victimId);
        if (event.conscript && victim !== undefined && victim.type !== 'K') this.remove([event.victimId]);
        break;
      }
      case 'CAPTIVE_CREATED':
        this.set(event.pieceId, { status: 'captive', holder: event.holder });
        break;
      case 'CAPTIVE_TRANSFERRED':
        this.set(event.pieceId, { holder: event.to });
        break;
      case 'CAPTIVE_RELEASED':
        this.set(event.pieceId, { status: 'active', holder: null, cell: event.to });
        break;
      case 'CAPTIVE_EXPIRED':
        this.remove([event.pieceId]);
        break;
      case 'PROMOTED':
        this.set(event.pieceId, { type: event.to });
        break;
      case 'JESTER_REVIVED':
        this.set(event.kingId, { cell: event.to });
        this.remove([event.jesterId]);
        break;
      case 'PLAYER_ELIMINATED':
        this.remove(event.removedPieceIds);
        break;
      case 'RING_COLLAPSED':
        this.remove(event.removedPieceIds);
        this.radius = event.radius;
        break;
      case 'DICE_ROLLED':
      case 'ROUND_STARTED':
      case 'TURN_STARTED':
      case 'TURN_SKIPPED':
      case 'CAPTIVE_CONSCRIPTED':
      case 'KING_CAPTURED':
      case 'RING_WARNING':
      case 'GAME_OVER':
        break;
    }
  }

  applyAll(events: readonly GameEvent[]): void {
    for (const event of events) this.apply(event);
  }

  /**
   * So với trạng thái engine và SỬA mô hình cho khớp. Trả về mô tả từng chỗ lệch (rỗng = dòng sự kiện đã đủ).
   */
  reconcile(state: GameState): string[] {
    const problems: string[] = [];
    if (this.radius !== state.radius) {
      problems.push(`bán kính ${this.radius} ≠ ${state.radius}`);
      this.radius = state.radius;
    }
    const wanted = new Set<string>();
    for (const piece of state.pieces) {
      wanted.add(piece.id);
      const want = viewOf(piece);
      const have = this.byId.get(piece.id);
      if (have === undefined) {
        problems.push(`thiếu quân ${piece.id}`);
      } else {
        const diffs: string[] = [];
        if (have.type !== want.type) diffs.push(`type ${have.type}→${want.type}`);
        if (have.owner !== want.owner) diffs.push(`owner ${have.owner}→${want.owner}`);
        if (!sameCell(have.cell, want.cell)) diffs.push(`cell (${have.cell.q},${have.cell.r})→(${want.cell.q},${want.cell.r})`);
        if (have.status !== want.status) diffs.push(`status ${have.status}→${want.status}`);
        if (have.holder !== want.holder) diffs.push(`holder ${String(have.holder)}→${String(want.holder)}`);
        if (diffs.length > 0) problems.push(`quân ${piece.id}: ${diffs.join(', ')}`);
        if (diffs.length === 0) continue;
      }
      this.byId.set(piece.id, want);
    }
    for (const id of [...this.byId.keys()]) {
      if (!wanted.has(id)) {
        problems.push(`thừa quân ${id}`);
        this.byId.delete(id);
      }
    }
    return problems;
  }
}
