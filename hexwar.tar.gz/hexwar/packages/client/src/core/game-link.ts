// Nối một ván đang chạy ở nơi khác (Worker cục bộ ở M4, server ở M6) với bộ điều khiển trên máy này.
// Thuần logic, không DOM/THREE: nhận `HostEvent`, cập nhật `GameController` (bản sao trạng thái để tô ô, PLAN 6.1),
// gửi ý định đi, và tự lưu ván solo (X-10). Test chạy thẳng trong Node bằng `InProcessTransport`.
import type { RejectReason, SeatStatus, ServerMessage } from '@hexwar/protocol';
import { SEATS, newGame, defaultConfig, type ActionResult, type GameState, type Move, type Seat } from '@hexwar/rules';
import type { HostEvent } from '../net/host-protocol';
import type { SaveStore } from '../net/save-store';
import type { Transport } from '../net/transport';
import { GameController, type ControllerListener } from './controller';

export interface LinkListener {
  /** Trạng thái đầy đủ vừa tới (bắt đầu / tiếp tục / vào lại): dựng lại mô hình hiển thị, không có hoạt ảnh. */
  onSnapshot?(state: GameState): void;
  /** Một hành động đã được nơi chạy ván chấp nhận (của mình hoặc của bot/người khác). */
  onAction?(result: ActionResult): void;
  onRejected?(reason: RejectReason): void;
  onError?(code: string, message: string): void;
  /** Ghế / đồng hồ đổi (để HUD vẽ lại). */
  onStatus?(): void;
}

export interface LinkOptions {
  readonly transport: Transport;
  /** Có thì tự lưu (ván solo); không có thì không lưu (hotseat, xem lại). */
  readonly store?: SaveStore;
  readonly now?: () => number;
  readonly listener?: LinkListener;
  readonly controllerListener?: ControllerListener;
  /** X-14 (PLAN 11.2, tuỳ chọn), chốt tại lúc tạo ván — đổi cài đặt giữa ván không hồi tố, giống chọn độ khó bot. */
  readonly confirmMoves?: boolean;
}

export class GameLink {
  readonly controller: GameController;
  private seatsStatus: readonly SeatStatus[] = [];
  private mine: readonly Seat[] = [];
  private currentDeadline: number | null = null;
  private currentSeq = 0;
  private started = false;
  private readonly unsubscribe: () => void;

  constructor(private readonly options: LinkOptions) {
    // Trạng thái tạm cho tới khi snapshot đầu tiên về (bàn cờ đầu ván, dùng làm nền cho màn chờ).
    const placeholder = newGame(defaultConfig, SEATS, 0);
    this.controller = new GameController(
      placeholder,
      {
        ...options.controllerListener,
        onAction: (result) => {
          options.controllerListener?.onAction?.(result);
          options.listener?.onAction?.(result);
        },
      },
      { submit: (move) => this.submitMove(move), controls: (seat) => this.mine.includes(seat), confirmMoves: options.confirmMoves },
    );
    this.unsubscribe = options.transport.subscribe((event) => this.onHostEvent(event));
  }

  get state(): GameState {
    return this.controller.state;
  }
  get seats(): readonly SeatStatus[] {
    return this.seatsStatus;
  }
  /** Các ghế máy này điều khiển. */
  get you(): readonly Seat[] {
    return this.mine;
  }
  get deadline(): number | null {
    return this.currentDeadline;
  }
  get seq(): number {
    return this.currentSeq;
  }
  /** Đã nhận trạng thái đầu tiên từ nơi chạy ván chưa. */
  get ready(): boolean {
    return this.started;
  }

  /** Đang là lượt của một ghế máy này điều khiển (và không bị bot tạm lái, X-04)? */
  isMyTurn(): boolean {
    const seat = this.state.turnSeat;
    return this.state.phase === 'playing' && seat !== null && this.mine.includes(seat);
  }

  submitMove(move: Move): void {
    this.options.transport.send({ type: 'game.move', seq: this.currentSeq, move });
  }

  rollDice(): void {
    this.options.transport.send({ type: 'game.rollDice' });
  }

  resign(): void {
    this.options.transport.send({ type: 'game.resign' });
  }

  close(): void {
    this.unsubscribe();
    this.options.transport.close();
  }

  private onHostEvent(event: HostEvent): void {
    switch (event.kind) {
      case 'server':
        this.onServerMessage(event.message);
        return;
      case 'saved': {
        const store = this.options.store;
        if (store === undefined) return;
        // Ván đã kết thúc thì không còn gì để "tiếp tục": xoá bản lưu (tránh vào lại màn kết quả cũ).
        if (this.state.phase === 'over') store.clear();
        else store.write(event.save, { round: this.state.round, savedAt: (this.options.now ?? Date.now)() });
        return;
      }
      case 'error':
        this.options.listener?.onError?.(event.code, event.message);
        return;
    }
  }

  private onServerMessage(message: ServerMessage): void {
    switch (message.type) {
      case 'game.snapshot':
        this.started = true;
        this.currentSeq = message.seq;
        this.seatsStatus = message.seats;
        this.mine = message.you;
        this.currentDeadline = message.deadline;
        this.controller.reset(message.state);
        this.options.listener?.onSnapshot?.(message.state);
        this.options.listener?.onStatus?.();
        return;
      case 'game.events':
        this.currentSeq = message.seq;
        this.seatsStatus = message.seats;
        this.currentDeadline = message.deadline;
        this.controller.receive({ state: message.state, events: message.events });
        this.options.listener?.onStatus?.();
        return;
      case 'game.rejected':
        this.options.listener?.onRejected?.(message.reason);
        return;
    }
  }
}
