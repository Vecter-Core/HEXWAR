// M10 (PLAN 12.5): mức đồ hoạ Thấp/Vừa/Cao → cấu hình CỤ THỂ (bóng đổ, hậu kỳ, mật độ hạt, phản xạ ô). Tách THUẦN
// khỏi three.js/DOM để test bằng Node — `app/main.ts` đọc để dựng renderer/composer/đèn thật;
// `scene/board-scene.ts` chỉ nhận các con số đã tính sẵn qua `GraphicsProfile`, không tự biết "quality" là chuỗi
// gì (giữ ranh giới cũ: `scene/` không phụ thuộc `net/settings-store.ts`, xem docs/decisions.md mục M10).
import type { GraphicsQuality } from '../net/settings-store';

export interface GraphicsProfile {
  readonly quality: GraphicsQuality;
  /** PLAN 12.5: "Thấp: không bóng động" / "Vừa: bóng mềm cho quân" / "Cao: bóng đầy đủ". */
  readonly shadows: boolean;
  /** PLAN 12.5: "Thấp: không hậu kỳ" / "Vừa: bloom nhẹ" / "Cao: bloom". */
  readonly bloom: boolean;
  readonly bloomStrength: number;
  /** PLAN 12.5: SSAO chỉ ở Cao. */
  readonly ssao: boolean;
  /** PLAN 12.5: "Cao: ... phản xạ nhẹ cho ô". */
  readonly reflections: boolean;
  /** Hệ số nhân vào số hạt mặc định của `scene/effects-layer.ts` (PLAN 12.5 "ít hạt"/"hạt dày"). */
  readonly particleDensity: number;
}

const PROFILES: Readonly<Record<GraphicsQuality, GraphicsProfile>> = {
  low: { quality: 'low', shadows: false, bloom: false, bloomStrength: 0, ssao: false, reflections: false, particleDensity: 0.35 },
  medium: { quality: 'medium', shadows: true, bloom: true, bloomStrength: 0.35, ssao: false, reflections: false, particleDensity: 1 },
  high: { quality: 'high', shadows: true, bloom: true, bloomStrength: 0.55, ssao: true, reflections: true, particleDensity: 1.6 },
};

export function graphicsProfileFor(quality: GraphicsQuality): GraphicsProfile {
  return PROFILES[quality];
}
