// i18n tối thiểu (PLAN 11.7): mọi chữ hiển thị đi qua khoá, không chữ cứng trong code UI. Chỉ 2 ngôn ngữ: vi, en.
// Đọc trực tiếp assets/i18n/*.json (một nguồn, không lặp lại trong code) nhờ resolveJsonModule.
// Cùng lý do với packages/rules/src/config.ts: Node 22 ESM (Playwright chạy Node trực tiếp) đòi hỏi khai báo
// thuộc tính "type: json"; Vite/Vitest cũng hiểu cú pháp này nên dùng chung được cho cả hai đường chạy.
import en from '../../../../assets/i18n/en.json' with { type: 'json' };
import vi from '../../../../assets/i18n/vi.json' with { type: 'json' };

export type Locale = 'vi' | 'en';
export type MessageKey = keyof typeof vi;

const DICTS: Readonly<Record<Locale, Readonly<Record<string, string>>>> = { vi, en };

export const LOCALES: readonly Locale[] = ['vi', 'en'];

/** Thay `{{tên}}` bằng giá trị tương ứng trong `vars` (chuyển sang chuỗi). Biến thiếu giữ nguyên `{{tên}}`. */
function interpolate(template: string, vars?: Readonly<Record<string, string | number>>): string {
  if (vars === undefined) return template;
  return template.replace(/\{\{(\w+)\}\}/g, (whole, name: string) => (name in vars ? String(vars[name]) : whole));
}

/** Dịch `key` sang `locale`. Khoá không tồn tại trả về chính khoá (không bao giờ ném lỗi vì làm UI vỡ). */
export function translate(locale: Locale, key: string, vars?: Readonly<Record<string, string | number>>): string {
  const template = DICTS[locale][key];
  return template === undefined ? key : interpolate(template, vars);
}

/** Bộ dịch đóng khung theo một ngôn ngữ cố định, tiện truyền cho renderer/controller. */
export interface Translator {
  (key: MessageKey | string, vars?: Readonly<Record<string, string | number>>): string;
  readonly locale: Locale;
}

export function translatorFor(locale: Locale): Translator {
  const fn = ((key: MessageKey | string, vars?: Readonly<Record<string, string | number>>) => translate(locale, key, vars)) as Translator;
  return Object.assign(fn, { locale });
}

/** Mọi khoá của một ngôn ngữ (dùng để kiểm tra hai ngôn ngữ không lệch bộ khoá). */
export const keysOf = (locale: Locale): string[] => Object.keys(DICTS[locale]);
