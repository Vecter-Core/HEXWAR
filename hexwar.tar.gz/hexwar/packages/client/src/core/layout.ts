// Bố cục bàn cờ trong không gian 3D. Dùng lại đúng công thức của engine (hex.ts) để client không tự quyết hình học.
import { isOnBoard, pixelToCell, seatCorner, worldPos, type Cell, type Seat } from '@hexwar/rules';
import type { Vec3 } from './vec';

/** Cạnh ô lục giác = bán kính ngoại tiếp (đơn vị thế giới). */
export const CELL_SIZE = 1;
/** Ô vẽ nhỏ hơn ô lưới một chút để có khe hở. */
export const TILE_RADIUS_SCALE = 0.94;
/** Độ dày của ô. Mặt trên nằm ở y = 0, quân đứng trên y = 0. */
export const TILE_HEIGHT = 0.35;

/** Tâm mặt trên của ô. */
export function cellCenter(c: Cell): Vec3 {
  const p = worldPos(c, CELL_SIZE);
  return { x: p.x, y: 0, z: p.z };
}

/** Ô nằm dưới điểm (x, z) trên mặt bàn, hoặc null nếu ngoài bàn cờ hiện tại. O(1) (PLAN 6.6). */
export function cellAt(x: number, z: number, radius: number): Cell | null {
  const c = pixelToCell(x, z, CELL_SIZE);
  return isOnBoard(c, radius) ? c : null;
}

/**
 * Góc phương vị (rad) của ghế nhìn từ tâm bàn trong mặt phẳng x–z: hướng từ tâm tới ô góc của ghế.
 * Camera đặt ở phía này (nhìn về tâm) thì ghế đó nằm ở đáy màn hình và quân của họ tiến "lên trên" (PLAN 3.3).
 * Ghế 0 = 90° (z dương, đáy màn hình), mỗi ghế kế tiếp +60° (chiều kim đồng hồ trên màn hình).
 */
export function seatAzimuth(seat: Seat, seatCornerRing: number): number {
  const p = worldPos(seatCorner(seat, seatCornerRing), CELL_SIZE);
  return Math.atan2(p.z, p.x);
}

/** Nửa kích thước bàn theo bán kính lưới (dùng để giới hạn camera). */
export const boardExtent = (radius: number): number => radius * CELL_SIZE * Math.sqrt(3);

export const TAU = Math.PI * 2;

/** Đưa góc về (−π, π]. */
export function wrapAngle(a: number): number {
  let x = a % TAU;
  if (x <= -Math.PI) x += TAU;
  else if (x > Math.PI) x -= TAU;
  return x;
}
