// Bản đồ nhỏ (PLAN 11.2 "Dưới trái": "quân là chấm màu, vòng sắp biến mất nhấp nháy"). THUẦN — không canvas/DOM —
// `app/minimap.ts` chỉ vẽ lại kết quả của hàm này lên một <canvas>.
import { nextCollapse, type GameState } from '@hexwar/rules';
import { boardExtent, cellCenter } from './layout';
import { seatColor, toCss } from './palette';

export interface MinimapDot {
  /** Toạ độ chuẩn hoá trong [-1, 1] theo nửa kích thước bàn LÚC BẮT ĐẦU ván (không đổi khi bàn thu hẹp). */
  readonly x: number;
  readonly y: number;
  readonly color: string;
  readonly isKing: boolean;
}

export interface MinimapView {
  readonly dots: readonly MinimapDot[];
  /** Bán kính bàn HIỆN TẠI / bán kính lúc bắt đầu, trong (0, 1] — vẽ vòng biên đang co lại. */
  readonly boardFraction: number;
  /** Bán kính của vòng sắp biến mất / bán kính lúc bắt đầu; null nếu chưa tới ngưỡng cảnh báo hoặc lịch đã hết. */
  readonly warnFraction: number | null;
  readonly warnLevel: 'yellow' | 'red' | null;
}

/** `startRadius`: bán kính bàn cờ lúc ván bắt đầu (PLAN.md board.radius, cố định cho cả ván — thu hẹp chỉ giảm). */
export function buildMinimapView(state: GameState, startRadius: number): MinimapView {
  const extent = boardExtent(startRadius);
  const dots: MinimapDot[] = state.pieces
    .filter((p) => p.status === 'active')
    .map((p) => {
      const center = cellCenter(p.cell);
      return { x: center.x / extent, y: center.z / extent, color: toCss(seatColor(p.owner)), isKing: p.type === 'K' };
    });

  // Chỉ vẽ vòng cảnh báo khi ĐÃ vào ngưỡng (vàng/đỏ, R-71) — khớp cách board-mesh.ts và hud-model.ts quyết định
  // hiện cảnh báo, không phải mọi lúc có "lần thu hẹp kế tiếp" (luôn có, trừ khi lịch đã hết).
  const upcoming = state.phase === 'over' ? undefined : nextCollapse(state);
  const warned = upcoming !== undefined && upcoming.level !== null ? upcoming : undefined;
  return {
    dots,
    boardFraction: state.radius / startRadius,
    warnFraction: warned === undefined ? null : warned.event.ring / startRadius,
    warnLevel: warned?.level ?? null,
  };
}
