// Màu sắc. Sáu màu người chơi theo bảng Okabe–Ito thân thiện người mù màu (PLAN 12.3).
import type { Seat } from '@hexwar/rules';

/** Màu quân theo ghế 0…5: cam, xanh da trời, xanh lục, vàng, đỏ cam, tím hồng. */
export const SEAT_COLORS: readonly number[] = [0xe69f00, 0x56b4e9, 0x009e73, 0xf0e442, 0xd55e00, 0xcc79a7];

export const seatColor = (seat: Seat): number => SEAT_COLORS[seat] as number;

/** Ba tông ô theo (q − r) mod 3 (PLAN 12.2): tối, trung bình, sáng, cùng một sắc để không tranh màu quân. */
export const TILE_TONES: readonly number[] = [0x2c3a4f, 0x34455e, 0x3d5069];

/** Lớp phủ ô: đi được / ăn được / đang chọn / cảnh báo thu hẹp (PLAN 11.2). */
export const HIGHLIGHT = {
  move: 0x35e0a1,
  capture: 0xff4d4f,
  selected: 0xffd60a,
  conscript: 0x9ad0ff,
  warnYellow: 0xffd60a,
  warnRed: 0xff3030,
} as const;

/** Trộn hai màu số theo tỉ lệ t (0 = a, 1 = b). */
export function mixColor(a: number, b: number, t: number): number {
  const ch = (shift: number): number => {
    const ca = (a >> shift) & 0xff;
    const cb = (b >> shift) & 0xff;
    return Math.round(ca + (cb - ca) * t) & 0xff;
  };
  return (ch(16) << 16) | (ch(8) << 8) | ch(0);
}

/** Màu tù binh: màu chủ cũ nhạt dần về xanh lạnh (PLAN 12.3, "ánh xanh lạnh"). */
export const captiveColor = (owner: Seat): number => mixColor(seatColor(owner), 0x8fc7ff, 0.55);

/** Màu số (0xRRGGBB) sang chuỗi CSS `#rrggbb`, dùng cho DOM (bảng người chơi, bản đồ nhỏ). */
export const toCss = (color: number): string => `#${color.toString(16).padStart(6, '0')}`;
