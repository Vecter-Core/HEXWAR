// Chọn ô / quân bằng tia (thuần số). Không raycast từng ô: tia cắt mặt bàn rồi đổi sang (q, r) bằng công thức
// nghịch đảo (PLAN 6.6). Quân cao che mất ô phía sau nên thử cắt các trụ đứng của quân trước.
import type { Cell } from '@hexwar/rules';
import type { Ray } from './camera';
import { cellAt } from './layout';

/** Cắt mặt phẳng nằm ngang y = planeY. Trả về null nếu tia không đi xuống hoặc song song. */
export function intersectPlaneY(ray: Ray, planeY: number): { t: number; x: number; z: number } | null {
  if (ray.dir.y === 0) return null;
  const t = (planeY - ray.origin.y) / ray.dir.y;
  if (!(t > 0)) return null;
  return { t, x: ray.origin.x + ray.dir.x * t, z: ray.origin.z + ray.dir.z * t };
}

/**
 * Cắt hình trụ đứng (tâm (cx, cz), bán kính r, từ y0 tới y1, có nắp trên). Trả về t nhỏ nhất > 0 hoặc null.
 */
export function intersectVerticalCylinder(ray: Ray, cx: number, cz: number, r: number, y0: number, y1: number): number | null {
  const ox = ray.origin.x - cx;
  const oz = ray.origin.z - cz;
  const { x: dx, y: dy, z: dz } = ray.dir;
  let best: number | null = null;
  const consider = (t: number): void => {
    if (t > 0 && (best === null || t < best)) best = t;
  };

  const a = dx * dx + dz * dz;
  if (a > 1e-12) {
    const b = ox * dx + oz * dz;
    const c = ox * ox + oz * oz - r * r;
    const disc = b * b - a * c;
    if (disc >= 0) {
      const root = Math.sqrt(disc);
      for (const t of [(-b - root) / a, (-b + root) / a]) {
        const y = ray.origin.y + dy * t;
        if (y >= y0 && y <= y1) consider(t);
      }
    }
  }
  if (Math.abs(dy) > 1e-12) {
    const t = (y1 - ray.origin.y) / dy; // nắp trên
    const px = ox + dx * t;
    const pz = oz + dz * t;
    if (px * px + pz * pz <= r * r) consider(t);
  }
  return best;
}

export interface PickablePiece {
  readonly id: string;
  readonly cell: Cell;
  /** Tâm quân trong thế giới (đang hiển thị, có thể giữa hoạt ảnh). */
  readonly x: number;
  readonly z: number;
  readonly radius: number;
  readonly height: number;
}

export type CellPick = { readonly kind: 'piece'; readonly pieceId: string; readonly cell: Cell } | { readonly kind: 'cell'; readonly cell: Cell };

/**
 * Điểm được trỏ tới: quân đứng gần camera nhất mà tia chạm tới, nếu không thì ô ở mặt bàn. null nếu trỏ ra ngoài
 * bàn cờ (bán kính `radius` hiện tại).
 */
export function pickCell(ray: Ray, pieces: readonly PickablePiece[], radius: number): CellPick | null {
  const ground = intersectPlaneY(ray, 0);
  let bestPiece: { piece: PickablePiece; t: number } | null = null;
  for (const piece of pieces) {
    const t = intersectVerticalCylinder(ray, piece.x, piece.z, piece.radius, 0, piece.height);
    if (t !== null && (bestPiece === null || t < bestPiece.t)) bestPiece = { piece, t };
  }
  if (bestPiece !== null && (ground === null || bestPiece.t <= ground.t)) {
    return { kind: 'piece', pieceId: bestPiece.piece.id, cell: bestPiece.piece.cell };
  }
  if (ground === null) return null;
  const cell = cellAt(ground.x, ground.z, radius);
  return cell === null ? null : { kind: 'cell', cell };
}
