// Thông tin quân đang chọn (PLAN 11.2, "Dưới giữa"): loại, tầm đi, kills/ngưỡng phong cấp kế tiếp, trạng thái tù
// binh, có nước đang chờ xác nhận không (X-14). THUẦN — không DOM — `hud.ts` chỉ vẽ lại kết quả của hàm này.
import type { GameState, PieceType } from '@hexwar/rules';
import type { Selection } from './controller';
import type { Translator } from './i18n';

export interface SelectionView {
  readonly pieceLabel: string;
  readonly reachText: string;
  /** Không null khi đang trưng dụng tù binh (R-32). */
  readonly captiveText: string | null;
  /** Không null khi quân có nguồn gốc Tốt (chỉ nhóm này được phong cấp, R-41). */
  readonly killsText: string | null;
  readonly promotionText: string | null;
  /** 0..1, null nếu không áp dụng (quân không có nguồn gốc Tốt). */
  readonly promotionProgress: number | null;
  /** X-14: có nước đang chờ bấm lại/xác nhận không — HUD hiện nút Xác nhận/Hủy khi true. */
  readonly hasPending: boolean;
}

/** Bậc phong tiếp theo của một loại quân xuất thân Tốt (R-41: 6 → Mã, 10 → Tượng, 15 → Xe, 20 → Hậu). */
const PROMOTES_TO: Partial<Record<PieceType, 'N' | 'B' | 'R' | 'Q'>> = { P: 'N', N: 'B', B: 'R', R: 'Q' };

function reachText(type: PieceType, config: GameState['config'], t: Translator): string {
  switch (type) {
    case 'R':
    case 'B':
    case 'Q':
      return t('hud.selection.reach.slide', { n: config.reach[type] });
    case 'J':
      return t('hud.selection.reach.slide', { n: config.reach.J });
    case 'N':
      return t('hud.selection.reach.fixed');
    case 'K':
      return t('hud.selection.reach.step');
    case 'P':
      return t('hud.selection.reach.pawn');
  }
}

/** null nếu quân đang chọn không còn trên bàn (không nên xảy ra: selection luôn đi kèm state khớp, nhưng an toàn). */
export function buildSelectionView(state: GameState, selection: Selection, t: Translator): SelectionView | null {
  const piece = state.pieces.find((p) => p.id === selection.pieceId);
  if (piece === undefined) return null;

  let killsText: string | null = null;
  let promotionText: string | null = null;
  let promotionProgress: number | null = null;
  if (piece.origin === 'P') {
    killsText = t('hud.selection.kills', { kills: piece.kills });
    const next = PROMOTES_TO[piece.type];
    if (next === undefined) {
      promotionText = t('hud.selection.maxed');
      promotionProgress = 1;
    } else {
      const threshold = state.config.promotion[next];
      promotionProgress = threshold > 0 ? Math.min(1, piece.kills / threshold) : 1;
      promotionText = t('hud.selection.promotion', { left: Math.max(0, threshold - piece.kills), to: t(`piece.${next}`) });
    }
  }

  return {
    pieceLabel: t(`piece.${piece.type}`),
    reachText: reachText(piece.type, state.config, t),
    captiveText: selection.conscript ? t('hud.selection.conscript') : null,
    killsText,
    promotionText,
    promotionProgress,
    hasPending: selection.pendingMove !== undefined,
  };
}
