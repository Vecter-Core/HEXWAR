// X-06 (PLAN mục 5, 11.2 "cảnh báo đe doạ"): quân nào của người TỚI LƯỢT đang đứng vào ô mà đối thủ có thể ăn
// ngay nước kế tiếp, nếu không dịch chuyển hoặc bảo vệ. Dùng lại đúng bản đồ đe doạ của bot (`attackersInState`,
// PLAN 9.2 "an toàn Vua") — client không tự chép lại luật ăn quân (PLAN 6.1 nguyên tắc 1: một engine dùng chung).
// THUẦN — không DOM — chỉ đọc `GameState`; `board-scene.ts`/`threat-mesh.ts` mới vẽ lại kết quả này.
import { attackersInState } from '@hexwar/bot';
import { cellKey, type GameState, type Seat } from '@hexwar/rules';

export interface ThreatInfo {
  /** Khoá ô (`cellKey`) của mọi quân đang bị đe doạ của `seat`. */
  readonly cellKeys: ReadonlySet<number>;
  /** Vua của `seat` nằm trong số đó — HUD dùng để báo riêng một lần (PLAN 11.2 "Vua đang bị ăn được"). */
  readonly kingThreatened: boolean;
}

export const NO_THREATS: ThreatInfo = { cellKeys: new Set(), kingThreatened: false };

// Bộ nhớ đệm 1 phần tử: state là object bất biến (mỗi hành động tạo state MỚI), nên chỉ cần so sánh tham chiếu để
// tránh tính lại nhiều lần trong cùng một khung hình / giữa các khung hình khi chưa có gì đổi (PLAN 6.6 hiệu năng).
let cache: { state: GameState; seat: Seat | null; info: ThreatInfo } | null = null;

/** Đe doạ đang treo lên quân của `seat` (null = không tính, ví dụ đang tắt X-06 hoặc không phải lượt của "mình"). */
export function threatsFor(state: GameState, seat: Seat | null): ThreatInfo {
  if (seat === null) return NO_THREATS;
  if (cache !== null && cache.state === state && cache.seat === seat) return cache.info;

  const cellKeys = new Set<number>();
  let kingThreatened = false;
  for (const piece of state.pieces) {
    if (piece.status !== 'active' || piece.owner !== seat) continue;
    if (attackersInState(state, piece.cell, seat).length === 0) continue;
    cellKeys.add(cellKey(piece.cell));
    if (piece.type === 'K') kingThreatened = true;
  }

  const info: ThreatInfo = { cellKeys, kingThreatened };
  cache = { state, seat, info };
  return info;
}
