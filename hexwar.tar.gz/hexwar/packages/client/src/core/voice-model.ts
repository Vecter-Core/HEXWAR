// Phần THUẦN của voice (PLAN 8.5): ai nên kết nối với ai, ai "nhường" khi cả hai cùng gửi offer một lúc (glare),
// và ngưỡng đơn giản để coi là "đang nói". Tách khỏi RTCPeerConnection/getUserMedia thật (net/voice-manager.ts) để
// test được mà không cần trình duyệt thật — giống chat-model.ts/hud-model.ts.
import type { Seat } from '@hexwar/rules';

/** Trạng thái voice CỦA MỘT NGƯỜI mà việc kết nối phụ thuộc vào (PLAN 8.5: hai công tắc Mic/Nghe độc lập). */
export interface VoicePresence {
  readonly mic: boolean;
  readonly listen: boolean;
}

export const VOICE_OFF: VoicePresence = { mic: false, listen: false };

/** Trong một cặp (mySeat, otherSeat), ai "nhường" khi cả hai cùng gửi offer một lúc (glare) — mẫu "perfect
 * negotiation" chuẩn của WebRTC (MDN) cần một quy ước NHẤT QUÁN, suy được ở cả hai phía mà không cần trao đổi gì
 * thêm: ghế số LỚN HƠN luôn là bên nhường ("polite"). Đối xứng tự nhiên: A thấy mình impolite với B khi A<B, và B
 * thấy mình polite với A vì B>A — không bao giờ cả hai cùng nghĩ mình impolite (hoặc cùng polite). */
export function isPolite(mySeat: Seat, otherSeat: Seat): boolean {
  return mySeat > otherSeat;
}

/** Chỉ đáng giữ một kết nối khi có ít nhất một CHIỀU âm thanh thật sự chảy được (PLAN 8.5 "chỉ tạo kết nối khi
 * người đó bật voice"): tôi nói và họ nghe, hoặc họ nói và tôi nghe. Cả hai cùng tắt Mic lẫn Nghe thì không có gì
 * để truyền — không cần kết nối, kể cả khi cả hai vẫn "muốn" voice nói chung. */
export function shouldConnect(mine: VoicePresence, other: VoicePresence): boolean {
  return (mine.mic && other.listen) || (other.mic && mine.listen);
}

/** Tập ghế (loại trừ ghế mình, bot, người đã chặn) mà mình NÊN đang giữ kết nối voice, dựa trên trạng thái
 * mic/nghe mới nhất mà mình biết được của từng người (từ tín hiệu "presence", xem net/voice-manager.ts). Ghế nào
 * chưa từng gửi presence coi như đang tắt cả hai (VOICE_OFF) — chưa biết thì coi là chưa cần kết nối, an toàn hơn
 * là đoán bừa. */
export function wantedPeers(
  mySeat: Seat,
  mine: VoicePresence,
  humanSeats: readonly Seat[],
  blockedSeats: ReadonlySet<Seat>,
  presenceOf: (seat: Seat) => VoicePresence,
): Seat[] {
  return humanSeats.filter((seat) => seat !== mySeat && !blockedSeats.has(seat) && shouldConnect(mine, presenceOf(seat)));
}

/** Ngưỡng đơn giản để hiện biểu tượng "đang nói" (PLAN 8.5) từ mức âm lượng đo được (RMS chuẩn hoá 0..1 của
 * `AnalyserNode`, xem net/voice-manager.ts). Ngưỡng thấp vì `getUserMedia` đã bật sẵn khử ồn/tự chỉnh âm lượng. */
export function isSpeaking(level: number, threshold = 0.04): boolean {
  return level >= threshold;
}

/** Dữ liệu đi trong `voice.signal` (server chỉ RELAY nguyên văn, xem packages/protocol/src/chat.ts) — bản thân
 * SDP/ICE là kiểu dữ liệu chuẩn của WebRTC (không phải đối tượng runtime cần DOM thật) nên khai báo được ở đây. */
export type VoiceSignalData =
  | ({ readonly kind: 'presence' } & VoicePresence)
  | { readonly kind: 'offer'; readonly sdp: RTCSessionDescriptionInit }
  | { readonly kind: 'answer'; readonly sdp: RTCSessionDescriptionInit }
  | { readonly kind: 'candidate'; readonly candidate: RTCIceCandidateInit };

/** `voice.signal`→`data` là `unknown` (server không hiểu nội dung) — kiểm tra hình dạng trước khi tin, giống mọi
 * message khác đi qua mạng. Không dùng Zod ở đây (client, không phải packages/protocol) vì hình dạng đơn giản và
 * sai định dạng ở phía TRÌNH DUYỆT NGƯỜI CHƠI KHÁC không phải điều cần báo lỗi chi tiết cho ai — bỏ qua an toàn. */
export function isVoiceSignalData(value: unknown): value is VoiceSignalData {
  if (typeof value !== 'object' || value === null) return false;
  const kind = (value as { kind?: unknown }).kind;
  return kind === 'presence' || kind === 'offer' || kind === 'answer' || kind === 'candidate';
}
