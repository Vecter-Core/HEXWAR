// @hexwar/client — Renderer 3D, UI, mạng, âm thanh, i18n (M3, M5).
// Khung rỗng của M0; code thật được thêm theo milestone (PLAN.md mục 15).
export {};
