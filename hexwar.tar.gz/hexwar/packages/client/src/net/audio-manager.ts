// M10 (PLAN 12.6): tổng hợp mọi hiệu ứng/nhạc nền bằng Web Audio API — KHÔNG file âm thanh ngoài (chưa có tài
// nguyên rõ giấy phép trong repo, CLAUDE.md; xem `docs/credits.md` cho ghi chú "placeholder do mã tạo ra, cần thay
// trước khi phát hành"). Lớp MỎNG: chỉ chạm `AudioContext`/`OscillatorNode` thật ở đây; bảng tần số/thời lượng
// THUẦN nằm ở `core/audio-cues.ts` (test được không cần dựng `AudioContext`) — cùng ranh giới core/net đã dùng cho
// `core/voice-model.ts` (quyết định thuần) / `net/voice-manager.ts` (WebRTC thật).
//
// Tự bảo vệ theo đúng khuôn `voice-manager.ts` (getUserMedia thất bại → im lặng, không vỡ UI): chính sách autoplay
// của trình duyệt chặn âm thanh tới khi có cử chỉ người dùng thật (`unlock()`), và một số môi trường (Playwright
// headless, iframe hạn chế) có thể không có `AudioContext` — mọi lỗi ở đây bị nuốt, ván vẫn chơi được bình thường.
import type { GameEvent } from '@hexwar/rules';
import { AMBIENCE, SFX_CUES, sfxForEvent, type AmbiencePhase, type Cue, type SfxId } from '../core/audio-cues';

/** `window.AudioContext` có thể vắng mặt (SSR/test) hoặc bị tiền tố `webkit` ở trình duyệt cũ. */
function getAudioContextCtor(): (new () => AudioContext) | null {
  const w = window as unknown as { AudioContext?: new () => AudioContext; webkitAudioContext?: new () => AudioContext };
  return w.AudioContext ?? w.webkitAudioContext ?? null;
}

export class AudioManager {
  private ctx: AudioContext | null = null;
  private master: GainNode | null = null;
  private musicBus: GainNode | null = null;
  private sfxBus: GainNode | null = null;
  private noiseBuffer: AudioBuffer | null = null;

  private ambienceOsc: OscillatorNode | null = null;
  private ambienceGain: GainNode | null = null;
  private ambienceLfo: OscillatorNode | null = null;
  private ambiencePhase: AmbiencePhase = 'normal';

  private volumeMaster = 1;
  private volumeMusic = 1;
  private volumeSfx = 1;

  /** Gọi từ CỬ CHỈ NGƯỜI DÙNG THẬT đầu tiên (bấm menu, chọn quân…) — chính sách autoplay chặn âm thanh tới lúc đó
   * (docs/questions.md). An toàn gọi nhiều lần; không ném lỗi nếu thiếu `AudioContext` hoặc bị chặn. */
  unlock(): void {
    try {
      if (this.ctx === null) {
        const Ctor = getAudioContextCtor();
        if (Ctor === null) return;
        const ctx = new Ctor();
        this.ctx = ctx;
        this.master = ctx.createGain();
        this.musicBus = ctx.createGain();
        this.sfxBus = ctx.createGain();
        this.musicBus.connect(this.master);
        this.sfxBus.connect(this.master);
        this.master.connect(ctx.destination);
        this.applyVolumes();
      }
      if (this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    } catch {
      // Một số môi trường (Playwright headless, iframe hạn chế) không cho tạo AudioContext — im lặng bỏ qua.
    }
  }

  /** PLAN 11.5 "Âm thanh: Tổng, nhạc, hiệu ứng" — mỗi tham số 0..1, nhân dồn (nhạc/hiệu ứng nhân thêm với Tổng qua
   * đồ thị nút `master → musicBus/sfxBus`, không cần tự nhân tay ở đây). */
  setVolumes(master: number, music: number, sfx: number): void {
    this.volumeMaster = master;
    this.volumeMusic = music;
    this.volumeSfx = sfx;
    this.applyVolumes();
  }

  private applyVolumes(): void {
    if (this.ctx === null || this.master === null || this.musicBus === null || this.sfxBus === null) return;
    const now = this.ctx.currentTime;
    this.master.gain.setTargetAtTime(this.volumeMaster, now, 0.05);
    this.musicBus.gain.setTargetAtTime(this.volumeMusic, now, 0.05);
    this.sfxBus.gain.setTargetAtTime(this.volumeSfx, now, 0.05);
  }

  /** Sự kiện engine → hiệu ứng đúng bảng `sfxForEvent` (PLAN 12.6). Gọi ở CHỖ `AnimationDirector`'s `onStart` đã
   * có sẵn (main.ts) — cùng nơi `hud.announceEvent` đọc dòng sự kiện, không nghe sự kiện engine ở nơi thứ hai. */
  onEvent(event: GameEvent): void {
    const id = sfxForEvent(event);
    if (id !== null) this.play(id);
  }

  play(id: SfxId): void {
    if (this.ctx === null || this.sfxBus === null) return;
    for (const cue of SFX_CUES[id]) this.playCue(cue, this.sfxBus);
  }

  private playCue(cue: Cue, destination: GainNode): void {
    const ctx = this.ctx;
    if (ctx === null) return;
    const start = ctx.currentTime + cue.delay;
    const end = start + cue.duration;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0, start);
    gain.gain.linearRampToValueAtTime(cue.gain, start + Math.min(0.01, cue.duration / 4));
    gain.gain.linearRampToValueAtTime(0, end);
    gain.connect(destination);

    if (cue.kind === 'tone') {
      const osc = ctx.createOscillator();
      osc.type = cue.type;
      osc.frequency.setValueAtTime(cue.freq, start);
      if (cue.slideTo !== undefined) osc.frequency.linearRampToValueAtTime(cue.slideTo, end);
      osc.connect(gain);
      osc.start(start);
      osc.stop(end + 0.02);
    } else {
      const source = ctx.createBufferSource();
      source.buffer = this.getNoiseBuffer();
      source.loop = true;
      const filter = ctx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(cue.filterHz, start);
      source.connect(filter);
      filter.connect(gain);
      source.start(start);
      source.stop(end + 0.02);
    }
  }

  /** Nhiễu trắng dựng MỘT LẦN, dùng lại cho mọi tiếng động (va chạm, thu hẹp). Tất định (không `Math.random`) —
   * không quan trọng với một placeholder tổng hợp, nhưng giữ nhất quán với quy ước "không nguồn ngẫu nhiên không
   * seed" đã áp cho các lớp khác của client (docs/decisions.md mục M10). */
  private getNoiseBuffer(): AudioBuffer {
    const ctx = this.ctx as AudioContext;
    if (this.noiseBuffer !== null) return this.noiseBuffer;
    const length = ctx.sampleRate; // 1 giây, đủ ngắn cho mọi hiệu ứng va chạm/thu hẹp (loop=true nếu cần dài hơn)
    const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    let s = 1;
    for (let i = 0; i < length; i++) {
      s = (s * 1103515245 + 12345) & 0x7fffffff;
      data[i] = (s / 0x7fffffff) * 2 - 1;
    }
    this.noiseBuffer = buffer;
    return buffer;
  }

  /** PLAN 12.6 "nhạc nền theo pha": đổi mượt sang `phase` mới bằng cách TRƯỢT tần số/âm lượng của MỘT oscillator
   * đang chạy (không dựng lại, tránh tiếng "cách" khi chuyển pha). Bắt đầu vòng lặp nếu chưa có (thường ngay sau
   * `unlock()`, khi `main.ts` biết ván vừa vào pha nào — bình thường/căng thẳng/kết thúc). */
  setAmbiencePhase(phase: AmbiencePhase): void {
    this.ambiencePhase = phase;
    if (this.ctx === null || this.musicBus === null) return;
    if (this.ambienceOsc === null) this.startAmbience();
    const spec = AMBIENCE[phase];
    const now = this.ctx.currentTime;
    this.ambienceOsc?.frequency.setTargetAtTime(spec.freq, now, 1.2);
    this.ambienceLfo?.frequency.setTargetAtTime(spec.beatHz, now, 1.2);
    this.ambienceGain?.gain.setTargetAtTime(spec.gain, now, 1.2);
  }

  private startAmbience(): void {
    const ctx = this.ctx;
    if (ctx === null || this.musicBus === null) return;
    const spec = AMBIENCE[this.ambiencePhase];
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.value = spec.freq;
    const gain = ctx.createGain();
    gain.gain.value = spec.gain;
    // LFO điều biến âm lượng (tremolo nhẹ) — cùng một kỹ thuật chuẩn của Web Audio để tạo cảm giác "sống" cho một
    // đệm nền chỉ từ MỘT oscillator, không cần nạp mẫu âm nhạc thật.
    const lfo = ctx.createOscillator();
    lfo.frequency.value = spec.beatHz;
    const lfoGain = ctx.createGain();
    lfoGain.gain.value = spec.gain * 0.6;
    lfo.connect(lfoGain);
    lfoGain.connect(gain.gain);
    osc.connect(gain);
    gain.connect(this.musicBus);
    osc.start();
    lfo.start();
    this.ambienceOsc = osc;
    this.ambienceGain = gain;
    this.ambienceLfo = lfo;
  }

  /** Dừng hẳn nhạc nền (về menu, thoát ván) — đổi pha TRONG một ván thì dùng `setAmbiencePhase`, không cần dừng. */
  stopAmbience(): void {
    try {
      this.ambienceOsc?.stop();
      this.ambienceLfo?.stop();
    } catch {
      // đã dừng rồi (gọi hai lần) — bỏ qua, giống khuôn `dispose()` của voice-manager.ts
    }
    this.ambienceOsc = null;
    this.ambienceGain = null;
    this.ambienceLfo = null;
  }

  dispose(): void {
    this.stopAmbience();
    try {
      void this.ctx?.close();
    } catch {
      // đóng hai lần / đã đóng — bỏ qua
    }
    this.ctx = null;
  }
}
