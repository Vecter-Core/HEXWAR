// Lệnh/sự kiện giữa luồng chính và nơi chạy ván cục bộ (Worker). CHỈ kiểu: luồng chính import file này mà không
// kéo theo bot/GameSession vào bundle chính (chúng chỉ nằm trong bundle của Worker).
import type { ClientMessage, SaveError, SavedGame, SeatSetup, ServerMessage, SessionTiming } from '@hexwar/protocol';

/** Luồng chính → nơi chạy ván. */
export type HostCommand =
  | { readonly kind: 'start'; readonly seed: number; readonly seats: readonly SeatSetup[]; readonly timing?: Partial<SessionTiming> }
  | { readonly kind: 'resume'; readonly save: unknown; readonly timing?: Partial<SessionTiming> }
  | { readonly kind: 'client'; readonly message: ClientMessage }
  | { readonly kind: 'stop' };

/** Nơi chạy ván → luồng chính. */
export type HostEvent =
  | { readonly kind: 'server'; readonly message: ServerMessage }
  | { readonly kind: 'saved'; readonly save: SavedGame }
  | { readonly kind: 'error'; readonly code: SaveError['code'] | 'NO_GAME' | 'INTERNAL'; readonly message: string };
