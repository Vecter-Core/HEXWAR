// Transport chạy nơi chạy ván ngay trong luồng hiện tại — cho test Node (không có Web Worker). Không dùng trong bản
// chơi thật (main.ts dùng WorkerTransport), nên bot/GameSession không bị kéo vào bundle chính.
import { LocalHost, realClock } from './local-host';
import type { HostCommand } from './host-protocol';
import { LocalTransportBase } from './transport';

/**
 * Ván chạy ngay trong luồng hiện tại (test Node, hoặc môi trường không có Worker). Mô phỏng tính bất đồng bộ của
 * `postMessage` bằng microtask và sao chép dữ liệu qua `structuredClone` để hành vi giống hệt Worker thật.
 */
export class InProcessTransport extends LocalTransportBase {
  private readonly host: LocalHost;

  constructor(clock = realClock) {
    super();
    this.host = new LocalHost(clock, (event) => {
      const copy = structuredClone(event);
      queueMicrotask(() => this.deliver(copy));
    });
  }

  protected post(command: HostCommand): void {
    const copy = structuredClone(command);
    queueMicrotask(() => this.host.receive(copy));
  }
}
