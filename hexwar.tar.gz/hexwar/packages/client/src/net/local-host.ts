// Nơi chạy ván CỤC BỘ cho chế độ solo (PLAN 6.1 nguyên tắc 3, 7.2 "Solo: 1 người + 5 bot chạy cục bộ"). Chạy trong
// Web Worker (local-worker.ts) để bot nghĩ không làm giật UI (PLAN 9.1); cùng lớp này cũng chạy thẳng trong luồng
// chính/Node cho test (InProcessTransport). Chỉ là lớp vỏ quanh `GameSession` dùng chung với server (M6).
import { botRngFor, chooseMove } from '@hexwar/bot';
import {
  GameSession,
  SaveError,
  loadSave,
  type BotBrain,
  type Clock,
  type SavedGame,
  type ServerMessage,
  type SessionTiming,
} from '@hexwar/protocol';
import { defaultConfig } from '@hexwar/rules';
import type { HostCommand, HostEvent } from './host-protocol';

export type { HostCommand, HostEvent } from './host-protocol';

export const botBrain: BotBrain = {
  decide: (state, seat, difficulty, actionIndex, personality) =>
    chooseMove(state, seat, difficulty, botRngFor(state, seat, actionIndex), personality)?.move ?? null,
};

/** Đồng hồ thật của trình duyệt/Worker. (Đồng hồ hệ thống chỉ được dùng ở tầng này, không bao giờ trong engine.) */
export const realClock: Clock = {
  now: () => Date.now(),
  setTimer: (ms, fn) => ({ id: setTimeout(fn, ms) as unknown as number }),
  clearTimer: (handle) => clearTimeout(handle.id),
};

export class LocalHost {
  private session: GameSession | null = null;

  constructor(
    private readonly clock: Clock,
    private readonly emit: (event: HostEvent) => void,
  ) {}

  receive(command: HostCommand): void {
    try {
      this.dispatch(command);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.emit({ kind: 'error', code: error instanceof SaveError ? error.code : 'INTERNAL', message });
    }
  }

  private dispatch(command: HostCommand): void {
    switch (command.kind) {
      case 'start':
        this.replace(
          GameSession.create({ config: defaultConfig, seed: command.seed, seats: command.seats }, this.options(command.timing)),
        );
        return;
      case 'resume': {
        const { save, state } = loadSave(command.save, defaultConfig.rulesVersion);
        this.replace(GameSession.resume(save, state, this.options(command.timing)));
        return;
      }
      case 'client':
        if (this.session === null) {
          this.emit({ kind: 'error', code: 'NO_GAME', message: 'chưa có ván nào đang chạy' });
          return;
        }
        this.session.handle(this.session.humanSeats(), command.message);
        return;
      case 'stop':
        this.session?.dispose();
        this.session = null;
        return;
    }
  }

  private replace(next: GameSession): void {
    this.session?.dispose();
    this.session = next;
    next.start();
  }

  private options(timing: Partial<SessionTiming> | undefined) {
    return {
      clock: this.clock,
      bot: botBrain,
      ...(timing !== undefined ? { timing } : {}),
      broadcast: (message: ServerMessage) => this.emit({ kind: 'server', message }),
      onAutosave: (save: SavedGame) => this.emit({ kind: 'saved', save }),
    };
  }
}

