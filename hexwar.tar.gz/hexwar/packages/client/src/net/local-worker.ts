// Điểm vào Web Worker của ván solo (PLAN 9.1: bot chạy trong Worker để không giật UI). Chỉ nối `postMessage` với
// `LocalHost`; mọi logic nằm ở local-host.ts (có test chạy thẳng trong Node).
import { LocalHost, realClock, type HostCommand, type HostEvent } from './local-host';

const scope = globalThis as unknown as {
  postMessage(message: HostEvent): void;
  onmessage: ((event: MessageEvent<HostCommand>) => void) | null;
};

const host = new LocalHost(realClock, (event) => scope.postMessage(event));
scope.onmessage = (event) => host.receive(event.data);
