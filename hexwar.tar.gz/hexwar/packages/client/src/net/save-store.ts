// Nơi cất ván solo đang chơi (X-10: "tự lưu mỗi lượt"). Bản trình duyệt/Electron dùng localStorage; M11 thêm Steam
// Cloud (PLAN 13.2) phía sau cùng giao diện này. Nội dung đọc ra là dữ liệu KHÔNG tin cậy: nơi chạy ván luôn kiểm
// lại bằng `loadSave` (schema + chơi lại + so hash) trước khi dùng.
import type { SavedGame } from '@hexwar/protocol';

/** Thông tin hiển thị kèm ván lưu (màn bắt đầu: "Tiếp tục — hiệp 42"). Chỉ để hiển thị, không dùng cho luật. */
export interface SaveMeta {
  readonly round: number;
  readonly savedAt: number;
}

export interface StoredGame {
  /** Dữ liệu thô, chưa kiểm — phải qua `loadSave` ở nơi chạy ván. */
  readonly save: unknown;
  readonly meta: SaveMeta | null;
}

export interface SaveStore {
  load(): StoredGame | null;
  write(save: SavedGame, meta: SaveMeta): void;
  clear(): void;
}

export const SAVE_KEY = 'hexwar.solo.v1';

export class LocalStorageSaveStore implements SaveStore {
  constructor(
    private readonly storage: Pick<Storage, 'getItem' | 'setItem' | 'removeItem'> | null = typeof localStorage === 'undefined' ? null : localStorage,
    private readonly key = SAVE_KEY,
  ) {}

  load(): StoredGame | null {
    try {
      const raw = this.storage?.getItem(this.key);
      if (raw === null || raw === undefined) return null;
      const parsed = JSON.parse(raw) as { save?: unknown; meta?: unknown };
      if (typeof parsed !== 'object' || parsed === null || parsed.save === undefined) return null;
      return { save: parsed.save, meta: readMeta(parsed.meta) };
    } catch {
      return null; // chế độ riêng tư / dữ liệu hỏng: coi như chưa có ván lưu
    }
  }

  write(save: SavedGame, meta: SaveMeta): void {
    try {
      this.storage?.setItem(this.key, JSON.stringify({ save, meta }));
    } catch {
      // Hết dung lượng hoặc bị chặn: ván vẫn chơi tiếp, chỉ mất khả năng tiếp tục (không làm vỡ UI).
    }
  }

  clear(): void {
    try {
      this.storage?.removeItem(this.key);
    } catch {
      // bỏ qua
    }
  }
}

function readMeta(raw: unknown): SaveMeta | null {
  if (typeof raw !== 'object' || raw === null) return null;
  const { round, savedAt } = raw as { round?: unknown; savedAt?: unknown };
  return typeof round === 'number' && typeof savedAt === 'number' ? { round, savedAt } : null;
}

/** Bộ nhớ trong RAM cho test. */
export class MemorySaveStore implements SaveStore {
  value: StoredGame | null = null;
  load(): StoredGame | null {
    return this.value === null ? null : (JSON.parse(JSON.stringify(this.value)) as StoredGame);
  }
  write(save: SavedGame, meta: SaveMeta): void {
    this.value = JSON.parse(JSON.stringify({ save, meta })) as StoredGame;
  }
  clear(): void {
    this.value = null;
  }
}
