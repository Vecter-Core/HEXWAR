// Bố trí 6 ghế cho các chế độ chơi cục bộ (R-01: đúng 6 ghế; người + bot đủ 6).
import type { Difficulty, Personality, SeatSetup } from '@hexwar/protocol';
import type { Seat } from '@hexwar/rules';

const MIXED_ROTATION: readonly Difficulty[] = ['easy', 'normal', 'hard']; // PLAN 9.3, M9: 'mixed' nay xoay cả Khó.

/**
 * Bố trí ghế cho ván solo: người chơi ở một ghế (R-01: ghế gán ngẫu nhiên — ở đây theo seed), 5 ghế còn lại là bot.
 * `personality` (PLAN 9.4, M9): áp dụng cho MỌI ghế bot của ván solo; bỏ trống = 'balanced' (hành vi mặc định).
 */
export function soloSeats(seed: number, difficulty: Difficulty | 'mixed', personality?: Personality): SeatSetup[] {
  const human = (seed % 6) as Seat;
  return ([0, 1, 2, 3, 4, 5] as const).map((seat, i) => {
    if (seat === human) return { seat, kind: 'human' };
    const level = difficulty === 'mixed' ? (MIXED_ROTATION[i % MIXED_ROTATION.length] as Difficulty) : difficulty;
    return { seat, kind: 'bot', difficulty: level, ...(personality !== undefined ? { personality } : {}) };
  });
}

/** Hotseat: 6 người trên một máy (chế độ của M3, giờ cũng đi qua GameSession). */
export function hotseatSeats(): SeatSetup[] {
  return ([0, 1, 2, 3, 4, 5] as const).map((seat) => ({ seat, kind: 'human' }));
}
