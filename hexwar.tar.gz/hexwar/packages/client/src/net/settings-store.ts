// Cài đặt (PLAN 11.5). Lưu cục bộ, áp dụng ngay khi đổi (không cần khởi động lại), trừ ngôn ngữ (đổi `<html lang>`
// và chữ hiển thị cần dựng lại toàn bộ UI — đơn giản hơn và không kém tin cậy so với làm mọi thứ phản ứng theo
// locale: tải lại trang, xem app/settings-panel.ts). Cùng khuôn mẫu với net/save-store.ts (interface + LocalStorage +
// Memory cho test).
import type { Locale } from '../core/i18n';

export type GraphicsQuality = 'low' | 'medium' | 'high';

export interface Settings {
  readonly locale: Locale;
  readonly graphics: GraphicsQuality;
  /** PLAN 12.4: "tuỳ chọn giảm chuyển động và bỏ qua hoạt ảnh (tăng tốc gấp đôi) cho ván dài". */
  readonly reduceMotion: boolean;
  /** X-06, mặc định bật ở tân thủ/chơi thường (PLAN mục 9.1 dùng "tân thủ" cho bot; ở đây là người chơi). */
  readonly threatWarnings: boolean;
  /** X-14, mặc định tắt (PLAN: "tuỳ chọn"). */
  readonly confirmMoves: boolean;
  /** PLAN 11.5 "Voice: ... 'chỉ qua TURN' (ẩn IP)" — mặc định tắt (PLAN 8.5: mọi thứ voice mặc định tắt). */
  readonly voiceTurnOnly: boolean;
  /** PLAN 11.5 "chọn micro" — id thiết bị đã chọn lần trước (`MediaDeviceInfo.deviceId`); null = thiết bị mặc định
   * của hệ thống. Không lưu thiết bị LOA: phát lại chỉ qua thẻ `<audio>` mặc định, chọn loa ra (`setSinkId`) chưa
   * được trình duyệt nào hỗ trợ đủ rộng để đáng làm ở M7 (xem docs/questions.md). */
  readonly voiceMicDeviceId: string | null;
  /** PLAN 11.5 "Âm thanh: Tổng, nhạc, hiệu ứng, voice" (M10: ba mục đầu — "voice" đã có công tắc mic/nghe riêng ở
   * `VoiceBar` từ M7, không phải một thanh trượt âm lượng). Cùng đơn vị 0..1 — `AudioManager.setVolumes` nhân
   * thẳng vào `GainNode.gain`, không cần đổi đơn vị ở lớp giữa. */
  readonly volumeMaster: number;
  readonly volumeMusic: number;
  readonly volumeSfx: number;
}

export const DEFAULT_SETTINGS: Settings = {
  locale: 'vi',
  graphics: 'medium',
  reduceMotion: false,
  threatWarnings: true,
  confirmMoves: false,
  voiceTurnOnly: false,
  voiceMicDeviceId: null,
  volumeMaster: 0.8,
  volumeMusic: 0.6,
  volumeSfx: 0.8,
};

export interface SettingsStore {
  load(): Settings;
  save(settings: Settings): void;
}

const KEY = 'hexwar.settings.v1';

function isLocale(v: unknown): v is Locale {
  return v === 'vi' || v === 'en';
}
function isGraphics(v: unknown): v is GraphicsQuality {
  return v === 'low' || v === 'medium' || v === 'high';
}
function isMicDeviceId(v: unknown): v is string | null {
  return v === null || typeof v === 'string';
}
/** Kẹp về [0, 1] thay vì loại bỏ toàn bộ — dữ liệu cũ/hỏng nhẹ (ví dụ số âm do lỗi UI trước đây) vẫn dùng được. */
function clampVolume(v: unknown, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? Math.min(1, Math.max(0, v)) : fallback;
}

/** Đọc một đối tượng thô (ví dụ từ JSON.parse) và trả về Settings hợp lệ, dùng mặc định cho phần thiếu/hỏng. */
function sanitize(raw: unknown): Settings {
  if (typeof raw !== 'object' || raw === null) return DEFAULT_SETTINGS;
  const r = raw as Record<string, unknown>;
  return {
    locale: isLocale(r['locale']) ? r['locale'] : DEFAULT_SETTINGS.locale,
    graphics: isGraphics(r['graphics']) ? r['graphics'] : DEFAULT_SETTINGS.graphics,
    reduceMotion: typeof r['reduceMotion'] === 'boolean' ? r['reduceMotion'] : DEFAULT_SETTINGS.reduceMotion,
    threatWarnings: typeof r['threatWarnings'] === 'boolean' ? r['threatWarnings'] : DEFAULT_SETTINGS.threatWarnings,
    confirmMoves: typeof r['confirmMoves'] === 'boolean' ? r['confirmMoves'] : DEFAULT_SETTINGS.confirmMoves,
    voiceTurnOnly: typeof r['voiceTurnOnly'] === 'boolean' ? r['voiceTurnOnly'] : DEFAULT_SETTINGS.voiceTurnOnly,
    voiceMicDeviceId: isMicDeviceId(r['voiceMicDeviceId']) ? r['voiceMicDeviceId'] : DEFAULT_SETTINGS.voiceMicDeviceId,
    volumeMaster: clampVolume(r['volumeMaster'], DEFAULT_SETTINGS.volumeMaster),
    volumeMusic: clampVolume(r['volumeMusic'], DEFAULT_SETTINGS.volumeMusic),
    volumeSfx: clampVolume(r['volumeSfx'], DEFAULT_SETTINGS.volumeSfx),
  };
}

export class LocalStorageSettingsStore implements SettingsStore {
  constructor(
    private readonly storage: Pick<Storage, 'getItem' | 'setItem'> | null = typeof localStorage === 'undefined' ? null : localStorage,
    private readonly key = KEY,
  ) {}

  load(): Settings {
    try {
      const raw = this.storage?.getItem(this.key);
      if (raw === null || raw === undefined) return DEFAULT_SETTINGS;
      return sanitize(JSON.parse(raw));
    } catch {
      return DEFAULT_SETTINGS; // dữ liệu hỏng / chế độ riêng tư: dùng mặc định, không làm vỡ UI
    }
  }

  save(settings: Settings): void {
    try {
      this.storage?.setItem(this.key, JSON.stringify(settings));
    } catch {
      // hết dung lượng hoặc bị chặn: cài đặt vẫn áp dụng cho phiên hiện tại, chỉ không nhớ được cho lần sau
    }
  }
}

/** Bộ nhớ trong RAM cho test. */
export class MemorySettingsStore implements SettingsStore {
  private value: Settings = DEFAULT_SETTINGS;
  load(): Settings {
    return this.value;
  }
  save(settings: Settings): void {
    this.value = settings;
  }
}
