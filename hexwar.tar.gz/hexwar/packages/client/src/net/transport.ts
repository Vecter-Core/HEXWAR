// Lớp trừu tượng Transport (PLAN 6.1 nguyên tắc 3): UI chỉ gửi ý định và nhận kết quả, không biết ván đang chạy
// trong Worker cục bộ (M4) hay trên server (M6, WebSocketTransport).
import type { ClientMessage, SavedGame, SeatSetup, SessionTiming } from '@hexwar/protocol';
import type { HostCommand, HostEvent } from './host-protocol';

export interface Transport {
  send(message: ClientMessage): void;
  /** Đăng ký nhận sự kiện từ nơi chạy ván; trả về hàm huỷ đăng ký. */
  subscribe(handler: (event: HostEvent) => void): () => void;
  close(): void;
}

/** Phần chung của hai transport cục bộ: gửi lệnh `HostCommand`, phát `HostEvent` cho người đăng ký. */
export abstract class LocalTransportBase implements Transport {
  private readonly handlers = new Set<(event: HostEvent) => void>();

  protected abstract post(command: HostCommand): void;

  protected deliver(event: HostEvent): void {
    for (const handler of [...this.handlers]) handler(event);
  }

  startNew(seed: number, seats: readonly SeatSetup[], timing?: Partial<SessionTiming>): void {
    this.post({ kind: 'start', seed, seats, ...(timing !== undefined ? { timing } : {}) });
  }

  resume(save: SavedGame | unknown, timing?: Partial<SessionTiming>): void {
    this.post({ kind: 'resume', save, ...(timing !== undefined ? { timing } : {}) });
  }

  send(message: ClientMessage): void {
    this.post({ kind: 'client', message });
  }

  subscribe(handler: (event: HostEvent) => void): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  close(): void {
    this.post({ kind: 'stop' });
    this.handlers.clear();
  }
}

export type LocalTransport = LocalTransportBase;

/** Ván chạy trong Web Worker (đường chạy thật của bản solo). */
export class WorkerTransport extends LocalTransportBase {
  private readonly worker: Worker;

  constructor() {
    super();
    this.worker = new Worker(new URL('./local-worker.ts', import.meta.url), { type: 'module' });
    this.worker.onmessage = (event: MessageEvent<HostEvent>) => this.deliver(event.data);
  }

  protected post(command: HostCommand): void {
    this.worker.postMessage(command);
  }

  override close(): void {
    super.close();
    this.worker.terminate();
  }
}
