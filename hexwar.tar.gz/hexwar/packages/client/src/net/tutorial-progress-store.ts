// Tiến độ bài tân thủ (M8, PLAN 10.1: nhớ đã hoàn thành bài nào; "lần đầu vào game tự mở bài 1" chỉ được làm
// ĐÚNG MỘT LẦN trong đời trình duyệt này). Cùng khuôn mẫu với net/save-store.ts / net/settings-store.ts:
// interface + LocalStorage (thật) + Memory (test), một khoá `hexwar.tutorial.v1`.
import type { LessonId } from '@hexwar/tutorial';

export interface TutorialProgress {
  /** Các bài đã đi hết tới bước cuối (không tính "Bỏ qua" — xem tutorial-panel.ts). */
  readonly completed: readonly LessonId[];
}

export interface TutorialProgressStore {
  load(): TutorialProgress;
  markCompleted(id: LessonId): void;
  /** Màn tân thủ đã từng được MỞ chưa (tự động lần đầu hoặc người tự bấm) — quyết định có tự mở bài 1 lần đầu
   * vào game không (chỉ đúng một lần, gọi `markStarted()` ngay khi màn hiện ra, không đợi hoàn thành bài nào). */
  hasStarted(): boolean;
  markStarted(): void;
}

export const TUTORIAL_PROGRESS_KEY = 'hexwar.tutorial.v1';

interface StoredProgress {
  readonly completed: readonly LessonId[];
  readonly started: boolean;
}

const EMPTY: StoredProgress = { completed: [], started: false };

function isLessonIdArray(v: unknown): v is LessonId[] {
  return Array.isArray(v) && v.every((x) => typeof x === 'string');
}

/** Đọc một đối tượng thô (JSON.parse) và trả về StoredProgress hợp lệ, dùng mặc định rỗng cho phần thiếu/hỏng. */
function sanitize(raw: unknown): StoredProgress {
  if (typeof raw !== 'object' || raw === null) return EMPTY;
  const r = raw as Record<string, unknown>;
  return {
    completed: isLessonIdArray(r['completed']) ? r['completed'] : EMPTY.completed,
    started: typeof r['started'] === 'boolean' ? r['started'] : EMPTY.started,
  };
}

export class LocalStorageTutorialProgressStore implements TutorialProgressStore {
  constructor(
    private readonly storage: Pick<Storage, 'getItem' | 'setItem'> | null = typeof localStorage === 'undefined' ? null : localStorage,
    private readonly key = TUTORIAL_PROGRESS_KEY,
  ) {}

  private read(): StoredProgress {
    try {
      const raw = this.storage?.getItem(this.key);
      if (raw === null || raw === undefined) return EMPTY;
      return sanitize(JSON.parse(raw));
    } catch {
      return EMPTY; // dữ liệu hỏng / chế độ riêng tư: coi như chưa có tiến độ, không làm vỡ UI
    }
  }

  private write(next: StoredProgress): void {
    try {
      this.storage?.setItem(this.key, JSON.stringify(next));
    } catch {
      // hết dung lượng hoặc bị chặn: tiến độ vẫn dùng được cho phiên này, chỉ không nhớ được cho lần sau
    }
  }

  load(): TutorialProgress {
    return { completed: this.read().completed };
  }

  markCompleted(id: LessonId): void {
    const cur = this.read();
    if (cur.completed.includes(id)) return;
    this.write({ ...cur, completed: [...cur.completed, id] });
  }

  hasStarted(): boolean {
    return this.read().started;
  }

  markStarted(): void {
    const cur = this.read();
    if (cur.started) return;
    this.write({ ...cur, started: true });
  }
}

/** Bộ nhớ trong RAM cho test. */
export class MemoryTutorialProgressStore implements TutorialProgressStore {
  private value: StoredProgress = EMPTY;

  load(): TutorialProgress {
    return { completed: [...this.value.completed] };
  }

  markCompleted(id: LessonId): void {
    if (!this.value.completed.includes(id)) this.value = { ...this.value, completed: [...this.value.completed, id] };
  }

  hasStarted(): boolean {
    return this.value.started;
  }

  markStarted(): void {
    this.value = { ...this.value, started: true };
  }
}
