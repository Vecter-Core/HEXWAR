// Transport giả cho MỘT ScenarioLesson (M8, PLAN mục 10.1). Cầu nối giữa runner thuần của @hexwar/tutorial
// (chạy trên engine thật, không DOM/hoạt ảnh) và `Transport`/`GameLink` mà client đã biết dùng cho ván thật —
// nhờ vậy bài học tái dùng NGUYÊN đường vẽ bàn cờ/chọn quân/hoạt ảnh/HUD của một ván thật (không viết lại UI
// riêng cho tân thủ, xem docs/decisions.md mục "M8 (client)").
//
// seq và số message phát ra mô phỏng ĐÚNG `GameSession.commit` (packages/protocol/src/session.ts): mỗi hành
// động tất định (một `applyMove` hay `rollDice`) phát ĐÚNG MỘT `game.events`, seq tăng 1 mỗi lần. Vì vậy lớp
// này KHÔNG gọi thẳng `pump()`/`attemptMove()` của gói tutorial: hai hàm đó gộp nhiều hành động nội bộ (ví dụ
// nước đi của người chơi rồi ngay lập tức một bước 'auto' của đối thủ, xem scenarios/t8.ts, t9.ts) vào MỘT
// `RunnerState`, và trường `.log` của nó chỉ còn giữ sự kiện của hành động NỘI BỘ CUỐI — nếu dùng thẳng, hoạt
// ảnh sẽ bỏ mất kết quả nước đi của chính người chơi (ví dụ T9: không thấy Tốt vừa ăn Hậu trước khi thấy Vua
// đối phương dịch chuyển). Để giữ đủ từng bước, lớp này tự lặp qua từng bước bằng ĐÚNG các hàm thuần đã export
// công khai của hai gói (`applyMove`/`checkMove`/`rollDice` của @hexwar/rules; `currentStep`/`goalMet` của
// @hexwar/tutorial) — không đụng vào phần chưa export của `runner.ts`, không sửa gói `tutorial`.
import type { ClientMessage, GameAction, RejectReason, SeatStatus, ServerMessage } from '@hexwar/protocol';
import { applyMove, checkMove, rollDice, type GameEvent, type GameState, type Seat } from '@hexwar/rules';
import { currentStep, goalMet, startLesson, type RunnerState, type ScenarioLesson } from '@hexwar/tutorial';
import type { HostEvent } from './host-protocol';
import type { Transport } from './transport';

export interface TutorialTransportOptions {
  /**
   * Một bước 'auto'/'roll' vừa chạy có `textKey` (lời dẫn ngắn, ví dụ "Bây giờ đối thủ ăn Vua của bạn — xem điều
   * gì xảy ra") — hiện NGAY lúc sự kiện đó bắt đầu diễn hoạt ảnh, giống cách `Hud.announceEvent` hiện thông báo
   * theo sự kiện thật. `runner.ts` không tự dừng ở các bước này (chúng tự chạy qua) nên đây là cách duy nhất để
   * bài học "nói" điều gì đó ngay trước một nước đi kịch bản.
   */
  readonly onStepNarration?: (textKey: string) => void;
}

/** Ghế nào là "người học" của bài — mọi bước 'move' trong 13 bài đều dùng ghế 0, nhưng suy luận thay vì đóng cứng
 * để không lệch nếu sau này có bài dùng ghế khác (xem docs/decisions.md). */
function playerSeatsOf(lesson: ScenarioLesson): Seat[] {
  const seats = new Set<Seat>();
  for (const step of lesson.steps) if (step.kind === 'move') seats.add(step.seat);
  return [...seats];
}

function advanceRunner(r: RunnerState, game: GameState, log: readonly GameEvent[]): RunnerState {
  const stepIndex = r.stepIndex + 1;
  return { lesson: r.lesson, stepIndex, game, log, done: stepIndex >= r.lesson.steps.length, lastRejection: null };
}

interface AutoStepResult {
  readonly runner: RunnerState;
  readonly action: GameAction;
  readonly events: readonly GameEvent[];
  readonly textKey?: string;
}

/** Chạy ĐÚNG MỘT bước 'auto'/'roll' hiện tại (nếu có) — bản sao có chủ đích của vòng lặp trong `runner.ts`'s
 * `pump()`, nhưng dừng lại sau mỗi bước thay vì gộp hết, để gọi nơi này emit một `game.events` cho mỗi bước. */
function runOnePendingStep(r: RunnerState): AutoStepResult | null {
  if (r.done) return null;
  const step = currentStep(r);
  if (step === undefined || step.kind === 'move' || step.kind === 'info') return null;
  if (step.kind === 'roll') {
    const { state, events } = rollDice(r.game);
    return { runner: advanceRunner(r, state, events), action: { kind: 'dice' }, events, textKey: step.textKey };
  }
  // step.kind === 'auto'
  const { state, events } = applyMove(r.game, step.move);
  if (step.expect !== undefined && !events.some((e) => e.type === step.expect)) {
    throw new Error(`TutorialTransport: bài ${r.lesson.id}, bước ${r.stepIndex}: mong sự kiện "${step.expect}" nhưng không xảy ra (lỗi soạn bài)`);
  }
  return { runner: advanceRunner(r, state, events), action: { kind: 'move', seat: step.seat, move: step.move }, events, textKey: step.textKey };
}

export class TutorialTransport implements Transport {
  private runner: RunnerState;
  private seq = 0;
  private readonly handlers = new Set<(event: HostEvent) => void>();
  private readonly you: readonly Seat[];

  constructor(
    readonly lesson: ScenarioLesson,
    private readonly options: TutorialTransportOptions = {},
  ) {
    // startLesson() tự chạy qua các bước 'auto'/'roll' dẫn đầu (không có bài nào trong 13 bài hiện có, nhưng vẫn
    // đúng nếu sau này có) TRƯỚC KHI có ai đăng ký nhận sự kiện — không sao vì đây là khung hình ĐẦU TIÊN, không
    // có trạng thái trước đó để diễn hoạt ảnh chuyển tiếp (giống `game.snapshot` thật: luôn vẽ thẳng, không hoạt ảnh).
    this.runner = startLesson(lesson);
    this.you = playerSeatsOf(lesson);
  }

  /** Đọc trạng thái runner hiện tại (bước, log, done, lastRejection) — bảng điều khiển bài học tự đọc lại sau
   * mỗi hành động nó gây ra thay vì cần một kênh sự kiện riêng (đơn giản hơn, vòng lặp vẽ đã tick mỗi khung hình). */
  getRunner(): RunnerState {
    return this.runner;
  }

  /** Phát khung hình đầy đủ đầu tiên — gọi SAU KHI `GameLink` đã `subscribe` (main.ts/tutorial-panel.ts), như
   * `WorkerTransport` chỉ thật sự có gì để gửi sau khi được `startNew` gọi vào lúc đó. */
  pushInitialSnapshot(): void {
    this.deliver({ kind: 'server', message: this.snapshotMessage() });
  }

  /** Người chơi bấm "Tiếp tục" ở một bước 'info'. Bước này không tương ứng `GameAction` nào (chỉ lời thoại, trạng
   * thái ván không đổi) nên không phát `game.events` cho chính nó — nhưng CÓ pump tiếp các bước 'auto'/'roll' kế
   * tiếp (mỗi bước phát sự kiện riêng, xem đầu file), vì những bước đó có thể có quân thật di chuyển ngay sau đó. */
  acknowledgeInfo(): void {
    const step = currentStep(this.runner);
    if (this.runner.done || step === undefined || step.kind !== 'info') return;
    this.runner = advanceRunner(this.runner, this.runner.game, []);
    this.pumpAndEmit();
  }

  send(message: ClientMessage): void {
    if (message.type !== 'game.move') return; // bài học không có xúc xắc/đầu hàng do người bấm (roll tự chạy, không nút đầu hàng)
    const seq = message.seq;
    if (seq !== this.seq) {
      this.emitRejection(seq, 'STALE_SEQ');
      return;
    }
    const step = currentStep(this.runner);
    if (this.runner.done || step === undefined || step.kind !== 'move') {
      this.emitRejection(seq, 'GAME_NOT_PLAYING');
      return;
    }
    const reason = checkMove(this.runner.game, step.seat, message.move);
    if (reason !== null) {
      this.runner = { ...this.runner, lastRejection: reason };
      this.emitRejection(seq, reason);
      return;
    }
    const { state, events } = applyMove(this.runner.game, message.move);
    const action: GameAction = { kind: 'move', seat: step.seat, move: message.move };
    if (goalMet(step.goal, state, events)) {
      this.runner = advanceRunner(this.runner, state, events);
      this.emitEvents(action, events);
      this.pumpAndEmit(); // các bước 'auto'/'roll' ngay sau bước 'move' vừa xong (xem t8.ts, t9.ts)
    } else {
      // Nước hợp lệ nhưng chưa thoả mục tiêu bài: áp dụng thật, ở lại bước này (giống `attemptMove` của runner.ts).
      this.runner = { ...this.runner, game: state, log: events, lastRejection: null };
      this.emitEvents(action, events);
    }
  }

  subscribe(handler: (event: HostEvent) => void): () => void {
    this.handlers.add(handler);
    return () => this.handlers.delete(handler);
  }

  close(): void {
    this.handlers.clear();
  }

  private pumpAndEmit(): void {
    for (;;) {
      const next = runOnePendingStep(this.runner);
      if (next === null) return;
      this.runner = next.runner;
      if (next.textKey !== undefined) this.options.onStepNarration?.(next.textKey);
      this.emitEvents(next.action, next.events);
    }
  }

  private snapshotMessage(): ServerMessage {
    return { type: 'game.snapshot', seq: this.seq, state: this.runner.game, seats: this.seatStatuses(), you: this.you, deadline: null };
  }

  private emitEvents(action: GameAction, events: readonly GameEvent[]): void {
    this.seq += 1;
    const message: ServerMessage = {
      type: 'game.events',
      seq: this.seq,
      action,
      events,
      state: this.runner.game,
      seats: this.seatStatuses(),
      deadline: null,
    };
    this.deliver({ kind: 'server', message });
  }

  private emitRejection(seq: number, reason: RejectReason): void {
    this.deliver({ kind: 'server', message: { type: 'game.rejected', seq, reason } });
  }

  private seatStatuses(): SeatStatus[] {
    return this.runner.game.order.map((seat) => ({ seat, kind: this.you.includes(seat) ? 'human' : 'bot', botControlled: false }));
  }

  private deliver(event: HostEvent): void {
    for (const handler of [...this.handlers]) handler(event);
  }
}
