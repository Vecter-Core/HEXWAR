// WebRTC mesh cho voice (PLAN 8.5): mỗi cặp người chơi đang cần voice giữ MỘT RTCPeerConnection, đàm phán kiểu
// "perfect negotiation" (mẫu chuẩn của WebRTC, MDN) để không cần một bên "chủ động" cố định — ai bật Mic sau, đổi
// thiết bị, hay bị mất kết nối rồi nối lại đều renegotiate được từ BẤT KỲ phía nào mà không giẫm chân nhau (ai
// nhường khi trùng lời mời cùng lúc — "glare" — xem `isPolite` ở core/voice-model.ts). Tín hiệu SDP/ICE đi qua
// `voice.signal` (server chỉ RELAY nguyên văn, không hiểu nội dung, xem packages/protocol/src/chat.ts và
// net/websocket-transport.ts). Không ghi âm, không lưu trữ (PLAN 8.5) — mọi thứ chỉ tồn tại trong bộ nhớ phiên này.
//
// KHÔNG unit-test được ở đây (cần RTCPeerConnection/getUserMedia thật, vitest chạy môi trường Node — xem
// vitest.config.ts): phần quyết định THUẦN (ai nên kết nối với ai, ai nhường) đã tách ra core/voice-model.ts và có
// test riêng. Lớp này chỉ còn việc "thi hành" quyết định đó bằng API trình duyệt thật — kiểm bằng Playwright (M7.5).
import type { Seat } from '@hexwar/rules';
import { isPolite, isSpeaking, isVoiceSignalData, shouldConnect, VOICE_OFF, type VoicePresence, type VoiceSignalData } from '../core/voice-model';

/** STUN công khai để tìm được đường đi trực tiếp giữa hai trình duyệt. TURN thật (coturn, PLAN 7.7) là hạ tầng
 * phải tự triển khai — chưa có sẵn ở đây; xem docs/questions.md cho việc "chỉ đi qua TURN" (`turnOnly`) chỉ có tác
 * dụng ẩn IP một khi đã cấu hình TURN thật vào danh sách này (qua tham số `iceServers` khi tạo `VoiceManager`). */
export const DEFAULT_ICE_SERVERS: readonly RTCIceServer[] = [{ urls: 'stun:stun.l.google.com:19302' }];

const SPEAKING_POLL_MS = 120; // đủ nhanh để thấy mượt, đủ chậm để không tốn CPU cho một chỉ báo nhỏ

export interface VoiceManagerCallbacks {
  /** PLAN 8.5 "biểu tượng đang nói" — gọi lại mỗi khi trạng thái đang-nói của MỘT ghế (mình hoặc người khác) đổi. */
  readonly onSpeaking: (seat: Seat, speaking: boolean) => void;
  /** Xin quyền micro thất bại (từ chối, không có thiết bị, trình duyệt chặn…) — để UI báo lỗi thay vì âm thầm không bật được. */
  readonly onMicError: (message: string) => void;
}

interface PeerLink {
  readonly seat: Seat;
  readonly pc: RTCPeerConnection;
  readonly audio: HTMLAudioElement;
  makingOffer: boolean;
  ignoreOffer: boolean;
  remoteAnalyser: AnalyserNode | null;
  speaking: boolean;
  muted: boolean;
  volume: number;
}

export class VoiceManager {
  private mySeat: Seat | null = null;
  private mine: VoicePresence = VOICE_OFF;
  private humanSeats: readonly Seat[] = [];
  private readonly blockedSeats = new Set<Seat>();
  private readonly presence = new Map<Seat, VoicePresence>();
  private readonly peers = new Map<Seat, PeerLink>();
  private localStream: MediaStream | null = null;
  private micDeviceId: string | null = null;
  private turnOnly = false;
  private audioContext: AudioContext | null = null;
  private localAnalyser: AnalyserNode | null = null;
  private localSpeaking = false;
  private pollHandle: ReturnType<typeof setInterval> | null = null;

  constructor(
    private iceServers: readonly RTCIceServer[],
    private readonly onSignal: (to: Seat, data: VoiceSignalData) => void,
    private readonly callbacks: VoiceManagerCallbacks,
  ) {}

  // ---- Cấu hình từ main.ts ---------------------------------------------------------------------------------------

  setMySeat(seat: Seat | null): void {
    this.mySeat = seat;
  }

  /** Gọi lại mỗi khi danh sách người thật trong phòng đổi (roster mới từ `game.snapshot`) — chào những người mới,
   * đóng kết nối với người đã rời. */
  setRoster(humanSeats: readonly Seat[]): void {
    this.humanSeats = humanSeats;
    this.broadcastPresence(humanSeats.filter((s) => !this.presence.has(s))); // chào người mới, họ chưa biết trạng thái của mình
    this.reconcile();
  }

  setBlocked(seat: Seat, blocked: boolean): void {
    if (blocked) this.blockedSeats.add(seat);
    else this.blockedSeats.delete(seat);
    this.reconcile();
  }

  /** PLAN 8.5 "Mặc định TẮT... lần đầu bật: hộp thoại giải thích và xin quyền micro" — hộp thoại là việc của UI
   * (app/voice-bar.ts) TRƯỚC khi gọi hàm này; đây chỉ lo phần `getUserMedia` + phát tín hiệu cho người khác. */
  async setMicEnabled(on: boolean): Promise<boolean> {
    if (!on) {
      this.mine = { ...this.mine, mic: false };
      this.setLocalTrackEnabled(false);
      this.broadcastPresence(this.humanSeats);
      this.reconcile();
      return true;
    }
    if (this.localStream === null) {
      try {
        this.localStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true, // PLAN 8.5: "bật sẵn khử tiếng vọng / khử ồn / tự chỉnh âm lượng"
            noiseSuppression: true,
            autoGainControl: true,
            ...(this.micDeviceId !== null ? { deviceId: { exact: this.micDeviceId } } : {}),
          },
        });
      } catch (err) {
        this.callbacks.onMicError(err instanceof Error ? err.message : String(err));
        return false;
      }
      this.setupLocalAnalyser(this.localStream);
    }
    this.setLocalTrackEnabled(false); // PLAN 8.5: Mic bật = SẴN SÀNG; chỉ THỰC SỰ gửi khi giữ phím V (push-to-talk)
    this.mine = { ...this.mine, mic: true };
    this.broadcastPresence(this.humanSeats);
    this.reconcile();
    return true;
  }

  /** Push-to-talk (PLAN 8.5, phím mặc định `V`): chỉ có tác dụng khi Mic đang bật — giữ phím mới thật sự gửi tiếng. */
  setPushToTalk(active: boolean): void {
    if (this.mine.mic) this.setLocalTrackEnabled(active);
  }

  private setLocalTrackEnabled(enabled: boolean): void {
    for (const track of this.localStream?.getAudioTracks() ?? []) track.enabled = enabled;
  }

  setListenEnabled(on: boolean): void {
    this.mine = { ...this.mine, listen: on };
    for (const peer of this.peers.values()) peer.audio.muted = !on || peer.muted;
    this.broadcastPresence(this.humanSeats);
    this.reconcile();
  }

  /** Đổi micro đang dùng (PLAN 11.5 "chọn micro/loa"); áp dụng ngay nếu Mic đang bật bằng cách lấy luồng mới. */
  async setMicDevice(deviceId: string | null): Promise<void> {
    this.micDeviceId = deviceId;
    if (!this.mine.mic) return;
    const wasEnabled = this.localStream?.getAudioTracks().some((t) => t.enabled) ?? false;
    this.stopLocalStream();
    const ok = await this.setMicEnabled(true);
    if (ok) this.setLocalTrackEnabled(wasEnabled);
  }

  setSeatVolume(seat: Seat, volume: number): void {
    const peer = this.peers.get(seat);
    if (peer !== undefined) {
      peer.volume = volume;
      peer.audio.volume = volume;
    }
  }

  setSeatMuted(seat: Seat, muted: boolean): void {
    const peer = this.peers.get(seat);
    if (peer !== undefined) {
      peer.muted = muted;
      peer.audio.muted = muted || !this.mine.listen;
    }
  }

  /** PLAN 11.5 "chỉ qua TURN" (ẩn IP, PLAN 8.5) — đổi cấu hình ICE cho các kết nối MỚI; kết nối đang có phải dựng
   * lại mới áp dụng được (đổi giữa ván là hiếm, chấp nhận gián đoạn ngắn thay vì logic ICE-restart phức tạp). */
  setTurnOnly(on: boolean): void {
    if (this.turnOnly === on) return;
    this.turnOnly = on;
    for (const seat of [...this.peers.keys()]) this.closePeer(seat);
    this.reconcile();
  }

  /** Nút "thử mic" (PLAN 8.5): đọc mức âm lượng micro hiện tại để UI vẽ đồng hồ mức, KHÔNG phát lại cho chính mình
   * (tránh dội tiếng). Trả về hàm dừng. */
  testMic(onLevel: (level: number) => void): () => void {
    let stopped = false;
    const tick = (): void => {
      if (stopped) return;
      onLevel(this.localAnalyser === null ? 0 : readLevel(this.localAnalyser));
      requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
    return () => {
      stopped = true;
    };
  }

  /** CHỈ để Playwright (M7.5) nhìn vào trạng thái kết nối thật — không dùng trong luồng chơi bình thường. */
  debugPeerStates(): Partial<Record<Seat, RTCPeerConnectionState>> {
    const out: Partial<Record<Seat, RTCPeerConnectionState>> = {};
    for (const [seat, peer] of this.peers) out[seat] = peer.pc.connectionState;
    return out;
  }

  /** CHỈ để Playwright (M7.5) xác nhận tuỳ chọn "chỉ đi qua TURN" (ẩn IP, PLAN 8.5) THẬT SỰ áp vào cấu hình
   * `RTCPeerConnection` của kết nối mới tạo (`iceTransportPolicy: 'relay'`) — môi trường này không có TURN server
   * thật (coturn, PLAN 7.7) để kiểm việc ẩn IP có hiệu quả thật hay không, đó là việc triển khai hạ tầng của bạn
   * (xem docs/questions.md); ở đây chỉ kiểm phần code của client nối đúng dây. */
  debugIceTransportPolicy(seat: Seat): RTCIceTransportPolicy | null {
    return this.peers.get(seat)?.pc.getConfiguration().iceTransportPolicy ?? null;
  }

  // ---- Tín hiệu vào từ server (relay `voice.signal`, PLAN 8.5) ----------------------------------------------------

  handleSignal(from: Seat, data: unknown): void {
    if (this.blockedSeats.has(from) || !isVoiceSignalData(data)) return; // PLAN 8.5 "người bị chặn không nghe nhau"
    if (data.kind === 'presence') {
      const isFirstContact = !this.presence.has(from);
      this.presence.set(from, { mic: data.mic, listen: data.listen });
      if (isFirstContact) this.broadcastPresence([from]); // họ chưa chắc biết trạng thái của mình — chào lại một lần
      this.reconcile();
      return;
    }
    const peer = this.getOrCreatePeer(from);
    if (data.kind === 'candidate') {
      peer.pc.addIceCandidate(data.candidate).catch((err: unknown) => {
        if (!peer.ignoreOffer) throw err instanceof Error ? err : new Error(String(err));
      });
      return;
    }
    void this.handleDescription(peer, data.sdp);
  }

  /** Mẫu "perfect negotiation" (MDN): nhận offer HAY answer đều qua một đường — chỉ tạo+gửi answer khi vừa nhận là
   * offer. `ignoreOffer` xử lý glare (hai bên cùng gửi offer một lúc): bên impolite bỏ qua offer của bên kia. */
  private async handleDescription(peer: PeerLink, sdp: RTCSessionDescriptionInit): Promise<void> {
    const polite = isPolite(this.mySeat as Seat, peer.seat);
    const offerCollision = sdp.type === 'offer' && (peer.makingOffer || peer.pc.signalingState !== 'stable');
    peer.ignoreOffer = !polite && offerCollision;
    if (peer.ignoreOffer) return;
    try {
      await peer.pc.setRemoteDescription(sdp);
      if (sdp.type === 'offer') {
        await peer.pc.setLocalDescription();
        if (peer.pc.localDescription !== null) this.onSignal(peer.seat, { kind: 'answer', sdp: peer.pc.localDescription });
      }
    } catch {
      // Kết nối có thể đã bị đóng/thay giữa chừng (người kia rời phòng) — bỏ qua, `reconcile()` sẽ dọn peer này sau.
    }
  }

  // ---- Dựng/đóng kết nối theo nhu cầu (PLAN 8.5 "chỉ tạo kết nối khi người đó bật voice") ---------------------------

  private presenceOf(seat: Seat): VoicePresence {
    return this.presence.get(seat) ?? VOICE_OFF;
  }

  private reconcile(): void {
    if (this.mySeat === null) return;
    const wanted = new Set(this.humanSeats.filter((s) => s !== this.mySeat && !this.blockedSeats.has(s) && shouldConnect(this.mine, this.presenceOf(s))));
    // Chỉ bên "impolite" (ghế nhỏ hơn, xem isPolite ở core/voice-model.ts) CHỦ ĐỘNG mở RTCPeerConnection ở đây. Nếu
    // cả hai bên cùng chủ động lúc khởi tạo nguội, cả hai đều tự bắn `onnegotiationneeded` gần như đồng thời -> đua
    // nhau gửi offer (glare) NGAY TỪ ĐẦU, trước khi có bất kỳ mô tả từ xa nào để phân xử — khiến kết nối kẹt ở
    // 'new' mãi (đã thấy thật khi kiểm bằng Playwright, xem e2e/voice.spec.ts). Bên polite chỉ dựng peer lúc THỰC
    // SỰ nhận được offer (handleSignal -> getOrCreatePeer), nên khởi tạo nguội chỉ có một nguồn offer duy nhất; cơ
    // chế perfect-negotiation (makingOffer/ignoreOffer) vẫn còn nguyên cho các lần renegotiate SAU khi đã kết nối
    // (đổi mic, mất mạng rồi nối lại) — khi đó cả hai bên đều đã có peer và có thể tự nêu lại nhu cầu renegotiate.
    for (const seat of wanted) if (!isPolite(this.mySeat, seat)) this.getOrCreatePeer(seat);
    for (const seat of [...this.peers.keys()]) if (!wanted.has(seat)) this.closePeer(seat);
  }

  private getOrCreatePeer(seat: Seat): PeerLink {
    const existing = this.peers.get(seat);
    if (existing !== undefined) return existing;

    const pc = new RTCPeerConnection({ iceServers: [...this.iceServers], iceTransportPolicy: this.turnOnly ? 'relay' : 'all' });
    const audio = document.createElement('audio');
    audio.autoplay = true;
    const peer: PeerLink = { seat, pc, audio, makingOffer: false, ignoreOffer: false, remoteAnalyser: null, speaking: false, muted: false, volume: 1 };
    audio.muted = !this.mine.listen;

    if (this.localStream !== null) for (const track of this.localStream.getAudioTracks()) pc.addTrack(track, this.localStream);
    else pc.addTransceiver('audio', { direction: 'recvonly' }); // chưa từng bật Mic: vẫn sẵn sàng NGHE người kia

    pc.onnegotiationneeded = () => {
      void (async () => {
        try {
          peer.makingOffer = true;
          await pc.setLocalDescription();
          if (pc.localDescription !== null) this.onSignal(seat, { kind: 'offer', sdp: pc.localDescription });
        } catch {
          // Có thể do đóng peer giữa chừng (rời phòng) — bỏ qua, `reconcile()` sẽ dọn peer này nếu cần.
        } finally {
          peer.makingOffer = false;
        }
      })();
    };
    pc.onicecandidate = (e) => {
      if (e.candidate !== null) this.onSignal(seat, { kind: 'candidate', candidate: e.candidate.toJSON() });
    };
    pc.ontrack = (e) => {
      const stream = e.streams[0] ?? new MediaStream([e.track]);
      if (audio.srcObject !== stream) audio.srcObject = stream;
      peer.remoteAnalyser = this.ensureAudioContext() === null ? null : this.createAnalyserFor(stream);
    };
    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'failed' || pc.connectionState === 'closed') this.closePeer(seat);
    };

    this.peers.set(seat, peer);
    this.ensurePolling();
    return peer;
  }

  private closePeer(seat: Seat): void {
    const peer = this.peers.get(seat);
    if (peer === undefined) return;
    peer.pc.close();
    peer.audio.srcObject = null;
    this.peers.delete(seat);
    if (peer.speaking) this.callbacks.onSpeaking(seat, false);
  }

  private broadcastPresence(to: readonly Seat[]): void {
    if (this.mySeat === null) return;
    for (const seat of to) if (seat !== this.mySeat) this.onSignal(seat, { kind: 'presence', ...this.mine });
  }

  // ---- Đo mức âm lượng cho biểu tượng "đang nói" (PLAN 8.5) -------------------------------------------------------

  private ensureAudioContext(): AudioContext | null {
    if (this.audioContext === null) {
      try {
        this.audioContext = new AudioContext();
      } catch {
        return null; // Môi trường không hỗ trợ AudioContext (hiếm) — voice vẫn nói/nghe được, chỉ mất chỉ báo "đang nói".
      }
    }
    return this.audioContext;
  }

  private createAnalyserFor(stream: MediaStream): AnalyserNode | null {
    const ctx = this.ensureAudioContext();
    if (ctx === null) return null;
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 512;
    ctx.createMediaStreamSource(stream).connect(analyser); // KHÔNG nối tới `ctx.destination`: <audio autoplay> đã tự phát rồi.
    return analyser;
  }

  private setupLocalAnalyser(stream: MediaStream): void {
    this.localAnalyser = this.createAnalyserFor(stream);
    this.ensurePolling();
  }

  private ensurePolling(): void {
    if (this.pollHandle !== null) return;
    this.pollHandle = setInterval(() => this.pollSpeaking(), SPEAKING_POLL_MS);
  }

  private pollSpeaking(): void {
    if (this.mySeat !== null && this.localAnalyser !== null) {
      const speaking = this.mine.mic && isSpeaking(readLevel(this.localAnalyser));
      if (speaking !== this.localSpeaking) {
        this.localSpeaking = speaking;
        this.callbacks.onSpeaking(this.mySeat, speaking);
      }
    }
    for (const peer of this.peers.values()) {
      const speaking = peer.remoteAnalyser !== null && isSpeaking(readLevel(peer.remoteAnalyser));
      if (speaking !== peer.speaking) {
        peer.speaking = speaking;
        this.callbacks.onSpeaking(peer.seat, speaking);
      }
    }
  }

  private stopLocalStream(): void {
    for (const track of this.localStream?.getTracks() ?? []) track.stop();
    this.localStream = null;
    this.localAnalyser = null;
  }

  /** Rời phòng / thoát ván (PLAN 8.5 "không ghi âm, không lưu") — đóng sạch mọi thứ, không để mic bật ngầm. */
  dispose(): void {
    if (this.pollHandle !== null) clearInterval(this.pollHandle);
    this.pollHandle = null;
    for (const seat of [...this.peers.keys()]) this.closePeer(seat);
    this.stopLocalStream();
    this.presence.clear();
    this.blockedSeats.clear();
    this.mine = VOICE_OFF;
    this.localSpeaking = false;
    void this.audioContext?.close();
    this.audioContext = null;
  }
}

/** RMS chuẩn hoá 0..1 từ dữ liệu miền thời gian của `AnalyserNode` (giá trị gốc 0..255, 128 là im lặng tuyệt đối). */
function readLevel(analyser: AnalyserNode): number {
  const data = new Uint8Array(analyser.fftSize);
  analyser.getByteTimeDomainData(data);
  let sumSquares = 0;
  for (const sample of data) {
    const centered = (sample - 128) / 128;
    sumSquares += centered * centered;
  }
  return Math.sqrt(sumSquares / data.length);
}
