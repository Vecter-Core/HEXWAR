// Transport thật qua WebSocket (PLAN 6.1 nguyên tắc 3, M6): nói đúng giao thức `game.*` mà `GameLink` đã hiểu từ
// M4 (`ServerMessage`/`ClientMessage`, packages/protocol/src/messages.ts) — UI không biết mình đang chơi online hay
// cục bộ. Khác với `WorkerTransport`, không có `startNew`/`resume`: ván online do SERVER tự quyết khi nào bắt đầu
// (PLAN 7.2, phòng tự chuyển khi đủ người/bot lấp chỗ) rồi tự đẩy `game.snapshot`, client chỉ cần đã `subscribe`
// từ trước (main.ts làm đúng thứ tự này, giống hệt ván cục bộ).
//
// Cùng MỘT kết nối còn mang tầng phòng/ghép trận (PLAN 7.1-7.3, `LobbyClientMessage`/`LobbyServerMessage`,
// packages/protocol/src/lobby.ts) — lớp này lộ thêm `sendLobby`/`subscribeLobby` cho tầng đó, tách khỏi
// `send`/`subscribe` (chỉ tầng ván) mà interface `Transport` yêu cầu. Và tầng chat/báo cáo/voice (PLAN mục 8,
// `ChatClientMessage`/`ChatServerMessage`, packages/protocol/src/chat.ts) qua `sendChat`/`subscribeChat` — có nghĩa
// cả ở sảnh lẫn giữa ván nên tách khỏi cả hai tầng kia, không gắn riêng vào lúc nào.
import type { ChatClientMessage, ChatServerMessage, ClientMessage, LobbyClientMessage, LobbyServerMessage, ServerMessage } from '@hexwar/protocol';
import type { HostEvent } from './host-protocol';
import type { Transport } from './transport';

const CHAT_SERVER_MESSAGE_TYPES = new Set(['chat.message', 'chat.error', 'report.ack', 'voice.signal']);

export type ConnectionState = { readonly kind: 'connecting' } | { readonly kind: 'open' } | { readonly kind: 'closed'; readonly reason: string };

/** `?server=` (kiểm thử: trỏ vào server thật đang chạy trên một cổng khác) — mặc định cổng 8080 cùng host trang
 * (PLAN 7 chưa định nghĩa khám phá server tự động; đây là điểm nối tối thiểu cho M6). */
export function resolveServerUrl(params: URLSearchParams, location: { protocol: string; hostname: string }): string {
  const override = params.get('server');
  if (override !== null && override.length > 0) return override;
  const scheme = location.protocol === 'https:' ? 'wss' : 'ws';
  return `${scheme}://${location.hostname}:8080`;
}

export class WebSocketTransport implements Transport {
  private readonly socket: WebSocket;
  private readonly gameHandlers = new Set<(event: HostEvent) => void>();
  private readonly lobbyHandlers = new Set<(message: LobbyServerMessage) => void>();
  private readonly chatHandlers = new Set<(message: ChatServerMessage) => void>();
  private readonly connectionHandlers = new Set<(state: ConnectionState) => void>();
  private connection: ConnectionState = { kind: 'connecting' };

  constructor(url: string) {
    this.socket = new WebSocket(url);
    this.socket.addEventListener('open', () => this.setConnection({ kind: 'open' }));
    this.socket.addEventListener('close', (event) => this.setConnection({ kind: 'closed', reason: event.reason || `mã ${event.code}` }));
    // Không có listener 'error' riêng thì trình duyệt cũng tự phát 'close' ngay sau — không cần xử lý gì thêm ở đây.
    this.socket.addEventListener('error', () => {});
    this.socket.addEventListener('message', (event: MessageEvent) => this.onMessage(event));
  }

  get connectionState(): ConnectionState {
    return this.connection;
  }

  subscribeConnection(handler: (state: ConnectionState) => void): () => void {
    this.connectionHandlers.add(handler);
    return () => this.connectionHandlers.delete(handler);
  }

  private setConnection(next: ConnectionState): void {
    this.connection = next;
    for (const handler of [...this.connectionHandlers]) handler(next);
  }

  private onMessage(event: MessageEvent): void {
    let parsed: unknown;
    try {
      parsed = JSON.parse(String(event.data));
    } catch {
      return; // dữ liệu hỏng từ server: bỏ qua thay vì làm vỡ UI (không nên xảy ra, server tự tạo message của mình).
    }
    const type = parsed !== null && typeof parsed === 'object' ? (parsed as { type?: unknown }).type : undefined;
    if (typeof type !== 'string') return;
    if (type.startsWith('game.')) {
      const message = parsed as ServerMessage;
      for (const handler of [...this.gameHandlers]) handler({ kind: 'server', message });
      return;
    }
    if (CHAT_SERVER_MESSAGE_TYPES.has(type)) {
      const message = parsed as ChatServerMessage;
      for (const handler of [...this.chatHandlers]) handler(message);
      return;
    }
    const message = parsed as LobbyServerMessage;
    for (const handler of [...this.lobbyHandlers]) handler(message);
  }

  // ---- Tầng phòng/ghép trận (PLAN 7.1-7.3) -------------------------------------------------------------------------

  sendLobby(message: LobbyClientMessage): void {
    if (this.socket.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify(message));
  }

  subscribeLobby(handler: (message: LobbyServerMessage) => void): () => void {
    this.lobbyHandlers.add(handler);
    return () => this.lobbyHandlers.delete(handler);
  }

  // ---- Tầng chat/báo cáo/voice (PLAN mục 8) --------------------------------------------------------------------

  sendChat(message: ChatClientMessage): void {
    if (this.socket.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify(message));
  }

  subscribeChat(handler: (message: ChatServerMessage) => void): () => void {
    this.chatHandlers.add(handler);
    return () => this.chatHandlers.delete(handler);
  }

  // ---- Transport (tầng ván, PLAN 6.1) ------------------------------------------------------------------------------

  send(message: ClientMessage): void {
    if (this.socket.readyState === WebSocket.OPEN) this.socket.send(JSON.stringify(message));
  }

  subscribe(handler: (event: HostEvent) => void): () => void {
    this.gameHandlers.add(handler);
    return () => this.gameHandlers.delete(handler);
  }

  close(): void {
    this.gameHandlers.clear();
    this.lobbyHandlers.clear();
    this.chatHandlers.clear();
    this.connectionHandlers.clear();
    this.socket.close();
  }
}
