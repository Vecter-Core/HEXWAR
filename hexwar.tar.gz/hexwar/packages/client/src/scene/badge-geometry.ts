// Hình học 6 biểu tượng đế quân (PLAN 12.3, 11.5) — mỗi hình là một khối phẳng mỏng (đùn `BADGE_HEIGHT`), dựng
// bằng THREE.Shape rồi xoay nằm ngang, giống `hex-geometry.ts::createTileGeometry` (cùng quy ước: mặt trên tại
// y = 0 SAU khi dịch, để `badge-scene.ts` chỉ cần tịnh tiến lên độ cao mong muốn, không cần biết chi tiết đùn).
import * as THREE from 'three';
import type { BadgeShape } from '../core/badge';

/** Độ dày khối biểu tượng — đủ để đổ bóng nhẹ, không đủ để nhô cao gây vướng hình quân (PLAN 12.3). */
export const BADGE_HEIGHT = 0.03;

function extrudeFlat(shape: THREE.Shape, height: number): THREE.BufferGeometry {
  const geometry = new THREE.ExtrudeGeometry(shape, { depth: height, bevelEnabled: false, curveSegments: 8 });
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(0, -height, 0); // mặt trên (đùn ra ở z=height) về y=0 sau xoay; đáy ở y=−height
  geometry.computeVertexNormals();
  return geometry;
}

/** Đa giác đều `sides` cạnh, bán kính `radius`, đỉnh đầu tiên ở góc `startAngle` (rad, 0 = trục +x). */
function regularPolygon(sides: number, radius: number, startAngle: number): THREE.Shape {
  const shape = new THREE.Shape();
  for (let i = 0; i < sides; i++) {
    const angle = startAngle + (Math.PI * 2 * i) / sides;
    const x = radius * Math.cos(angle);
    const y = radius * Math.sin(angle);
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  shape.closePath();
  return shape;
}

function starShape(points: number, outerRadius: number, innerRadius: number): THREE.Shape {
  const shape = new THREE.Shape();
  const step = Math.PI / points;
  for (let i = 0; i < points * 2; i++) {
    const radius = i % 2 === 0 ? outerRadius : innerRadius;
    const angle = -Math.PI / 2 + i * step; // đỉnh đầu tiên hướng lên (trong mặt phẳng Shape)
    const x = radius * Math.cos(angle);
    const y = radius * Math.sin(angle);
    if (i === 0) shape.moveTo(x, y);
    else shape.lineTo(x, y);
  }
  shape.closePath();
  return shape;
}

function circleShape(radius: number): THREE.Shape {
  const shape = new THREE.Shape();
  shape.absarc(0, 0, radius, 0, Math.PI * 2, false);
  return shape;
}

/** Dựng hình khối của một biểu tượng, bán kính ngoại tiếp xấp xỉ `radius`. Gọi một lần mỗi hình (6 lần/ván). */
export function createBadgeGeometry(shape: BadgeShape, radius: number): THREE.BufferGeometry {
  switch (shape) {
    case 'circle':
      return extrudeFlat(circleShape(radius), BADGE_HEIGHT);
    case 'triangle':
      return extrudeFlat(regularPolygon(3, radius, -Math.PI / 2), BADGE_HEIGHT);
    case 'square':
      return extrudeFlat(regularPolygon(4, radius, Math.PI / 4), BADGE_HEIGHT);
    case 'diamond':
      return extrudeFlat(regularPolygon(4, radius, 0), BADGE_HEIGHT);
    case 'star':
      return extrudeFlat(starShape(5, radius, radius * 0.45), BADGE_HEIGHT);
    case 'hexagon':
      return extrudeFlat(regularPolygon(6, radius, Math.PI / 2), BADGE_HEIGHT);
  }
}
