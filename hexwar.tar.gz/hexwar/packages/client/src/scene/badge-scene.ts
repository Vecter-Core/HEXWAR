// Vẽ biểu tượng đế quân theo ghế (PLAN 12.3, 11.5 "Hỗ trợ truy cập": 6 hình khác nhau, không phụ thuộc màu).
// Một InstancedMesh MỖI HÌNH (6 tổng cộng, vài chục đỉnh/hình) — giữ đúng nguyên tắc PLAN 6.6 ("một InstancedMesh
// mỗi loại"), áp dụng cho "loại" = hình biểu tượng thay vì loại quân. Đồng bộ mỗi khung hình CÙNG lúc với
// `PieceScene` (đọc lại `DisplayModel` + `AnimationDirector.motions()`), đặt tại chân quân (PLAN 12.3: "trên đế
// quân"): một đĩa mỏng RỘNG HƠN bán kính đế quân lớn nhất, nằm sát mặt ô, nên phần vành ngoài luôn lộ ra quanh
// chân quân dù quân đứng trên đó (giống một "bệ màu" quen thuộc trong cờ 3D để nhận chủ quân từ xa/nhìn từ trên).
import * as THREE from 'three';
import { BADGE_SHAPES, badgeShapeForSeat, type BadgeShape } from '../core/badge';
import type { Motion } from '../core/animation';
import type { PieceView } from '../core/display-model';
import { cellCenter } from '../core/layout';
import { seatColor } from '../core/palette';
import { createBadgeGeometry } from './badge-geometry';
import { CAPTIVE_SCALE } from './piece-geometry';

/** Bán kính ngoại tiếp của đĩa biểu tượng — lớn hơn bán kính đế lớn nhất trong PIECE_FOOTPRINT (Xe, Hậu = 0.3/0.28)
 * nên luôn có vành lộ ra quanh chân quân, kể cả quân to nhất. */
const BADGE_RADIUS = 0.34;
/** Nhích lên trên mặt ô, THẤP HƠN highlight-mesh (0.01)/threat-mesh (0.02) một chút để không chớp hình (z-fighting)
 * và để không đè lên hai lớp tô sáng đó khi cùng hiện. */
const Y_OFFSET = 0.006;
const MAX_PER_SHAPE = 108; // giới hạn an toàn: cả bàn tối đa 108 quân, dù dồn hết vào một ghế cũng không tràn

const tmpMatrix = new THREE.Matrix4();
const tmpPos = new THREE.Vector3();
const tmpQuat = new THREE.Quaternion();
const tmpScale = new THREE.Vector3();
const tmpColor = new THREE.Color();

export class BadgeScene {
  readonly group = new THREE.Group();
  private readonly meshes: Record<BadgeShape, THREE.InstancedMesh>;

  constructor() {
    const meshes = {} as Record<BadgeShape, THREE.InstancedMesh>;
    for (const shape of BADGE_SHAPES) {
      const geometry = createBadgeGeometry(shape, BADGE_RADIUS);
      // Không `vertexColors: true` — xem chú thích piece-scene.ts (hoá đen vì thiếu thuộc tính `color` theo đỉnh).
      const material = new THREE.MeshStandardMaterial({ roughness: 0.5, metalness: 0.1 });
      const mesh = new THREE.InstancedMesh(geometry, material, MAX_PER_SHAPE);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.count = 0;
      this.group.add(mesh);
      meshes[shape] = mesh;
    }
    this.meshes = meshes;
  }

  /** Cùng chữ ký với `PieceScene.sync` (đọc lại toàn bộ mô hình + hoạt ảnh mỗi khung hình, PLAN 6.1). */
  sync(pieces: readonly PieceView[], motions: ReadonlyMap<string, Motion>): void {
    const perShape = new Map<BadgeShape, PieceView[]>(BADGE_SHAPES.map((s) => [s, []]));
    for (const piece of pieces) perShape.get(badgeShapeForSeat(piece.owner))?.push(piece);

    for (const shape of BADGE_SHAPES) {
      const mesh = this.meshes[shape];
      const list = perShape.get(shape) ?? [];
      list.forEach((piece, i) => {
        const base = cellCenter(piece.cell);
        const motion = motions.get(piece.id);
        const x = motion?.pos?.x ?? base.x;
        const z = motion?.pos?.z ?? base.z;
        const baseScale = piece.status === 'captive' ? CAPTIVE_SCALE : 1;
        const scale = baseScale * (motion?.scale ?? 1);
        tmpPos.set(x, Y_OFFSET, z);
        tmpQuat.identity();
        tmpScale.set(scale, 1, scale); // giữ đĩa mỏng phẳng dù quân co lại theo chiều đứng lúc hoạt ảnh
        tmpMatrix.compose(tmpPos, tmpQuat, tmpScale);
        mesh.setMatrixAt(i, tmpMatrix);
        tmpColor.setHex(seatColor(piece.owner));
        mesh.setColorAt(i, tmpColor);
      });
      mesh.count = list.length;
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor !== null) mesh.instanceColor.needsUpdate = true;
    }
  }

  dispose(): void {
    for (const shape of BADGE_SHAPES) {
      const mesh = this.meshes[shape];
      mesh.geometry.dispose();
      (mesh.material as THREE.Material).dispose();
    }
  }
}
