// Vẽ toàn bộ ô bằng MỘT InstancedMesh (PLAN 6.6: hiệu năng). Tô 3 tông theo `colorOf` (PLAN 12.2). Khi vòng
// ngoài biến mất (RING_COLLAPSED), ẩn các ô đó bằng cách giảm `InstancedMesh.count` — KHÔNG dựng lại hình học —
// vì các ô được xếp theo thứ tự hạng tăng dần nên phần đầu mảng luôn đúng là "mọi ô của bán kính nhỏ hơn".
import * as THREE from 'three';
import { cellCount, cellKey, cellsInRing, colorOf, type Cell, type WarningLevel } from '@hexwar/rules';
import { collapsePhaseAt, collapseTileTransform } from '../core/collapse-fx';
import { CELL_SIZE, TILE_HEIGHT, TILE_RADIUS_SCALE, cellCenter } from '../core/layout';
import { HIGHLIGHT, TILE_TONES, mixColor } from '../core/palette';
import { createTileGeometry } from './hex-geometry';

const tmpMatrix = new THREE.Matrix4();
const tmpColor = new THREE.Color();
const tmpPos = new THREE.Vector3();
const tmpScale = new THREE.Vector3();
const tmpQuat = new THREE.Quaternion(); // luôn giữ nguyên (không xoay) — chỉ cần cho Matrix4.compose

/** Tốc độ nhấp nháy (chu kỳ/giây) của vòng sắp biến mất (X-01, PLAN 12.2). */
const PULSE_HZ = 1.6;
/** Màu "vết nứt" khi ô đang rơi (PLAN 12.2, M10) — trộn dần vào tông gốc, khác `HIGHLIGHT.warnRed` (cảnh báo TRƯỚC
 * khi thu hẹp) để hai giai đoạn không lẫn nhau trên ảnh chụp. */
const CRACK_COLOR = 0xff5a1f;

export class BoardMesh {
  readonly mesh: THREE.InstancedMesh;
  private readonly indexOf = new Map<number, number>();
  private readonly cellOf: Cell[];
  /** Vòng đang được tô cảnh báo (X-01); null khi không có. Dùng để biết ô nào cần trả lại màu gốc khi đổi vòng. */
  private warnedRing: number | null = null;
  /** M10: vòng đang chạy hoạt ảnh "rung → nứt → rơi" (PLAN 12.2/12.4); null khi không có vòng nào đang thu hẹp. */
  private collapsingRing: number | null = null;
  private collapsePhase: 'shake' | 'fall' | null = null;

  /** `maxRadius`: bán kính lớn nhất từng cần vẽ trong ván này (thường là bán kính lúc bắt đầu). */
  constructor(maxRadius: number) {
    const geometry = createTileGeometry(CELL_SIZE * TILE_RADIUS_SCALE, TILE_HEIGHT);
    // Không đặt `vertexColors: true` — xem chú thích ở piece-scene.ts: cờ đó nhân thêm thuộc tính `color` theo
    // đỉnh (không tồn tại ở đây) vào TRƯỚC màu theo instance, hoá đen toàn bộ. `setColorAt` tự đủ.
    const material = new THREE.MeshStandardMaterial({ roughness: 0.85, metalness: 0.05 });
    const capacity = cellCount(maxRadius);
    this.mesh = new THREE.InstancedMesh(geometry, material, capacity);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.cellOf = new Array(capacity);

    let i = 0;
    for (let r = 0; r <= maxRadius; r++) {
      for (const c of cellsInRing(r)) {
        this.cellOf[i] = c;
        this.indexOf.set(cellKey(c), i);
        const center = cellCenter(c);
        tmpMatrix.makeTranslation(center.x, center.y, center.z);
        this.mesh.setMatrixAt(i, tmpMatrix);
        tmpColor.setHex(TILE_TONES[colorOf(c)] as number);
        this.mesh.setColorAt(i, tmpColor);
        i++;
      }
    }
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor !== null) this.mesh.instanceColor.needsUpdate = true;
    this.mesh.count = capacity;
  }

  /** Bán kính bàn cờ giảm đi (thu hẹp không bao giờ đảo ngược): ẩn tức thời các ô ngoài bán kính mới. Gọi ĐÚNG một
   * lần khi hiệu ứng `'collapse'` (M10) đã chạy xong (progress = 1) — trước đó vòng vẫn hiển thị TRỌN VẸN, chỉ bị
   * `animateCollapsingRing` làm rung/nứt/rơi tại chỗ, nên cú ẩn cứng này diễn ra khi vòng đã gần như biến mất
   * (co nhỏ + chìm sâu), không còn thấy "vỡ" đột ngột (docs/decisions.md mục M10). */
  setRadius(radius: number): void {
    this.mesh.count = cellCount(Math.max(0, radius));
    this.collapsingRing = null;
    this.collapsePhase = null;
  }

  /**
   * M10 (PLAN 12.2 "rung → nứt → rơi", 12.4 "thu hẹp: như 12.2"): chạy TRONG SUỐT hiệu ứng `'collapse'` của
   * `AnimationDirector` (progress 0→1, cùng thời lượng `DURATION.ringCollapsed` mà quân trên vòng đã dùng để rơi
   * từ M3 — không đụng `animation.ts`, chỉ thêm hoạt ảnh cho CHÍNH CÁC Ô). Vòng vẫn ở nguyên trong `mesh.count`
   * (chưa bị `setRadius` ẩn) nên vẫn vẽ được; toạ độ tất định theo `collapse-fx.ts` (không `Math.random`) để hai
   * lần chạy lại cùng ván cho hạt/rung giống hệt nhau (dễ so ảnh chụp Playwright).
   * `onFallStart`: gọi ĐÚNG MỘT LẦN cho một vài ô mẫu, đúng lúc cả vòng chuyển từ pha rung sang pha rơi (PLAN 12.2
   * "kèm bụi") — không gọi mỗi khung hình, tránh sinh hạt liên tục suốt nửa sau của hoạt ảnh.
   */
  animateCollapsingRing(ring: number, progress: number, onFallStart?: (cell: Cell) => void): void {
    if (this.collapsingRing !== ring) {
      this.collapsingRing = ring;
      this.collapsePhase = null;
    }
    const nowPhase = collapsePhaseAt(progress);
    const justStartedFalling = this.collapsePhase === 'shake' && nowPhase === 'fall';
    this.collapsePhase = nowPhase;

    let changed = false;
    let ordinal = 0;
    for (const c of cellsInRing(ring)) {
      const index = this.indexOf.get(cellKey(c));
      ordinal++;
      if (index === undefined) continue;
      const transform = collapseTileTransform(progress, index);
      const center = cellCenter(c);
      tmpPos.set(center.x + transform.dx, center.y + transform.dy, center.z + transform.dz);
      tmpScale.set(transform.scale, transform.scale, transform.scale);
      tmpMatrix.compose(tmpPos, tmpQuat, tmpScale);
      this.mesh.setMatrixAt(index, tmpMatrix);
      tmpColor.setHex(mixColor(TILE_TONES[colorOf(c)] as number, CRACK_COLOR, transform.crack));
      this.mesh.setColorAt(index, tmpColor);
      changed = true;
      if (justStartedFalling && onFallStart !== undefined && ordinal % 4 === 0) onFallStart(c);
    }
    if (changed) {
      this.mesh.instanceMatrix.needsUpdate = true;
      if (this.mesh.instanceColor !== null) this.mesh.instanceColor.needsUpdate = true;
    }
  }

  /** Trả các ô của một vòng về màu gốc (3 tông theo `colorOf`, PLAN 12.2) — dùng khi thôi cảnh báo vòng đó. */
  private restoreRing(ring: number): boolean {
    let changed = false;
    for (const c of cellsInRing(ring)) {
      const index = this.indexOf.get(cellKey(c));
      if (index === undefined) continue;
      tmpColor.setHex(TILE_TONES[colorOf(c)] as number);
      this.mesh.setColorAt(index, tmpColor);
      changed = true;
    }
    return changed;
  }

  /**
   * X-01 (PLAN R-71, 12.2): tô nhấp nháy vòng `ring` sắp biến mất — vàng (còn vài hiệp) rồi đỏ (hiệp cuối).
   * `nowSeconds`: đồng hồ hoạt ảnh (không phải giờ hệ thống — packages/rules và mọi thứ dưới `core/` tất định,
   * nhưng đây là lớp trình chiếu THREE thuần UI nên dùng thời gian thật của vòng lặp vẽ, giống AnimationDirector).
   */
  pulseWarning(nowSeconds: number, ring: number | null, level: WarningLevel | null): void {
    let changed = false;
    if (ring !== this.warnedRing && this.warnedRing !== null) changed = this.restoreRing(this.warnedRing);
    this.warnedRing = level === null ? null : ring;

    if (this.warnedRing !== null) {
      const warnColor = level === 'red' ? HIGHLIGHT.warnRed : HIGHLIGHT.warnYellow;
      const factor = 0.25 + 0.35 * (0.5 + 0.5 * Math.sin(nowSeconds * PULSE_HZ * Math.PI * 2));
      for (const c of cellsInRing(this.warnedRing)) {
        const index = this.indexOf.get(cellKey(c));
        if (index === undefined) continue;
        tmpColor.setHex(mixColor(TILE_TONES[colorOf(c)] as number, warnColor, factor));
        this.mesh.setColorAt(index, tmpColor);
        changed = true;
      }
    }
    if (changed && this.mesh.instanceColor !== null) this.mesh.instanceColor.needsUpdate = true;
  }

  /** M10 (PLAN 12.5 "Cao: ... phản xạ nhẹ cho ô"): bật/tắt phản xạ môi trường trên vật liệu ô. `scene.environment`
   * (nguồn phản xạ) do `board-scene.ts::applyGraphicsProfile` dựng một lần và gán vào `Scene`; ở đây chỉ cần cho
   * vật liệu ô BIẾT dùng bao nhiêu (`envMapIntensity`), độc lập với có `environment` hay không. */
  setReflective(enabled: boolean): void {
    (this.mesh.material as THREE.MeshStandardMaterial).envMapIntensity = enabled ? 0.6 : 0;
  }

  indexOfCell(c: Cell): number | undefined {
    return this.indexOf.get(cellKey(c));
  }

  cellAt(index: number): Cell | undefined {
    return this.cellOf[index];
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
  }
}
