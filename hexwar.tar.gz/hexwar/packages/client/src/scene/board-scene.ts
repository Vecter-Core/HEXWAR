// Lắp ráp cảnh THREE cho M3: ánh sáng + bàn cờ instanced + quân procedural instanced + lớp tô sáng, đồng bộ mỗi
// khung hình từ `DisplayModel`/`AnimationDirector` (PLAN 6.1: "hoạt ảnh 3D chỉ đọc sự kiện"). Không đụng luật.
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { nextCollapse, type GameState } from '@hexwar/rules';
import type { AnimationDirector } from '../core/animation';
import type { Selection } from '../core/controller';
import type { DisplayModel } from '../core/display-model';
import type { GraphicsProfile } from '../core/graphics-quality';
import type { PickablePiece } from '../core/picking';
import { NO_THREATS, type ThreatInfo } from '../core/threats';
import { BadgeScene } from './badge-scene';
import { BoardMesh } from './board-mesh';
import { EffectsLayer } from './effects-layer';
import { HighlightMesh } from './highlight-mesh';
import { PieceScene } from './piece-scene';
import { ThreatMesh } from './threat-mesh';

export class BoardScene {
  readonly scene = new THREE.Scene();
  private readonly board: BoardMesh;
  private readonly pieces = new PieceScene();
  private readonly badges = new BadgeScene();
  private readonly highlight = new HighlightMesh();
  private readonly threat = new ThreatMesh();
  private readonly effects = new EffectsLayer();
  private readonly sun: THREE.DirectionalLight;
  private lastRadius: number;
  private lastNow: number | null = null;
  private roomEnvironment: THREE.Texture | null = null;
  /** M10 (PLAN 12.4 "rung nhẹ camera" khi ăn Vua): độ lệch camera hiện tại, `main.ts` đọc mỗi khung hình rồi cộng
   * vào vị trí camera đã tính — BoardScene không tự đụng `THREE.Camera` (giữ đúng ranh giới cũ: scene/ chỉ dựng
   * cảnh, main.ts lắp camera thật, xem docs/decisions.md mục M3). */
  cameraShake = { x: 0, y: 0, z: 0 };

  /** `maxRadius`: bán kính lớn nhất cần vẽ trong ván này (bán kính lúc bắt đầu ván — thu hẹp chỉ giảm dần). */
  constructor(maxRadius: number) {
    this.lastRadius = maxRadius;
    this.board = new BoardMesh(maxRadius);

    this.scene.background = new THREE.Color(0x0b1220);
    this.scene.fog = new THREE.Fog(0x0b1220, 60, 220);
    this.scene.add(this.board.mesh, this.pieces.group, this.badges.group, this.highlight.mesh, this.threat.mesh, this.effects.group);

    // Cường độ cao hơn hẳn so với trực giác "ánh sáng thường" (0.5–1.5): three.js r15x+ bỏ chế độ đèn "legacy",
    // đơn vị đèn giờ theo vật lý (lux/candela) nên phải tăng lên nhiều lần mới đủ sáng để đọc được bàn cờ
    // (PLAN 12.1: "phải nhìn ra loại quân, chủ quân và ô đi được ngay từ xa" — đo bằng ảnh chụp Playwright thật).
    const hemi = new THREE.HemisphereLight(0xbcd4ff, 0x1c2433, 3.2);
    this.sun = new THREE.DirectionalLight(0xfff2d8, 3.6);
    this.sun.position.set(35, 70, 25);
    const fill = new THREE.AmbientLight(0x6c7ea8, 0.8);
    this.scene.add(hemi, this.sun, fill);
  }

  /**
   * M10 (PLAN 12.5 "mức đồ hoạ"): áp mức Thấp/Vừa/Cao lên CẢNH (bóng đổ, mật độ hạt, phản xạ nhẹ cho ô). Hậu kỳ
   * (bloom/SSAO) và `pixelRatio` là việc của `main.ts` (đụng `THREE.WebGLRenderer`/`EffectComposer`, ngoài `Scene`).
   * `renderer`: chỉ dùng để dựng `PMREMGenerator` một lần cho phản xạ ở mức Cao — không giữ tham chiếu lâu dài.
   */
  applyGraphicsProfile(profile: GraphicsProfile, renderer: THREE.WebGLRenderer): void {
    this.effects.particleDensity = profile.particleDensity;
    this.sun.castShadow = profile.shadows;
    if (profile.shadows) {
      this.sun.shadow.mapSize.set(1024, 1024);
      this.sun.shadow.camera.near = 10;
      this.sun.shadow.camera.far = 160;
      const extent = 60;
      this.sun.shadow.camera.left = -extent;
      this.sun.shadow.camera.right = extent;
      this.sun.shadow.camera.top = extent;
      this.sun.shadow.camera.bottom = -extent;
    }
    this.board.mesh.receiveShadow = profile.shadows;
    this.pieces.setCastShadow(profile.shadows);

    if (profile.reflections && this.roomEnvironment === null) {
      const pmrem = new THREE.PMREMGenerator(renderer);
      this.roomEnvironment = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      pmrem.dispose();
    }
    this.scene.environment = profile.reflections ? this.roomEnvironment : null;
    this.board.setReflective(profile.reflections);
  }

  /**
   * Đồng bộ toàn cảnh với mô hình hiển thị hiện tại (vị trí "đã ổn định" + ghi đè hoạt ảnh) và trạng thái ván
   * (để tô ô đi được theo lựa chọn hiện tại). `threats` (X-06, PLAN 11.2): null = tắt cảnh báo đe doạ (cài đặt hoặc
   * không phải lượt của mình). `nowSeconds`: đồng hồ hoạt ảnh dùng để nhấp nháy vòng sắp biến mất (X-01, PLAN 12.2).
   * Trả về danh sách quân để `picking.ts` dùng ở khung kế tiếp.
   */
  sync(state: GameState, model: DisplayModel, animator: AnimationDirector, selection: Selection | null, threats: ThreatInfo = NO_THREATS, nowSeconds = 0): readonly PickablePiece[] {
    const dt = this.lastNow === null ? 0 : Math.max(0, Math.min(0.1, nowSeconds - this.lastNow));
    this.lastNow = nowSeconds;

    // M10 (PLAN 12.2/12.4): trong lúc hiệu ứng 'collapse' đang chạy (progress < 1), `model.radius` CHƯA đổi —
    // AnimationDirector chỉ áp sự kiện (và vì vậy đổi radius) khi bước hoạt ảnh KẾT THÚC (animation.ts). Vòng vẫn
    // hiển thị trọn vẹn suốt lúc đó, chỉ bị `animateCollapsingRing` làm rung/nứt/rơi tại chỗ; `setRadius` (ẩn cứng)
    // chỉ xảy ra ở khung hình mà `model.radius` thật sự đổi, lúc đó vòng đã gần như biến mất trên màn hình.
    const collapseEffect = animator.effects().find((e) => e.kind === 'collapse');
    if (collapseEffect !== undefined && collapseEffect.kind === 'collapse') {
      this.board.animateCollapsingRing(collapseEffect.ring, collapseEffect.progress, (cell) => this.effects.spawnCollapseDust(cell));
    }
    if (model.radius !== this.lastRadius) {
      this.board.setRadius(model.radius);
      this.lastRadius = model.radius;
    }
    const picks = this.pieces.sync(model.all(), animator.motions());
    this.badges.sync(model.all(), animator.motions());
    this.highlight.sync(state, selection);
    this.threat.sync(state, threats);
    this.effects.sync(animator.effects(), dt);
    this.cameraShake = this.effects.shakeOffset();
    const upcoming = state.phase === 'over' ? undefined : nextCollapse(state);
    this.board.pulseWarning(nowSeconds, upcoming?.event.ring ?? null, upcoming?.level ?? null);
    return picks;
  }

  dispose(): void {
    this.board.dispose();
    this.pieces.dispose();
    this.badges.dispose();
    this.highlight.dispose();
    this.threat.dispose();
    this.effects.dispose();
    this.roomEnvironment?.dispose();
  }
}
