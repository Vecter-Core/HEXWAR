// M10 (PLAN 12.4): vẽ các hiệu ứng mà `AnimationDirector.effects()` đã tính sẵn nhưng TRƯỚC ĐÂY không ai đọc
// (`impact` khi ăn quân, `kingHit` khi ăn Vua, bụi khi một ô bắt đầu rơi lúc thu hẹp — xem `board-mesh.ts`).
// Một hệ hạt CPU đơn giản dùng MỘT `THREE.Points` (một draw call, tối đa `MAX_PARTICLES`) + MỘT `THREE.PointLight`
// dùng lại (bật/tắt cường độ, không tạo/xoá) cho chớp sáng — giữ đúng PLAN 6.6 "không tạo/xoá đối tượng mỗi khung
// hình". Không có test riêng cho lớp này (thuần THREE, không có logic tách bạch được khỏi WebGL); toán rơi/tắt dần
// dùng ở `collapseFallProgress`/`shakeOffsetFor` (thuần số) được export riêng để `board-mesh.test.ts` kiểm được.
import * as THREE from 'three';
import type { Cell } from '@hexwar/rules';
import type { Effect } from '../core/animation';
import { cellCenter } from '../core/layout';

const MAX_PARTICLES = 480;
/** Cửa sổ camera rung sau khi ăn Vua (PLAN 12.4: "rung nhẹ camera"), giây. */
const SHAKE_DURATION = 0.35;

interface Particle {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  life: number;
  maxLife: number;
  /** Hệ số trọng lực riêng của hạt (1 = rơi bình thường như `spawnBurst`; gần 0 = lơ lửng, dùng cho
   * "tan thành hạt sáng"/"ánh sáng từ dưới lên"/"vệt sáng" — M10, PLAN 12.4 — để chúng không rơi/nảy như mảnh vỡ). */
  gravity: number;
  r: number;
  g: number;
  b: number;
}

/** RNG tất định theo seed số (không `Math.random`): hai lần chạy lại CÙNG một ván (cùng chuỗi sự kiện) cho hạt
 * giống hệt nhau, hữu ích khi so ảnh chụp Playwright trước/sau. Đây là lớp trình chiếu THREE thuần UI (không phải
 * `packages/rules`) nên không bị CLAUDE.md cấm `Math.random`, nhưng giữ tất định vẫn tốt hơn cho việc kiểm ảnh. */
function pseudoRandom(seed: number): number {
  const x = Math.sin(seed * 12.9898) * 43758.5453;
  return x - Math.floor(x);
}

function effectKey(e: Effect): string {
  switch (e.kind) {
    case 'impact':
      return `impact:${e.cell.q},${e.cell.r}`;
    case 'kingHit':
      return `kingHit:${e.cell.q},${e.cell.r}`;
    case 'collapse':
      return `collapse:${e.ring}`;
    case 'dissolve':
      return `dissolve:${e.cell.q},${e.cell.r}`;
    case 'promote':
      return `promote:${e.cell.q},${e.cell.r}`;
    case 'beam':
      return `beam:${e.from.q},${e.from.r}-${e.to.q},${e.to.r}`;
  }
}

/** Độ lệch camera rung (thuần số, test được) tại thời điểm còn `remaining`/`duration` giây, biên độ `amplitude`. */
export function shakeOffsetFor(remaining: number, duration: number, amplitude: number): { x: number; y: number; z: number } {
  if (remaining <= 0) return { x: 0, y: 0, z: 0 };
  const decay = remaining / duration;
  const s = remaining * 90;
  return { x: Math.sin(s * 1.7) * amplitude * decay, y: Math.sin(s * 2.3) * amplitude * 0.5 * decay, z: Math.cos(s * 1.3) * amplitude * decay };
}

export class EffectsLayer {
  readonly group = new THREE.Group();
  private readonly points: THREE.Points;
  private readonly geometry: THREE.BufferGeometry;
  private readonly positions: Float32Array;
  private readonly colors: Float32Array;
  private readonly particles: Particle[] = [];
  private readonly flashLight: THREE.PointLight;
  private flashRemaining = 0;
  private flashMax = 0;
  private shakeRemaining = 0;
  private previousKey: string | null = null;
  private seedCounter = 0;

  /** Mật độ hạt (PLAN 12.5 "ít hạt" ở Thấp, "hạt dày" ở Cao) — `main.ts` đặt lại khi đổi mức đồ hoạ. */
  particleDensity = 1;

  constructor() {
    this.geometry = new THREE.BufferGeometry();
    this.positions = new Float32Array(MAX_PARTICLES * 3);
    this.colors = new Float32Array(MAX_PARTICLES * 3);
    this.geometry.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.geometry.setAttribute('color', new THREE.BufferAttribute(this.colors, 3));
    this.geometry.setDrawRange(0, 0);
    const material = new THREE.PointsMaterial({ size: 0.16, vertexColors: true, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
    this.points = new THREE.Points(this.geometry, material);
    this.points.frustumCulled = false;
    this.flashLight = new THREE.PointLight(0xffffff, 0, 7, 2);
    this.group.add(this.points, this.flashLight);
  }

  /** Đọc hiệu ứng hiện tại của `AnimationDirector` + chạy tiếp hạt/chớp sáng đang có. `dt`: giây thực (đã nhân tốc
   * độ hoạt ảnh, `board-scene.ts` tự đo bằng đồng hồ vẽ) — hạt cần rơi/tan XONG dù bước hoạt ảnh đã kết thúc, nên
   * không dùng `progress` của hiệu ứng cho việc này, chỉ dùng nó để biết KHI NÀO một hiệu ứng mới vừa xuất hiện. */
  sync(effects: readonly Effect[], dt: number): void {
    const current = effects[0];
    const key = current === undefined ? null : effectKey(current);
    if (key !== null && key !== this.previousKey && current !== undefined) {
      if (current.kind === 'impact') this.spawnBurst(current.cell, 0xfff2b0, 10);
      else if (current.kind === 'kingHit') {
        this.spawnBurst(current.cell, 0xff5050, 36);
        this.flash(current.cell, 0xff4040, 2.4);
        this.shakeRemaining = SHAKE_DURATION;
      } else if (current.kind === 'dissolve') this.spawnDissolve(current.cell);
      else if (current.kind === 'promote') this.spawnPromoteLight(current.cell);
      else if (current.kind === 'beam') this.spawnBeam(current.from, current.to);
      // 'collapse': bụi sinh bởi `spawnCollapseDust()` do board-scene gọi đúng lúc chuyển pha rung→rơi, không ở đây.
    }
    this.previousKey = key;
    this.step(dt);
  }

  /** PLAN 12.2 "kèm bụi": gọi MỘT LẦN khi một ô chuyển từ pha rung sang pha rơi (board-mesh theo dõi cạnh chuyển pha). */
  spawnCollapseDust(cell: Cell): void {
    this.spawnBurst(cell, 0xbfd8ff, 7);
  }

  /** Độ lệch camera rung hiện tại (PLAN 12.4 "rung nhẹ camera" khi ăn Vua) — `main.ts` cộng vào vị trí camera. */
  shakeOffset(): { x: number; y: number; z: number } {
    return shakeOffsetFor(this.shakeRemaining, SHAKE_DURATION, 0.4);
  }

  private spawnBurst(cell: Cell, color: number, count: number): void {
    const n = Math.max(0, Math.round(count * this.particleDensity));
    const center = cellCenter(cell);
    const c = new THREE.Color(color);
    for (let i = 0; i < n && this.particles.length < MAX_PARTICLES; i++) {
      const seed = this.seedCounter++;
      const angle = pseudoRandom(seed) * Math.PI * 2;
      const speed = 0.7 + pseudoRandom(seed + 0.37) * 1.6;
      this.particles.push({
        x: center.x,
        y: 0.18,
        z: center.z,
        vx: Math.cos(angle) * speed,
        vy: 0.9 + pseudoRandom(seed + 0.71) * 1.4,
        vz: Math.sin(angle) * speed,
        life: 0,
        maxLife: 0.4 + pseudoRandom(seed + 0.13) * 0.4,
        gravity: 1,
        r: c.r,
        g: c.g,
        b: c.b,
      });
    }
  }

  /** PLAN 12.4 "hết hạn tù binh: tan thành hạt sáng" — hạt bay lên chậm rồi tan (trọng lực rất nhỏ, không nảy). */
  private spawnDissolve(cell: Cell): void {
    const n = Math.max(0, Math.round(16 * this.particleDensity));
    const center = cellCenter(cell);
    const c = new THREE.Color(0xfff2c4);
    for (let i = 0; i < n && this.particles.length < MAX_PARTICLES; i++) {
      const seed = this.seedCounter++;
      const angle = pseudoRandom(seed) * Math.PI * 2;
      const radius = pseudoRandom(seed + 0.21) * 0.32;
      this.particles.push({
        x: center.x + Math.cos(angle) * radius,
        y: 0.12,
        z: center.z + Math.sin(angle) * radius,
        vx: Math.cos(angle) * 0.2,
        vy: 0.5 + pseudoRandom(seed + 0.53) * 0.7,
        vz: Math.sin(angle) * 0.2,
        life: 0,
        maxLife: 0.6 + pseudoRandom(seed + 0.9) * 0.5,
        gravity: 0.15,
        r: c.r,
        g: c.g,
        b: c.b,
      });
    }
  }

  /** PLAN 12.4 "phong cấp: ánh sáng từ dưới lên" — cột hạt hẹp bắn thẳng lên, gần như không rơi. */
  private spawnPromoteLight(cell: Cell): void {
    const n = Math.max(0, Math.round(12 * this.particleDensity));
    const center = cellCenter(cell);
    const c = new THREE.Color(0xb9ffce);
    for (let i = 0; i < n && this.particles.length < MAX_PARTICLES; i++) {
      const seed = this.seedCounter++;
      const angle = pseudoRandom(seed + 0.4) * Math.PI * 2;
      const radius = pseudoRandom(seed) * 0.18;
      this.particles.push({
        x: center.x + Math.cos(angle) * radius,
        y: 0,
        z: center.z + Math.sin(angle) * radius,
        vx: 0,
        vy: 1.1 + pseudoRandom(seed + 0.61) * 0.6,
        vz: 0,
        life: 0,
        maxLife: 0.45 + pseudoRandom(seed + 0.2) * 0.3,
        gravity: 0.05,
        r: c.r,
        g: c.g,
        b: c.b,
      });
    }
  }

  /** PLAN 12.4 "hồi sinh Vua: vệt sáng nối Hề và Vua" — chuỗi hạt tĩnh dọc đoạn `from` → `to`, chỉ mờ dần. */
  private spawnBeam(from: Cell, to: Cell): void {
    const a = cellCenter(from);
    const b = cellCenter(to);
    const steps = Math.max(4, Math.round(10 * this.particleDensity));
    const c = new THREE.Color(0xbfe7ff);
    for (let i = 0; i <= steps && this.particles.length < MAX_PARTICLES; i++) {
      const seed = this.seedCounter++;
      const f = i / steps;
      this.particles.push({
        x: a.x + (b.x - a.x) * f,
        y: 0.2 + pseudoRandom(seed) * 0.08,
        z: a.z + (b.z - a.z) * f,
        vx: 0,
        vy: 0.1,
        vz: 0,
        life: 0,
        maxLife: 0.5 + pseudoRandom(seed + 0.3) * 0.2,
        gravity: 0,
        r: c.r,
        g: c.g,
        b: c.b,
      });
    }
  }

  private flash(cell: Cell, color: number, intensity: number): void {
    const center = cellCenter(cell);
    this.flashLight.position.set(center.x, 1.3, center.z);
    this.flashLight.color.setHex(color);
    this.flashMax = intensity;
    this.flashRemaining = 0.25;
  }

  private step(dt: number): void {
    const gravity = 2.8;
    for (let i = this.particles.length - 1; i >= 0; i--) {
      const p = this.particles[i] as Particle;
      p.life += dt;
      if (p.life >= p.maxLife) {
        this.particles.splice(i, 1);
        continue;
      }
      p.vy -= gravity * p.gravity * dt;
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      if (p.y < 0) {
        p.y = 0;
        p.vy *= -0.25;
      }
    }
    const n = Math.min(this.particles.length, MAX_PARTICLES);
    for (let i = 0; i < n; i++) {
      const p = this.particles[i] as Particle;
      const fade = 1 - p.life / p.maxLife;
      const base = i * 3;
      this.positions[base] = p.x;
      this.positions[base + 1] = p.y;
      this.positions[base + 2] = p.z;
      this.colors[base] = p.r * fade;
      this.colors[base + 1] = p.g * fade;
      this.colors[base + 2] = p.b * fade;
    }
    this.geometry.setDrawRange(0, n);
    const positionAttr = this.geometry.getAttribute('position') as THREE.BufferAttribute;
    const colorAttr = this.geometry.getAttribute('color') as THREE.BufferAttribute;
    positionAttr.needsUpdate = true;
    colorAttr.needsUpdate = true;

    if (this.flashRemaining > 0) {
      this.flashRemaining = Math.max(0, this.flashRemaining - dt);
      this.flashLight.intensity = this.flashMax * (this.flashRemaining / 0.25);
    } else {
      this.flashLight.intensity = 0;
    }
    if (this.shakeRemaining > 0) this.shakeRemaining = Math.max(0, this.shakeRemaining - dt);
  }

  dispose(): void {
    this.geometry.dispose();
    (this.points.material as THREE.Material).dispose();
  }
}
