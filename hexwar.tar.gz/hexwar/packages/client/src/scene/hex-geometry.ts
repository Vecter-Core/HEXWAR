// Hình học ô lục giác phẳng-đỉnh (PLAN 3.1, 6.6) dựng bằng THREE.Shape + đùn khối (không dùng model tải sẵn ở M3).
// Đỉnh ô ở góc 0°, 60°, …, 300° (khớp công thức worldPos: x = 1.5·q, z = √3·(r + q/2), xem docs/decisions.md).
import * as THREE from 'three';

/** 6 đỉnh của ô lục giác phẳng-đỉnh, bán kính `size`, theo chiều kim đồng hồ bắt đầu từ góc 0° (trục +x). */
export function hexCorners(size: number): readonly [number, number][] {
  const corners: [number, number][] = [];
  for (let i = 0; i < 6; i++) {
    const angle = (Math.PI / 180) * (60 * i);
    corners.push([size * Math.cos(angle), size * Math.sin(angle)]);
  }
  return corners;
}

/**
 * Khối lăng trụ lục giác: mặt trên tại y = 0, đáy tại y = −height (khớp `layout.ts` cellCenter: quân đứng ở y = 0).
 * `Shape` dựng trong mặt phẳng (x, y) rồi đùn dọc trục z; xoay −90° quanh X để trục đùn thành +y hướng lên, sau đó
 * dịch xuống `height` để mặt đùn ra (ban đầu ở z=0..height, tức y=0..height sau xoay) nằm ở y ∈ [−height, 0].
 */
export function createTileGeometry(size: number, height: number): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  const corners = hexCorners(size);
  const [first, ...rest] = corners;
  if (first === undefined) throw new Error('hexCorners rỗng');
  shape.moveTo(first[0], first[1]);
  for (const [x, y] of rest) shape.lineTo(x, y);
  shape.closePath();

  const geometry = new THREE.ExtrudeGeometry(shape, { depth: height, bevelEnabled: false, curveSegments: 1 });
  geometry.rotateX(-Math.PI / 2);
  geometry.translate(0, -height, 0);
  geometry.computeVertexNormals();
  return geometry;
}

/** Viền mỏng nằm sát mặt trên ô, dùng cho lớp tô sáng (đi được / ăn được / đang chọn, PLAN 11.2). */
export function createHighlightGeometry(size: number): THREE.BufferGeometry {
  const shape = new THREE.Shape();
  const corners = hexCorners(size);
  const [first, ...rest] = corners;
  if (first === undefined) throw new Error('hexCorners rỗng');
  shape.moveTo(first[0], first[1]);
  for (const [x, y] of rest) shape.lineTo(x, y);
  shape.closePath();
  const geometry = new THREE.ShapeGeometry(shape);
  geometry.rotateX(-Math.PI / 2);
  return geometry;
}
