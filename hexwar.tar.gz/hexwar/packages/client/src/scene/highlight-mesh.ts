// Lớp phủ tô sáng ô — đi được / ăn được / trưng dụng / đang chọn (PLAN 11.2, 12.2). InstancedMesh RIÊNG, nằm
// nhích lên trên mặt ô một chút, không đụng vật liệu ô gốc (PLAN 12.2: "vẽ bằng lớp phủ instanced riêng").
import * as THREE from 'three';
import type { GameState } from '@hexwar/rules';
import { classifyMove, type MoveKind, type Selection } from '../core/controller';
import { cellCenter } from '../core/layout';
import { HIGHLIGHT } from '../core/palette';
import { createHighlightGeometry } from './hex-geometry';

/** Tầm đi xa nhất (Hậu: 9 ô × 12 hướng) vẫn nằm rất xa dưới mức này; giới hạn chỉ để cấp phát bộ nhớ cố định. */
const MAX_HIGHLIGHTS = 256;
/** Nhích lên trên mặt ô (mặt trên ở y = 0, xem layout.ts) một chút để không bị chớp hình (z-fighting). */
const Y_OFFSET = 0.01;

function colorFor(kind: MoveKind): number {
  switch (kind) {
    case 'move':
      return HIGHLIGHT.move;
    case 'capture':
      return HIGHLIGHT.capture;
    case 'conscriptMove':
    case 'conscriptCapture':
      return HIGHLIGHT.conscript;
  }
}

const tmpMatrix = new THREE.Matrix4();
const tmpColor = new THREE.Color();

export class HighlightMesh {
  readonly mesh: THREE.InstancedMesh;

  constructor() {
    const geometry = createHighlightGeometry(0.92);
    // Không đặt `vertexColors: true` — xem chú thích ở piece-scene.ts (hoá đen vì thiếu thuộc tính `color` theo đỉnh).
    const material = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.55, side: THREE.DoubleSide, depthWrite: false });
    this.mesh = new THREE.InstancedMesh(geometry, material, MAX_HIGHLIGHTS);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.renderOrder = 1;
    this.mesh.count = 0;
  }

  /** Tô ô đang chọn (vàng) + mọi ô đích hợp lệ của quân đang chọn, màu theo loại nước đi (PLAN 11.2). */
  sync(state: GameState, selection: Selection | null): void {
    let i = 0;
    const put = (cell: { readonly q: number; readonly r: number }, color: number): void => {
      if (i >= MAX_HIGHLIGHTS) return;
      const center = cellCenter(cell);
      tmpMatrix.makeTranslation(center.x, Y_OFFSET, center.z);
      this.mesh.setMatrixAt(i, tmpMatrix);
      tmpColor.setHex(color);
      this.mesh.setColorAt(i, tmpColor);
      i++;
    };

    if (selection !== null) {
      const selected = state.pieces.find((p) => p.id === selection.pieceId);
      if (selected !== undefined) put(selected.cell, HIGHLIGHT.selected);
      for (const move of selection.moves.values()) put(move.to, colorFor(classifyMove(state, move)));
    }

    this.mesh.count = i;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor !== null) this.mesh.instanceColor.needsUpdate = true;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
  }
}
