// Hình khối quân cờ, dựng bằng code từ khối hình học cơ bản (PLAN 12.3: "giai đoạn đầu dựng bằng code… sau đó
// thay bằng glTF nếu có hoạ sĩ"). Mỗi loại quân là MỘT BufferGeometry (gộp từ nhiều khối) để vẽ bằng một
// InstancedMesh mỗi loại (PLAN 6.6: hiệu năng). Đế quân ở y = 0 (đứng trên mặt ô, xem layout.ts), quân cao dần
// theo trục y. Không tải model ngoài ở M3; `PieceModelRegistry` (glTF + fallback) là việc của M10.
import * as THREE from 'three';
import { mergeGeometries } from 'three/addons/utils/BufferGeometryUtils.js';
import type { PieceType } from '@hexwar/rules';

/** Bán kính đế và chiều cao xấp xỉ của mỗi loại quân — dùng cho picking (picking.ts) và bố cục camera. */
export const PIECE_FOOTPRINT: Readonly<Record<PieceType, { readonly radius: number; readonly height: number }>> = {
  P: { radius: 0.24, height: 0.42 },
  N: { radius: 0.28, height: 0.67 },
  B: { radius: 0.24, height: 0.72 },
  R: { radius: 0.3, height: 0.6 },
  Q: { radius: 0.28, height: 0.94 },
  K: { radius: 0.28, height: 0.98 },
  J: { radius: 0.26, height: 0.72 },
};

/** Dịch/xoay một khối MỚI TẠO tại chỗ (không alias — mỗi lời gọi truyền một geometry dùng đúng một lần). */
function part(geometry: THREE.BufferGeometry, opts: { x?: number; y?: number; z?: number; rx?: number; ry?: number; rz?: number } = {}): THREE.BufferGeometry {
  const m = new THREE.Matrix4();
  const euler = new THREE.Euler(opts.rx ?? 0, opts.ry ?? 0, opts.rz ?? 0);
  m.compose(new THREE.Vector3(opts.x ?? 0, opts.y ?? 0, opts.z ?? 0), new THREE.Quaternion().setFromEuler(euler), new THREE.Vector3(1, 1, 1));
  geometry.applyMatrix4(m);
  return geometry;
}

function merge(parts: readonly THREE.BufferGeometry[]): THREE.BufferGeometry {
  const merged = mergeGeometries(parts, false);
  if (merged === null) throw new Error('mergeGeometries: không gộp được (thuộc tính đỉnh không khớp)');
  for (const p of parts) p.dispose();
  merged.computeVertexNormals();
  return merged;
}

/** Đế hình trụ dùng chung cho mọi loại quân (thân chính). */
function base(radiusTop: number, radiusBottom: number, height: number, y: number, segments = 16): THREE.BufferGeometry {
  const g = new THREE.CylinderGeometry(radiusTop, radiusBottom, height, segments);
  g.translate(0, y + height / 2, 0);
  return g;
}

function ring(count: number, radius: number, y: number, make: () => THREE.BufferGeometry): THREE.BufferGeometry[] {
  const out: THREE.BufferGeometry[] = [];
  for (let i = 0; i < count; i++) {
    const angle = (Math.PI * 2 * i) / count;
    out.push(part(make(), { x: Math.cos(angle) * radius, z: Math.sin(angle) * radius, y }));
  }
  return out;
}

// ---- Tốt: thân tròn thấp, đầu bán cầu (PLAN 12.3) ------------------------------------------------------------
function pawn(): THREE.BufferGeometry {
  const body = base(0.14, 0.2, 0.28, 0);
  const head = part(new THREE.SphereGeometry(0.13, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), { y: 0.28 });
  return merge([body, head]);
}

// ---- Mã: dáng chữ L nghiêng gợi đầu ngựa (thay cho mô hình đầu ngựa chi tiết, để ở M10) -------------------
function knight(): THREE.BufferGeometry {
  const body = base(0.16, 0.22, 0.3, 0);
  const neck = part(new THREE.BoxGeometry(0.14, 0.34, 0.16), { y: 0.42, rz: -0.35 });
  const head = part(new THREE.BoxGeometry(0.24, 0.14, 0.14), { x: 0.14, y: 0.58, rz: -0.1 });
  return merge([body, neck, head]);
}

// ---- Tượng: mũ nhọn có khe (PLAN 12.3) --------------------------------------------------------------------
function bishop(): THREE.BufferGeometry {
  const body = base(0.15, 0.21, 0.34, 0);
  const mitre = part(new THREE.ConeGeometry(0.16, 0.32, 14), { y: 0.5 });
  const slit = part(new THREE.BoxGeometry(0.03, 0.16, 0.2), { y: 0.62 });
  return merge([body, mitre, slit]);
}

// ---- Xe: tháp có răng cưa (PLAN 12.3) ----------------------------------------------------------------------
function rook(): THREE.BufferGeometry {
  const body = base(0.22, 0.24, 0.42, 0);
  const rim = base(0.24, 0.24, 0.06, 0.42, 10);
  const teeth = ring(6, 0.2, 0.48, () => new THREE.BoxGeometry(0.09, 0.1, 0.09));
  return merge([body, rim, ...teeth]);
}

// ---- Hậu: vương miện nhiều mũi (PLAN 12.3) -----------------------------------------------------------------
function queen(): THREE.BufferGeometry {
  const body = base(0.18, 0.24, 0.5, 0);
  const collar = base(0.2, 0.16, 0.08, 0.5, 14);
  const spikes = ring(7, 0.13, 0.58, () => new THREE.ConeGeometry(0.045, 0.22, 8));
  const orb = part(new THREE.SphereGeometry(0.07, 10, 8), { y: 0.85 });
  return merge([body, collar, ...spikes, orb]);
}

// ---- Vua: vương miện có thập tự (PLAN 12.3) ----------------------------------------------------------------
function king(): THREE.BufferGeometry {
  const body = base(0.19, 0.25, 0.52, 0);
  const collar = base(0.21, 0.17, 0.08, 0.52, 14);
  const crownBase = base(0.14, 0.18, 0.14, 0.6, 12);
  const crossV = part(new THREE.BoxGeometry(0.05, 0.22, 0.05), { y: 0.85 });
  const crossH = part(new THREE.BoxGeometry(0.16, 0.05, 0.05), { y: 0.82 });
  return merge([body, collar, crownBase, crossV, crossH]);
}

// ---- Hề: mũ ba chóp có chuông (PLAN 12.3) ------------------------------------------------------------------
function jester(): THREE.BufferGeometry {
  const body = base(0.17, 0.22, 0.36, 0);
  const capBase = base(0.15, 0.17, 0.1, 0.36, 12);
  const points = ring(3, 0.09, 0.44, () => new THREE.ConeGeometry(0.06, 0.22, 8));
  const bells = ring(3, 0.09, 0.66, () => new THREE.SphereGeometry(0.035, 8, 6));
  return merge([body, capBase, ...points, ...bells]);
}

const BUILDERS: Readonly<Record<PieceType, () => THREE.BufferGeometry>> = { P: pawn, N: knight, B: bishop, R: rook, Q: queen, K: king, J: jester };

/** Dựng hình khối của một loại quân. Gọi một lần mỗi loại (7 lần cho cả ván) rồi dùng chung cho InstancedMesh. */
export function createPieceGeometry(type: PieceType): THREE.BufferGeometry {
  return BUILDERS[type]();
}

/** Hình khối co lại còn 40% cho tù binh (PLAN 12.3: "đứng chung ô nhưng thấp hơn quân giữ"). */
export const CAPTIVE_SCALE = 0.55;
