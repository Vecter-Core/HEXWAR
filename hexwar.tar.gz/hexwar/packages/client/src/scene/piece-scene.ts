// Vẽ quân cờ bằng một InstancedMesh MỖI LOẠI (PLAN 6.6: tối đa 108 quân, 7 loại). Mỗi khung hình, đọc lại toàn bộ
// `DisplayModel` (vị trí đã "ổn định") và ghi đè bằng `AnimationDirector.motions()` (vị trí/độ nâng/co giãn/độ sáng
// tạm thời trong lúc một bước hoạt ảnh đang chạy) — đúng hợp đồng ở animation.ts: mô hình chỉ đổi khi bước xong.
import * as THREE from 'three';
import { PIECE_TYPES, type PieceType } from '@hexwar/rules';
import type { Motion } from '../core/animation';
import type { PieceView } from '../core/display-model';
import { cellCenter } from '../core/layout';
import { captiveColor, seatColor } from '../core/palette';
import type { PickablePiece } from '../core/picking';
import { CAPTIVE_SCALE, PIECE_FOOTPRINT, createPieceGeometry } from './piece-geometry';

/** Giới hạn an toàn: 108 quân trên bàn, phong cấp dồn hết vào một loại vẫn không tràn (trường hợp cực đoan). */
const MAX_PER_TYPE = 108;

const tmpMatrix = new THREE.Matrix4();
const tmpPos = new THREE.Vector3();
const tmpQuat = new THREE.Quaternion();
const tmpScale = new THREE.Vector3();
const tmpColor = new THREE.Color();
const WHITE = new THREE.Color(0xffffff);

export class PieceScene {
  readonly group = new THREE.Group();
  private readonly meshes: Record<PieceType, THREE.InstancedMesh>;

  constructor() {
    const meshes = {} as Record<PieceType, THREE.InstancedMesh>;
    for (const type of PIECE_TYPES) {
      const geometry = createPieceGeometry(type);
      // KHÔNG đặt `vertexColors: true`: cờ đó bật luôn `USE_COLOR` (đọc thuộc tính `color` theo TỪNG ĐỈNH của
      // geometry, thứ ta không có) và nhân nó vào TRƯỚC màu theo từng-instance — vì thuộc tính đó không tồn tại,
      // WebGL trả về (0,0,0) mặc định nên toàn bộ hoá đen. Màu theo instance (`setColorAt`) tự bật USE_INSTANCING_COLOR
      // độc lập, không cần cờ này (xem three/src/renderers/webgl/WebGLPrograms.js: instancingColor).
      const material = new THREE.MeshStandardMaterial({ roughness: 0.45, metalness: 0.2 });
      const mesh = new THREE.InstancedMesh(geometry, material, MAX_PER_TYPE);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.count = 0;
      this.group.add(mesh);
      meshes[type] = mesh;
    }
    this.meshes = meshes;
  }

  /** Cập nhật mọi instance từ mô hình + hoạt ảnh hiện tại. Trả về danh sách quân để `picking.ts` dùng ở khung kế. */
  sync(pieces: readonly PieceView[], motions: ReadonlyMap<string, Motion>): PickablePiece[] {
    const perType = new Map<PieceType, PieceView[]>(PIECE_TYPES.map((t) => [t, []]));
    for (const piece of pieces) perType.get(piece.type)?.push(piece);

    const picks: PickablePiece[] = [];
    for (const type of PIECE_TYPES) {
      const mesh = this.meshes[type];
      const list = perType.get(type) ?? [];
      const footprint = PIECE_FOOTPRINT[type];
      list.forEach((piece, i) => {
        const base = cellCenter(piece.cell);
        const motion = motions.get(piece.id);
        const x = motion?.pos?.x ?? base.x;
        const z = motion?.pos?.z ?? base.z;
        const lift = motion?.lift ?? 0;
        const baseScale = piece.status === 'captive' ? CAPTIVE_SCALE : 1;
        const scale = baseScale * (motion?.scale ?? 1);
        tmpPos.set(x, base.y + lift, z);
        tmpQuat.identity();
        tmpScale.set(scale, scale, scale);
        tmpMatrix.compose(tmpPos, tmpQuat, tmpScale);
        mesh.setMatrixAt(i, tmpMatrix);

        tmpColor.setHex(piece.status === 'captive' ? captiveColor(piece.owner) : seatColor(piece.owner));
        const glow = motion?.glow ?? 0;
        if (glow > 0) tmpColor.lerp(WHITE, Math.min(1, glow) * 0.6);
        mesh.setColorAt(i, tmpColor);

        picks.push({ id: piece.id, cell: piece.cell, x, z, radius: footprint.radius, height: footprint.height * scale });
      });
      mesh.count = list.length;
      mesh.instanceMatrix.needsUpdate = true;
      if (mesh.instanceColor !== null) mesh.instanceColor.needsUpdate = true;
    }
    return picks;
  }

  /** M10 (PLAN 12.5 "Vừa: bóng mềm cho quân"): bật/tắt đổ bóng của quân theo mức đồ hoạ. Quân không cần NHẬN bóng
   * (đứng trên ô, ô mới là thứ nhận bóng — xem `board-scene.ts::applyGraphicsProfile`). */
  setCastShadow(enabled: boolean): void {
    for (const type of PIECE_TYPES) this.meshes[type].castShadow = enabled;
  }

  dispose(): void {
    for (const type of PIECE_TYPES) {
      const mesh = this.meshes[type];
      mesh.geometry.dispose();
      (mesh.material as THREE.Material).dispose();
    }
  }
}
