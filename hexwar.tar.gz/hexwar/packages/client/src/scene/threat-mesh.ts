// X-06: tô đỏ mờ các ô có quân của mình đang bị đe doạ (PLAN 11.2, 12.2 "vẽ bằng lớp phủ instanced riêng").
// InstancedMesh RIÊNG với highlight-mesh.ts (đó là nước-đi-của-quân-đang-chọn; đây là đe-doạ-lên-toàn-bộ-quân-mình),
// để hai lớp không tranh màu/giẫm lên nhau khi cả hai cùng hiện (quân đang chọn cũng có thể đang bị đe doạ).
import * as THREE from 'three';
import { cellKey, type GameState } from '@hexwar/rules';
import type { ThreatInfo } from '../core/threats';
import { cellCenter } from '../core/layout';
import { createHighlightGeometry } from './hex-geometry';

const MAX_THREATS = 108; // tối đa 18 quân/ghế đều bị đe doạ cùng lúc
const Y_OFFSET = 0.02; // nhích cao hơn highlight-mesh (0.01) một chút để không bị chớp hình
const THREAT_COLOR = 0xff2d3d;

const tmpMatrix = new THREE.Matrix4();
const tmpColor = new THREE.Color();

export class ThreatMesh {
  readonly mesh: THREE.InstancedMesh;

  constructor() {
    const geometry = createHighlightGeometry(0.8);
    const material = new THREE.MeshBasicMaterial({ transparent: true, opacity: 0.5, side: THREE.DoubleSide, depthWrite: false });
    this.mesh = new THREE.InstancedMesh(geometry, material, MAX_THREATS);
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.renderOrder = 1;
    this.mesh.count = 0;
  }

  /** `threats.cellKeys` chỉ là tập khoá; lấy toạ độ thật bằng cách quét quân hoạt động của `state` (không cần bảng tra ngược). */
  sync(state: GameState, threats: ThreatInfo): void {
    let i = 0;
    if (threats.cellKeys.size > 0) {
      for (const piece of state.pieces) {
        if (i >= MAX_THREATS) break;
        if (piece.status !== 'active' || !threats.cellKeys.has(cellKey(piece.cell))) continue;
        const center = cellCenter(piece.cell);
        tmpMatrix.makeTranslation(center.x, Y_OFFSET, center.z);
        this.mesh.setMatrixAt(i, tmpMatrix);
        tmpColor.setHex(THREAT_COLOR);
        this.mesh.setColorAt(i, tmpColor);
        i++;
      }
    }
    this.mesh.count = i;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor !== null) this.mesh.instanceColor.needsUpdate = true;
  }

  dispose(): void {
    this.mesh.geometry.dispose();
    (this.mesh.material as THREE.Material).dispose();
  }
}
