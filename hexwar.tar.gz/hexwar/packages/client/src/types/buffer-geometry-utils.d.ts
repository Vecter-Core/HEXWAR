// three không kèm khai báo kiểu cho các addon dạng .js (chỉ có .d.ts cho module lõi). Khai riêng đúng những gì dùng
// ở src/scene, thay vì `any` (CLAUDE.md: TypeScript strict, không any).
declare module 'three/addons/utils/BufferGeometryUtils.js' {
  import type { BufferGeometry } from 'three';

  export function mergeGeometries(geometries: readonly BufferGeometry[], useGroups?: boolean): BufferGeometry | null;
}
