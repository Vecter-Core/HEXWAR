// M3: đạo diễn hoạt ảnh (PLAN 6.1 nguyên tắc 5, 12.4). Sự kiện chạy tuần tự, mô hình chỉ đổi khi bước kết thúc,
// kết quả cuối luôn khớp engine bất kể tốc độ / nhịp khung hình.
import { describe, expect, it } from 'vitest';
import { applyMove, createPiece, makeState, createRng, type GameEvent, type Piece } from '@hexwar/rules';
import { AnimationDirector, DURATION } from '../src/core/animation';
import { DisplayModel } from '../src/core/display-model';
import { cellCenter } from '../src/core/layout';
import { SIM_CONFIGS, playGame } from './simulate';

const P = (id: string, owner: 0 | 1 | 2, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });
const duel = () =>
  makeState({
    seats: [0, 1, 2],
    pieces: [P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
  });

describe('AnimationDirector: nước đi và ăn quân', () => {
  it('mô hình chỉ đổi khi bước kết thúc; giữa chừng quân bị bẻ theo đường đi từ ô đi tới ô đến', () => {
    const before = duel();
    const { events } = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    const model = DisplayModel.fromState(before);
    const director = new AnimationDirector(model);
    director.enqueue(events);

    director.update(0.01); // bước MOVED bắt đầu
    expect(director.currentEvent?.type).toBe('MOVED');
    expect(model.get('r0')?.cell).toEqual({ q: 0, r: 0 }); // chưa đổi
    const start = director.motions().get('r0')?.pos;
    expect(start?.x).toBeCloseTo(0, 1);

    const moveDuration = DURATION.moveBase + DURATION.movePerCell * 3;
    director.update(moveDuration / 2 - 0.01); // ~ giữa bước
    const mid = director.motions().get('r0')?.pos;
    const target = cellCenter({ q: 3, r: 0 });
    expect(mid?.x).toBeGreaterThan(0.2 * target.x);
    expect(mid?.x).toBeLessThan(0.8 * target.x);

    director.update(moveDuration); // xong MOVED, sang CAPTURED
    expect(model.get('r0')?.cell).toEqual({ q: 3, r: 0 });
    expect(director.currentEvent?.type).toBe('CAPTURED');
    expect(director.effects()).toMatchObject([{ kind: 'impact', cell: { q: 3, r: 0 } }]);
  });

  it('Mã nhảy cung (lift > 0 giữa bước), Xe lướt sát mặt bàn (lift = 0)', () => {
    const state = makeState({ seats: [0, 1, 2], pieces: [P('k0', 0, 'K', -20, 20), P('n0', 0, 'N', 0, 0), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)] });
    const { events } = applyMove(state, { pieceId: 'n0', to: { q: 1, r: -3 } });
    const knight = new AnimationDirector(DisplayModel.fromState(state));
    knight.enqueue(events);
    knight.update(0.2);
    expect(knight.motions().get('n0')?.lift ?? 0).toBeGreaterThan(0.3);

    const rook = duel();
    const rookEvents = applyMove(rook, { pieceId: 'r0', to: { q: 1, r: 0 } }).events;
    const d2 = new AnimationDirector(DisplayModel.fromState(rook));
    d2.enqueue(rookEvents);
    d2.update(0.1);
    expect(d2.motions().get('r0')?.lift ?? 0).toBe(0);
  });

  it('các sự kiện chạy đúng thứ tự, mỗi sự kiện đúng một lần bắt đầu và một lần kết thúc', () => {
    const before = duel();
    const { events } = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    const started: string[] = [];
    const done: string[] = [];
    const director = new AnimationDirector(DisplayModel.fromState(before), {
      onStart: (e) => started.push(e.type),
      onDone: (e) => done.push(e.type),
    });
    director.enqueue(events);
    for (let i = 0; i < 500 && director.busy; i++) director.update(1 / 60);
    expect(director.busy).toBe(false);
    expect(started).toEqual(events.map((e) => e.type));
    expect(done).toEqual(events.map((e) => e.type));
  });

  it('thời lượng: nước đi thường không quá 1,2 giây ở 1× (PLAN 12.4); tốc độ 2× chạy xong trong nửa thời gian', () => {
    const before = duel();
    const { events } = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    const total = (speed: number): number => {
      const director = new AnimationDirector(DisplayModel.fromState(before));
      director.setSpeed(speed);
      director.enqueue(events);
      let t = 0;
      while (director.busy && t < 60) {
        director.update(1 / 120);
        t += 1 / 120;
      }
      return t;
    };
    const normal = total(1);
    const fast = total(2);
    expect(normal).toBeGreaterThan(0.3);
    expect(fast).toBeCloseTo(normal / 2, 1);
    expect(DURATION.moveMax).toBeLessThanOrEqual(1.2);
    for (const value of Object.values(DURATION)) expect(value).toBeGreaterThanOrEqual(0);
  });

  it('bỏ qua hoạt ảnh (Infinity): áp dụng ngay, không bận; flush() hoàn tất phần đang dở', () => {
    const before = duel();
    const { events, state } = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    const model = DisplayModel.fromState(before);
    const director = new AnimationDirector(model);
    director.enqueue(events);
    director.update(0.05);
    expect(director.busy).toBe(true);
    director.flush();
    expect(director.busy).toBe(false);
    expect(director.motions().size).toBe(0);
    expect(model.reconcile(state)).toEqual([]);

    const instant = new AnimationDirector(DisplayModel.fromState(before));
    instant.setSpeed(Number.POSITIVE_INFINITY);
    instant.enqueue(events);
    expect(instant.busy).toBe(false);
    expect(instant.model.reconcile(state)).toEqual([]);
  });

  it('tham số không hợp lệ bị từ chối; dt âm hoặc 0 không làm gì', () => {
    const director = new AnimationDirector(DisplayModel.fromState(duel()));
    expect(() => director.setSpeed(0)).toThrowError(RangeError);
    expect(() => director.setSpeed(-1)).toThrowError(RangeError);
    director.update(-5);
    director.update(0);
    expect(director.busy).toBe(false);
  });
});

describe('AnimationDirector: kết quả cuối khớp engine trên ván mô phỏng (mọi nhịp khung hình)', () => {
  const cadences: Array<[string, (rng: ReturnType<typeof createRng>) => number]> = [
    ['60 fps đều', () => 1 / 60],
    ['nhịp thất thường (giật, treo tab)', (rng) => (rng.int(10) === 0 ? 3 + rng.next() * 5 : rng.next() * 0.05)],
  ];
  for (const [label, dtOf] of cadences) {
    it(`${label}: sau khi hoạt ảnh xong, mô hình khớp trạng thái và mọi sự kiện được xử lý đúng một lần`, () => {
      for (const [name, config] of Object.entries(SIM_CONFIGS)) {
        const rng = createRng(11);
        let director: AnimationDirector | null = null;
        let expected = 0;
        let handled = 0;
        playGame(2, config, ({ before, result }) => {
          director ??= new AnimationDirector(DisplayModel.fromState(before), { onDone: () => handled++ });
          director.enqueue(result.events);
          expected += result.events.length;
          // Chạy hoạt ảnh xen kẽ với ván, giống vòng lặp vẽ: có lúc chưa kịp xong đã có hành động mới.
          for (let i = 0; i < 3; i++) director.update(dtOf(rng));
          if (result.state.phase !== 'playing') {
            director.flush();
            expect(director.model.reconcile(result.state), name).toEqual([]);
          }
        });
        expect(handled, name).toBe(expected);
      }
    });
  }

  it('tất định: cùng chuỗi sự kiện và cùng nhịp khung hình cho cùng chuỗi chuyển động', () => {
    const record = (): string[] => {
      const out: string[] = [];
      const rng = createRng(3);
      let director: AnimationDirector | null = null;
      playGame(1, SIM_CONFIGS['R=16 lịch thưa'] ?? (undefined as never), ({ before, result }) => {
        director ??= new AnimationDirector(DisplayModel.fromState(before));
        director.enqueue(result.events);
        director.update(rng.next() * 0.3);
        out.push(JSON.stringify([...director.motions()]) + JSON.stringify(director.effects()));
      });
      return out;
    };
    expect(record()).toEqual(record());
  });
});

describe('AnimationDirector: sự kiện đặc biệt', () => {
  it('loại người chơi: các quân biến mất so le trong khoảng 0,6–1,2 giây; thu hẹp: quân trên vòng rơi', () => {
    const elim: GameEvent = { type: 'PLAYER_ELIMINATED', seat: 1, reason: 'king', removedPieceIds: ['a', 'b', 'c', 'd'] };
    const state = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), P('a', 1, 'R', 1, 0), P('b', 1, 'R', 2, 0), P('c', 1, 'R', 3, 0), P('d', 1, 'R', 4, 0), P('k2', 2, 'K', 20, -20)],
    });
    const director = new AnimationDirector(DisplayModel.fromState(state));
    director.enqueue([elim]);
    director.update(0.35);
    const scales = ['a', 'b', 'c', 'd'].map((id) => director.motions().get(id)?.scale ?? 1);
    expect(scales[0]).toBeLessThan(scales[3] ?? 0); // quân đầu tan trước quân cuối
    director.update(2);
    expect(director.model.size).toBe(2);

    const collapse: GameEvent = { type: 'RING_COLLAPSED', round: 50, ring: 24, radius: 23, removedPieceIds: ['k0'] };
    const d2 = new AnimationDirector(DisplayModel.fromState(state));
    d2.enqueue([collapse]);
    d2.update(DURATION.ringCollapsed / 2);
    expect(d2.motions().get('k0')?.lift ?? 0).toBeLessThan(-1);
    expect(d2.effects()).toMatchObject([{ kind: 'collapse', ring: 24 }]);
    d2.update(DURATION.ringCollapsed);
    expect(d2.model.radius).toBe(23);
    expect(d2.model.get('k0')).toBeUndefined();
  });
});

describe('AnimationDirector: hiệu ứng M10 (PLAN 12.4) cho tù binh hết hạn / phong cấp / hồi sinh Hề-Vua', () => {
  it('CAPTIVE_EXPIRED phát hiệu ứng dissolve tại đúng ô của quân', () => {
    const state = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), P('b', 1, 'R', 2, 0), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
    });
    const event: GameEvent = { type: 'CAPTIVE_EXPIRED', pieceId: 'b', owner: 1, holder: 0, cell: { q: 2, r: 0 } };
    const director = new AnimationDirector(DisplayModel.fromState(state));
    director.enqueue([event]);
    director.update(0.01);
    expect(director.effects()).toMatchObject([{ kind: 'dissolve', cell: { q: 2, r: 0 } }]);
  });

  it('PROMOTED phát hiệu ứng promote tại ô hiện tại của quân (không cần MOVED kèm theo)', () => {
    const state = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), P('p0', 0, 'P', 5, 1), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
    });
    const event: GameEvent = { type: 'PROMOTED', pieceId: 'p0', owner: 0, from: 'P', to: 'N', kills: 6 };
    const director = new AnimationDirector(DisplayModel.fromState(state));
    director.enqueue([event]);
    director.update(0.01);
    expect(director.effects()).toMatchObject([{ kind: 'promote', cell: { q: 5, r: 1 } }]);
  });

  it('JESTER_REVIVED phát hiệu ứng beam nối đúng ô Vua cũ (from) và ô Hề (to)', () => {
    const state = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', 0, 0), P('j0', 0, 'J', 2, -1), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
    });
    const event: GameEvent = { type: 'JESTER_REVIVED', kingId: 'k0', jesterId: 'j0', owner: 0, from: { q: 0, r: 0 }, to: { q: 2, r: -1 }, cause: 'capture' };
    const director = new AnimationDirector(DisplayModel.fromState(state));
    director.enqueue([event]);
    director.update(0.01);
    expect(director.effects()).toMatchObject([{ kind: 'beam', from: { q: 0, r: 0 }, to: { q: 2, r: -1 } }]);
  });
});
