// M10 (PLAN 12.6): bảng tần số/thời lượng hiệu ứng âm thanh + ánh xạ sự kiện engine → hiệu ứng — thuần, không
// dựng AudioContext (đó là việc của net/audio-manager.ts, chỉ kiểm bằng Playwright/thủ công vì cần trình duyệt thật).
import { describe, expect, it } from 'vitest';
import type { GameEvent } from '@hexwar/rules';
import { AMBIENCE, SFX_CUES, sfxForEvent, type SfxId } from '../src/core/audio-cues';

const SFX_IDS = Object.keys(SFX_CUES) as SfxId[];

describe('SFX_CUES', () => {
  it('mọi hiệu ứng có ít nhất một nốt/tiếng động, thời lượng và độ trễ không âm', () => {
    for (const id of SFX_IDS) {
      const cues = SFX_CUES[id];
      expect(cues.length).toBeGreaterThan(0);
      for (const cue of cues) {
        expect(cue.delay).toBeGreaterThanOrEqual(0);
        expect(cue.duration).toBeGreaterThan(0);
        expect(cue.gain).toBeGreaterThan(0);
        expect(cue.gain).toBeLessThanOrEqual(1);
      }
    }
  });

  it('bao phủ đúng danh sách hiệu ứng PLAN 12.6 (chọn quân, đi, ăn, tù binh, phong cấp, hồi sinh, đếm ngược, thu hẹp, xúc xắc, tin nhắn, kết thúc)', () => {
    const expected: SfxId[] = ['select', 'move', 'capture', 'captive', 'promote', 'revive', 'tick', 'collapse', 'dice', 'chat', 'gameEnd'];
    for (const id of expected) expect(SFX_CUES[id]).toBeDefined();
  });
});

describe('sfxForEvent', () => {
  const cell = { q: 0, r: 0 };

  it('ánh xạ đúng các sự kiện engine chính sang hiệu ứng PLAN 12.6', () => {
    const cases: [GameEvent, SfxId | null][] = [
      [{ type: 'MOVED', pieceId: 'a', seat: 0, from: cell, to: cell, conscript: false }, 'move'],
      [{ type: 'CAPTURED', attackerId: 'a', victimId: 'b', seat: 0, victimOwner: 1, cell, conscript: false }, 'capture'],
      [{ type: 'KING_CAPTURED', kingId: 'k', owner: 1, by: 0, cell }, 'kingHit'],
      [{ type: 'CAPTIVE_CREATED', pieceId: 'b', owner: 1, holder: 0, cell }, 'captive'],
      [{ type: 'CAPTIVE_CONSCRIPTED', pieceId: 'b', owner: 1, holder: 0 }, 'captive'],
      [{ type: 'PROMOTED', pieceId: 'a', owner: 0, from: 'P', to: 'N', kills: 6 }, 'promote'],
      [{ type: 'JESTER_REVIVED', kingId: 'k', jesterId: 'j', owner: 0, from: cell, to: cell, cause: 'capture' }, 'revive'],
      [{ type: 'RING_COLLAPSED', round: 50, ring: 24, radius: 23, removedPieceIds: [] }, 'collapse'],
      [{ type: 'DICE_ROLLED', attempt: 1, rolls: [{ seat: 0, dice: [1, 2, 3], total: 6 }], winner: 0 }, 'dice'],
      [{ type: 'PLAYER_ELIMINATED', seat: 0, reason: 'king', removedPieceIds: [] }, 'eliminated'],
      [{ type: 'GAME_OVER', reason: 'lastKing', winner: 0, ranking: [] }, 'gameEnd'],
    ];
    for (const [event, expected] of cases) expect(sfxForEvent(event)).toBe(expected);
  });

  it('sự kiện không có âm thanh riêng trả về null (không ném lỗi)', () => {
    const noSound: GameEvent[] = [
      { type: 'ROUND_STARTED', round: 2 },
      { type: 'TURN_STARTED', seat: 0, round: 2 },
      { type: 'TURN_SKIPPED', seat: 0, reason: 'timeout' },
      { type: 'RING_WARNING', ring: 24, level: 'yellow', roundsLeft: 3 },
    ];
    for (const event of noSound) expect(sfxForEvent(event)).toBeNull();
  });
});

describe('AMBIENCE (PLAN 12.6 "nhạc nền theo pha")', () => {
  it('có đủ 3 pha, mỗi pha có tần số và âm lượng dương', () => {
    for (const phase of ['normal', 'tense', 'end'] as const) {
      expect(AMBIENCE[phase].freq).toBeGreaterThan(0);
      expect(AMBIENCE[phase].gain).toBeGreaterThan(0);
    }
  });

  it('"căng thẳng" nhịp nhanh hơn "bình thường" (cảm giác gấp gáp khi vòng sắp biến mất)', () => {
    expect(AMBIENCE.tense.beatHz).toBeGreaterThan(AMBIENCE.normal.beatHz);
  });
});
