// M10 (PLAN 12.3): hình học 6 biểu tượng đế quân — thuần THREE trên CPU (gộp/đùn không cần WebGL), kiểm bất biến
// dựng hình giống `piece-geometry.test.ts`: không vỡ, nằm quanh gốc, bán kính đúng khai báo, không NaN/Infinity.
import type * as THREE from 'three';
import { describe, expect, it } from 'vitest';
import { BADGE_SHAPES } from '../src/core/badge';
import { BADGE_HEIGHT, createBadgeGeometry } from '../src/scene/badge-geometry';

function bounds(geometry: THREE.BufferGeometry): { minY: number; maxY: number; maxRadius: number; vertexCount: number } {
  const pos = geometry.getAttribute('position');
  let minY = Number.POSITIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  let maxRadius = 0;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
    maxRadius = Math.max(maxRadius, Math.hypot(x, z));
  }
  return { minY, maxY, maxRadius, vertexCount: pos.count };
}

const RADIUS = 0.34;

describe('createBadgeGeometry: mỗi hình dựng được, phẳng, đúng bán kính khai báo', () => {
  it.each(BADGE_SHAPES)('%s: có hình khối thật (không suy biến), nằm trong bán kính khai báo', (shape) => {
    const geometry = createBadgeGeometry(shape, RADIUS);
    const { maxRadius, vertexCount, minY, maxY } = bounds(geometry);
    expect(vertexCount).toBeGreaterThan(6);
    expect(maxRadius).toBeLessThanOrEqual(RADIUS + 1e-6);
    expect(maxY - minY).toBeCloseTo(BADGE_HEIGHT, 6);
    geometry.dispose();
  });

  it('không có toạ độ NaN/Infinity', () => {
    for (const shape of BADGE_SHAPES) {
      const pos = createBadgeGeometry(shape, RADIUS).getAttribute('position');
      for (let i = 0; i < pos.count; i++) {
        expect(Number.isFinite(pos.getX(i))).toBe(true);
        expect(Number.isFinite(pos.getY(i))).toBe(true);
        expect(Number.isFinite(pos.getZ(i))).toBe(true);
      }
    }
  });

  it('tất định: gọi lại cùng một hình luôn ra hình khối giống hệt', () => {
    for (const shape of BADGE_SHAPES) {
      const a = Array.from(createBadgeGeometry(shape, RADIUS).getAttribute('position').array);
      const b = Array.from(createBadgeGeometry(shape, RADIUS).getAttribute('position').array);
      expect(a).toEqual(b);
    }
  });

  it('6 hình khác nhau cho ra 6 tập đỉnh khác nhau (không phải cùng một hình vẽ lại)', () => {
    const signatures = BADGE_SHAPES.map((shape) => JSON.stringify(Array.from(createBadgeGeometry(shape, RADIUS).getAttribute('position').array.slice(0, 12))));
    expect(new Set(signatures).size).toBe(BADGE_SHAPES.length);
  });
});
