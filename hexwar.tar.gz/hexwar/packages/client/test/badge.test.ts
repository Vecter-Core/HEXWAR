// M10 (PLAN 12.3, 11.5): ánh xạ ghế → biểu tượng đế quân — thuần, không THREE.
import { describe, expect, it } from 'vitest';
import { SEATS } from '@hexwar/rules';
import { BADGE_SHAPES, badgeShapeForSeat } from '../src/core/badge';

describe('badgeShapeForSeat', () => {
  it('đúng 6 hình, đúng thứ tự PLAN 12.3 (tròn, tam giác, vuông, thoi, sao, lục giác)', () => {
    expect(BADGE_SHAPES).toEqual(['circle', 'triangle', 'square', 'diamond', 'star', 'hexagon']);
  });

  it('mỗi ghế 0..5 có một hình riêng, không trùng nhau (PLAN 11.5: không phụ thuộc màu để phân biệt)', () => {
    const shapes = SEATS.map((s) => badgeShapeForSeat(s));
    expect(new Set(shapes).size).toBe(6);
  });

  it('tất định: gọi lại nhiều lần cho cùng một ghế luôn ra cùng một hình', () => {
    for (const seat of SEATS) expect(badgeShapeForSeat(seat)).toBe(badgeShapeForSeat(seat));
  });
});
