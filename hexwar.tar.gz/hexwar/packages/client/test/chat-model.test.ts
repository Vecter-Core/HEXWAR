import { describe, expect, it } from 'vitest';
import type { ChatMessage } from '@hexwar/protocol';
import { isHiddenBySeatFilter, seatOfTab, tabIdFor, targetForTab, whisperTabId } from '../src/core/chat-model';

function textMsg(overrides: Partial<ChatMessage> & Pick<ChatMessage, 'channel' | 'from'>): ChatMessage {
  return { type: 'chat.message', id: 'x', at: 0, kind: 'text', text: 'hi', ...overrides } as ChatMessage;
}

describe('tabIdFor', () => {
  it('kênh all/dead luôn về đúng một tab cố định', () => {
    expect(tabIdFor(textMsg({ channel: 'all', from: 2 }), 0)).toBe('all');
    expect(tabIdFor(textMsg({ channel: 'dead', from: 2 }), 0)).toBe('dead');
  });

  it('whisper nhóm theo NGƯỜI CÒN LẠI, không theo hướng gửi/nhận (PLAN 8.2)', () => {
    // Mình (ghế 0) nhận tin từ ghế 3: tab là "phía bên kia" = 3.
    expect(tabIdFor(textMsg({ channel: 'whisper', from: 3, to: 0 }), 0)).toBe(whisperTabId(3));
    // Mình (ghế 0) tự gửi cho ghế 3 (tin vọng lại cho chính mình): tab vẫn là 3, không phải 0.
    expect(tabIdFor(textMsg({ channel: 'whisper', from: 0, to: 3 }), 0)).toBe(whisperTabId(3));
  });
});

describe('seatOfTab / targetForTab', () => {
  it('lấy lại đúng ghế từ id tab whisper; null cho all/dead', () => {
    expect(seatOfTab(whisperTabId(4))).toBe(4);
    expect(seatOfTab('all')).toBeNull();
    expect(seatOfTab('dead')).toBeNull();
  });

  it('suy đúng nơi gửi (channel + to) từ tab đang mở', () => {
    expect(targetForTab('all')).toEqual({ channel: 'all' });
    expect(targetForTab('dead')).toEqual({ channel: 'dead' });
    expect(targetForTab(whisperTabId(5))).toEqual({ channel: 'whisper', to: 5 });
  });
});

describe('isHiddenBySeatFilter', () => {
  it('ẩn tin của ghế đang tắt tiếng hoặc đang chặn', () => {
    const msg = textMsg({ channel: 'all', from: 2 });
    expect(isHiddenBySeatFilter(msg, 0, new Set([2]), new Set())).toBe(true);
    expect(isHiddenBySeatFilter(msg, 0, new Set(), new Set([2]))).toBe(true);
    expect(isHiddenBySeatFilter(msg, 0, new Set([1]), new Set([3]))).toBe(false);
  });

  it('không bao giờ tự ẩn tin của chính mình', () => {
    const mine = textMsg({ channel: 'all', from: 0 });
    expect(isHiddenBySeatFilter(mine, 0, new Set([0]), new Set([0]))).toBe(false);
  });
});
