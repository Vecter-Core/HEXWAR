// M10 (PLAN 12.2 "rung → nứt → rơi"): toán thuần cho hoạt ảnh ô đang biến mất.
import { describe, expect, it } from 'vitest';
import {
  COLLAPSE_FALL_DISTANCE,
  COLLAPSE_MIN_SCALE,
  COLLAPSE_SHAKE_FRACTION,
  collapsePhaseAt,
  collapseTileTransform,
} from '../src/core/collapse-fx';

describe('collapsePhaseAt', () => {
  it('trước ngưỡng COLLAPSE_SHAKE_FRACTION là pha rung, từ đó trở đi là pha rơi', () => {
    expect(collapsePhaseAt(0)).toBe('shake');
    expect(collapsePhaseAt(COLLAPSE_SHAKE_FRACTION - 0.01)).toBe('shake');
    expect(collapsePhaseAt(COLLAPSE_SHAKE_FRACTION)).toBe('fall');
    expect(collapsePhaseAt(1)).toBe('fall');
  });
});

describe('collapseTileTransform', () => {
  it('progress = 0: chưa lệch vị trí, chưa co, chưa nứt (ô còn nguyên vẹn lúc bắt đầu)', () => {
    const t0 = collapseTileTransform(0, 5);
    expect(t0.dy).toBe(0);
    expect(t0.scale).toBe(1);
    expect(t0.crack).toBe(0);
    expect(t0.phase).toBe('shake');
  });

  it('pha rung (progress < 0.4): không rơi (dy = 0), không co (scale = 1), chỉ lệch ngang nhẹ + bắt đầu nứt', () => {
    for (const p of [0.1, 0.2, 0.35]) {
      const transform = collapseTileTransform(p, 7);
      expect(transform.phase).toBe('shake');
      expect(transform.dy).toBe(0);
      expect(transform.scale).toBe(1);
      expect(Math.abs(transform.dx)).toBeLessThan(0.06);
      expect(Math.abs(transform.dz)).toBeLessThan(0.06);
    }
  });

  it('pha rơi (progress >= 0.4): rơi CÀNG SÂU và CO CÀNG NHỎ khi progress tăng, không lệch ngang nữa', () => {
    const a = collapseTileTransform(0.5, 3);
    const b = collapseTileTransform(0.8, 3);
    expect(a.phase).toBe('fall');
    expect(b.phase).toBe('fall');
    expect(a.dx).toBe(0);
    expect(a.dz).toBe(0);
    expect(b.dy).toBeLessThan(a.dy); // rơi sâu hơn (âm hơn)
    expect(b.scale).toBeLessThan(a.scale); // co nhỏ hơn
    expect(b.crack).toBeGreaterThan(a.crack); // nứt rõ hơn
  });

  it('progress = 1: rơi đúng COLLAPSE_FALL_DISTANCE, co về đúng COLLAPSE_MIN_SCALE, nứt hoàn toàn (crack = 1)', () => {
    const end = collapseTileTransform(1, 9);
    expect(end.dy).toBeCloseTo(-COLLAPSE_FALL_DISTANCE, 6);
    expect(end.scale).toBeCloseTo(COLLAPSE_MIN_SCALE, 6);
    expect(end.crack).toBeCloseTo(1, 6);
  });

  it('kẹp progress ngoài [0, 1] về biên (không NaN/giá trị phi lý nếu gọi sai)', () => {
    expect(collapseTileTransform(-0.5, 1)).toEqual(collapseTileTransform(0, 1));
    expect(collapseTileTransform(1.5, 1)).toEqual(collapseTileTransform(1, 1));
  });

  it('seed khác nhau cho lệch rung khác nhau (để cả vòng không rung đồng bộ y hệt, PLAN 12.2)', () => {
    const a = collapseTileTransform(0.2, 1);
    const b = collapseTileTransform(0.2, 2);
    expect(a.dx !== b.dx || a.dz !== b.dz).toBe(true);
  });

  it('tất định: cùng đầu vào luôn ra cùng kết quả (không Math.random)', () => {
    expect(collapseTileTransform(0.6, 42)).toEqual(collapseTileTransform(0.6, 42));
  });
});
