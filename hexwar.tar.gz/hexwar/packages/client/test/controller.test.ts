// M3: bộ điều khiển hotseat (PLAN 11.3, "chọn quân → bấm ô đích"). Trọng tài luôn là engine (`checkMove`/`applyMove`);
// controller chỉ diễn giải các lượt bấm thành lời gọi engine, không tự quyết luật (PLAN 6.1 nguyên tắc 2).
import { describe, expect, it } from 'vitest';
import {
  SEATS,
  applyMove,
  createRng,
  defaultConfig,
  legalMoves,
  makeState,
  createPiece,
  newGame,
  rollDice,
  type GameState,
  type IllegalReason,
  type Move,
  type Piece,
  type Seat,
} from '@hexwar/rules';
import { GameController, classifyMove } from '../src/core/controller';
import { SIM_CONFIGS } from './simulate';

const P = (id: string, owner: Seat, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });
const duel = () =>
  makeState({
    seats: [0, 1, 2],
    pieces: [P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
  });

describe('GameController: xúc xắc', () => {
  it('rollDice chuyển từ pha dice sang playing; không gọi được lần hai', () => {
    const controller = new GameController(newGame(defaultConfig, SEATS, 1));
    expect(controller.state.phase).toBe('dice');
    controller.rollDice(createRng(1));
    expect(controller.state.phase).toBe('playing');
    expect(controller.state.turnSeat).not.toBeNull();
    expect(() => controller.rollDice(createRng(1))).toThrowError(/pha tung xúc xắc/);
  });

  it('gọi listener.onAction đúng một lần với kết quả tung xúc xắc', () => {
    const results: string[] = [];
    const controller = new GameController(newGame(defaultConfig, SEATS, 7), { onAction: (r) => results.push(r.events.map((e) => e.type).join(',')) });
    controller.rollDice(createRng(7));
    expect(results).toHaveLength(1);
    expect(results[0]).toContain('DICE_ROLLED');
  });
});

describe('GameController: chọn quân và đi', () => {
  it('bấm quân của mình → chọn; danh sách nước đi khớp legalMovesOfPiece; bấm lại quân đó → bỏ chọn', () => {
    const controller = new GameController(duel());
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    expect(controller.selection?.pieceId).toBe('r0');
    expect(controller.selection?.conscript).toBe(false);
    expect([...(controller.selection?.moves.keys() ?? [])].sort()).toEqual(
      legalMoves(controller.state, 0)
        .filter((m) => m.pieceId === 'r0')
        .map((m) => `${m.to.q},${m.to.r}`)
        .sort(),
    );
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    expect(controller.selection).toBeNull();
  });

  it('bấm ô đích hợp lệ → áp dụng đúng nước đi engine sẽ áp dụng, tự bỏ chọn sau khi đi', () => {
    const before = duel();
    const controller = new GameController(before);
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 3, r: 0 } });
    expect(controller.selection).toBeNull();
    const direct = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    expect(controller.state).toEqual(direct.state);
  });

  it('bấm quân địch nằm trong tầm ăn → coi như bấm ô đích đó (PLAN 11.3: ăn quân)', () => {
    const controller = new GameController(duel());
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'piece', pieceId: 'n1', cell: { q: 3, r: 0 } });
    expect(controller.state.pieces.find((p) => p.id === 'n1')).toMatchObject({ status: 'captive', holder: 0 });
  });

  it('đổi chọn: bấm quân khác của mình trong khi đang chọn quân trước → chọn quân mới', () => {
    const controller = new GameController(makeState({ seats: [0, 1], pieces: [P('k0', 0, 'K', -10, 10), P('r0', 0, 'R', 0, 0), P('n0', 0, 'N', 5, 0), P('k1', 1, 'K', -10, -10)] }));
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'piece', pieceId: 'n0', cell: { q: 5, r: 0 } });
    expect(controller.selection?.pieceId).toBe('n0');
  });

  it('bấm ô không hợp lệ: KHÔNG đổi trạng thái ván, giữ nguyên chọn, báo đúng lý do qua onRejected', () => {
    const before = duel();
    const rejected: { reason: IllegalReason; move: Move }[] = [];
    const controller = new GameController(before, { onRejected: (reason, move) => rejected.push({ reason, move }) });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 9, r: 9 } }); // quá tầm và/hoặc sai hướng
    expect(controller.state).toEqual(before);
    expect(controller.selection?.pieceId).toBe('r0'); // vẫn đang chọn r0
    expect(rejected).toHaveLength(1);
    expect(rejected[0]?.reason).not.toBe('NOT_ALLOWED');
  });

  it('bấm ra ngoài bàn cờ (pick = null) hoặc chưa chọn gì: không làm gì, trả về false', () => {
    const controller = new GameController(duel());
    expect(controller.handlePick(null)).toBe(false);
    expect(controller.handlePick({ kind: 'cell', cell: { q: 5, r: 5 } })).toBe(false); // chưa có chọn
    expect(controller.selection).toBeNull();
  });

  it('ngoài pha đang chơi (chưa tung xúc xắc, hoặc ván đã kết thúc): mọi lượt bấm đều bị bỏ qua', () => {
    const initial = newGame(defaultConfig, SEATS, 1);
    const anyPiece = initial.pieces[0];
    if (anyPiece === undefined) throw new Error('thế cờ đầu rỗng');
    const beforeDice = new GameController(initial);
    expect(beforeDice.handlePick({ kind: 'piece', pieceId: anyPiece.id, cell: anyPiece.cell })).toBe(false);
    expect(beforeDice.selection).toBeNull();

    const finished = new GameController(makeState({ seats: [0, 1], pieces: [P('k0', 0, 'K', -10, 10), P('r0', 0, 'R', 0, 0), P('k1', 1, 'K', -10, -10)], phase: 'over' }));
    expect(finished.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } })).toBe(false);
    expect(finished.selection).toBeNull();
  });

  it('trưng dụng tù binh: chọn tù binh của mình đặt cờ conscript, đi ăn quân không tăng kills của quân nào', () => {
    const captiveState: GameState = makeState({
      seats: [0, 1, 2],
      pieces: [
        P('k0', 0, 'K', -20, 20),
        { ...P('c1', 1, 'R', 3, 0), status: 'captive', holder: 0, armed: true },
        P('k1', 1, 'K', -20, 0),
        P('v2', 2, 'N', 3, 1),
        P('k2', 2, 'K', 20, -20),
      ],
    });
    const controller = new GameController(captiveState);
    controller.handlePick({ kind: 'piece', pieceId: 'c1', cell: { q: 3, r: 0 } });
    expect(controller.selection?.conscript).toBe(true);
    controller.handlePick({ kind: 'cell', cell: { q: 3, r: 1 } });
    expect(controller.state.pieces.find((p) => p.id === 'v2')).toBeUndefined();
    // R-33: tù binh đã tới hạn (armed) bị loại ngay cuối CHÍNH lượt trưng dụng này, dù vừa dùng để ăn quân.
    expect(controller.state.pieces.find((p) => p.id === 'c1')).toBeUndefined();
    expect(controller.state.playerKills[0]).toBe(1);
  });

  it('bấm ô không hợp lệ trong khi đang trưng dụng tù binh: lý do là của TÙ BINH (đúng cờ conscript), không phải "PIECE_IS_CAPTIVE"', () => {
    const captiveState: GameState = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), { ...P('c1', 1, 'R', 3, 0), status: 'captive', holder: 0, armed: true }, P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
    });
    const rejected: { reason: IllegalReason; move: Move }[] = [];
    const controller = new GameController(captiveState, { onRejected: (reason, move) => rejected.push({ reason, move }) });
    controller.handlePick({ kind: 'piece', pieceId: 'c1', cell: { q: 3, r: 0 } });
    expect(controller.selection?.conscript).toBe(true);
    controller.handlePick({ kind: 'cell', cell: { q: 15, r: 0 } }); // đúng hướng của Xe (12 ô), nhưng quá tầm 9 ô, vẫn trong bàn
    expect(rejected).toHaveLength(1);
    expect(rejected[0]).toMatchObject({ reason: 'OUT_OF_RANGE', move: { pieceId: 'c1', conscript: true } });
    expect(controller.selection?.pieceId).toBe('c1'); // vẫn đang chọn, chưa bị huỷ vì một lần bấm sai
  });

  it('chỉ đi được quân của người tới lượt; quân của người khác không chọn được (kể cả khi mình đang giữ tù binh của họ dạng active)', () => {
    const controller = new GameController(duel());
    expect(controller.handlePick({ kind: 'piece', pieceId: 'n1', cell: { q: 3, r: 0 } })).toBe(false);
    expect(controller.selection).toBeNull();
  });
});

describe('GameController: xác nhận nước đi (X-14, ControllerOptions.confirmMoves)', () => {
  it('mặc định (confirmMoves không bật): bấm ô đích đi ngay, không có pendingMove', () => {
    const controller = new GameController(duel());
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    expect(controller.selection?.pendingMove).toBeUndefined();
    controller.handlePick({ kind: 'cell', cell: { q: 3, r: 0 } });
    expect(controller.state.pieces.find((p) => p.id === 'n1')).toMatchObject({ status: 'captive' }); // đã đi thật
  });

  it('bật confirmMoves: bấm ô đích lần đầu chỉ đặt pendingMove, KHÔNG đổi trạng thái ván', () => {
    const before = duel();
    const controller = new GameController(before, {}, { confirmMoves: true });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 1, r: 0 } });
    expect(controller.state).toEqual(before);
    expect(controller.selection?.pieceId).toBe('r0');
    expect(controller.selection?.pendingMove).toEqual({ pieceId: 'r0', to: { q: 1, r: 0 } });
  });

  it('bật confirmMoves: bấm lại ĐÚNG ô đích đang chờ mới thật sự đi', () => {
    const before = duel();
    const controller = new GameController(before, {}, { confirmMoves: true });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 1, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 1, r: 0 } });
    expect(controller.selection).toBeNull();
    expect(controller.state.pieces.find((p) => p.id === 'r0')).toMatchObject({ cell: { q: 1, r: 0 } });
  });

  it('bật confirmMoves: bấm một ô đích HỢP LỆ KHÁC trong khi đang chờ → dời pendingMove sang ô mới, chưa đi', () => {
    const before = duel();
    const controller = new GameController(before, {}, { confirmMoves: true });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 1, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 2, r: 0 } });
    expect(controller.state).toEqual(before);
    expect(controller.selection?.pendingMove).toEqual({ pieceId: 'r0', to: { q: 2, r: 0 } });
  });

  it('confirmPending(): áp dụng đúng nước đang chờ; không làm gì nếu chưa có nước nào chờ', () => {
    const before = duel();
    const controller = new GameController(before, {}, { confirmMoves: true });
    controller.confirmPending(); // chưa chọn gì: không làm gì, không ném lỗi
    expect(controller.state).toEqual(before);
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 3, r: 0 } }); // ô ăn quân n1
    controller.confirmPending();
    expect(controller.selection).toBeNull();
    expect(controller.state.pieces.find((p) => p.id === 'n1')).toMatchObject({ status: 'captive', holder: 0 });
  });

  it('cancelPending(): xoá nước đang chờ nhưng vẫn giữ quân đang chọn', () => {
    const before = duel();
    const controller = new GameController(before, {}, { confirmMoves: true });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 1, r: 0 } });
    controller.cancelPending();
    expect(controller.state).toEqual(before);
    expect(controller.selection?.pieceId).toBe('r0');
    expect(controller.selection?.pendingMove).toBeUndefined();
    controller.cancelPending(); // gọi lại khi không có gì đang chờ: không làm gì
    expect(controller.selection?.pieceId).toBe('r0');
  });

  it('bấm ô không hợp lệ trong khi bật confirmMoves: báo lý do như bình thường, không tạo pendingMove', () => {
    const before = duel();
    const rejected: IllegalReason[] = [];
    const controller = new GameController(before, { onRejected: (r) => rejected.push(r) }, { confirmMoves: true });
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.handlePick({ kind: 'cell', cell: { q: 9, r: 9 } });
    expect(rejected).toHaveLength(1);
    expect(controller.selection?.pendingMove).toBeUndefined();
  });
});

describe('GameController: đầu hàng và hết giờ', () => {
  it('resignSeat loại người đó, xoá chọn hiện tại nếu có', () => {
    const controller = new GameController(duel());
    controller.handlePick({ kind: 'piece', pieceId: 'r0', cell: { q: 0, r: 0 } });
    controller.resignSeat(0);
    expect(controller.state.eliminated).toMatchObject([{ seat: 0, reason: 'resign' }]);
    expect(controller.selection).toBeNull();
  });

  it('timeoutCurrentTurn bỏ qua lượt của người đang tới lượt', () => {
    const controller = new GameController(duel());
    controller.timeoutCurrentTurn();
    expect(controller.state.turnSeat).toBe(1);
  });
});

describe('classifyMove: phân loại để tô màu (PLAN 11.2)', () => {
  it('move / capture / conscriptMove / conscriptCapture', () => {
    const state = duel();
    expect(classifyMove(state, { pieceId: 'r0', to: { q: 1, r: 0 } })).toBe('move');
    expect(classifyMove(state, { pieceId: 'r0', to: { q: 3, r: 0 } })).toBe('capture');
    const withCaptive: GameState = { ...state, pieces: [...state.pieces, { ...P('c9', 1, 'B', 0, 1), status: 'captive', holder: 0, armed: true }] };
    expect(classifyMove(withCaptive, { pieceId: 'c9', to: { q: 0, r: 2 }, conscript: true })).toBe('conscriptMove');
    expect(classifyMove(withCaptive, { pieceId: 'c9', to: { q: 3, r: 0 }, conscript: true })).toBe('conscriptCapture');
  });
});

describe('GameController: khớp engine trên ván mô phỏng đầy đủ (mọi hành động đi qua controller)', () => {
  for (const [name, config] of Object.entries(SIM_CONFIGS)) {
    it(`${name}: chơi trọn ván qua controller cho kết quả HỆT applyMove trực tiếp`, () => {
      const rng = createRng(1234);
      const seed = 5;
      const direct = newGame(config, SEATS, seed);
      const controller = new GameController(direct);
      controller.rollDice(createRng(seed));
      expect(controller.state).toEqual(rollDice(direct, createRng(seed)).state);

      let turns = 0;
      const rejections: string[] = [];
      const withRejects = new GameController(direct, { onRejected: (r) => rejections.push(r) });
      withRejects.rollDice(createRng(seed));
      let state = withRejects.state;
      while (state.phase === 'playing' && turns < 4000) {
        const moves = legalMoves(state, state.turnSeat as Seat);
        const move = moves[rng.int(moves.length)] as Move;
        const piece = state.pieces.find((p) => p.id === move.pieceId);
        withRejects.handlePick({ kind: 'piece', pieceId: move.pieceId, cell: piece?.cell ?? move.to });
        withRejects.handlePick({ kind: 'cell', cell: move.to });
        const applied = applyMove(state, move);
        expect(withRejects.state).toEqual(applied.state);
        state = withRejects.state;
        turns++;
      }
      expect(rejections).toEqual([]);
      expect(turns).toBeGreaterThan(20);
      expect(state.phase).toBe('over');
    });
  }
});
