// M3: mô hình hiển thị dựng từ sự kiện (PLAN 6.1 nguyên tắc 5). Bất biến chính: sau mỗi hành động của engine,
// áp dụng các sự kiện của hành động đó lên mô hình phải cho đúng trạng thái engine (không cần "sửa" gì thêm).
import { describe, expect, it } from 'vitest';
import { SEATS, applyMove, cell, defaultConfig, makeState, newGame, createPiece, type GameEventType, type Piece } from '@hexwar/rules';
import { DisplayModel } from '../src/core/display-model';
import { SIM_CONFIGS, playGame } from './simulate';

describe('DisplayModel: khởi tạo từ trạng thái', () => {
  it('108 quân ở thế đầu, khớp trạng thái, không có gì để sửa', () => {
    const state = newGame(defaultConfig, SEATS, 1);
    const model = DisplayModel.fromState(state);
    expect(model.size).toBe(108);
    expect(model.radius).toBe(24);
    expect(model.reconcile(state)).toEqual([]);
  });

  it('clone độc lập với bản gốc', () => {
    const state = newGame(defaultConfig, SEATS, 1);
    const a = DisplayModel.fromState(state);
    const b = a.clone();
    b.apply({ type: 'CAPTIVE_EXPIRED', pieceId: state.pieces[0]?.id ?? '', owner: 0, holder: 1, cell: cell(0, 0) });
    expect(a.size).toBe(108);
    expect(b.size).toBe(107);
  });
});

describe('DisplayModel: từng loại sự kiện', () => {
  const P = (id: string, owner: 0 | 1 | 2, type: Piece['type'], q: number, r: number): Piece => createPiece(id, owner, type, { q, r });
  const base = () =>
    makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)],
    });

  it('ăn quân thường: quân ăn đứng ở ô đích, quân bị ăn thành tù binh của người ăn (không biến mất)', () => {
    const before = base();
    const { state, events } = applyMove(before, { pieceId: 'r0', to: { q: 3, r: 0 } });
    const model = DisplayModel.fromState(before);
    model.applyAll(events);
    expect(model.get('r0')?.cell).toEqual({ q: 3, r: 0 });
    expect(model.get('n1')).toMatchObject({ status: 'captive', holder: 0, cell: { q: 3, r: 0 } });
    expect(model.reconcile(state)).toEqual([]);
  });

  it('ăn Vua không có Hề: mọi quân của người đó biến mất theo PLAYER_ELIMINATED', () => {
    const before = makeState({ seats: [0, 1, 2], pieces: [P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', -3, 0), P('k1', 1, 'K', 0, 0), P('q1', 1, 'Q', 5, 5), P('k2', 2, 'K', 20, -20)] });
    const { state, events } = applyMove(before, { pieceId: 'r0', to: { q: 0, r: 0 } });
    const model = DisplayModel.fromState(before);
    model.applyAll(events);
    expect(model.get('k1')).toBeUndefined();
    expect(model.get('q1')).toBeUndefined();
    expect(model.reconcile(state)).toEqual([]);
  });

  it('ăn Vua có Hề cứu: Vua dời sang ô Hề, Hề biến mất, quân ăn ở lại', () => {
    const before = makeState({
      seats: [0, 1, 2],
      pieces: [P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', -3, 0), P('k1', 1, 'K', 0, 0), P('j1', 1, 'J', 0, 4), P('k2', 2, 'K', 20, -20)],
    });
    const { state, events } = applyMove(before, { pieceId: 'r0', to: { q: 0, r: 0 } });
    const model = DisplayModel.fromState(before);
    model.applyAll(events);
    expect(model.get('k1')?.cell).toEqual({ q: 0, r: 4 });
    expect(model.get('j1')).toBeUndefined();
    expect(model.get('r0')?.cell).toEqual({ q: 0, r: 0 });
    expect(model.reconcile(state)).toEqual([]);
  });

  it('sự kiện không đổi bố cục (xúc xắc, lượt, cảnh báo) không làm đổi mô hình', () => {
    const state = base();
    const model = DisplayModel.fromState(state);
    const before = model.all();
    for (const e of [
      { type: 'ROUND_STARTED', round: 3 },
      { type: 'TURN_STARTED', seat: 1, round: 3 },
      { type: 'TURN_SKIPPED', seat: 1, reason: 'timeout' },
      { type: 'RING_WARNING', ring: 24, roundsLeft: 2, level: 'yellow' },
    ] as const) {
      model.apply(e);
    }
    expect(model.all()).toEqual(before);
  });

  it('reconcile báo và sửa từng loại sai lệch', () => {
    const state = base();
    const model = DisplayModel.fromState(state);
    model.apply({ type: 'CAPTIVE_EXPIRED', pieceId: 'n1', owner: 1, holder: 0, cell: cell(3, 0) }); // xoá nhầm
    model.apply({ type: 'MOVED', pieceId: 'r0', seat: 0, from: cell(0, 0), to: cell(1, 1), conscript: false }); // sai ô
    model.radius = 20;
    const problems = model.reconcile(state);
    expect(problems.some((p) => p.includes('thiếu quân n1'))).toBe(true);
    expect(problems.some((p) => p.includes('r0') && p.includes('cell'))).toBe(true);
    expect(problems.some((p) => p.includes('bán kính'))).toBe(true);
    expect(model.reconcile(state)).toEqual([]); // đã sửa
  });
});

describe('DisplayModel: sự kiện đủ để dựng lại trạng thái trên ván mô phỏng đầy đủ', () => {
  const seen = new Set<GameEventType>();
  for (const [name, config] of Object.entries(SIM_CONFIGS)) {
    it(`${name}: sau MỌI hành động, chỉ dùng sự kiện là khớp trạng thái engine`, () => {
      for (const seed of [1, 2, 3, 4]) {
        let model: DisplayModel | null = null;
        let actions = 0;
        playGame(seed, config, ({ before, result }) => {
          model ??= DisplayModel.fromState(before);
          model.applyAll(result.events);
          for (const e of result.events) seen.add(e.type);
          const problems = model.clone().reconcile(result.state);
          expect(problems, `seed ${seed}, hành động ${actions}`).toEqual([]);
          actions++;
        });
        expect(actions).toBeGreaterThan(50);
      }
    });
  }

  it('các ván trên đã phủ những sự kiện làm đổi bố cục quân (nếu không thì bất biến trên chưa chứng minh gì)', () => {
    const needed: GameEventType[] = [
      'MOVED',
      'CAPTURED',
      'CAPTIVE_CREATED',
      'CAPTIVE_EXPIRED',
      'CAPTIVE_CONSCRIPTED',
      'PROMOTED',
      'KING_CAPTURED',
      'PLAYER_ELIMINATED',
      'RING_COLLAPSED',
      'CAPTIVE_RELEASED',
      'CAPTIVE_TRANSFERRED',
      'JESTER_REVIVED',
    ];
    for (const type of needed) expect(seen.has(type), `chưa gặp ${type}`).toBe(true);
  });
});
