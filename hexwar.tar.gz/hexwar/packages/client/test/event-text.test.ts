// M3: dịch sự kiện engine thành thông báo HUD (PLAN 11.2 "Thông báo ngắn"). Thuần (không DOM): kiểm bằng Node.
import { describe, expect, it } from 'vitest';
import { SEATS, cell, defaultConfig, newGame, type GameEvent } from '@hexwar/rules';
import { describeEvent } from '../src/app/event-text';
import { DisplayModel } from '../src/core/display-model';
import { translatorFor } from '../src/core/i18n';

const state = newGame(defaultConfig, SEATS, 1);
const model = DisplayModel.fromState(state);
const rook = state.pieces.find((p) => p.type === 'R' && p.owner === 0);
if (rook === undefined) throw new Error('fixture hỏng: không tìm thấy Xe của ghế 0');

const vi = translatorFor('vi');
const en = translatorFor('en');

describe('describeEvent: mỗi loại sự kiện có thông báo đúng (hoặc cố ý bỏ qua)', () => {
  it('CAPTURED: nêu đúng loại quân ăn (tra từ mô hình TRƯỚC khi áp dụng) và ghế bị ăn', () => {
    const event: GameEvent = { type: 'CAPTURED', attackerId: rook.id, victimId: 'x', seat: 0, victimOwner: 2, cell: cell(0, 0), conscript: false };
    expect(describeEvent(event, model, vi)).toEqual([`${vi('piece.R')} ăn quân của ${vi('seat.label', { seat: 2 })}`]);
    expect(describeEvent(event, model, en)).toEqual([`${en('piece.R')} captures ${en('seat.label', { seat: 2 })}'s piece`]);
  });

  it('CAPTURED: quân tấn công không có trong mô hình vẫn ra một dòng (không ném lỗi), dùng "?" thay tên quân', () => {
    const event: GameEvent = { type: 'CAPTURED', attackerId: 'khong-ton-tai', victimId: 'x', seat: 0, victimOwner: 1, cell: cell(0, 0), conscript: false };
    expect(describeEvent(event, model, vi)).toEqual(['? ăn quân của Ghế 1']);
  });

  it('DICE_ROLLED: một dòng mỗi ghế tung + một dòng người thắng khi đã phân định', () => {
    const event: GameEvent = {
      type: 'DICE_ROLLED',
      attempt: 1,
      rolls: [
        { seat: 0, dice: [1, 2, 3], total: 6 },
        { seat: 1, dice: [4, 5, 6], total: 15 },
      ],
      winner: 1,
    };
    expect(describeEvent(event, model, vi)).toEqual(['Ghế 0 tung được 6 điểm', 'Ghế 1 tung được 15 điểm', 'Ghế 1 đi đầu']);
  });

  it('DICE_ROLLED: đồng điểm cao nhất (winner = null) ra dòng "tung lại" liệt kê đúng những ghế đồng điểm', () => {
    const event: GameEvent = {
      type: 'DICE_ROLLED',
      attempt: 1,
      rolls: [
        { seat: 0, dice: [6, 6, 6], total: 18 },
        { seat: 3, dice: [6, 6, 6], total: 18 },
      ],
      winner: null,
    };
    expect(describeEvent(event, model, vi).at(-1)).toBe('Đồng điểm cao nhất, tung lại: Ghế 0, Ghế 3');
  });

  it('TURN_SKIPPED: khớp đúng lý do (timeout / no_moves)', () => {
    expect(describeEvent({ type: 'TURN_SKIPPED', seat: 4, reason: 'timeout' }, model, vi)).toEqual(['Ghế 4 hết giờ, lượt bị bỏ qua']);
    expect(describeEvent({ type: 'TURN_SKIPPED', seat: 4, reason: 'no_moves' }, model, vi)).toEqual(['Ghế 4 không có nước đi, lượt tự bỏ qua']);
  });

  it('PROMOTED: nêu đúng loại cũ → loại mới', () => {
    const event: GameEvent = { type: 'PROMOTED', pieceId: rook.id, owner: 5, from: 'P', to: 'Q', kills: 20 };
    expect(describeEvent(event, model, en)).toEqual(["Seat 5's Pawn is promoted to Queen"]);
  });

  it('GAME_OVER: có người thắng thì nêu tên; hoà/hết hiệp thì không cần biến', () => {
    expect(describeEvent({ type: 'GAME_OVER', reason: 'lastKing', winner: 2, ranking: [] }, model, vi)).toEqual(['Ghế 2 thắng!']);
    expect(describeEvent({ type: 'GAME_OVER', reason: 'allEliminated', winner: null, ranking: [] }, model, vi)).toEqual(['Hoà: tất cả bị loại cùng lúc']);
  });

  it('MOVED / ROUND_STARTED / TURN_STARTED: cố ý không thông báo riêng (đã có ở chỗ khác trong HUD)', () => {
    expect(describeEvent({ type: 'MOVED', pieceId: rook.id, seat: 0, from: cell(0, 0), to: cell(1, 0), conscript: false }, model, vi)).toEqual([]);
    expect(describeEvent({ type: 'ROUND_STARTED', round: 2 }, model, vi)).toEqual([]);
    expect(describeEvent({ type: 'TURN_STARTED', seat: 0, round: 2 }, model, vi)).toEqual([]);
  });

  it('mọi loại sự kiện đều xử lý được mà không ném lỗi (không sót case khi engine thêm sự kiện)', () => {
    const samples: GameEvent[] = [
      { type: 'CAPTIVE_CREATED', pieceId: 'a', owner: 0, holder: 1, cell: cell(0, 0) },
      { type: 'CAPTIVE_CONSCRIPTED', pieceId: 'a', owner: 0, holder: 1 },
      { type: 'CAPTIVE_TRANSFERRED', pieceId: 'a', owner: 0, from: 1, to: 2 },
      { type: 'CAPTIVE_RELEASED', pieceId: 'a', owner: 0, from: cell(0, 0), to: cell(1, 0), cause: 'rescued' },
      { type: 'CAPTIVE_EXPIRED', pieceId: 'a', owner: 0, holder: 1, cell: cell(0, 0) },
      { type: 'KING_CAPTURED', kingId: 'a', owner: 0, by: 1, cell: cell(0, 0) },
      { type: 'JESTER_REVIVED', kingId: 'a', jesterId: 'b', owner: 0, from: cell(0, 0), to: cell(1, 0), cause: 'capture' },
      { type: 'PLAYER_ELIMINATED', seat: 0, reason: 'king', removedPieceIds: [] },
      { type: 'RING_WARNING', ring: 24, roundsLeft: 3, level: 'yellow' },
      { type: 'RING_COLLAPSED', round: 50, ring: 24, radius: 23, removedPieceIds: [] },
      { type: 'GAME_OVER', reason: 'hardCap', winner: null, ranking: [] },
    ];
    for (const event of samples) {
      for (const t of [vi, en]) {
        const lines = describeEvent(event, model, t);
        expect(lines.length).toBeGreaterThan(0);
        for (const line of lines) expect(line.includes('{{')).toBe(false); // không sót biến chưa thay
      }
    }
  });
});
