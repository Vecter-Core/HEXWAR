// GameLink + LocalHost + InProcessTransport: đúng đường chạy của bản solo (chỉ thay Web Worker bằng chạy cùng luồng
// và đồng hồ thật bằng đồng hồ giả). PLAN M4 nghiệm thu: "chơi trọn ván 1 vs 5 bot, thoát và vào lại được".
import { describe, expect, it } from 'vitest';
import { ManualClock, type RejectReason } from '@hexwar/protocol';
import { botRngFor, chooseMove } from '@hexwar/bot';
import { hash, type Seat } from '@hexwar/rules';
import { GameLink } from '../src/core/game-link';
import { soloSeats } from '../src/net/seats';
import { MemorySaveStore } from '../src/net/save-store';
import { InProcessTransport } from '../src/net/in-process-transport';

/** Chờ mọi microtask (postMessage giả) chạy xong. */
const flush = (): Promise<void> => new Promise((resolve) => setImmediate(resolve));

interface Rig {
  readonly link: GameLink;
  readonly transport: InProcessTransport;
  readonly clock: ManualClock;
  readonly store: MemorySaveStore;
  readonly rejected: RejectReason[];
  readonly errors: string[];
}

function rig(store = new MemorySaveStore()): Rig {
  const clock = new ManualClock();
  const transport = new InProcessTransport(clock);
  const rejected: RejectReason[] = [];
  const errors: string[] = [];
  const link = new GameLink({
    transport,
    store,
    now: () => 1_700_000_000_000,
    listener: { onRejected: (r) => rejected.push(r), onError: (code) => errors.push(code) },
  });
  return { link, transport, clock, store, rejected, errors };
}

/** Người chơi: chọn quân rồi bấm ô đích qua ĐÚNG GameController (như bấm chuột), nước đi do bot Thường gợi ý. */
function playMyTurn(r: Rig): void {
  const state = r.link.state;
  const seat = state.turnSeat as Seat;
  const decision = chooseMove(state, seat, 'normal', botRngFor(state, seat, r.link.seq + 555));
  if (decision === null) throw new Error('không có nước đi');
  r.link.controller.select(decision.move.pieceId);
  expect(r.link.controller.handlePick({ kind: 'cell', cell: decision.move.to })).toBe(true);
}

/** Chạy tới khi `until` đúng: tới lượt mình thì đi, không thì cho đồng hồ trôi. */
async function run(r: Rig, until: () => boolean, maxSteps = 100_000): Promise<void> {
  for (let i = 0; i < maxSteps && !until(); i++) {
    if (r.link.isMyTurn()) playMyTurn(r);
    else if (!r.clock.step()) throw new Error('không còn hẹn giờ nào');
    await flush();
  }
  if (!until()) throw new Error('quá số bước cho phép');
}

const FAST = { botDelayMinMs: 10, botDelayMaxMs: 20 };

describe('GameLink: ván solo qua Transport (M4)', () => {
  it('bắt đầu: nhận snapshot, biết ghế của mình; bấm xúc xắc thì vào pha chơi', async () => {
    const r = rig();
    const seed = 20;
    r.transport.startNew(seed, soloSeats(seed, 'easy'), FAST);
    await flush();
    expect(r.link.ready).toBe(true);
    expect(r.link.you).toEqual([seed % 6]);
    expect(r.link.state.phase).toBe('dice');
    expect(r.link.seats.filter((s) => s.kind === 'bot')).toHaveLength(5);
    r.link.rollDice();
    await flush();
    expect(r.link.state.phase).toBe('playing');
    expect(r.link.seq).toBe(1);
  });

  it('không cho bấm đi khi không phải lượt mình; nước sai luật bị nơi chạy ván từ chối (không tự quyết luật ở client)', async () => {
    const r = rig();
    r.transport.startNew(3, soloSeats(3, 'easy'), FAST);
    await flush();
    r.link.rollDice();
    await flush();
    await run(r, () => !r.link.isMyTurn() && r.link.state.phase === 'playing');
    const mine = r.link.state.pieces.find((p) => p.owner === r.link.you[0]) as { id: string; cell: { q: number; r: number } };
    expect(r.link.controller.handlePick({ kind: 'piece', pieceId: mine.id, cell: mine.cell })).toBe(false);

    await run(r, () => r.link.isMyTurn());
    r.link.submitMove({ pieceId: mine.id, to: { q: 0, r: 0 } }); // gửi thẳng, bỏ qua kiểm tra của controller
    await flush();
    expect(r.rejected.length).toBe(1);
    expect(r.rejected[0]).not.toBe('STALE_SEQ');
  });

  it('tự lưu mỗi lượt; "thoát" rồi "vào lại" từ bản lưu cho đúng thế cờ (hash) và chơi tiếp được', async () => {
    const store = new MemorySaveStore();
    const a = rig(store);
    a.transport.startNew(41, soloSeats(41, 'mixed'), FAST);
    await flush();
    a.link.rollDice();
    await flush();
    await run(a, () => a.link.seq >= 80);
    const before = hash(a.link.state);
    const seqBefore = a.link.seq;
    expect(store.value?.meta?.round).toBe(a.link.state.round);
    a.link.close(); // thoát

    const b = rig(store);
    const stored = store.load();
    expect(stored).not.toBeNull();
    b.transport.resume(stored?.save);
    await flush();
    expect(b.errors).toEqual([]);
    expect(b.link.ready).toBe(true);
    expect(hash(b.link.state)).toBe(before);
    expect(b.link.seq).toBe(seqBefore);
    await run(b, () => b.link.seq >= seqBefore + 30);
  }, 60_000);

  it('chơi trọn ván tới khi kết thúc thì xoá bản lưu (không còn gì để tiếp tục)', async () => {
    const r = rig();
    r.transport.startNew(8, soloSeats(8, 'easy'), { botDelayMinMs: 0, botDelayMaxMs: 0, spectatorBotDelayMs: 0 });
    await flush();
    r.link.rollDice();
    await flush();
    await run(r, () => r.link.state.phase === 'over', 200_000);
    expect(r.link.state.result?.ranking).toHaveLength(6);
    expect(r.store.load()).toBeNull();
  }, 180_000);

  it('bản lưu hỏng → báo lỗi, không vào ván', async () => {
    const r = rig();
    r.transport.resume({ format: 'hexwar-save', version: 1, junk: true });
    await flush();
    expect(r.errors).toEqual(['BAD_FORMAT']);
    expect(r.link.ready).toBe(false);
  });
});
