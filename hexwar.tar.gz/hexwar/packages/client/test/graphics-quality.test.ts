// M10 (PLAN 12.5): mức đồ hoạ → cấu hình cụ thể — thuần, không dựng renderer/composer thật.
import { describe, expect, it } from 'vitest';
import { graphicsProfileFor } from '../src/core/graphics-quality';

describe('graphicsProfileFor', () => {
  it('Thấp: không bóng, không hậu kỳ, không phản xạ (PLAN 12.5)', () => {
    const p = graphicsProfileFor('low');
    expect(p.shadows).toBe(false);
    expect(p.bloom).toBe(false);
    expect(p.ssao).toBe(false);
    expect(p.reflections).toBe(false);
  });

  it('Vừa: bóng bật, bloom nhẹ bật, SSAO/phản xạ vẫn tắt (PLAN 12.5)', () => {
    const p = graphicsProfileFor('medium');
    expect(p.shadows).toBe(true);
    expect(p.bloom).toBe(true);
    expect(p.ssao).toBe(false);
    expect(p.reflections).toBe(false);
  });

  it('Cao: bóng, bloom, SSAO, phản xạ đều bật (PLAN 12.5)', () => {
    const p = graphicsProfileFor('high');
    expect(p.shadows).toBe(true);
    expect(p.bloom).toBe(true);
    expect(p.ssao).toBe(true);
    expect(p.reflections).toBe(true);
  });

  it('mật độ hạt tăng dần Thấp < Vừa < Cao (PLAN 12.5 "ít hạt"/"hạt dày")', () => {
    const low = graphicsProfileFor('low').particleDensity;
    const medium = graphicsProfileFor('medium').particleDensity;
    const high = graphicsProfileFor('high').particleDensity;
    expect(low).toBeLessThan(medium);
    expect(medium).toBeLessThan(high);
    expect(low).toBeGreaterThan(0); // "ít hạt" không phải "không hạt"
  });

  it('quality phản ánh đúng tham số truyền vào', () => {
    expect(graphicsProfileFor('low').quality).toBe('low');
    expect(graphicsProfileFor('medium').quality).toBe('medium');
    expect(graphicsProfileFor('high').quality).toBe('high');
  });
});
