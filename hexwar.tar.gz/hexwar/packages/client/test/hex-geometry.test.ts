// M3: hình học ô lục giác (PLAN 3.1, 6.6). Thuần THREE (không cần WebGL): ExtrudeGeometry/ShapeGeometry tam giác
// hoá trên CPU nên kiểm tra được bằng Node. Đối chiếu với `hexCorners` và với `pixelToCell`/`cellCenter` của engine.
import type * as THREE from 'three';
import { describe, expect, it } from 'vitest';
import { cell, pixelToCell } from '@hexwar/rules';
import { createHighlightGeometry, createTileGeometry, hexCorners } from '../src/scene/hex-geometry';

function boundingCorners(geometry: THREE.BufferGeometry): { minY: number; maxY: number; xz: Set<string> } {
  geometry.computeBoundingBox();
  const pos = geometry.getAttribute('position');
  let minY = Number.POSITIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  const xz = new Set<string>();
  for (let i = 0; i < pos.count; i++) {
    const y = pos.getY(i);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
    xz.add(`${pos.getX(i).toFixed(4)},${pos.getZ(i).toFixed(4)}`);
  }
  return { minY, maxY, xz };
}

describe('hexCorners: khớp công thức worldPos (PLAN 3.1)', () => {
  it('6 đỉnh ở góc 0°, 60°, …, 300°, bán kính đúng size', () => {
    const size = 2;
    const corners = hexCorners(size);
    expect(corners).toHaveLength(6);
    corners.forEach(([x, y], i) => {
      expect(Math.hypot(x, y)).toBeCloseTo(size, 10);
      expect(x).toBeCloseTo(size * Math.cos((Math.PI / 3) * i), 10);
      expect(y).toBeCloseTo(size * Math.sin((Math.PI / 3) * i), 10);
    });
    expect(corners[0]).toEqual([size, 0]); // đỉnh đầu nằm đúng trên trục +x (flat-top, PLAN 3.1)
  });

  it('hai đỉnh liên tiếp bất kỳ cách nhau đúng size (lục giác đều)', () => {
    const corners = hexCorners(1.5);
    for (let i = 0; i < 6; i++) {
      const [ax, ay] = corners[i] as [number, number];
      const [bx, by] = corners[(i + 1) % 6] as [number, number];
      expect(Math.hypot(bx - ax, by - ay)).toBeCloseTo(1.5, 10);
    }
  });
});

describe('createTileGeometry: khối ô (PLAN layout.ts cellCenter — mặt trên ở y = 0)', () => {
  it('mặt trên đúng y = 0, đáy đúng y = −height', () => {
    const { minY, maxY } = boundingCorners(createTileGeometry(1, 0.35));
    expect(maxY).toBeCloseTo(0, 6);
    expect(minY).toBeCloseTo(-0.35, 6);
  });

  it('tiết diện ngang (x, z) đúng 6 đỉnh của hexCorners (đùn giữ nguyên mặt cắt)', () => {
    const size = 1;
    const geometry = createTileGeometry(size, 0.35);
    const { xz } = boundingCorners(geometry);
    const expected = new Set(hexCorners(size).map(([x, y]) => `${x.toFixed(4)},${y.toFixed(4)}`));
    // Toạ độ Z sau `rotateX(-90°)` bằng −y gốc của Shape; so khớp tập điểm bất biến qua phép đối xứng đó.
    const expectedZ = new Set(hexCorners(size).map(([x, y]) => `${x.toFixed(4)},${(-y).toFixed(4)}`));
    expect(xz.size).toBeGreaterThanOrEqual(6);
    for (const p of xz) expect(expected.has(p) || expectedZ.has(p)).toBe(true);
  });

  it('mỗi ô lục giác không chồng lấn ô lân cận: ô kề khít nhau khi bán kính vẽ = cạnh lưới; vẽ nhỏ hơn 1 chút để có khe hở', () => {
    // Hai ô lục giác đều cạnh `size` khít nhau (chạm cạnh, không đè) khi tâm cách nhau đúng size·√3 (PLAN 3.1: đây
    // chính là khoảng cách giữa hai ô kề theo `worldPos`, kiểm ở test dưới). Vẽ đúng bán kính đó (scale = 1) thì hai
    // ô chạm khít; TILE_RADIUS_SCALE < 1 (layout.ts) để lại khe hở nhìn được giữa các ô.
    const gridSize = 1;
    const fitsExactlyAt = gridSize; // bán kính ngoại tiếp = cạnh lưới, xem chứng minh ở test kế
    const drawnRadius = 0.94 * gridSize; // TILE_RADIUS_SCALE của layout.ts
    expect(drawnRadius).toBeLessThan(fitsExactlyAt);
    expect(drawnRadius).toBeGreaterThan(0.8 * fitsExactlyAt); // vẫn gần lấp đầy, không để khe quá to
  });

  it('khoảng cách giữa tâm hai ô lưới kề nhau (mọi trong 6 hướng cạnh) đúng bằng size·√3', () => {
    const size = 1;
    for (const [dx, dz] of [
      [0, -Math.sqrt(3)],
      [1.5, -Math.sqrt(3) / 2],
      [1.5, Math.sqrt(3) / 2],
      [0, Math.sqrt(3)],
      [-1.5, Math.sqrt(3) / 2],
      [-1.5, -Math.sqrt(3) / 2],
    ]) {
      expect(Math.hypot(dx as number, dz as number)).toBeCloseTo(size * Math.sqrt(3), 10);
    }
  });
});

describe('createHighlightGeometry: lớp phủ tô sáng phẳng (PLAN 11.2)', () => {
  it('không có chiều dày (mọi đỉnh cùng y)', () => {
    const { minY, maxY } = boundingCorners(createHighlightGeometry(0.9));
    expect(maxY - minY).toBeCloseTo(0, 9);
  });
});

describe('Đối chiếu hình học ô với engine: pixelToCell của một điểm trong ô phải ra đúng ô đó', () => {
  it('tâm và các điểm gần đỉnh (trong phạm vi an toàn) đều quy về đúng ô trung tâm', () => {
    for (const [x, y] of hexCorners(0.9)) {
      // Điểm ở 90% khoảng cách tới đỉnh vẫn còn trong ô trung tâm (bán kính nội tiếp ~0.87 > 0.9*0.9? kiểm bằng pixelToCell).
      const near = [x * 0.5, y * 0.5] as const;
      expect(pixelToCell(near[0], near[1], 1)).toEqual(cell(0, 0));
    }
  });
});
