// HUD tối thiểu M4 (PLAN 15: "lượt, hiệp, đồng hồ, danh sách người"): dữ liệu hiển thị tính thuần từ trạng thái.
import { describe, expect, it } from 'vitest';
import type { SeatStatus } from '@hexwar/protocol';
import { SEATS, createPiece, defaultConfig, makeState, newGame, rollDice, type GameState, type Seat } from '@hexwar/rules';
import { buildHudView, seatName } from '../src/app/hud-model';
import { translatorFor } from '../src/core/i18n';

const t = translatorFor('vi');

const SEATS_SOLO: SeatStatus[] = SEATS.map((seat) =>
  seat === 2 ? { seat, kind: 'human', botControlled: false } : { seat, kind: 'bot', difficulty: seat % 2 === 0 ? 'easy' : 'normal', botControlled: false },
);

function playing(): GameState {
  return rollDice(newGame(defaultConfig, SEATS, 5)).state;
}

describe('buildHudView', () => {
  it('pha xúc xắc: hiện nút tung cho người chơi, chưa có đồng hồ', () => {
    const view = buildHudView({ state: newGame(defaultConfig, SEATS, 1), seats: SEATS_SOLO, you: [2], deadline: null, now: 0 }, t);
    expect(view.phaseText).toBe('Đang tung xúc xắc');
    expect(view.showDice).toBe(true);
    expect(view.clockText).toBeNull();
    expect(view.showExit).toBe(true);
    expect(view.players).toHaveLength(6);
  });

  it('lượt của mình: "Lượt của bạn" + đồng hồ đếm ngược làm tròn lên, ≤ 10 giây thì báo gấp (R-12)', () => {
    const base = playing();
    const state: GameState = { ...base, turnSeat: 2 };
    const view = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: 60_000, now: 500 }, t);
    expect(view.phaseText).toBe(`Hiệp ${state.round}`);
    expect(view.turnText).toBe('Lượt của bạn');
    expect(view.yourTurn).toBe(true);
    expect(view.clockText).toBe('60 giây');
    expect(view.clockUrgent).toBe(false);
    const late = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: 60_000, now: 50_500 }, t);
    expect(late.clockText).toBe('10 giây');
    expect(late.clockUrgent).toBe(true);
    const over = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: 60_000, now: 99_000 }, t);
    expect(over.clockText).toBe('0 giây');
  });

  it('lượt của bot: tên bot theo độ khó, không có đồng hồ', () => {
    const state: GameState = { ...playing(), turnSeat: 3 };
    const view = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: null, now: 0 }, t);
    expect(view.turnText).toBe('Lượt của Bot Thường');
    expect(view.yourTurn).toBe(false);
    expect(view.clockText).toBeNull();
  });

  it('bảng người chơi: tên, ghế, số quân, kill, điểm (R-82), nhãn BOT / bị loại / bot lái tạm (X-04)', () => {
    const state: GameState = {
      ...makeState({
        pieces: [createPiece('k2', 2, 'K', { q: 0, r: 5 }), createPiece('q2', 2, 'Q', { q: 1, r: 5 }), createPiece('k3', 3, 'K', { q: 5, r: 0 })],
        seats: [2, 3, 4],
        playerKills: [0, 0, 3, 0, 0, 0],
        eliminated: [{ seat: 4, round: 7, reason: 'king', batch: 1, score: 11 }],
      }),
    };
    const seats = SEATS_SOLO.map((s) => (s.seat === 2 ? { ...s, botControlled: true } : s));
    const view = buildHudView({ state, seats, you: [2], deadline: null, now: 0 }, t);
    const me = view.players.find((p) => p.seat === 2);
    expect(me).toMatchObject({ name: 'Bạn', seatLabel: 'Ghế 2', pieces: 2, kills: 3, score: 9 + 3, alive: true, isYou: true, isTurn: true });
    expect(me?.tags).toEqual(['Bot đang lái tạm']);
    const out = view.players.find((p) => p.seat === 4);
    expect(out).toMatchObject({ alive: false, score: 11 });
    expect(out?.tags).toEqual(['BOT', 'Bị loại (hiệp 7)']);
    expect(view.players.map((p) => p.seat)).toEqual([2, 3, 4]);
    expect(me?.color).toBe('#009e73'); // PLAN 12.3 Okabe–Ito, ghế 2
  });

  it('M7.4: speaking mặc định false (không có voice, ví dụ solo/hotseat); true đúng ghế có trong speakingSeats', () => {
    const state = playing();
    const withoutVoice = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: null, now: 0 }, t);
    expect(withoutVoice.players.every((p) => !p.speaking)).toBe(true);
    const withVoice = buildHudView({ state, seats: SEATS_SOLO, you: [2], deadline: null, now: 0, speakingSeats: new Set<Seat>([3]) }, t);
    expect(withVoice.players.find((p) => p.seat === 3)?.speaking).toBe(true);
    expect(withVoice.players.find((p) => p.seat === 2)?.speaking).toBe(false);
  });

  it('đếm ngược thu hẹp (PLAN 11.2 "Trên giữa", R-71): hiện khi còn ≤ 10 hiệp, kèm mức cảnh báo', () => {
    const at = (round: number) => buildHudView({ state: { ...playing(), round }, seats: SEATS_SOLO, you: [2], deadline: null, now: 0 }, t);
    expect(at(30).collapseText).toBeNull();
    expect(at(40).collapseText).toBe('Vòng 24 biến mất sau 10 hiệp');
    expect(at(40).collapseLevel).toBeNull();
    expect(at(47).collapseLevel).toBe('yellow');
    expect(at(49).collapseLevel).toBe('red');
  });

  it('hotseat (một máy điều khiển 6 ghế): tên là "Ghế N", không hiện "Lượt của bạn"', () => {
    const humans: SeatStatus[] = SEATS.map((seat) => ({ seat, kind: 'human', botControlled: false }));
    const state: GameState = { ...playing(), turnSeat: 1 as Seat };
    const view = buildHudView({ state, seats: humans, you: SEATS, deadline: 5000, now: 0 }, t);
    expect(view.turnText).toBe('Lượt của Ghế 1');
    expect(seatName(1, humans, SEATS, t)).toBe('Ghế 1');
  });
});
