// M3: i18n tối thiểu (PLAN 11.7). Không kiểm nội dung dịch (đó là việc của người dịch), chỉ kiểm hợp đồng:
// hai ngôn ngữ có cùng bộ khoá, nội suy đúng, khoá thiếu không làm vỡ UI.
import { readFileSync, readdirSync, statSync } from 'node:fs';
import { join } from 'node:path';
import { describe, expect, it } from 'vitest';
import type { ChatErrorCode } from '@hexwar/protocol';
import { PERSONALITIES, PHRASE_IDS, REPORT_REASONS } from '@hexwar/protocol';
import type { IllegalReason } from '@hexwar/rules';
import { TUTORIAL_STRINGS } from '@hexwar/tutorial';
import { LOCALES, keysOf, translate, translatorFor } from '../src/core/i18n';

/** Mọi khoá mà lõi client (controller, HUD tối thiểu) thực sự dùng ở M3. Nếu thêm khoá dùng mới, thêm vào đây. */
const ILLEGAL_REASONS: IllegalReason[] = [
  'GAME_NOT_PLAYING',
  'NOT_IN_GAME',
  'NOT_YOUR_TURN',
  'NOT_YOUR_PIECE',
  'UNKNOWN_PIECE',
  'PIECE_IS_CAPTIVE',
  'NOT_A_CAPTIVE',
  'CONSCRIPT_DISABLED',
  'CAPTIVE_NOT_READY',
  'TARGET_OFF_BOARD',
  'SAME_CELL',
  'BAD_DIRECTION',
  'OUT_OF_RANGE',
  'PATH_BLOCKED',
  'TARGET_OWN_PIECE',
  'TARGET_BLOCKED',
  'PAWN_CAPTURE_STRAIGHT',
  'PAWN_DIAGONAL_NEEDS_CAPTURE',
  'JESTER_CANNOT_CAPTURE',
  'NOT_ALLOWED',
];
const USED_KEYS = [
  ...ILLEGAL_REASONS.map((r) => `illegal.${r}`),
  ...(['P', 'N', 'B', 'R', 'Q', 'K', 'J'] as const).map((t) => `piece.${t}`),
  'seat.label',
  'seat.you',
  'phase.dice',
  'phase.playing',
  'phase.over',
  'turn.of',
  'turn.skipped.timeout',
  'turn.skipped.no_moves',
  'dice.rolled',
  'dice.winner',
  'dice.tie',
  'event.moved',
  'event.captured',
  'event.captiveCreated',
  'event.captiveConscripted',
  'event.captiveTransferred',
  'event.captiveReleased',
  'event.captiveExpired',
  'event.promoted',
  'event.kingCaptured',
  'event.jesterRevived',
  'event.playerEliminated',
  'event.ringWarning.yellow',
  'event.ringWarning.red',
  'event.ringCollapsed',
  'event.gameOver.lastKing',
  'event.gameOver.allEliminated',
  'event.gameOver.hardCap',
  'control.rotateCamera',
  'control.zoomCamera',
  'control.panCamera',
  'control.cancel',
  'control.resign',
  'control.rotateSeat',
  'control.jumpToSeat',
  'control.topDown',
  'app.rollDice',
  'app.result.title',
  'app.result.row',
  // M10: settings-panel.ts's `volumeRow` nhận khoá qua tham số (`t(key)`, không viết chữ trực tiếp) — cùng khuôn
  // 'settings.reduceMotion'/'settings.threatWarnings' đã có từ M5 (đều đi qua `checkboxRow`, chưa từng liệt kê ở
  // đây; thêm ba khoá MỚI này vào cho chắc, vì đây là lần đầu khoá dạng đó được người viết chú ý tới).
  'settings.volume',
  'settings.volume.master',
  'settings.volume.music',
  'settings.volume.sfx',
  // M4: khoá ghép động (`t(\`difficulty.${d}\`)`, `t(\`save.error.${code}\`)`, lý do từ chối của giao thức)
  // M9: thêm 'hard' vào danh sách độ khó ghép động (menu.ts, lobby.ts).
  ...(['easy', 'normal', 'hard', 'mixed'] as const).map((d) => `difficulty.${d}`),
  // M9: tính cách bot (menu.ts, lobby.ts) — `t(\`personality.${p}\`)`, khoá ghép động.
  ...PERSONALITIES.map((p) => `personality.${p}`),
  ...(['BAD_FORMAT', 'RULES_VERSION', 'REPLAY_FAILED', 'HASH_MISMATCH', 'NO_GAME', 'INTERNAL'] as const).map((c) => `save.error.${c}`),
  'illegal.STALE_SEQ',
  'illegal.BAD_MESSAGE',
  // M7: chat-panel.ts ghép khoá động qua biến/tam phân, quét chữ trực tiếp không bắt được (giống tiền lệ trên).
  'chat.roster.mute',
  'chat.roster.unmute',
  'chat.roster.block',
  'chat.roster.unblock',
  ...PHRASE_IDS.map((id) => `phrase.${id}`),
  ...REPORT_REASONS.map((r) => `chat.report.reason.${r}`),
  ...(['RATE_LIMITED', 'RESTRICTED', 'INVALID_TARGET', 'NOT_ALLOWED'] satisfies ChatErrorCode[]).map((c) => `chat.error.${c}`),
  // M8: tutorial-panel.ts đọc `lesson.titleKey`/`step.textKey` (khoá động, không phải chuỗi viết tay) — nguồn khoá
  // thật là TUTORIAL_STRINGS của @hexwar/tutorial, copy y nguyên bộ khoá đó vào đây để quét được.
  ...Object.keys(TUTORIAL_STRINGS),
];

/** Mọi file .ts trong src/ (để quét các khoá chữ viết trực tiếp dạng t('khoá')). */
function sourceFiles(dir: string): string[] {
  return readdirSync(dir).flatMap((name) => {
    const path = join(dir, name);
    return statSync(path).isDirectory() ? sourceFiles(path) : path.endsWith('.ts') ? [path] : [];
  });
}

describe('i18n: hợp đồng vi/en', () => {
  it('cả hai ngôn ngữ có đúng cùng một bộ khoá (không lệch, không thiếu, không thừa)', () => {
    const [vi, en] = LOCALES.map((l) => new Set(keysOf(l)));
    expect(vi).toEqual(en);
    expect(vi?.size).toBeGreaterThan(30);
  });

  it('mọi khoá lõi client dùng đều có bản dịch ở cả hai ngôn ngữ, không rơi về chính khoá', () => {
    for (const locale of LOCALES) {
      const keys = new Set(keysOf(locale));
      for (const key of USED_KEYS) {
        expect(keys.has(key), `${locale} thiếu khoá ${key}`).toBe(true);
        expect(translate(locale, key)).not.toBe(key);
      }
    }
  });

  it('mọi khoá viết trực tiếp trong mã nguồn client (t(\'...\')) đều có ở cả hai ngôn ngữ', () => {
    const literal = /\bt\(\s*'([a-zA-Z0-9_.]+)'/g;
    const found = new Set<string>();
    for (const file of sourceFiles(join(__dirname, '..', 'src'))) {
      for (const match of readFileSync(file, 'utf8').matchAll(literal)) found.add(match[1] as string);
    }
    expect(found.size, 'phải quét được các khoá thật (kiểm tra biểu thức quét)').toBeGreaterThan(30);
    for (const locale of LOCALES) {
      const keys = new Set(keysOf(locale));
      for (const key of found) expect(keys.has(key), `${locale} thiếu khoá ${key}`).toBe(true);
    }
  });

  it('mọi mã IllegalReason của engine đều dịch được (không sót khi engine thêm lý do mới)', () => {
    for (const locale of LOCALES) {
      for (const reason of ILLEGAL_REASONS) expect(translate(locale, `illegal.${reason}`)).not.toBe(`illegal.${reason}`);
    }
  });

  it('nội suy thay đúng biến, giữ nguyên biến thiếu, không đụng văn bản khác', () => {
    expect(translate('vi', 'seat.label', { seat: 3 })).toBe('Ghế 3');
    expect(translate('en', 'seat.label', { seat: 3 })).toBe('Seat 3');
    expect(translate('vi', 'dice.rolled', { seat: 'Ghế 2', total: 15 })).toBe('Ghế 2 tung được 15 điểm');
    expect(translate('vi', 'dice.rolled')).toBe('{{seat}} tung được {{total}} điểm'); // thiếu biến: giữ nguyên placeholder
  });

  it('khoá không tồn tại trả về chính khoá, không ném lỗi (UI không bao giờ vỡ vì thiếu dịch)', () => {
    expect(translate('vi', 'khong.ton.tai')).toBe('khong.ton.tai');
  });

  it('translatorFor: hàm đóng khung theo ngôn ngữ, giữ tham chiếu locale', () => {
    const t = translatorFor('en');
    expect(t.locale).toBe('en');
    expect(t('piece.K')).toBe('King');
    expect(t('seat.label', { seat: 0 })).toBe('Seat 0');
  });
});
