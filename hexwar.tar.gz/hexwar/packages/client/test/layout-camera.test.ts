// M3: bố cục, camera quỹ đạo và chọn ô (PLAN 3.1, 3.3, 6.6, 11.4). Toàn bộ là toán thuần, chạy bằng Node.
import * as THREE from 'three';
import { describe, expect, it } from 'vitest';
import { SEATS, cell, cellsInRadius, createRng, defaultConfig, isOnBoard, newGame, rotate, worldPos, type Cell, type Seat } from '@hexwar/rules';
import {
  DEFAULT_ELEVATION,
  FOV_DEG,
  MAX_DISTANCE,
  MAX_ELEVATION,
  MIN_DISTANCE,
  SEAT_FOCUS,
  cameraPose,
  clampOrbit,
  lerpOrbit,
  panOrbit,
  projectToNdc,
  rayFromNdc,
  rotateOrbit,
  seatOrbit,
  zoomOrbit,
  type OrbitState,
} from '../src/core/camera';
import { CELL_SIZE, boardExtent, cellAt, cellCenter, seatAzimuth, wrapAngle } from '../src/core/layout';
import { intersectPlaneY, intersectVerticalCylinder, pickCell, type PickablePiece } from '../src/core/picking';
import { SEAT_COLORS, captiveColor, mixColor } from '../src/core/palette';
import { vec } from '../src/core/vec';

const RING = defaultConfig.board.seatCornerRing;
const R = defaultConfig.board.radius;
const deg = (d: number): number => (d * Math.PI) / 180;

describe('layout: toạ độ thế giới khớp engine (PLAN 3.1)', () => {
  it('cellCenter dùng đúng công thức x = 1.5·q, z = √3·(r + q/2), mặt trên ở y = 0', () => {
    for (const c of [cell(0, 0), cell(3, -2), cell(-7, 11), cell(24, -24)]) {
      const p = cellCenter(c);
      expect(p.x).toBeCloseTo(1.5 * CELL_SIZE * c.q, 12);
      expect(p.z).toBeCloseTo(Math.sqrt(3) * CELL_SIZE * (c.r + c.q / 2), 12);
      expect(p.y).toBe(0);
    }
  });

  it('cellAt là nghịch đảo của cellCenter trên cả 1801 ô, kể cả điểm lệch gần biên ô (trong bán kính nội tiếp)', () => {
    const inscribed = (Math.sqrt(3) / 2) * CELL_SIZE * 0.98;
    const rng = createRng(7);
    let count = 0;
    for (const c of cellsInRadius(R)) {
      const p = cellCenter(c);
      expect(cellAt(p.x, p.z, R)).toEqual(c);
      const angle = rng.next() * Math.PI * 2;
      const rho = rng.next() * inscribed;
      expect(cellAt(p.x + Math.cos(angle) * rho, p.z + Math.sin(angle) * rho, R)).toEqual(c);
      count++;
    }
    expect(count).toBe(1801);
  });

  it('cellAt trả về null ngoài bàn cờ hiện tại (bán kính nhỏ hơn sau thu hẹp)', () => {
    const p = cellCenter(cell(0, 24));
    expect(cellAt(p.x, p.z, 24)).toEqual(cell(0, 24));
    expect(cellAt(p.x, p.z, 23)).toBeNull();
    expect(cellAt(1e6, -1e6, R)).toBeNull();
  });

  it('seatAzimuth: ghế 0 ở 90° (đáy màn hình), mỗi ghế kế tiếp +60° (chiều kim đồng hồ)', () => {
    expect(seatAzimuth(0, RING)).toBeCloseTo(deg(90), 12);
    SEATS.forEach((seat) => {
      const expected = wrapAngle(deg(90) + deg(60) * seat);
      expect(wrapAngle(seatAzimuth(seat, RING) - expected)).toBeCloseTo(0, 9);
    });
  });

  it('wrapAngle đưa mọi góc về (−π, π]', () => {
    for (const a of [-10, -Math.PI, 0, Math.PI, 3 * Math.PI, 7.1, 100]) {
      const w = wrapAngle(a);
      expect(w).toBeGreaterThan(-Math.PI - 1e-12);
      expect(w).toBeLessThanOrEqual(Math.PI + 1e-12);
      expect(Math.cos(w)).toBeCloseTo(Math.cos(a), 9);
      expect(Math.sin(w)).toBeCloseTo(Math.sin(a), 9);
    }
  });
});

describe('camera: ghế của mình luôn ở đáy màn hình, quân tiến lên trên (PLAN 3.3)', () => {
  const aspect = 16 / 9;

  it.each(SEATS.map((s) => [s]))('ghế %i: ô góc nằm giữa-đáy màn hình, hướng tiến về tâm đi lên', (seat) => {
    const pose = cameraPose(seatOrbit(seat as Seat, RING));
    const corner = rotate(cell(0, RING), seat as Seat);
    const ahead = rotate(cell(0, RING - 4), seat as Seat); // 4 ô về phía tâm
    const a = projectToNdc(pose, cellCenter(corner), FOV_DEG, aspect);
    const b = projectToNdc(pose, cellCenter(ahead), FOV_DEG, aspect);
    expect(a).not.toBeNull();
    expect(b).not.toBeNull();
    expect(a?.x).toBeCloseTo(0, 9); // đúng giữa theo chiều ngang
    expect(a?.y).toBeLessThan(0); // nửa dưới
    expect(b?.x).toBeCloseTo(0, 9);
    expect((b?.y ?? -9) > (a?.y ?? 9)).toBe(true); // tiến về tâm = đi lên màn hình
  });

  it('ghế 0: ô bên phải ghế (x lớn hơn) hiện bên phải màn hình (x sang phải, PLAN 3.1)', () => {
    const pose = cameraPose(seatOrbit(0, RING));
    const left = projectToNdc(pose, cellCenter(cell(-5, RING)), FOV_DEG, aspect);
    const right = projectToNdc(pose, cellCenter(cell(5, RING - 5)), FOV_DEG, aspect);
    expect((right?.x ?? -9) > (left?.x ?? 9)).toBe(true);
  });

  it('rayFromNdc và projectToNdc là nghịch đảo (tia qua điểm chiếu của P cắt mặt bàn đúng tại P)', () => {
    const rng = createRng(99);
    for (let i = 0; i < 300; i++) {
      const state: OrbitState = clampOrbit(
        {
          azimuth: rng.next() * 6.28 - 3.14,
          elevation: 0.3 + rng.next() * 1.2,
          distance: 15 + rng.next() * 90,
          targetX: rng.next() * 20 - 10,
          targetZ: rng.next() * 20 - 10,
        },
        R,
      );
      const pose = cameraPose(state);
      const p = vec(state.targetX + rng.next() * 16 - 8, 0, state.targetZ + rng.next() * 16 - 8);
      const ndc = projectToNdc(pose, p, FOV_DEG, aspect);
      if (ndc === null) continue;
      const hit = intersectPlaneY(rayFromNdc(pose, ndc.x, ndc.y, FOV_DEG, aspect), 0);
      expect(hit).not.toBeNull();
      expect(hit?.x).toBeCloseTo(p.x, 6);
      expect(hit?.z).toBeCloseTo(p.z, 6);
    }
  });

  it('khớp THREE.PerspectiveCamera + Raycaster (đối chiếu độc lập với thư viện)', () => {
    const rng = createRng(2024);
    for (let i = 0; i < 100; i++) {
      const state = clampOrbit(
        { azimuth: rng.next() * 6 - 3, elevation: 0.25 + rng.next() * 1.25, distance: 10 + rng.next() * 100, targetX: rng.next() * 30 - 15, targetZ: rng.next() * 30 - 15 },
        R,
      );
      const pose = cameraPose(state);
      const camera = new THREE.PerspectiveCamera(FOV_DEG, aspect, 0.1, 500);
      camera.position.set(pose.position.x, pose.position.y, pose.position.z);
      camera.lookAt(state.targetX, 0, state.targetZ);
      camera.updateMatrixWorld(true);
      camera.updateProjectionMatrix();
      const ndcX = rng.next() * 2 - 1;
      const ndcY = rng.next() * 2 - 1;
      const raycaster = new THREE.Raycaster();
      raycaster.setFromCamera(new THREE.Vector2(ndcX, ndcY), camera);
      const mine = rayFromNdc(pose, ndcX, ndcY, FOV_DEG, aspect);
      expect(mine.dir.x).toBeCloseTo(raycaster.ray.direction.x, 9);
      expect(mine.dir.y).toBeCloseTo(raycaster.ray.direction.y, 9);
      expect(mine.dir.z).toBeCloseTo(raycaster.ray.direction.z, 9);
      expect(mine.origin.x).toBeCloseTo(raycaster.ray.origin.x, 9);
    }
  });

  it('điều khiển: xoay/zoom/pan có giới hạn, không lật camera, target không rời khỏi bàn', () => {
    const s0 = seatOrbit(0, RING);
    expect(rotateOrbit(s0, 0, 10, R).elevation).toBeCloseTo(MAX_ELEVATION, 12);
    expect(rotateOrbit(s0, 0, -10, R).elevation).toBeGreaterThan(0);
    expect(zoomOrbit(s0, 1e-6, R).distance).toBe(MIN_DISTANCE);
    expect(zoomOrbit(s0, 1e6, R).distance).toBeLessThanOrEqual(140);
    const far = panOrbit(s0, 1e5, 1e5, R);
    expect(Math.hypot(far.targetX, far.targetZ)).toBeCloseTo(boardExtent(R), 6);
  });

  it('pan đi theo hệ quy chiếu của camera: "tiến" luôn hướng tới tâm bàn khi camera ở ghế bất kỳ', () => {
    for (const seat of SEATS) {
      const start = seatOrbit(seat, RING);
      const moved = panOrbit(start, 0, 5, R);
      expect(Math.hypot(start.targetX, start.targetZ)).toBeCloseTo(SEAT_FOCUS, 9);
      expect(Math.hypot(moved.targetX, moved.targetZ)).toBeCloseTo(SEAT_FOCUS - 5, 9); // 5 đơn vị về phía tâm
      const along = (moved.targetX * Math.cos(start.azimuth) + moved.targetZ * Math.sin(start.azimuth)) / (SEAT_FOCUS - 5);
      expect(along).toBeCloseTo(1, 9); // vẫn nằm trên trục của ghế
    }
  });

  it('lerpOrbit đi đường góc ngắn nhất (không quay vòng dài) và chạm hai đầu mút', () => {
    const a: OrbitState = { azimuth: deg(170), elevation: 0.9, distance: 60, targetX: 0, targetZ: 0 };
    const b: OrbitState = { azimuth: deg(-170), elevation: 0.5, distance: 40, targetX: 10, targetZ: -4 };
    const mid = lerpOrbit(a, b, 0.5);
    expect(Math.abs(wrapAngle(mid.azimuth - deg(180)))).toBeLessThan(1e-9); // qua 180°, không qua 0°
    expect(lerpOrbit(a, b, 0)).toEqual({ ...a, azimuth: wrapAngle(a.azimuth) });
    expect(wrapAngle(lerpOrbit(a, b, 1).azimuth - b.azimuth)).toBeCloseTo(0, 12);
    expect(mid.distance).toBeCloseTo(50, 12);
  });

  it('camera mặc định của mỗi ghế thấy trọn 18 quân của ghế đó (lề ≥ 15%) ở 16:9 và 4:3, và vẫn thấy tâm bàn', () => {
    const initial = newGame(defaultConfig, SEATS, 1);
    for (const seat of SEATS) {
      const pose = cameraPose(seatOrbit(seat, RING));
      for (const ratio of [16 / 9, 4 / 3]) {
        for (const piece of initial.pieces.filter((p) => p.owner === seat)) {
          const ndc = projectToNdc(pose, cellCenter(piece.cell), FOV_DEG, ratio);
          expect(ndc, `ghế ${seat} quân ${piece.id}`).not.toBeNull();
          expect(Math.abs(ndc?.x ?? 9)).toBeLessThan(0.85);
          expect(Math.abs(ndc?.y ?? 9)).toBeLessThan(0.85);
        }
        const centre = projectToNdc(pose, vec(0, 0, 0), FOV_DEG, ratio);
        expect(Math.abs(centre?.y ?? 9)).toBeLessThan(0.95);
      }
    }
    expect(DEFAULT_ELEVATION).toBeLessThan(MAX_ELEVATION);
  });

  it('zoom ra hết cỡ (MAX_DISTANCE) thấy trọn bàn R=24: ô góc của cả 6 ghế nằm trong khung 16:9', () => {
    for (const seat of SEATS) {
      const pose = cameraPose({ ...seatOrbit(seat, RING), distance: MAX_DISTANCE });
      for (const s of SEATS) {
        const ndc = projectToNdc(pose, cellCenter(rotate(cell(0, R), s)), FOV_DEG, 16 / 9);
        expect(ndc).not.toBeNull();
        expect(Math.abs(ndc?.x ?? 9)).toBeLessThan(1);
        expect(Math.abs(ndc?.y ?? 9)).toBeLessThan(1);
      }
    }
  });
});

describe('picking: tia → ô / quân (PLAN 6.6)', () => {
  const aspect = 1.6;

  it('cắt mặt phẳng: đúng điểm, null nếu tia đi lên hoặc song song', () => {
    const hit = intersectPlaneY({ origin: vec(0, 10, 0), dir: vec(0, -1, 0) }, 0);
    expect(hit).toEqual({ t: 10, x: 0, z: 0 });
    expect(intersectPlaneY({ origin: vec(0, 10, 0), dir: vec(0, 1, 0) }, 0)).toBeNull();
    expect(intersectPlaneY({ origin: vec(0, 10, 0), dir: vec(1, 0, 0) }, 0)).toBeNull();
  });

  it('cắt trụ đứng: trúng thân, trúng nắp, trượt, và trả t gần nhất', () => {
    const side = intersectVerticalCylinder({ origin: vec(-5, 0.5, 0), dir: vec(1, 0, 0) }, 0, 0, 1, 0, 1);
    expect(side).toBeCloseTo(4, 12);
    const top = intersectVerticalCylinder({ origin: vec(0.2, 5, 0), dir: vec(0, -1, 0) }, 0, 0, 1, 0, 2);
    expect(top).toBeCloseTo(3, 12);
    expect(intersectVerticalCylinder({ origin: vec(-5, 3, 0), dir: vec(1, 0, 0) }, 0, 0, 1, 0, 1)).toBeNull(); // bay trên đầu
    expect(intersectVerticalCylinder({ origin: vec(-5, 0.5, 2), dir: vec(1, 0, 0) }, 0, 0, 1, 0, 1)).toBeNull(); // lệch bán kính
    expect(intersectVerticalCylinder({ origin: vec(5, 0.5, 0), dir: vec(1, 0, 0) }, 0, 0, 1, 0, 1)).toBeNull(); // quay lưng
  });

  it('nhấp vào giữa màn hình chọn đúng ô ở tâm; nhấp vào điểm chiếu của tâm ô bất kỳ chọn đúng ô đó', () => {
    const pose = cameraPose({ ...seatOrbit(2, RING), distance: 90 });
    for (const c of [cell(0, 0), cell(5, -3), cell(-12, 7), cell(20, -10), cell(-3, 23)]) {
      const ndc = projectToNdc(pose, cellCenter(c), FOV_DEG, aspect);
      expect(ndc).not.toBeNull();
      const pick = pickCell(rayFromNdc(pose, ndc?.x ?? 0, ndc?.y ?? 0, FOV_DEG, aspect), [], R);
      expect(pick).toEqual({ kind: 'cell', cell: c });
    }
  });

  it('nhấp ra ngoài mép bàn hoặc lên trời → null', () => {
    const pose = cameraPose({ ...seatOrbit(0, RING), distance: 130 });
    expect(pickCell(rayFromNdc(pose, 0.99, 0.99, FOV_DEG, aspect), [], 3)).toBeNull(); // bàn thu nhỏ còn bán kính 3
    const flat = cameraPose({ ...seatOrbit(0, RING), elevation: 0.2 });
    expect(pickCell(rayFromNdc(flat, 0, 0.99, FOV_DEG, aspect), [], R)).toBeNull(); // nhìn lên trời
  });

  it('quân cao che ô phía sau: nhấp vào đầu quân chọn quân, không chọn ô nằm sau nó', () => {
    const pose = cameraPose({ ...seatOrbit(0, RING), elevation: deg(35), distance: 40 });
    const at: Cell = cell(2, -1);
    const base = cellCenter(at);
    const piece: PickablePiece = { id: 'k0', cell: at, x: base.x, z: base.z, radius: 0.45, height: 1.6 };
    const head = projectToNdc(pose, vec(base.x, 1.5, base.z), FOV_DEG, aspect);
    expect(head).not.toBeNull();
    const ray = rayFromNdc(pose, head?.x ?? 0, head?.y ?? 0, FOV_DEG, aspect);
    // Không có quân: tia cắt mặt bàn ở một ô phía SAU quân (xa camera hơn).
    const groundOnly = pickCell(ray, [], R);
    expect(groundOnly?.kind).toBe('cell');
    expect(groundOnly && 'cell' in groundOnly ? groundOnly.cell : at).not.toEqual(at);
    // Có quân: chọn quân.
    expect(pickCell(ray, [piece], R)).toEqual({ kind: 'piece', pieceId: 'k0', cell: at });
  });

  it('nhiều quân chồng nhau trên tia: chọn quân gần camera nhất', () => {
    const pose = cameraPose({ ...seatOrbit(0, RING), elevation: deg(20), distance: 30 });
    const near: Cell = cell(0, 2);
    const far: Cell = cell(0, -2);
    const mk = (id: string, c: Cell): PickablePiece => {
      const p = cellCenter(c);
      return { id, cell: c, x: p.x, z: p.z, radius: 0.5, height: 3 };
    };
    const ndc = projectToNdc(pose, vec(cellCenter(near).x, 1, cellCenter(near).z), FOV_DEG, aspect);
    const ray = rayFromNdc(pose, ndc?.x ?? 0, ndc?.y ?? 0, FOV_DEG, aspect);
    const pick = pickCell(ray, [mk('far', far), mk('near', near)], R);
    expect(pick).toEqual({ kind: 'piece', pieceId: 'near', cell: near });
  });

  it('mọi ô trong bàn đều chọn được đúng ô khi nhìn từ 6 ghế (không sót, không lệch)', () => {
    const rng = createRng(5);
    let checked = 0;
    for (const seat of SEATS) {
      const pose = cameraPose({ ...seatOrbit(seat, RING), distance: 120, elevation: deg(60) });
      for (let i = 0; i < 120; i++) {
        const all = cellsInRadius(R);
        const c = all[rng.int(all.length)] as Cell;
        const ndc = projectToNdc(pose, cellCenter(c), FOV_DEG, 16 / 9);
        if (ndc === null || Math.abs(ndc.x) > 1 || Math.abs(ndc.y) > 1) continue;
        const pick = pickCell(rayFromNdc(pose, ndc.x, ndc.y, FOV_DEG, 16 / 9), [], R);
        expect(pick).toEqual({ kind: 'cell', cell: c });
        expect(isOnBoard(c, R)).toBe(true);
        checked++;
      }
    }
    expect(checked).toBeGreaterThan(500);
  });

  it('worldPos của engine và cellCenter khớp (không có bản công thức thứ hai lệch)', () => {
    const c = cell(-6, 9);
    expect(cellCenter(c).x).toBe(worldPos(c, CELL_SIZE).x);
    expect(cellCenter(c).z).toBe(worldPos(c, CELL_SIZE).z);
  });
});

describe('palette (PLAN 12.3)', () => {
  it('sáu màu người chơi đúng bảng Okabe–Ito của PLAN và khác nhau', () => {
    expect(SEAT_COLORS.map((c) => c.toString(16).padStart(6, '0'))).toEqual(['e69f00', '56b4e9', '009e73', 'f0e442', 'd55e00', 'cc79a7']);
    expect(new Set(SEAT_COLORS).size).toBe(6);
  });

  it('mixColor: hai đầu mút và điểm giữa; tù binh khác màu chủ nhưng vẫn phân biệt được giữa các ghế', () => {
    expect(mixColor(0x000000, 0xffffff, 0)).toBe(0x000000);
    expect(mixColor(0x000000, 0xffffff, 1)).toBe(0xffffff);
    expect(mixColor(0x000000, 0xfefefe, 0.5)).toBe(0x7f7f7f);
    const captives = SEATS.map((s) => captiveColor(s));
    expect(new Set(captives).size).toBe(6);
    SEATS.forEach((s, i) => expect(captives[i]).not.toBe(SEAT_COLORS[s]));
  });
});
