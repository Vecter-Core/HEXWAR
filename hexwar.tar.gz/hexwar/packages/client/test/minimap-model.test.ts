// PLAN 11.2 "Bản đồ nhỏ": chấm quân theo toạ độ chuẩn hoá, vòng sắp biến mất nhấp nháy.
import { describe, expect, it } from 'vitest';
import { createPiece, defaultConfig, makeState } from '@hexwar/rules';
import { buildMinimapView } from '../src/core/minimap-model';
import { seatColor, toCss } from '../src/core/palette';

const START_RADIUS = defaultConfig.board.radius;

describe('buildMinimapView', () => {
  it('quân ở tâm bàn: chấm ở đúng tâm bản đồ (0, 0); màu theo seatColor', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1] });
    const view = buildMinimapView(state, START_RADIUS);
    const dot = view.dots.find((d) => d.isKing && d.x === 0 && d.y === 0);
    expect(dot).toBeDefined();
    expect(dot?.color).toBe(toCss(seatColor(0)));
  });

  it('quân đứng đúng ở góc xuất phát (vòng ngoài): toạ độ chuẩn hoá có độ lớn xấp xỉ 1 (chạm mép bản đồ)', () => {
    const config = defaultConfig;
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: config.board.seatCornerRing }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1] });
    const dot = buildMinimapView(state, START_RADIUS).dots.find((d) => d.isKing);
    const magnitude = Math.hypot(dot?.x ?? 0, dot?.y ?? 0);
    expect(magnitude).toBeGreaterThan(0.9);
    expect(magnitude).toBeLessThanOrEqual(1.001);
  });

  it('tù binh (không hoạt động) không xuất hiện thành chấm', () => {
    const captive = { ...createPiece('c0', 0, 'N', { q: 1, r: 0 }), status: 'captive' as const, holder: 1 as const };
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), captive, createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1] });
    expect(buildMinimapView(state, START_RADIUS).dots).toHaveLength(2);
  });

  it('boardFraction = bán kính hiện tại / bán kính lúc bắt đầu', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1], radius: 12 });
    expect(buildMinimapView(state, 24).boardFraction).toBeCloseTo(0.5);
  });

  it('gần một lần thu hẹp (trong ngưỡng cảnh báo): warnFraction/warnLevel khớp nextCollapse', () => {
    const firstCollapseRound = defaultConfig.collapse.rounds[0] as number; // hiệp 50 theo PLAN 3.5
    const yellowRound = firstCollapseRound - defaultConfig.collapse.warn.yellowRoundsBefore;
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1], round: yellowRound });
    const view = buildMinimapView(state, START_RADIUS);
    expect(view.warnLevel).toBe('yellow');
    expect(view.warnFraction).toBeCloseTo(START_RADIUS / START_RADIUS); // vòng ngoài cùng (bán kính = START_RADIUS) sắp biến mất
  });

  it('còn xa lần thu hẹp tiếp theo: warnFraction/warnLevel đều null', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1], round: 1 });
    const view = buildMinimapView(state, START_RADIUS);
    expect(view.warnLevel).toBeNull();
    expect(view.warnFraction).toBeNull();
  });

  it('ván đã kết thúc: không tính cảnh báo thu hẹp nữa (khớp cách hud-model xử lý)', () => {
    const firstCollapseRound = defaultConfig.collapse.rounds[0] as number;
    const state = { ...makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1], round: firstCollapseRound - 1 }), phase: 'over' as const };
    expect(buildMinimapView(state, START_RADIUS).warnLevel).toBeNull();
  });
});
