// M3: hình khối quân cờ (PLAN 12.3). Thuần THREE trên CPU (gộp geometry không cần WebGL) nên kiểm bằng Node.
// Không kiểm "đẹp" (chủ quan, để mắt người ở ảnh chụp Playwright) — chỉ kiểm bất biến dựng hình: không vỡ, đứng
// trên mặt ô (đế ở y = 0), đủ cao để phân biệt loại quân, và khớp với `PIECE_FOOTPRINT` dùng cho picking/camera.
import type * as THREE from 'three';
import { describe, expect, it } from 'vitest';
import { PIECE_TYPES, type PieceType } from '@hexwar/rules';
import { CAPTIVE_SCALE, PIECE_FOOTPRINT, createPieceGeometry } from '../src/scene/piece-geometry';

function bounds(geometry: THREE.BufferGeometry): { minY: number; maxY: number; maxRadius: number; vertexCount: number } {
  const pos = geometry.getAttribute('position');
  let minY = Number.POSITIVE_INFINITY;
  let maxY = Number.NEGATIVE_INFINITY;
  let maxRadius = 0;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const y = pos.getY(i);
    const z = pos.getZ(i);
    minY = Math.min(minY, y);
    maxY = Math.max(maxY, y);
    maxRadius = Math.max(maxRadius, Math.hypot(x, z));
  }
  return { minY, maxY, maxRadius, vertexCount: pos.count };
}

describe('createPieceGeometry: mỗi loại quân dựng được, đứng trên mặt ô', () => {
  it.each(PIECE_TYPES)('%s: đế chạm y = 0, không có phần chìm xuống dưới ô, có hình khối thật (không suy biến)', (type) => {
    const geometry = createPieceGeometry(type);
    const { minY, maxY, vertexCount } = bounds(geometry);
    expect(vertexCount).toBeGreaterThan(50);
    expect(minY).toBeCloseTo(0, 6);
    expect(maxY).toBeGreaterThan(0.2); // đủ cao để nhìn thấy trên ô
    geometry.dispose();
  });

  it('mỗi loại quân có một chiều cao khác nhau theo đúng thứ bậc PLAN (Tốt thấp nhất; Vua/Hậu cao nhất)', () => {
    const heights = new Map(PIECE_TYPES.map((t) => [t, bounds(createPieceGeometry(t)).maxY]));
    const pawn = heights.get('P') as number;
    const king = heights.get('K') as number;
    const queen = heights.get('Q') as number;
    for (const t of PIECE_TYPES) if (t !== 'P') expect(heights.get(t) as number).toBeGreaterThan(pawn);
    expect(king).toBeGreaterThan(pawn * 1.5);
    expect(queen).toBeGreaterThan(pawn * 1.5);
  });

  it('khớp với PIECE_FOOTPRINT dùng cho picking (picking.ts): bán kính/chiều cao thật không vượt quá khai báo', () => {
    for (const type of PIECE_TYPES) {
      const { maxY, maxRadius } = bounds(createPieceGeometry(type));
      const footprint = PIECE_FOOTPRINT[type];
      expect(maxY, `${type}: chiều cao thật ${maxY} > khai báo ${footprint.height}`).toBeLessThanOrEqual(footprint.height + 1e-6);
      expect(maxRadius, `${type}: bán kính thật ${maxRadius} > khai báo ${footprint.radius}`).toBeLessThanOrEqual(footprint.radius + 1e-6);
    }
  });

  it('không có toạ độ NaN/Infinity (lỗi thường gặp khi gộp geometry sai thuộc tính)', () => {
    for (const type of PIECE_TYPES) {
      const pos = createPieceGeometry(type).getAttribute('position');
      for (let i = 0; i < pos.count; i++) {
        expect(Number.isFinite(pos.getX(i))).toBe(true);
        expect(Number.isFinite(pos.getY(i))).toBe(true);
        expect(Number.isFinite(pos.getZ(i))).toBe(true);
      }
    }
  });

  it('gọi lại nhiều lần cho cùng một loại luôn ra hình khối giống hệt (tất định, không phụ thuộc trạng thái toàn cục)', () => {
    for (const type of PIECE_TYPES) {
      const a = Array.from(createPieceGeometry(type).getAttribute('position').array);
      const b = Array.from(createPieceGeometry(type).getAttribute('position').array);
      expect(a).toEqual(b);
    }
  });
});

describe('CAPTIVE_SCALE (PLAN 12.3: tù binh "thấp hơn quân giữ")', () => {
  it('nằm trong (0, 1) — co lại nhưng không biến mất, không phóng to', () => {
    expect(CAPTIVE_SCALE).toBeGreaterThan(0);
    expect(CAPTIVE_SCALE).toBeLessThan(1);
  });
});

describe('PIECE_FOOTPRINT: đủ cho cả 7 loại quân, không có bán kính/chiều cao phi lý', () => {
  it('mọi loại quân có bán kính và chiều cao dương, nhỏ hơn nửa cạnh ô (không tràn sang ô bên)', () => {
    const typeSet = new Set<PieceType>(PIECE_TYPES);
    expect(new Set(Object.keys(PIECE_FOOTPRINT))).toEqual(typeSet);
    for (const { radius, height } of Object.values(PIECE_FOOTPRINT)) {
      expect(radius).toBeGreaterThan(0);
      expect(radius).toBeLessThan(0.5);
      expect(height).toBeGreaterThan(0);
    }
  });
});
