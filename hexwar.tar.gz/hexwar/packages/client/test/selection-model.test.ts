// PLAN 11.2 "Dưới giữa": loại quân, tầm đi, kills/ngưỡng phong cấp, trạng thái tù binh, X-14 đang chờ xác nhận.
import { describe, expect, it } from 'vitest';
import { createPiece, defaultConfig, makeState, type Piece } from '@hexwar/rules';
import { buildSelectionView } from '../src/core/selection-model';
import { translatorFor } from '../src/core/i18n';

const t = translatorFor('vi');

describe('buildSelectionView', () => {
  it('quân trượt (Xe): tầm đi theo config.reach.R, không có thông tin phong cấp (không xuất thân Tốt)', () => {
    const rook = createPiece('r0', 0, 'R', { q: 0, r: 0 });
    const state = makeState({ pieces: [rook, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'r0', conscript: false, moves: new Map() }, t);
    expect(view?.pieceLabel).toBe('Xe');
    expect(view?.reachText).toBe(`Tầm đi: ≤ ${defaultConfig.reach.R} ô`);
    expect(view?.killsText).toBeNull();
    expect(view?.promotionText).toBeNull();
    expect(view?.promotionProgress).toBeNull();
    expect(view?.captiveText).toBeNull();
    expect(view?.hasPending).toBe(false);
  });

  it('Mã, Vua, Hề, Tốt: mỗi loại một cách diễn đạt tầm đi riêng', () => {
    const pieces: Piece[] = [
      createPiece('n0', 0, 'N', { q: 0, r: 0 }),
      createPiece('k0', 0, 'K', { q: -10, r: 10 }),
      createPiece('j0', 0, 'J', { q: 1, r: 0 }),
      createPiece('p0', 0, 'P', { q: 2, r: 0 }),
      createPiece('k1', 1, 'K', { q: 10, r: -10 }),
    ];
    const state = makeState({ pieces, seats: [0, 1] });
    const of = (id: string): string | undefined => buildSelectionView(state, { pieceId: id, conscript: false, moves: new Map() }, t)?.reachText;
    expect(of('n0')).toBe('Tầm đi: cố định (nhảy qua quân chắn)');
    expect(of('k0')).toBe('Tầm đi: 1 bước');
    expect(of('j0')).toBe(`Tầm đi: ≤ ${defaultConfig.reach.J} ô`);
    expect(of('p0')).toBe('Tầm đi: 1 ô tiến/lùi, ăn chéo');
  });

  it('Tốt chưa phong: có kills + tiến độ tới Mã (ngưỡng 6, R-41)', () => {
    const pawn: Piece = { ...createPiece('p0', 0, 'P', { q: 0, r: 0 }), kills: 4 };
    const state = makeState({ pieces: [pawn, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'p0', conscript: false, moves: new Map() }, t);
    expect(view?.killsText).toBe('4 kill');
    expect(view?.promotionText).toBe('Còn 2 kill nữa để phong Mã');
    expect(view?.promotionProgress).toBeCloseTo(4 / 6);
  });

  it('quân xuất thân Tốt đã phong Hậu (bậc cuối): báo đã đạt bậc cao nhất, tiến độ đầy', () => {
    const queen: Piece = { ...createPiece('q0', 0, 'Q', { q: 0, r: 0 }), origin: 'P', kills: 22 };
    const state = makeState({ pieces: [queen, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'q0', conscript: false, moves: new Map() }, t);
    expect(view?.killsText).toBe('22 kill');
    expect(view?.promotionText).toBe('Đã đạt bậc phong cấp cao nhất');
    expect(view?.promotionProgress).toBe(1);
  });

  it('quân KHÔNG xuất thân Tốt (Hậu ban đầu) dù cùng loại: không có thông tin phong cấp', () => {
    const queen = createPiece('q0', 0, 'Q', { q: 0, r: 0 }); // origin = 'Q' (createPiece: origin = type)
    const state = makeState({ pieces: [queen, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'q0', conscript: false, moves: new Map() }, t);
    expect(view?.killsText).toBeNull();
    expect(view?.promotionText).toBeNull();
  });

  it('đang trưng dụng tù binh (conscript=true): có captiveText', () => {
    const captive: Piece = { ...createPiece('c1', 1, 'R', { q: 3, r: 0 }), status: 'captive', holder: 0, armed: true };
    const state = makeState({ pieces: [captive, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'c1', conscript: true, moves: new Map() }, t);
    expect(view?.captiveText).toBe('Tù binh — có thể trưng dụng đi 1 nước (R-32)');
  });

  it('có pendingMove (X-14): hasPending = true', () => {
    const rook = createPiece('r0', 0, 'R', { q: 0, r: 0 });
    const state = makeState({ pieces: [rook, createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    const view = buildSelectionView(state, { pieceId: 'r0', conscript: false, moves: new Map(), pendingMove: { pieceId: 'r0', to: { q: 1, r: 0 } } }, t);
    expect(view?.hasPending).toBe(true);
  });

  it('quân đang chọn không còn trên bàn (đã bị loại giữa chừng): trả về null, không ném lỗi', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: -10, r: 10 }), createPiece('k1', 1, 'K', { q: 10, r: -10 })], seats: [0, 1] });
    expect(buildSelectionView(state, { pieceId: 'ghost', conscript: false, moves: new Map() }, t)).toBeNull();
  });
});
