// PLAN 11.5 (Cài đặt): lưu cục bộ, không vỡ UI khi dữ liệu hỏng/thiếu (cùng nguyên tắc với save-store).
import { describe, expect, it } from 'vitest';
import { DEFAULT_SETTINGS, LocalStorageSettingsStore, MemorySettingsStore, type Settings } from '../src/net/settings-store';

class FakeStorage {
  private data = new Map<string, string>();
  getItem(key: string): string | null {
    return this.data.get(key) ?? null;
  }
  setItem(key: string, value: string): void {
    this.data.set(key, value);
  }
}

describe('LocalStorageSettingsStore', () => {
  it('chưa lưu gì: trả về mặc định', () => {
    const store = new LocalStorageSettingsStore(new FakeStorage());
    expect(store.load()).toEqual(DEFAULT_SETTINGS);
  });

  it('lưu rồi đọc lại: khớp nguyên vẹn', () => {
    const storage = new FakeStorage();
    const store = new LocalStorageSettingsStore(storage);
    const settings: Settings = {
      locale: 'en',
      graphics: 'high',
      reduceMotion: true,
      threatWarnings: false,
      confirmMoves: true,
      voiceTurnOnly: true,
      voiceMicDeviceId: 'mic-123',
      volumeMaster: 0.5,
      volumeMusic: 0.3,
      volumeSfx: 0.9,
    };
    store.save(settings);
    expect(new LocalStorageSettingsStore(storage).load()).toEqual(settings);
  });

  it('dữ liệu hỏng (không phải JSON, hoặc thiếu trường): trả về mặc định cho phần hỏng/thiếu, không ném lỗi', () => {
    const storage = new FakeStorage();
    storage.setItem('hexwar.settings.v1', '{not json');
    expect(new LocalStorageSettingsStore(storage).load()).toEqual(DEFAULT_SETTINGS);

    storage.setItem('hexwar.settings.v1', JSON.stringify({ locale: 'fr', graphics: 'ultra', reduceMotion: 'yes' }));
    expect(new LocalStorageSettingsStore(storage).load()).toEqual(DEFAULT_SETTINGS);

    storage.setItem('hexwar.settings.v1', JSON.stringify({ locale: 'en' }));
    expect(new LocalStorageSettingsStore(storage).load()).toEqual({ ...DEFAULT_SETTINGS, locale: 'en' });

    storage.setItem('hexwar.settings.v1', JSON.stringify({ voiceTurnOnly: 'yes', voiceMicDeviceId: 42 }));
    expect(new LocalStorageSettingsStore(storage).load()).toEqual(DEFAULT_SETTINGS);
  });

  it('M10: âm lượng ngoài [0, 1] hoặc không phải số thì dùng mặc định cho mục đó, số hợp lệ thì kẹp về [0, 1]', () => {
    const storage = new FakeStorage();
    storage.setItem('hexwar.settings.v1', JSON.stringify({ volumeMaster: 1.5, volumeMusic: -0.2, volumeSfx: 'loud' }));
    expect(new LocalStorageSettingsStore(storage).load()).toEqual({ ...DEFAULT_SETTINGS, volumeMaster: 1, volumeMusic: 0 });

    storage.setItem('hexwar.settings.v1', JSON.stringify({ volumeMaster: 0.42 }));
    expect(new LocalStorageSettingsStore(storage).load()).toEqual({ ...DEFAULT_SETTINGS, volumeMaster: 0.42 });
  });

  it('không có Storage (chế độ riêng tư nghiêm ngặt): dùng mặc định, save() không ném lỗi', () => {
    const store = new LocalStorageSettingsStore(null);
    expect(store.load()).toEqual(DEFAULT_SETTINGS);
    expect(() => store.save({ ...DEFAULT_SETTINGS, graphics: 'low' })).not.toThrow();
  });
});

describe('MemorySettingsStore', () => {
  it('bắt đầu bằng mặc định, save() rồi load() lại đúng giá trị vừa lưu', () => {
    const store = new MemorySettingsStore();
    expect(store.load()).toEqual(DEFAULT_SETTINGS);
    const settings: Settings = { ...DEFAULT_SETTINGS, confirmMoves: true };
    store.save(settings);
    expect(store.load()).toEqual(settings);
  });
});
