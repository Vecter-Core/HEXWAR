// Bộ mô phỏng nhỏ cho test client: chơi ván ngẫu nhiên có seed bằng API công khai của engine, thiên về các hành động
// hiếm (ăn Vua, trưng dụng, ăn quân) để dòng sự kiện phủ đủ các loại.
import {
  SEATS,
  applyMove,
  configWith,
  createRng,
  defaultConfig,
  legalMoves,
  newGame,
  rollDice,
  type ActionResult,
  type GameEvent,
  type GameState,
  type Move,
  type Rng,
  type RulesConfig,
  type Seat,
} from '@hexwar/rules';

/** Bàn nhỏ R=16, lịch thu hẹp thưa: ván nào cũng có giao tranh, tù binh, phong cấp rồi mới thu hẹp. */
const small = {
  board: { radius: 16, seatCornerRing: 15 },
  collapse: { rounds: [20, 45, 70, 95, 120, 145, 170, 195, 220, 245], extension: { firstRound: 270, every: 25 }, hardCapRound: 500 },
};

export const SIM_CONFIGS: Readonly<Record<string, RulesConfig>> = {
  'luật chuẩn R=24': defaultConfig,
  'R=16 lịch thưa': configWith(small),
  'R=16 phong cấp dễ': configWith({ ...small, promotion: { N: 1, B: 2, R: 3, Q: 4 } }),
  'R=16 biến thể cờ': configWith({
    ...small,
    captive: { conscript: false, rescueByOwner: false },
    jester: { savesFromCollapse: true },
    promotion: { cumulativeKills: false },
  }),
};

function pick<T>(items: readonly T[], rng: Rng): T {
  const item = items[rng.int(items.length)];
  if (item === undefined) throw new Error('pick: danh sách rỗng');
  return item;
}

function chooseMove(state: GameState, rng: Rng): Move {
  const moves = legalMoves(state, state.turnSeat as Seat);
  const at = (m: Move) => state.pieces.find((p) => p.status === 'active' && p.cell.q === m.to.q && p.cell.r === m.to.r);
  const kingHits = moves.filter((m) => at(m)?.type === 'K');
  if (kingHits.length > 0 && rng.next() < 0.95) return pick(kingHits, rng);
  const conscripts = moves.filter((m) => m.conscript === true);
  if (conscripts.length > 0 && rng.next() < 0.5) return pick(conscripts, rng);
  const captures = moves.filter((m) => {
    const t = at(m);
    return t !== undefined && t.owner !== state.turnSeat;
  });
  if (captures.length > 0 && rng.next() < 0.5) return pick(captures, rng);
  return pick(moves, rng);
}

export interface Step {
  readonly before: GameState;
  readonly move: Move | null;
  readonly result: ActionResult;
}

/** Bắt đầu ván (xúc xắc) rồi chơi tới khi kết thúc; gọi `onStep` sau mỗi hành động. */
export function playGame(seed: number, config: RulesConfig, onStep: (step: Step) => void, maxTurns = 20_000): GameState {
  const rng = createRng(seed ^ 0x9e3779b9);
  const start = rollDice(newGame(config, SEATS, seed), createRng(seed));
  onStep({ before: newGame(config, SEATS, seed), move: null, result: start });
  let state = start.state;
  let turns = 0;
  while (state.phase === 'playing') {
    if (turns++ >= maxTurns) throw new Error(`Ván seed=${seed} chưa kết thúc sau ${maxTurns} nước`);
    const move = chooseMove(state, rng);
    const result = applyMove(state, move);
    onStep({ before: state, move, result });
    state = result.state;
  }
  return state;
}

export const eventTypes = (events: readonly GameEvent[]): Set<string> => new Set(events.map((e) => e.type));
