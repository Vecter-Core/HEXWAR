// X-06 (PLAN 11.2 "cảnh báo đe doạ"): quân của người tới lượt đang đứng vào ô đối thủ ăn được ngay nước tới.
import { describe, expect, it } from 'vitest';
import { cellKey, createPiece, makeState, type Piece } from '@hexwar/rules';
import { NO_THREATS, threatsFor } from '../src/core/threats';

describe('threatsFor', () => {
  it('seat = null: không tính gì (X-06 tắt hoặc không phải lượt của mình)', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: 5, r: 0 })], seats: [0, 1] });
    expect(threatsFor(state, null)).toBe(NO_THREATS);
  });

  it('Xe địch ăn được Vua của mình ngay nước tới: báo đúng ô, kingThreatened = true', () => {
    const pieces: Piece[] = [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('r1', 1, 'R', { q: 3, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })];
    const state = makeState({ pieces, seats: [0, 1] });
    const threats = threatsFor(state, 0);
    expect(threats.kingThreatened).toBe(true);
    expect(threats.cellKeys.has(cellKey({ q: 0, r: 0 }))).toBe(true);
    expect(threats.cellKeys.size).toBe(1);
  });

  it('không có đe doạ nào: cellKeys rỗng, kingThreatened = false', () => {
    const pieces: Piece[] = [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })];
    const state = makeState({ pieces, seats: [0, 1] });
    const threats = threatsFor(state, 0);
    expect(threats.cellKeys.size).toBe(0);
    expect(threats.kingThreatened).toBe(false);
  });

  it('chỉ tính quân của SEAT được hỏi, không tính quân bị đe doạ của người khác', () => {
    const pieces: Piece[] = [
      createPiece('k0', 0, 'K', { q: -10, r: 10 }),
      createPiece('k1', 1, 'K', { q: 0, r: 0 }),
      createPiece('r2', 2, 'R', { q: 3, r: 0 }), // đe doạ Vua ghế 1, không phải ghế 0
    ];
    const state = makeState({ pieces, seats: [0, 1, 2] });
    expect(threatsFor(state, 0).cellKeys.size).toBe(0);
    expect(threatsFor(state, 1).kingThreatened).toBe(true);
  });

  it('quân đang là tù binh (không hoạt động) không được tính, kể cả khi ô đó bị vây', () => {
    const captive: Piece = { ...createPiece('c0', 0, 'N', { q: 0, r: 0 }), status: 'captive', holder: 1 };
    const pieces: Piece[] = [createPiece('k0', 0, 'K', { q: -10, r: 10 }), captive, createPiece('r1', 1, 'R', { q: 3, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 0 })];
    const state = makeState({ pieces, seats: [0, 1] });
    expect(threatsFor(state, 0).cellKeys.size).toBe(0);
  });

  it('nhớ đệm theo tham chiếu state: gọi lại với CÙNG state trả về đúng cùng object (không tính lại)', () => {
    const state = makeState({ pieces: [createPiece('k0', 0, 'K', { q: 0, r: 0 }), createPiece('k1', 1, 'K', { q: -10, r: 10 })], seats: [0, 1] });
    expect(threatsFor(state, 0)).toBe(threatsFor(state, 0));
  });
});
