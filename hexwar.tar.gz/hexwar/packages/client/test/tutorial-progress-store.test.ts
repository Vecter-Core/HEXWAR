// M8 (PLAN 10.1): tiến độ bài tân thủ lưu cục bộ — cùng nguyên tắc với settings-store/save-store (không vỡ UI
// khi dữ liệu hỏng/thiếu; không có Storage thì vẫn dùng được, chỉ mất khả năng nhớ).
import { describe, expect, it } from 'vitest';
import { LocalStorageTutorialProgressStore, MemoryTutorialProgressStore, TUTORIAL_PROGRESS_KEY } from '../src/net/tutorial-progress-store';

class FakeStorage {
  private data = new Map<string, string>();
  getItem(key: string): string | null {
    return this.data.get(key) ?? null;
  }
  setItem(key: string, value: string): void {
    this.data.set(key, value);
  }
}

describe('LocalStorageTutorialProgressStore', () => {
  it('chưa lưu gì: chưa hoàn thành bài nào, chưa từng mở màn tân thủ', () => {
    const store = new LocalStorageTutorialProgressStore(new FakeStorage());
    expect(store.load()).toEqual({ completed: [] });
    expect(store.hasStarted()).toBe(false);
  });

  it('markCompleted: thêm vào danh sách, gọi lại cùng id không lặp', () => {
    const storage = new FakeStorage();
    const store = new LocalStorageTutorialProgressStore(storage);
    store.markCompleted('T1');
    store.markCompleted('T2');
    store.markCompleted('T1');
    expect(new LocalStorageTutorialProgressStore(storage).load()).toEqual({ completed: ['T1', 'T2'] });
  });

  it('markStarted: hasStarted() true ngay sau đó, và bền qua instance mới (đọc lại localStorage)', () => {
    const storage = new FakeStorage();
    const store = new LocalStorageTutorialProgressStore(storage);
    expect(store.hasStarted()).toBe(false);
    store.markStarted();
    expect(store.hasStarted()).toBe(true);
    expect(new LocalStorageTutorialProgressStore(storage).hasStarted()).toBe(true);
  });

  it('markStarted không đụng danh sách đã hoàn thành, markCompleted không đụng cờ started', () => {
    const storage = new FakeStorage();
    const store = new LocalStorageTutorialProgressStore(storage);
    store.markCompleted('T3');
    store.markStarted();
    expect(store.load()).toEqual({ completed: ['T3'] });
    expect(store.hasStarted()).toBe(true);
  });

  it('dữ liệu hỏng (không phải JSON, hoặc sai kiểu): coi như rỗng, không ném lỗi', () => {
    const storage = new FakeStorage();
    storage.setItem(TUTORIAL_PROGRESS_KEY, '{not json');
    expect(new LocalStorageTutorialProgressStore(storage).load()).toEqual({ completed: [] });
    expect(new LocalStorageTutorialProgressStore(storage).hasStarted()).toBe(false);

    storage.setItem(TUTORIAL_PROGRESS_KEY, JSON.stringify({ completed: 'T1', started: 'yes' }));
    expect(new LocalStorageTutorialProgressStore(storage).load()).toEqual({ completed: [] });
    expect(new LocalStorageTutorialProgressStore(storage).hasStarted()).toBe(false);
  });

  it('không có Storage (chế độ riêng tư nghiêm ngặt): dùng mặc định rỗng, không ném lỗi', () => {
    const store = new LocalStorageTutorialProgressStore(null);
    expect(store.load()).toEqual({ completed: [] });
    expect(store.hasStarted()).toBe(false);
    expect(() => store.markCompleted('T1')).not.toThrow();
    expect(() => store.markStarted()).not.toThrow();
  });
});

describe('MemoryTutorialProgressStore', () => {
  it('bắt đầu rỗng, markCompleted/markStarted phản ánh ngay qua load()/hasStarted()', () => {
    const store = new MemoryTutorialProgressStore();
    expect(store.load()).toEqual({ completed: [] });
    store.markCompleted('T5');
    store.markStarted();
    expect(store.load()).toEqual({ completed: ['T5'] });
    expect(store.hasStarted()).toBe(true);
  });
});
