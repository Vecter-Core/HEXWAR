import { describe, expect, it } from 'vitest';
import { SEATS } from '@hexwar/rules';
import { isPolite, isSpeaking, isVoiceSignalData, shouldConnect, VOICE_OFF, wantedPeers, type VoicePresence } from '../src/core/voice-model';

describe('isPolite', () => {
  it('ghế số lớn hơn luôn là bên nhường, đối xứng ở cả hai phía', () => {
    expect(isPolite(0, 3)).toBe(false); // 0 < 3: 0 là impolite
    expect(isPolite(3, 0)).toBe(true); // 3 > 0: 3 là polite
  });

  it('không bao giờ cả hai cùng impolite hay cùng polite cho cùng một cặp', () => {
    for (const a of SEATS) {
      for (const b of SEATS) {
        if (a === b) continue;
        expect(isPolite(a, b)).not.toBe(isPolite(b, a));
      }
    }
  });
});

describe('shouldConnect', () => {
  const ON: VoicePresence = { mic: true, listen: true };
  const MIC_ONLY: VoicePresence = { mic: true, listen: false };
  const LISTEN_ONLY: VoicePresence = { mic: false, listen: true };

  it('cả hai cùng tắt hết thì không cần kết nối', () => {
    expect(shouldConnect(VOICE_OFF, VOICE_OFF)).toBe(false);
  });

  it('tôi nói, họ nghe -> cần kết nối (dù họ không nói)', () => {
    expect(shouldConnect(MIC_ONLY, LISTEN_ONLY)).toBe(true);
  });

  it('họ nói, tôi nghe -> cần kết nối', () => {
    expect(shouldConnect(LISTEN_ONLY, MIC_ONLY)).toBe(true);
  });

  it('tôi nói nhưng họ không nghe, và họ không nói -> không cần kết nối (không chiều nào truyền được)', () => {
    expect(shouldConnect(MIC_ONLY, MIC_ONLY)).toBe(false);
  });

  it('cả hai bật đủ hai công tắc -> cần kết nối', () => {
    expect(shouldConnect(ON, ON)).toBe(true);
  });
});

describe('wantedPeers', () => {
  const presence: Record<number, VoicePresence> = {
    1: { mic: true, listen: true },
    2: { mic: false, listen: false },
    3: { mic: true, listen: false },
  };
  const presenceOf = (seat: number): VoicePresence => presence[seat] ?? VOICE_OFF;

  it('loại trừ chính mình, ghế chưa cần kết nối, và ghế đang bị chặn', () => {
    const mine: VoicePresence = { mic: false, listen: true };
    expect(wantedPeers(0, mine, [0, 1, 2, 3], new Set(), presenceOf)).toEqual([1, 3]);
  });

  it('ghế bị chặn thì loại khỏi danh sách dù đáng lẽ đủ điều kiện kết nối', () => {
    const mine: VoicePresence = { mic: false, listen: true };
    expect(wantedPeers(0, mine, [0, 1, 2, 3], new Set([1]), presenceOf)).toEqual([3]);
  });

  it('ghế chưa từng gửi presence coi như đang tắt cả hai, không kết nối bừa', () => {
    const mine: VoicePresence = { mic: true, listen: true };
    expect(wantedPeers(0, mine, [0, 5], new Set(), presenceOf)).toEqual([]);
  });
});

describe('isSpeaking', () => {
  it('dưới ngưỡng mặc định thì im lặng, từ ngưỡng trở lên thì coi là đang nói', () => {
    expect(isSpeaking(0)).toBe(false);
    expect(isSpeaking(0.03)).toBe(false);
    expect(isSpeaking(0.04)).toBe(true);
    expect(isSpeaking(0.5)).toBe(true);
  });

  it('nhận ngưỡng tuỳ chỉnh', () => {
    expect(isSpeaking(0.1, 0.2)).toBe(false);
    expect(isSpeaking(0.25, 0.2)).toBe(true);
  });
});

describe('isVoiceSignalData', () => {
  it('nhận đúng cả 4 loại tín hiệu voice', () => {
    expect(isVoiceSignalData({ kind: 'presence', mic: true, listen: false })).toBe(true);
    expect(isVoiceSignalData({ kind: 'offer', sdp: { type: 'offer', sdp: 'x' } })).toBe(true);
    expect(isVoiceSignalData({ kind: 'answer', sdp: { type: 'answer', sdp: 'x' } })).toBe(true);
    expect(isVoiceSignalData({ kind: 'candidate', candidate: {} })).toBe(true);
  });

  it('từ chối dữ liệu không đúng hình dạng (bảo vệ khỏi tín hiệu hỏng/độc hại từ người chơi khác)', () => {
    expect(isVoiceSignalData(null)).toBe(false);
    expect(isVoiceSignalData(undefined)).toBe(false);
    expect(isVoiceSignalData('offer')).toBe(false);
    expect(isVoiceSignalData({ kind: 'unknown' })).toBe(false);
    expect(isVoiceSignalData({})).toBe(false);
  });
});
