// Cấu hình Vite tối thiểu cho M3 (PLAN 6.2: Three.js + Vite). Không cần plugin framework nào (TypeScript thuần
// + THREE), Vite tự xử lý qua esbuild/rollup.
import { defineConfig } from 'vite';

export default defineConfig({
  base: './',
  build: {
    target: 'es2022',
  },
  server: {
    port: 5173,
  },
});
