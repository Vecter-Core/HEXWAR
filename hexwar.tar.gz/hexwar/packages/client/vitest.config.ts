import { defineConfig } from 'vitest/config';

// Chỉ test thuần (Node). Test trình duyệt nằm ở e2e/ và chạy bằng Playwright.
export default defineConfig({
  test: { include: ['test/**/*.test.ts'], environment: 'node' },
});
