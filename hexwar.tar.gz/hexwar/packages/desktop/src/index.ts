// @hexwar/desktop — Electron main, steam.ts, đóng gói, SteamPipe (M0 spike, M11).
// Khung rỗng của M0; code thật được thêm theo milestone (PLAN.md mục 15).
export {};
