// Giao thức chat + báo cáo + tín hiệu voice (PLAN mục 8) — chạy trên CÙNG một kết nối với `lobby.*`/`game.*`
// (server.ts phân biệt bằng `type`), và có nghĩa cả khi đang ở sảnh lẫn giữa ván (PLAN 8.1 không giới hạn theo pha).
// Câu có sẵn gửi bằng MÃ (`phraseId`): mỗi client tự dịch theo ngôn ngữ của mình qua i18n (khoá `phrase.<id>`), nên
// hai người khác ngôn ngữ vẫn hiểu nhau và không cần lọc từ cho nhóm này (PLAN 8.3). Voice chỉ có tín hiệu SDP/ICE
// đi qua đây (`voice.signal`) — server chỉ RELAY nguyên văn `data`, không hiểu và không cần hiểu nội dung (âm thanh
// tự đi thẳng giữa hai trình duyệt qua WebRTC, xem docs/decisions.md M7).
import { z } from 'zod';
import type { Seat } from '@hexwar/rules';
import { SeatSchema } from './messages';

export const CHAT_TEXT_MAX_LENGTH = 200; // PLAN 8.4
/** PLAN 8.4: "tối đa 5 tin/10 giây" — cũng là cấu hình `RateLimiter` phía server (packages/server/src/room.ts). */
export const CHAT_RATE_LIMIT = { capacity: 5, refillPerSecond: 5 / 10 } as const;

/** PLAN 8.3, ~24 câu mở đầu, nhóm theo mục đích cho vòng chọn nhanh của client (phím mặc định `T`). Mỗi câu dịch
 * qua khoá i18n `phrase.<id>`. */
export const PHRASE_GROUPS = [
  {
    id: 'greeting',
    phraseIds: ['greeting.goodLuck', 'greeting.wellPlayed', 'greeting.sorry', 'greeting.hello', 'greeting.goodGame', 'greeting.thanks'],
  },
  {
    id: 'diplomacy',
    phraseIds: [
      'diplomacy.dontAttackMe',
      'diplomacy.attackLeader',
      'diplomacy.noHarmIntended',
      'diplomacy.truce',
      'diplomacy.needHelp',
      'diplomacy.watchOut',
    ],
  },
  {
    id: 'warning',
    phraseIds: [
      'warning.kingThreatened',
      'warning.ringVanishing',
      'warning.captiveWarning',
      'warning.pieceThreatened',
      'warning.turnEnding',
      'warning.jesterGone',
    ],
  },
  { id: 'emote', phraseIds: ['emote.haha', 'emote.tooBad', 'emote.surprised', 'emote.wow', 'emote.oops', 'emote.gg'] },
] as const satisfies readonly { id: string; phraseIds: readonly string[] }[];
export type PhraseGroupId = (typeof PHRASE_GROUPS)[number]['id'];
export const PHRASE_IDS = PHRASE_GROUPS.flatMap((g) => g.phraseIds);
export type PhraseId = (typeof PHRASE_IDS)[number];

export const CHAT_CHANNELS = ['all', 'whisper', 'dead'] as const; // PLAN 8.1 (kênh "Hệ thống" không qua chat.send, xem docs/decisions.md)
export type ChatChannel = (typeof CHAT_CHANNELS)[number];

export const REPORT_REASONS = ['spam', 'abuse', 'cheating', 'hateSpeech', 'other'] as const; // PLAN 8.4 "chọn lý do"
export type ReportReason = (typeof REPORT_REASONS)[number];

// ---- Client → server -------------------------------------------------------------------------------------------

const ChatSendBase = z.object({ type: z.literal('chat.send'), channel: z.enum(CHAT_CHANNELS), to: SeatSchema.optional() });
/** `to` bắt buộc đúng khi và chỉ khi `channel === 'whisper'` (PLAN 8.2). */
export const ChatSendSchema = z
  .discriminatedUnion('kind', [
    ChatSendBase.extend({ kind: z.literal('text'), text: z.string().min(1).max(CHAT_TEXT_MAX_LENGTH) }).strict(),
    ChatSendBase.extend({ kind: z.literal('phrase'), phraseId: z.enum(PHRASE_IDS) }).strict(),
  ])
  .refine((msg) => (msg.channel === 'whisper') === (msg.to !== undefined), {
    message: 'nhắn riêng cần "to"; các kênh khác thì không được có "to"',
  });
export type ChatSend = z.infer<typeof ChatSendSchema>;

export const ReportPlayerSchema = z.strictObject({ type: z.literal('report.player'), seat: SeatSchema, reason: z.enum(REPORT_REASONS) });
export type ReportPlayer = z.infer<typeof ReportPlayerSchema>;

/** `data`: SDP offer/answer hoặc ICE candidate — nội dung của WebRTC, server không parse, chỉ relay theo `to`. */
export const VoiceSignalSchema = z.strictObject({ type: z.literal('voice.signal'), to: SeatSchema, data: z.unknown() });
export type VoiceSignal = z.infer<typeof VoiceSignalSchema>;

export const ChatClientMessageSchema = z.union([ChatSendSchema, ReportPlayerSchema, VoiceSignalSchema]);
export type ChatClientMessage = z.infer<typeof ChatClientMessageSchema>;
/** Cùng vai trò với `LOBBY_MESSAGE_TYPES` (lobby.ts): server.ts dùng để tách 3 loại message này khỏi `game.*`
 * TRƯỚC khi thử phân giải bằng schema tương ứng. */
export const CHAT_MESSAGE_TYPES: ReadonlySet<'chat.send' | 'report.player' | 'voice.signal'> = new Set([
  'chat.send',
  'report.player',
  'voice.signal',
]);

// ---- Server → client -------------------------------------------------------------------------------------------

export type ChatErrorCode = 'RATE_LIMITED' | 'RESTRICTED' | 'INVALID_TARGET' | 'NOT_ALLOWED';

interface ChatMessageBase {
  readonly type: 'chat.message';
  readonly id: string;
  readonly channel: ChatChannel;
  readonly from: Seat;
  /** Chỉ có ở kênh `whisper`. */
  readonly to?: Seat;
  readonly at: number;
}
export type ChatMessage = (ChatMessageBase & { readonly kind: 'text'; readonly text: string }) | (ChatMessageBase & { readonly kind: 'phrase'; readonly phraseId: PhraseId });

export type ChatServerMessage =
  | ChatMessage
  | { readonly type: 'chat.error'; readonly code: ChatErrorCode; readonly message: string }
  | { readonly type: 'report.ack' }
  | { readonly type: 'voice.signal'; readonly from: Seat; readonly data: unknown };
