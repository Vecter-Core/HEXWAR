// Giao thức phòng/ghép trận (PLAN 7.1, 7.2, 7.3) — lớp NẰM TRƯỚC `GameSession`: một kết nối bắt tay (`hello`),
// vào hàng chờ ghép nhanh hoặc tạo/vào phòng riêng, rồi khi đủ người (hoặc bot lấp chỗ) phòng tự chuyển sang ván
// thật — từ đó client chỉ còn thấy đúng giao thức `game.*` sẵn có ở `messages.ts` (không có `game.start` riêng:
// `game.snapshot` đã tài liệu rõ dùng cho "bắt đầu / tiếp tục / vào lại", xem docs/decisions.md).
//
// Cùng quy ước với `messages.ts`: message CLIENT → SERVER là dữ liệu không tin cậy nên có schema Zod; message
// SERVER → CLIENT do server tự tạo nên chỉ cần kiểu TS (không ai giả mạo được nguồn phát của chính server).
import { z } from 'zod';
import { PRESET_NAMES, type PresetName, type Seat } from '@hexwar/rules';
import { DIFFICULTIES, PERSONALITIES, SeatSchema, type Difficulty, type Personality } from './messages';

export type { PresetName };
/** X-09. `classic` = mặc định PLAN (60 giây, lịch gốc); `standard`/`blitz` co giãn theo `RulesConfig.presets`
 * (`applyPreset`, `@hexwar/rules`) — dùng lại đúng tên preset của engine để không có hai nguồn sự thật. */
export { PRESET_NAMES };

const displayName = z.string().trim().min(1).max(24);
/** Mã phòng riêng: 6 ký tự hoa/số, dễ đọc qua điện thoại — không dùng ký tự dễ nhầm (0/O, 1/I). */
export const ROOM_CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const roomCode = z.string().length(6);

// ---- Client → server ---------------------------------------------------------------------------------------------

/** Bắt tay đầu kết nối (PLAN 7.1). `token` có thì server coi là xin vào lại phiên cũ (PLAN 7.5); không có/hết hạn
 * thì cấp danh tính khách mới (xem docs/questions.md — chưa có Steam thật, xem M0). */
export const HelloSchema = z.strictObject({
  type: z.literal('hello'),
  rulesVersion: z.string().min(1),
  name: displayName,
  token: z.string().min(1).max(128).optional(),
  locale: z.enum(['vi', 'en']).optional(),
});

export const QueueJoinSchema = z.strictObject({ type: z.literal('queue.join'), preset: z.enum(PRESET_NAMES) });
export const QueueLeaveSchema = z.strictObject({ type: z.literal('queue.leave') });

export const RoomCreateSchema = z.strictObject({ type: z.literal('room.create'), preset: z.enum(PRESET_NAMES) });
export const RoomJoinSchema = z.strictObject({ type: z.literal('room.join'), code: roomCode });
export const RoomLeaveSchema = z.strictObject({ type: z.literal('room.leave') });
/** PLAN 7.2 "Lobby ... nút Sẵn sàng". Vô nghĩa ở phòng ghép nhanh (luôn coi như sẵn sàng ngay khi vào hàng chờ). */
export const RoomReadySchema = z.strictObject({ type: z.literal('room.ready'), ready: z.boolean() });
/** Chỉ chủ phòng — server tự kiểm, không tin cờ `isHost` từ client. `personality` (PLAN 9.4, M9): bỏ trống = 'balanced'. */
export const RoomAddBotSchema = z.strictObject({
  type: z.literal('room.addBot'),
  difficulty: z.enum(DIFFICULTIES),
  personality: z.enum(PERSONALITIES).optional(),
});
export const RoomRemoveBotSchema = z.strictObject({ type: z.literal('room.removeBot'), seat: SeatSchema });
export const RoomSetConfigSchema = z.strictObject({ type: z.literal('room.setConfig'), preset: z.enum(PRESET_NAMES) });

export const LobbyClientMessageSchema = z.discriminatedUnion('type', [
  HelloSchema,
  QueueJoinSchema,
  QueueLeaveSchema,
  RoomCreateSchema,
  RoomJoinSchema,
  RoomLeaveSchema,
  RoomReadySchema,
  RoomAddBotSchema,
  RoomRemoveBotSchema,
  RoomSetConfigSchema,
]);
export type LobbyClientMessage = z.infer<typeof LobbyClientMessageSchema>;
/** Tập hợp `type` của mọi message tầng phòng — dùng để server phân biệt với `ClientMessageSchema` (tầng ván) trên
 * cùng một kết nối trước khi thử phân giải bằng schema tương ứng. Liệt kê tay (không soi cấu trúc nội bộ Zod) để
 * không phụ thuộc chi tiết cài đặt của `z.discriminatedUnion` giữa các phiên bản zod. */
export const LOBBY_MESSAGE_TYPES: ReadonlySet<LobbyClientMessage['type']> = new Set([
  'hello',
  'queue.join',
  'queue.leave',
  'room.create',
  'room.join',
  'room.leave',
  'room.ready',
  'room.addBot',
  'room.removeBot',
  'room.setConfig',
]);

// ---- Server → client ------------------------------------------------------------------------------------------

/** Lý do từ chối ở tầng phòng (khác `RejectReason` của tầng ván trong `messages.ts`). */
export type LobbyErrorCode =
  | 'BAD_MESSAGE'
  | 'RULES_VERSION'
  | 'ROOM_NOT_FOUND'
  | 'ROOM_FULL'
  | 'ROOM_STARTED'
  | 'NOT_HOST'
  | 'NOT_IN_ROOM'
  | 'ALREADY_IN_ROOM'
  | 'RATE_LIMITED';

export interface RoomSeatView {
  readonly seat: Seat;
  readonly kind: 'human' | 'bot' | 'empty';
  /** Chỉ có ở ghế người. */
  readonly name?: string;
  /** Chỉ có ở ghế bot. */
  readonly difficulty?: Difficulty;
  /** Chỉ có ở ghế bot (PLAN 9.4, M9). Bỏ trống = 'balanced'. */
  readonly personality?: Personality;
  readonly ready: boolean;
  /** false = người chơi ghế này đang mất kết nối, còn giữ ghế trong `turn.reconnectGraceSeconds` (PLAN 7.5). Luôn
   * true ở ghế bot/trống. */
  readonly connected: boolean;
  /** Ghế này có phải một trong các ghế client nhận message đang điều khiển không (tiện vẽ UI, không phải nguồn luật). */
  readonly you: boolean;
}

export type LobbyServerMessage =
  | { readonly type: 'hello.ack'; readonly token: string; readonly identityId: string; readonly name: string }
  | {
      readonly type: 'room.state';
      /** null = phòng ghép nhanh (không có mã để chia sẻ), khác `room.create`/`room.join` luôn có mã. */
      readonly code: string | null;
      readonly preset: PresetName;
      readonly seats: readonly RoomSeatView[];
      readonly host: Seat | null;
      /** true nếu phòng công khai (ghép nhanh): không cần bấm Sẵn sàng, tự lấp bot sau một khoảng chờ. */
      readonly quickMatch: boolean;
      /** Còn bao nhiêu mili-giây nữa (nếu có hẹn) trước khi bot lấp các ghế trống — chỉ có ở phòng ghép nhanh. */
      readonly botFillInMs: number | null;
    }
  | { readonly type: 'room.closed'; readonly reason: 'left' | 'started' }
  | { readonly type: 'lobby.error'; readonly code: LobbyErrorCode; readonly message: string };
