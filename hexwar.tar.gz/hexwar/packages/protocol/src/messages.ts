// Giao thức giữa client và nơi chạy ván (PLAN 7.3). Cùng một bộ message cho:
//   - M4: ván solo trong Web Worker cục bộ (LocalTransport),
//   - M6: server online (WebSocketTransport) — sẽ bổ sung các message phòng/ghép trận/chat.
// UI không biết mình đang chơi online hay offline (PLAN 6.1 nguyên tắc 3).
//
// Mọi message từ client là DỮ LIỆU KHÔNG TIN CẬY (PLAN 7.6): nơi chạy ván luôn kiểm bằng schema Zod ở đây rồi
// mới đưa cho engine kiểm luật.
import { z } from 'zod';
import type { GameEvent, GameState, IllegalReason, Move, Seat } from '@hexwar/rules';

export const SeatSchema = z.union([z.literal(0), z.literal(1), z.literal(2), z.literal(3), z.literal(4), z.literal(5)]) satisfies z.ZodType<Seat>;

/** Độ khó bot (PLAN 9.3). M4: Dễ + Thường; Khó thêm ở M9. */
export const DIFFICULTIES = ['easy', 'normal', 'hard'] as const;
export type Difficulty = (typeof DIFFICULTIES)[number];

/** Tính cách bot (PLAN 9.4, M9). 'balanced' = mặc định, hành vi hệt trước M9 (`@hexwar/bot` `Personality`). */
export const PERSONALITIES = ['balanced', 'aggressive', 'defensive', 'opportunist'] as const;
export type Personality = (typeof PERSONALITIES)[number];

export const SeatSetupSchema = z.strictObject({
  seat: SeatSchema,
  kind: z.enum(['human', 'bot']),
  /** Chỉ có ở ghế bot. */
  difficulty: z.enum(DIFFICULTIES).optional(),
  /** Chỉ có ở ghế bot (PLAN 9.4, M9). Bỏ trống = 'balanced'. */
  personality: z.enum(PERSONALITIES).optional(),
});
export type SeatSetup = z.infer<typeof SeatSetupSchema>;

const coord = z.number().int().min(-64).max(64);
export const MoveSchema = z.strictObject({
  pieceId: z.string().min(1).max(32),
  to: z.strictObject({ q: coord, r: coord }),
  conscript: z.boolean().optional(),
}) satisfies z.ZodType<Move>;

/** Một hành động đã được nơi chạy ván chấp nhận. Log hành động + seed tái hiện toàn bộ ván (X-11). */
export const GameActionSchema = z.discriminatedUnion('kind', [
  z.strictObject({ kind: z.literal('dice') }),
  z.strictObject({ kind: z.literal('move'), seat: SeatSchema, move: MoveSchema }),
  z.strictObject({ kind: z.literal('timeout'), seat: SeatSchema }),
  z.strictObject({ kind: z.literal('resign'), seat: SeatSchema }),
]);
export type GameAction = z.infer<typeof GameActionSchema>;

// ---- Client → nơi chạy ván -------------------------------------------------------------------------------------

export const ClientMessageSchema = z.discriminatedUnion('type', [
  /** R-02: xin tung xúc xắc (nơi chạy ván cũng tự tung sau một khoảng chờ). */
  z.strictObject({ type: z.literal('game.rollDice') }),
  /** `seq`: số hành động client đã thấy; lệch thì bị từ chối để không đi nhầm trên thế cờ cũ (PLAN 7.6). */
  z.strictObject({ type: z.literal('game.move'), seq: z.number().int().nonnegative(), move: MoveSchema }),
  /** X-05, R-61. */
  z.strictObject({ type: z.literal('game.resign') }),
]);
export type ClientMessage = z.infer<typeof ClientMessageSchema>;

// ---- Nơi chạy ván → client -------------------------------------------------------------------------------------

/** Lý do từ chối ở tầng giao thức (ngoài các lý do luật `IllegalReason` của engine). */
export type RejectReason = IllegalReason | 'STALE_SEQ' | 'BAD_MESSAGE';

export interface SeatStatus {
  readonly seat: Seat;
  readonly kind: 'human' | 'bot';
  readonly difficulty?: Difficulty;
  /** Chỉ có ở ghế bot (PLAN 9.4, M9). */
  readonly personality?: Personality;
  /** X-04: ghế người đang được bot lái tạm (hết giờ liên tiếp); người chơi thao tác lại thì lấy lại quyền. */
  readonly botControlled: boolean;
}

export type ServerMessage =
  | {
      /** Trạng thái đầy đủ: khi bắt đầu, khi tiếp tục ván đã lưu, khi vào lại (PLAN 7.5). */
      readonly type: 'game.snapshot';
      readonly seq: number;
      readonly state: GameState;
      readonly seats: readonly SeatStatus[];
      /** Các ghế client này điều khiển. */
      readonly you: readonly Seat[];
      /** Hạn của lượt hiện tại theo đồng hồ nơi chạy ván (ms), null nếu không có đồng hồ (pha xúc xắc, hết ván). */
      readonly deadline: number | null;
    }
  | {
      /** Kết quả một hành động: sự kiện để diễn hoạt ảnh + trạng thái mới (PLAN 7.3 `game.events`). */
      readonly type: 'game.events';
      readonly seq: number;
      readonly action: GameAction;
      readonly events: readonly GameEvent[];
      readonly state: GameState;
      readonly seats: readonly SeatStatus[];
      readonly deadline: number | null;
    }
  | { readonly type: 'game.rejected'; readonly seq: number; readonly reason: RejectReason };
