// Lọc từ cấm tối thiểu (PLAN 8.4 "Lọc từ cấm bằng danh sách nội bộ theo ngôn ngữ"). Thuần và nhỏ có chủ đích:
// - Đây CHỈ là khung minh hoạ cơ chế (thay từ khớp bằng dấu `*` cùng độ dài, không phân biệt hoa/thường, khớp cả
//   khi từ nằm giữa câu). Danh sách thật cần bạn tự biên soạn đầy đủ hơn trước khi phát hành — xem docs/questions.md
//   (Q-28) để biết vì sao không tự sinh danh sách dài ở đây.
// - Chạy ở CLIENT khi hiển thị (tuỳ chọn cá nhân "ẩn từ tục", PLAN 8.4), không phải một chốt chặn an ninh ở server:
//   đây là moderation nhẹ cho một trò chơi không giao dịch thật, không phải chống gian lận (xem docs/decisions.md,
//   M7). Muốn chặn cứng ở server (không cho bypass qua client tự sửa) chỉ cần gọi `censorText` thêm một dòng trong
//   `Room.handleChatMessage` (packages/server) trước khi phát đi.
const BADWORDS: Record<'vi' | 'en', readonly string[]> = {
  vi: ['đụ', 'địt', 'lồn', 'cặc', 'đéo'],
  en: ['fuck', 'shit', 'bitch', 'asshole'],
};

function escapeRegExp(word: string): string {
  return word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/** Thay mọi từ khớp (không phân biệt hoa/thường) bằng dấu `*` cùng độ dài. Không đổi độ dài chuỗi tổng thể. */
export function censorText(text: string, locale: 'vi' | 'en'): string {
  let out = text;
  for (const word of BADWORDS[locale]) {
    const pattern = new RegExp(escapeRegExp(word), 'giu');
    out = out.replace(pattern, (match) => '*'.repeat(match.length));
  }
  return out;
}
