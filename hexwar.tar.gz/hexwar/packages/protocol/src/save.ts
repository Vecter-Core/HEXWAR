// Ván lưu (X-10) = ghi lại ván (X-11): chỉ cần cấu hình + seed + danh sách hành động, vì engine tất định
// (PLAN 5 X-11, 6.1). Kèm `hash` của trạng thái cuối để phát hiện file hỏng hoặc lệch phiên bản luật.
// Tải lại = chơi lại toàn bộ hành động bằng engine thật, rồi so hash — không tin trạng thái ghi sẵn trong file.
import { z } from 'zod';
import {
  RulesConfigSchema,
  SEATS,
  applyMove,
  hash,
  newGame,
  resign,
  rollDice,
  timeoutTurn,
  type ActionResult,
  type GameState,
  type RulesConfig,
} from '@hexwar/rules';
import { GameActionSchema, SeatSetupSchema, type GameAction } from './messages';

export const SAVE_FORMAT = 'hexwar-save';
export const SAVE_VERSION = 1;

export const SavedGameSchema = z.strictObject({
  format: z.literal(SAVE_FORMAT),
  version: z.literal(SAVE_VERSION),
  rulesVersion: z.string().min(1),
  config: RulesConfigSchema,
  seed: z.number().int().nonnegative(),
  seats: z.array(SeatSetupSchema).length(6),
  actions: z.array(GameActionSchema),
  /** `hash(state)` sau hành động cuối. */
  hash: z.string().min(1),
});
export type SavedGame = z.infer<typeof SavedGameSchema>;

/** Lỗi khi đọc ván lưu: file hỏng, sai định dạng, khác phiên bản luật, hoặc chơi lại không ra đúng trạng thái. */
export class SaveError extends Error {
  constructor(
    readonly code: 'BAD_FORMAT' | 'RULES_VERSION' | 'REPLAY_FAILED' | 'HASH_MISMATCH',
    message: string,
  ) {
    super(message);
    this.name = 'SaveError';
  }
}

/** Áp dụng một hành động đã ghi bằng engine. Ném lỗi của engine nếu hành động không hợp lệ ở trạng thái đó. */
export function applyAction(state: GameState, action: GameAction): ActionResult {
  switch (action.kind) {
    case 'dice':
      return rollDice(state); // RNG mặc định lấy từ seed của ván (tất định, R-02)
    case 'move':
      if (state.turnSeat !== action.seat) throw new Error(`hành động của ghế ${action.seat} nhưng đang là lượt ghế ${String(state.turnSeat)}`);
      return applyMove(state, action.move);
    case 'timeout':
      if (state.turnSeat !== action.seat) throw new Error(`hết giờ của ghế ${action.seat} nhưng đang là lượt ghế ${String(state.turnSeat)}`);
      return timeoutTurn(state);
    case 'resign':
      return resign(state, action.seat);
  }
}

/** Dựng lại trạng thái từ seed + log hành động (X-11). */
export function replay(config: RulesConfig, seed: number, actions: readonly GameAction[]): GameState {
  let state = newGame(config, SEATS, seed);
  for (const action of actions) state = applyAction(state, action).state;
  return state;
}

/**
 * Đọc và KIỂM CHỨNG một ván lưu (dữ liệu từ đĩa/Steam Cloud là dữ liệu không tin cậy). `expectedRulesVersion`: bản
 * luật của bản build hiện tại — khác thì từ chối (PLAN 7.1, 13.5: không chơi lẫn phiên bản luật).
 */
export function loadSave(raw: unknown, expectedRulesVersion: string): { save: SavedGame; state: GameState } {
  const parsed = SavedGameSchema.safeParse(raw);
  if (!parsed.success) throw new SaveError('BAD_FORMAT', `ván lưu sai định dạng: ${parsed.error.issues[0]?.message ?? 'không rõ'}`);
  const save = parsed.data;
  if (save.rulesVersion !== expectedRulesVersion || save.config.rulesVersion !== expectedRulesVersion) {
    throw new SaveError('RULES_VERSION', `ván lưu dùng luật ${save.rulesVersion}, bản hiện tại là ${expectedRulesVersion}`);
  }
  let state: GameState;
  try {
    state = replay(save.config, save.seed, save.actions);
  } catch (error) {
    throw new SaveError('REPLAY_FAILED', `không chơi lại được ván lưu: ${error instanceof Error ? error.message : String(error)}`);
  }
  if (hash(state) !== save.hash) throw new SaveError('HASH_MISMATCH', 'ván lưu không khớp mã kiểm tra (file hỏng hoặc bị sửa)');
  return { save, state };
}
