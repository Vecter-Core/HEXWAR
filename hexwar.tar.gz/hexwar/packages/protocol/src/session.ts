// GameSession — nơi chạy một ván có thẩm quyền (PLAN 6.1 nguyên tắc 2, 3). Cùng một lớp chạy:
//   - trong Web Worker cục bộ cho ván solo (M4, LocalTransport),
//   - trên server cho ván online (M6).
// Nhận ý định từ client (message đã kiểm schema), kiểm luật bằng engine, phát kết quả; quản lý đồng hồ lượt (R-12),
// tự tung xúc xắc (PLAN 7.3), cho bot đi (PLAN 9.1), bot tạm lái ghế người hết giờ liên tiếp (X-04), và ghi log
// hành động để lưu/tiếp tục (X-10) và phát lại (X-11).
//
// Không đọc đồng hồ hệ thống, không dùng timer toàn cục: mọi thứ thời gian đi qua `Clock` được tiêm vào, nên test chạy
// hết một ván 1 vs 5 bot tức thì bằng đồng hồ giả, và kết quả tất định.
import {
  SEATS,
  checkMove,
  createRng,
  hash,
  newGame,
  type ActionResult,
  type GameState,
  type Move,
  type RulesConfig,
  type Seat,
} from '@hexwar/rules';
import {
  ClientMessageSchema,
  type ClientMessage,
  type Difficulty,
  type GameAction,
  type Personality,
  type RejectReason,
  type SeatSetup,
  type SeatStatus,
  type ServerMessage,
} from './messages';
import { SAVE_FORMAT, SAVE_VERSION, applyAction, type SavedGame } from './save';

export interface TimerHandle {
  readonly id: number;
}

/** Đồng hồ + hẹn giờ. Worker/server dùng đồng hồ thật; test dùng `ManualClock`. */
export interface Clock {
  now(): number;
  setTimer(ms: number, fn: () => void): TimerHandle;
  clearTimer(handle: TimerHandle): void;
}

/** Bộ não bot (PLAN 9): tiêm vào để package này không phụ thuộc cách cài đặt bot. Phải tất định theo tham số.
 * `personality` (PLAN 9.4, M9): bỏ trống = 'balanced' (hành vi hệt trước M9). */
export interface BotBrain {
  decide(state: GameState, seat: Seat, difficulty: Difficulty, actionIndex: number, personality?: Personality): Move | null;
}

/** Thời gian (ms) — là tham số trình bày/nhịp chơi của nơi chạy ván, KHÔNG phải luật (luật chỉ có 60 giây, R-12). */
export interface SessionTiming {
  /** PLAN 9.1: bot "suy nghĩ" giả lập 1–6 giây (ngẫu nhiên theo seed). */
  readonly botDelayMinMs: number;
  readonly botDelayMaxMs: number;
  /** Khi không còn người chơi nào sống (xem tiếp, X-07): bot đi nhanh để ván kết thúc sớm. */
  readonly spectatorBotDelayMs: number;
  /** PLAN 7.3: tự tung xúc xắc sau 15 giây nếu chưa ai bấm. */
  readonly autoDiceMs: number;
  /** PLAN 7.4: thời gian hoạt ảnh cộng thêm vào hạn lượt kế (không trừ vào thời gian suy nghĩ). */
  readonly graceMoveMs: number;
  readonly graceCollapseMs: number;
  /** Tắt đồng hồ lượt (chỉ dùng cho test/tân thủ). Mặc định bật theo R-12. */
  readonly turnClock: boolean;
}

export const DEFAULT_TIMING: SessionTiming = {
  botDelayMinMs: 1000,
  botDelayMaxMs: 6000,
  spectatorBotDelayMs: 300,
  autoDiceMs: 15_000,
  graceMoveMs: 1000,
  graceCollapseMs: 3000,
  turnClock: true,
};

export interface SessionOptions {
  readonly clock: Clock;
  readonly bot: BotBrain;
  readonly timing?: Partial<SessionTiming>;
  /** Gửi message tới mọi client (ván công khai thông tin, PLAN 7.6). */
  readonly broadcast: (message: ServerMessage) => void;
  /** Gửi lời từ chối riêng cho người vừa gửi. */
  readonly reply?: (message: ServerMessage) => void;
  /** X-10: gọi sau mỗi hành động với bản lưu mới nhất (worker chuyển cho luồng chính để ghi đĩa). */
  readonly onAutosave?: (save: SavedGame) => void;
}

export interface NewSessionSetup {
  readonly config: RulesConfig;
  readonly seed: number;
  readonly seats: readonly SeatSetup[];
}

/** Trộn số nguyên thành seed 32-bit (tách dòng ngẫu nhiên cho độ trễ của bot, không ảnh hưởng nước đi). */
function mix(a: number, b: number): number {
  let h = Math.imul((a >>> 0) ^ 0x9e3779b9, 0x85ebca6b) ^ (b >>> 0);
  h = Math.imul(h ^ (h >>> 13), 0xc2b2ae35);
  return (h ^ (h >>> 16)) >>> 0;
}

function validateSeats(seats: readonly SeatSetup[]): void {
  const seen = new Set(seats.map((s) => s.seat));
  if (seats.length !== 6 || seen.size !== 6) throw new Error('GameSession: cần đúng 6 ghế 0..5 (R-01)');
  for (const s of seats) {
    if (s.kind === 'bot' && s.difficulty === undefined) throw new Error(`GameSession: ghế bot ${s.seat} thiếu độ khó`);
  }
}

export class GameSession {
  private current: GameState;
  private readonly actions: GameAction[];
  private readonly seats: readonly SeatSetup[];
  private readonly timing: SessionTiming;
  private readonly consecutiveTimeouts = new Map<Seat, number>();
  private readonly botControlled = new Set<Seat>();
  private timer: TimerHandle | null = null;
  private deadline: number | null = null;
  private disposed = false;

  private constructor(
    private readonly config: RulesConfig,
    private readonly seed: number,
    seats: readonly SeatSetup[],
    state: GameState,
    actions: readonly GameAction[],
    private readonly options: SessionOptions,
  ) {
    validateSeats(seats);
    this.seats = [...seats].sort((a, b) => a.seat - b.seat);
    this.current = state;
    this.actions = [...actions];
    this.timing = { ...DEFAULT_TIMING, ...options.timing };
  }

  /** Ván mới ở pha tung xúc xắc. Gọi `start()` để phát trạng thái đầu và bắt đầu đồng hồ. */
  static create(setup: NewSessionSetup, options: SessionOptions): GameSession {
    return new GameSession(setup.config, setup.seed, setup.seats, newGame(setup.config, SEATS, setup.seed), [], options);
  }

  /** Tiếp tục một ván đã lưu (X-10). `state` phải là kết quả của `loadSave` (đã chơi lại và kiểm hash). */
  static resume(save: SavedGame, state: GameState, options: SessionOptions): GameSession {
    return new GameSession(save.config, save.seed, save.seats, state, save.actions, options);
  }

  get state(): GameState {
    return this.current;
  }

  /** Số hành động đã áp dụng — cũng là `seq` hiện tại của giao thức. */
  get seq(): number {
    return this.actions.length;
  }

  humanSeats(): Seat[] {
    return this.seats.filter((s) => s.kind === 'human').map((s) => s.seat);
  }

  seatStatus(): SeatStatus[] {
    return this.seats.map((s) => ({
      seat: s.seat,
      kind: s.kind,
      ...(s.difficulty !== undefined ? { difficulty: s.difficulty } : {}),
      ...(s.personality !== undefined ? { personality: s.personality } : {}),
      botControlled: this.botControlled.has(s.seat),
    }));
  }

  /** Phát trạng thái đầy đủ (bắt đầu / tiếp tục / vào lại) và lên lịch việc kế tiếp. */
  start(): void {
    this.schedule();
    this.options.broadcast(this.snapshotFor(this.humanSeats()));
  }

  snapshotFor(you: readonly Seat[]): ServerMessage {
    return { type: 'game.snapshot', seq: this.seq, state: this.current, seats: this.seatStatus(), you, deadline: this.deadline };
  }

  /** Bản lưu hiện tại (X-10). */
  save(): SavedGame {
    return {
      format: SAVE_FORMAT,
      version: SAVE_VERSION,
      rulesVersion: this.config.rulesVersion,
      config: this.config,
      seed: this.seed,
      seats: [...this.seats],
      actions: [...this.actions],
      hash: hash(this.current),
    };
  }

  /**
   * Message từ client điều khiển các ghế `senders`. Dữ liệu không tin cậy: kiểm schema, rồi kiểm luật bằng engine
   * (PLAN 7.6). Trả về lý do từ chối (đồng thời gửi `game.rejected`) hoặc null nếu được chấp nhận.
   */
  handle(senders: readonly Seat[], raw: unknown): RejectReason | null {
    if (this.disposed) return 'GAME_NOT_PLAYING';
    const parsed = ClientMessageSchema.safeParse(raw);
    if (!parsed.success) return this.reject('BAD_MESSAGE');
    const message: ClientMessage = parsed.data;
    const humans = senders.filter((s) => this.seats.some((x) => x.seat === s && x.kind === 'human'));
    if (humans.length === 0) return this.reject('NOT_IN_GAME');

    switch (message.type) {
      case 'game.rollDice':
        if (this.current.phase !== 'dice') return this.reject('GAME_NOT_PLAYING');
        this.commit({ kind: 'dice' });
        return null;
      case 'game.resign': {
        // Hotseat (một client điều khiển nhiều ghế): ưu tiên ghế đang tới lượt; không thì ghế người còn sống đầu tiên.
        const aliveHumans = humans.filter((s) => !this.current.eliminated.some((e) => e.seat === s));
        const turn = this.current.turnSeat;
        const alive = turn !== null && aliveHumans.includes(turn) ? turn : aliveHumans[0];
        if (this.current.phase !== 'playing' || alive === undefined) return this.reject('GAME_NOT_PLAYING');
        this.commit({ kind: 'resign', seat: alive });
        return null;
      }
      case 'game.move': {
        if (message.seq !== this.seq) return this.reject('STALE_SEQ');
        const seat = this.current.turnSeat;
        if (seat === null || !humans.includes(seat)) return this.reject(this.current.phase === 'playing' ? 'NOT_YOUR_TURN' : 'GAME_NOT_PLAYING');
        const reason = checkMove(this.current, seat, message.move);
        if (reason !== null) return this.reject(reason);
        this.reclaim(seat); // X-04: người chơi thao tác lại thì lấy lại quyền điều khiển
        this.consecutiveTimeouts.set(seat, 0);
        this.commit({ kind: 'move', seat, move: message.move });
        return null;
      }
    }
  }

  dispose(): void {
    this.disposed = true;
    this.clearTimer();
  }

  // ---- Nội bộ -----------------------------------------------------------------------------------------------------

  private reject(reason: RejectReason): RejectReason {
    (this.options.reply ?? this.options.broadcast)({ type: 'game.rejected', seq: this.seq, reason });
    return reason;
  }

  private reclaim(seat: Seat): void {
    this.botControlled.delete(seat);
  }

  /** Áp dụng một hành động đã được kiểm, ghi log, phát kết quả, tự lưu, lên lịch việc kế tiếp. */
  private commit(action: GameAction): void {
    const result: ActionResult = applyAction(this.current, action);
    this.current = result.state;
    this.actions.push(action);
    this.clearTimer();
    this.deadline = null;
    const hasCollapse = result.events.some((e) => e.type === 'RING_COLLAPSED');
    this.schedule(hasCollapse ? this.timing.graceCollapseMs : this.timing.graceMoveMs);
    this.options.broadcast({
      type: 'game.events',
      seq: this.seq,
      action,
      events: result.events,
      state: this.current,
      seats: this.seatStatus(),
      deadline: this.deadline,
    });
    this.options.onAutosave?.(this.save());
  }

  private isHumanDriven(seat: Seat): boolean {
    return this.seats.some((s) => s.seat === seat && s.kind === 'human') && !this.botControlled.has(seat);
  }

  private anyHumanAlive(): boolean {
    return this.humanSeats().some((s) => !this.current.eliminated.some((e) => e.seat === s));
  }

  /** Lên lịch việc kế tiếp theo trạng thái hiện tại: tự tung xúc xắc, bot đi, hoặc đồng hồ lượt của người. */
  private schedule(graceMs = 0): void {
    if (this.disposed) return;
    const state = this.current;
    if (state.phase === 'over') return;
    if (state.phase === 'dice') {
      const delay = this.humanSeats().length === 0 ? 0 : this.timing.autoDiceMs;
      this.setTimer(delay, () => this.commit({ kind: 'dice' }));
      return;
    }
    const seat = state.turnSeat;
    if (seat === null) return;
    if (this.isHumanDriven(seat)) {
      if (!this.timing.turnClock) return;
      const ms = state.config.turn.seconds * 1000 + graceMs; // R-12 + PLAN 7.4
      this.deadline = this.options.clock.now() + ms;
      this.setTimer(ms, () => this.onTimeout(seat));
      return;
    }
    this.setTimer(this.botDelay() + graceMs, () => this.playBot(seat));
  }

  private botDelay(): number {
    if (!this.anyHumanAlive()) return this.timing.spectatorBotDelayMs;
    const { botDelayMinMs: min, botDelayMaxMs: max } = this.timing;
    return Math.round(min + createRng(mix(this.seed, this.seq)).next() * Math.max(0, max - min));
  }

  private onTimeout(seat: Seat): void {
    if (this.current.turnSeat !== seat) return;
    const count = (this.consecutiveTimeouts.get(seat) ?? 0) + 1;
    this.consecutiveTimeouts.set(seat, count);
    if (count >= this.current.config.turn.afkTimeoutsBeforeBot) this.botControlled.add(seat); // X-04
    this.commit({ kind: 'timeout', seat }); // R-12
  }

  private playBot(seat: Seat): void {
    if (this.current.turnSeat !== seat || this.current.phase !== 'playing') return;
    const setup = this.seats.find((s) => s.seat === seat);
    const difficulty: Difficulty = setup?.difficulty ?? 'normal'; // ghế người đang được bot lái tạm (X-04) dùng bot Thường
    const move = this.options.bot.decide(this.current, seat, difficulty, this.seq, setup?.personality);
    // Bot cũng không được tin mù quáng: kiểm lại bằng engine; nước hỏng thì coi như hết giờ (không làm treo ván).
    if (move === null || checkMove(this.current, seat, move) !== null) this.commit({ kind: 'timeout', seat });
    else this.commit({ kind: 'move', seat, move });
  }

  private setTimer(ms: number, fn: () => void): void {
    this.clearTimer();
    this.timer = this.options.clock.setTimer(ms, () => {
      this.timer = null;
      if (!this.disposed) fn();
    });
  }

  private clearTimer(): void {
    if (this.timer !== null) this.options.clock.clearTimer(this.timer);
    this.timer = null;
  }
}

/** Đồng hồ giả cho test: thời gian chỉ trôi khi gọi `advance`/`runAll`. */
export class ManualClock implements Clock {
  private time = 0;
  private nextId = 1;
  private readonly timers = new Map<number, { at: number; fn: () => void }>();

  now(): number {
    return this.time;
  }

  setTimer(ms: number, fn: () => void): TimerHandle {
    const id = this.nextId++;
    this.timers.set(id, { at: this.time + Math.max(0, ms), fn });
    return { id };
  }

  clearTimer(handle: TimerHandle): void {
    this.timers.delete(handle.id);
  }

  get pending(): number {
    return this.timers.size;
  }

  /** Chạy hẹn giờ sớm nhất (nếu có); trả về false nếu không còn hẹn giờ nào. */
  step(): boolean {
    let first: [number, { at: number; fn: () => void }] | undefined;
    for (const entry of this.timers) if (first === undefined || entry[1].at < first[1].at) first = entry;
    if (first === undefined) return false;
    this.timers.delete(first[0]);
    this.time = Math.max(this.time, first[1].at);
    first[1].fn();
    return true;
  }

  /** Cho thời gian trôi `ms`, chạy mọi hẹn giờ tới hạn theo thứ tự. */
  advance(ms: number): void {
    const until = this.time + ms;
    for (;;) {
      let first: [number, { at: number; fn: () => void }] | undefined;
      for (const entry of this.timers) if (entry[1].at <= until && (first === undefined || entry[1].at < first[1].at)) first = entry;
      if (first === undefined) break;
      this.timers.delete(first[0]);
      this.time = first[1].at;
      first[1].fn();
    }
    this.time = until;
  }

  /** Chạy hẹn giờ liên tục tới khi hết (hoặc vượt `maxSteps`). */
  runAll(maxSteps = 1_000_000): number {
    let steps = 0;
    while (steps < maxSteps && this.step()) steps++;
    return steps;
  }
}
