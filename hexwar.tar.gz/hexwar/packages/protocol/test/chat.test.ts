// Giao thức chat/báo cáo/voice (PLAN mục 8) — chỉ kiểm schema + bộ lọc từ cấm thuần. Logic phòng thật (kênh, hạn
// chế do báo cáo, relay voice...) nằm ở packages/server và có test riêng ở đó (test/chat.test.ts).
import { describe, expect, it } from 'vitest';
import {
  CHAT_MESSAGE_TYPES,
  CHAT_TEXT_MAX_LENGTH,
  ChatClientMessageSchema,
  ChatSendSchema,
  PHRASE_GROUPS,
  PHRASE_IDS,
  REPORT_REASONS,
  ReportPlayerSchema,
  VoiceSignalSchema,
  censorText,
} from '../src';

describe('ChatSendSchema', () => {
  it('chấp nhận chat toàn phòng dạng chữ tự do, đúng giới hạn 200 ký tự (PLAN 8.4)', () => {
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'text', text: 'Xin chào!' }).success).toBe(true);
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'text', text: 'x'.repeat(CHAT_TEXT_MAX_LENGTH) }).success).toBe(true);
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'text', text: 'x'.repeat(CHAT_TEXT_MAX_LENGTH + 1) }).success).toBe(
      false,
    );
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'text', text: '' }).success).toBe(false);
  });

  it('chấp nhận câu có sẵn đúng mã, từ chối mã lạ (PLAN 8.3)', () => {
    for (const phraseId of PHRASE_IDS) {
      expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'phrase', phraseId }).success).toBe(true);
    }
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'phrase', phraseId: 'greeting.notReal' }).success).toBe(false);
  });

  it('nhắn riêng (whisper) bắt buộc có "to"; kênh khác thì không được có (PLAN 8.2)', () => {
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'whisper', to: 2, kind: 'text', text: 'hi' }).success).toBe(true);
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'whisper', kind: 'text', text: 'hi' }).success).toBe(false);
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'all', to: 2, kind: 'text', text: 'hi' }).success).toBe(false);
    expect(ChatSendSchema.safeParse({ type: 'chat.send', channel: 'dead', to: 2, kind: 'text', text: 'hi' }).success).toBe(false);
  });

  it('4 nhóm câu có sẵn, mỗi nhóm 6 câu, tổng khoảng 24 câu (PLAN 8.3 "khoảng 24 câu")', () => {
    expect(PHRASE_GROUPS).toHaveLength(4);
    for (const group of PHRASE_GROUPS) expect(group.phraseIds.length).toBeGreaterThanOrEqual(6);
    expect(PHRASE_IDS.length).toBeGreaterThanOrEqual(24);
    expect(new Set(PHRASE_IDS).size).toBe(PHRASE_IDS.length); // không trùng mã
  });
});

describe('ReportPlayerSchema / VoiceSignalSchema', () => {
  it('report.player chấp nhận đúng ghế + lý do hợp lệ', () => {
    for (const reason of REPORT_REASONS) expect(ReportPlayerSchema.safeParse({ type: 'report.player', seat: 3, reason }).success).toBe(true);
    expect(ReportPlayerSchema.safeParse({ type: 'report.player', seat: 3, reason: 'made up' }).success).toBe(false);
  });

  it('voice.signal chấp nhận mọi payload SDP/ICE (server chỉ relay, không hiểu nội dung)', () => {
    expect(VoiceSignalSchema.safeParse({ type: 'voice.signal', to: 1, data: { sdp: 'v=0...' } }).success).toBe(true);
    expect(VoiceSignalSchema.safeParse({ type: 'voice.signal', to: 1, data: null }).success).toBe(true);
    expect(VoiceSignalSchema.safeParse({ type: 'voice.signal', data: {} }).success).toBe(false); // thiếu "to"
  });
});

describe('ChatClientMessageSchema / CHAT_MESSAGE_TYPES', () => {
  it('gồm đúng 3 loại message, mỗi loại phân giải được qua hợp (union)', () => {
    expect(CHAT_MESSAGE_TYPES).toEqual(new Set(['chat.send', 'report.player', 'voice.signal']));
    expect(ChatClientMessageSchema.safeParse({ type: 'chat.send', channel: 'all', kind: 'text', text: 'hi' }).success).toBe(true);
    expect(ChatClientMessageSchema.safeParse({ type: 'report.player', seat: 0, reason: 'spam' }).success).toBe(true);
    expect(ChatClientMessageSchema.safeParse({ type: 'voice.signal', to: 0, data: {} }).success).toBe(true);
  });
});

describe('censorText', () => {
  it('thay từ cấm khớp (không phân biệt hoa/thường) bằng dấu * cùng độ dài, giữ nguyên phần còn lại', () => {
    expect(censorText('Đồ FUCK này', 'en')).toBe('Đồ **** này');
    expect(censorText('chào bạn', 'vi')).toBe('chào bạn'); // không có từ cấm thì giữ nguyên
  });

  it('không đổi độ dài chuỗi tổng thể (chỉ thay ký tự, không xoá)', () => {
    const input = 'shit happens';
    expect(censorText(input, 'en')).toHaveLength(input.length);
  });
});
