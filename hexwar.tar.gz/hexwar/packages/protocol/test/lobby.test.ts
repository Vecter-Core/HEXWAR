// Giao thức phòng/ghép trận (PLAN 7.2, 7.3) — chỉ kiểm schema (dữ liệu client→server không tin cậy, PLAN 7.6).
// Logic phòng thật (ghép nhanh, bot lấp chỗ, mã phòng...) nằm ở packages/server và có test riêng ở đó.
import { describe, expect, it } from 'vitest';
import {
  HelloSchema,
  LOBBY_MESSAGE_TYPES,
  LobbyClientMessageSchema,
  PRESET_NAMES,
  QueueJoinSchema,
  ROOM_CODE_ALPHABET,
  RoomAddBotSchema,
  RoomCreateSchema,
  RoomJoinSchema,
  RoomReadySchema,
  RoomRemoveBotSchema,
  RoomSetConfigSchema,
} from '../src';

describe('HelloSchema', () => {
  it('chấp nhận bắt tay hợp lệ, có hoặc không có token vào lại', () => {
    expect(HelloSchema.safeParse({ type: 'hello', rulesVersion: 'r1', name: 'Alice' }).success).toBe(true);
    expect(HelloSchema.safeParse({ type: 'hello', rulesVersion: 'r1', name: 'Alice', token: 'abc', locale: 'vi' }).success).toBe(true);
  });

  it('từ chối tên rỗng/quá dài, thiếu rulesVersion, trường lạ (strict)', () => {
    expect(HelloSchema.safeParse({ type: 'hello', rulesVersion: 'r1', name: '' }).success).toBe(false);
    expect(HelloSchema.safeParse({ type: 'hello', rulesVersion: 'r1', name: 'x'.repeat(25) }).success).toBe(false);
    expect(HelloSchema.safeParse({ type: 'hello', name: 'Alice' }).success).toBe(false);
    expect(HelloSchema.safeParse({ type: 'hello', rulesVersion: 'r1', name: 'Alice', evil: 1 }).success).toBe(false);
  });
});

describe('Queue/Room message schemas', () => {
  it('queue.join chỉ chấp nhận preset hợp lệ trong PRESET_NAMES', () => {
    for (const preset of PRESET_NAMES) expect(QueueJoinSchema.safeParse({ type: 'queue.join', preset }).success).toBe(true);
    expect(QueueJoinSchema.safeParse({ type: 'queue.join', preset: 'turbo' }).success).toBe(false);
  });

  it('room.create/join/ready/addBot/removeBot/setConfig khớp đúng hình dạng', () => {
    expect(RoomCreateSchema.safeParse({ type: 'room.create', preset: 'classic' }).success).toBe(true);
    expect(RoomJoinSchema.safeParse({ type: 'room.join', code: 'ABC234' }).success).toBe(true);
    expect(RoomJoinSchema.safeParse({ type: 'room.join', code: 'short' }).success).toBe(false);
    expect(RoomReadySchema.safeParse({ type: 'room.ready', ready: true }).success).toBe(true);
    expect(RoomAddBotSchema.safeParse({ type: 'room.addBot', difficulty: 'easy' }).success).toBe(true);
    expect(RoomAddBotSchema.safeParse({ type: 'room.addBot', difficulty: 'hard' }).success).toBe(true); // Khó có từ M9
    expect(RoomAddBotSchema.safeParse({ type: 'room.addBot', difficulty: 'hard', personality: 'aggressive' }).success).toBe(true); // M9
    expect(RoomAddBotSchema.safeParse({ type: 'room.addBot', difficulty: 'godlike' }).success).toBe(false);
    expect(RoomRemoveBotSchema.safeParse({ type: 'room.removeBot', seat: 5 }).success).toBe(true);
    expect(RoomRemoveBotSchema.safeParse({ type: 'room.removeBot', seat: 6 }).success).toBe(false);
    expect(RoomSetConfigSchema.safeParse({ type: 'room.setConfig', preset: 'blitz' }).success).toBe(true);
  });

  it('LobbyClientMessageSchema là hợp của đúng 10 loại message (PLAN 7.3)', () => {
    expect(LOBBY_MESSAGE_TYPES.size).toBe(10);
    for (const type of LOBBY_MESSAGE_TYPES) {
      // Mỗi type ứng với ít nhất một payload tối thiểu hợp lệ theo đúng loại đó.
      const minimal: Record<string, unknown> = {
        hello: { type, rulesVersion: 'r1', name: 'A' },
        'queue.join': { type, preset: 'classic' },
        'queue.leave': { type },
        'room.create': { type, preset: 'classic' },
        'room.join': { type, code: 'ABCDEF' },
        'room.leave': { type },
        'room.ready': { type, ready: false },
        'room.addBot': { type, difficulty: 'easy' },
        'room.removeBot': { type, seat: 0 },
        'room.setConfig': { type, preset: 'classic' },
      };
      expect(LobbyClientMessageSchema.safeParse(minimal[type]).success, `type=${type}`).toBe(true);
    }
  });

  it('ROOM_CODE_ALPHABET không chứa ký tự dễ nhầm (0/O, 1/I)', () => {
    for (const bad of ['0', 'O', '1', 'I']) expect(ROOM_CODE_ALPHABET.includes(bad)).toBe(false);
  });
});
