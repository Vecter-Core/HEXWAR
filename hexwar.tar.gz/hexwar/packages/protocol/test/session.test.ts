// GameSession: nơi chạy ván có thẩm quyền (PLAN 6.1), dùng chung cho Worker solo (M4) và server (M6).
// Chạy bằng đồng hồ giả nên cả một ván 1 vs 5 bot kết thúc trong vài giây và hoàn toàn tất định.
import { describe, expect, it } from 'vitest';
import { defaultConfig, hash, type GameState, type Move, type Seat } from '@hexwar/rules';
import { botRngFor, chooseMove } from '@hexwar/bot';
import {
  GameSession,
  ManualClock,
  SaveError,
  loadSave,
  type BotBrain,
  type SavedGame,
  type SeatSetup,
  type ServerMessage,
  type SessionTiming,
} from '../src';

const brain: BotBrain = {
  decide: (state, seat, difficulty, actionIndex) => chooseMove(state, seat, difficulty, botRngFor(state, seat, actionIndex))?.move ?? null,
};

/** "Người chơi" giả: đi đúng nước bot Thường sẽ đi (tất định), nhưng GỬI QUA GIAO THỨC như người thật. */
function humanMove(state: GameState, seat: Seat, index: number): Move {
  const decision = chooseMove(state, seat, 'normal', botRngFor(state, seat, index + 7777));
  if (decision === null) throw new Error('người chơi giả không có nước đi');
  return decision.move;
}

const SOLO: readonly SeatSetup[] = [
  { seat: 0, kind: 'human' },
  { seat: 1, kind: 'bot', difficulty: 'easy' },
  { seat: 2, kind: 'bot', difficulty: 'normal' },
  { seat: 3, kind: 'bot', difficulty: 'easy' },
  { seat: 4, kind: 'bot', difficulty: 'normal' },
  { seat: 5, kind: 'bot', difficulty: 'easy' },
];

interface Harness {
  readonly session: GameSession;
  readonly clock: ManualClock;
  readonly messages: ServerMessage[];
  readonly saves: SavedGame[];
}

function harness(seed: number, timing: Partial<SessionTiming> = {}, seats: readonly SeatSetup[] = SOLO): Harness {
  const clock = new ManualClock();
  const messages: ServerMessage[] = [];
  const saves: SavedGame[] = [];
  const session = GameSession.create(
    { config: defaultConfig, seed, seats },
    { clock, bot: brain, timing, broadcast: (m) => messages.push(m), onAutosave: (s) => saves.push(s) },
  );
  session.start();
  return { session, clock, messages, saves };
}

/** Chạy ván: người chơi giả đi khi tới lượt ghế 0, còn lại cho đồng hồ trôi. Dừng khi hết ván hoặc đủ `maxActions`. */
function drive(h: Harness, maxActions = Number.POSITIVE_INFINITY): void {
  while (h.session.state.phase !== 'over' && h.session.seq < maxActions) {
    const s = h.session.state;
    if (s.phase === 'playing' && s.turnSeat === 0 && !h.session.seatStatus()[0]?.botControlled) {
      expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: humanMove(s, 0, h.session.seq) })).toBeNull();
    } else if (!h.clock.step()) {
      throw new Error('ván bị treo: không còn hẹn giờ nào mà chưa kết thúc');
    }
  }
}

/** Đọc lượt hiện tại qua hàm (tránh TypeScript thu hẹp kiểu sai giữa các vòng lặp chờ). */
const turnOf = (h: Harness): Seat | null => h.session.state.turnSeat;

const eventsMessages = (messages: readonly ServerMessage[]) => messages.filter((m): m is Extract<ServerMessage, { type: 'game.events' }> => m.type === 'game.events');

describe('GameSession: ván solo 1 người + 5 bot (PLAN M4 nghiệm thu, chạy không giao diện)', () => {
  it('chơi trọn ván tới khi kết thúc; seq tăng đều; mỗi hành động có một bản tự lưu (X-10)', () => {
    const h = harness(4242);
    drive(h);
    const state = h.session.state;
    expect(state.phase).toBe('over');
    expect(state.result?.ranking).toHaveLength(6);

    const events = eventsMessages(h.messages);
    expect(events.map((m) => m.seq)).toEqual(events.map((_, i) => i + 1));
    expect(events[0]?.action).toEqual({ kind: 'dice' });
    expect(events.at(-1)?.events.at(-1)?.type).toBe('GAME_OVER');
    expect(h.saves).toHaveLength(events.length);
    expect(h.clock.pending, 'ván đã kết thúc thì không còn hẹn giờ nào').toBe(0);
  });

  it('bản lưu cuối chơi lại ra đúng trạng thái (hash khớp, X-11)', () => {
    const h = harness(77);
    drive(h, 300);
    const save = JSON.parse(JSON.stringify(h.session.save())) as unknown; // đi qua JSON như khi ghi đĩa
    const { state } = loadSave(save, defaultConfig.rulesVersion);
    expect(hash(state)).toBe(hash(h.session.state));
  });

  it('thoát giữa ván rồi vào lại: ván tiếp tục y hệt như chưa từng thoát (tất định)', () => {
    const original = harness(99);
    drive(original, 150);
    const save = JSON.parse(JSON.stringify(original.session.save())) as unknown;

    // "Thoát": bỏ phiên cũ. "Vào lại": phiên mới từ bản lưu, đồng hồ mới.
    const { save: loaded, state } = loadSave(save, defaultConfig.rulesVersion);
    const clock = new ManualClock();
    const messages: ServerMessage[] = [];
    const resumed = GameSession.resume(loaded, state, { clock, bot: brain, broadcast: (m) => messages.push(m) });
    resumed.start();
    expect(messages[0]?.type).toBe('game.snapshot');
    const resumedHarness: Harness = { session: resumed, clock, messages, saves: [] };

    drive(original, 400);
    drive(resumedHarness, 400);
    expect(hash(resumed.state)).toBe(hash(original.session.state));
    expect(resumed.seq).toBe(original.session.seq);
  });
});

describe('GameSession: kiểm tra message từ client (PLAN 7.6: không tin client)', () => {
  function playing(): Harness {
    const h = harness(5);
    while (h.session.state.phase === 'dice') h.clock.step();
    return h;
  }

  it('message sai schema → BAD_MESSAGE; ghế không phải người → NOT_IN_GAME', () => {
    const h = playing();
    expect(h.session.handle([0], { type: 'game.move', move: 'e2e4' })).toBe('BAD_MESSAGE');
    expect(h.session.handle([0], null)).toBe('BAD_MESSAGE');
    expect(h.session.handle([3], { type: 'game.resign' })).toBe('NOT_IN_GAME');
    expect(h.messages.at(-1)).toMatchObject({ type: 'game.rejected', reason: 'NOT_IN_GAME' });
  });

  it('đi khi không phải lượt mình → NOT_YOUR_TURN; seq cũ → STALE_SEQ; nước sai luật → lý do của engine', () => {
    const h = playing();
    while (turnOf(h) === 0) h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: humanMove(h.session.state, 0, 0) });
    const pawn = h.session.state.pieces.find((p) => p.owner === 0 && p.type === 'P');
    const anyMove = { pieceId: pawn?.id ?? 'p0-1', to: { q: 0, r: 0 } };
    expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: anyMove })).toBe('NOT_YOUR_TURN');
    while (turnOf(h) !== 0) h.clock.step();
    expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq - 1, move: anyMove })).toBe('STALE_SEQ');
    const king = h.session.state.pieces.find((p) => p.owner === 0 && p.type === 'K');
    expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: { pieceId: king?.id ?? '', to: { q: 0, r: 0 } } })).toBe('OUT_OF_RANGE');
    expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: { pieceId: king?.id ?? '', to: { q: 40, r: 0 } } })).toBe('TARGET_OFF_BOARD');
  });
});

describe('GameSession: đồng hồ, bot, xúc xắc', () => {
  it('tự tung xúc xắc sau 15 giây nếu người chơi không bấm (PLAN 7.3); bấm thì tung ngay', () => {
    const h = harness(1);
    h.clock.advance(14_999);
    expect(h.session.state.phase).toBe('dice');
    h.clock.advance(1);
    expect(h.session.state.phase).toBe('playing');

    const h2 = harness(1);
    expect(h2.session.handle([0], { type: 'game.rollDice' })).toBeNull();
    expect(h2.session.state.phase).toBe('playing');
    expect(hash(h2.session.state)).toBe(hash(h.session.state)); // cùng seed → cùng kết quả xúc xắc (R-02 tất định)
  });

  it('bot "suy nghĩ" 1–6 giây (PLAN 9.1); lượt người có hạn 60 giây + thời gian hoạt ảnh (R-12, PLAN 7.4)', () => {
    const h = harness(3);
    h.session.handle([0], { type: 'game.rollDice' });
    let checkedBot = 0;
    let checkedHuman = 0;
    while (h.session.seq < 60) {
      const s = h.session.state;
      const before = h.clock.now();
      if (s.turnSeat === 0) {
        const last = h.messages.at(-1);
        const deadline = last?.type === 'game.events' || last?.type === 'game.snapshot' ? last.deadline : null;
        expect(deadline).not.toBeNull();
        expect((deadline ?? 0) - before).toBeGreaterThanOrEqual(60_000);
        expect((deadline ?? 0) - before).toBeLessThanOrEqual(63_000);
        h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: humanMove(s, 0, h.session.seq) });
        checkedHuman++;
      } else {
        const seq = h.session.seq;
        h.clock.step();
        if (h.session.seq > seq) {
          const waited = h.clock.now() - before;
          expect(waited).toBeGreaterThanOrEqual(1000);
          expect(waited).toBeLessThanOrEqual(6000 + 3000);
          checkedBot++;
        }
      }
    }
    expect(checkedBot).toBeGreaterThan(20);
    expect(checkedHuman).toBeGreaterThan(3);
  });

  it('hết giờ → bỏ lượt (R-12); 3 lần liên tiếp → bot tạm lái ghế (X-04); người đi lại thì lấy lại quyền', () => {
    const h = harness(8);
    h.session.handle([0], { type: 'game.rollDice' });
    let timeouts = 0;
    while (!h.session.seatStatus()[0]?.botControlled) {
      const seq = h.session.seq;
      const wasHumanTurn = h.session.state.turnSeat === 0;
      h.clock.step();
      if (wasHumanTurn && h.session.seq > seq) {
        const last = eventsMessages(h.messages).at(-1);
        expect(last?.action).toEqual({ kind: 'timeout', seat: 0 });
        expect(last?.events.some((e) => e.type === 'TURN_SKIPPED' && e.seat === 0 && e.reason === 'timeout')).toBe(true);
        timeouts++;
      }
    }
    expect(timeouts).toBe(defaultConfig.turn.afkTimeoutsBeforeBot);

    // Bot lái ghế 0: tới lượt ghế 0 thì bot đi (không phải hết giờ).
    while (turnOf(h) !== 0) h.clock.step();
    h.clock.step();
    expect(eventsMessages(h.messages).at(-1)?.action).toMatchObject({ kind: 'move', seat: 0 });

    // Người chơi thao tác lại → lấy lại quyền.
    while (turnOf(h) !== 0) h.clock.step();
    expect(h.session.handle([0], { type: 'game.move', seq: h.session.seq, move: humanMove(h.session.state, 0, 1) })).toBeNull();
    expect(h.session.seatStatus()[0]?.botControlled).toBe(false);
  });

  it('người chơi đầu hàng (X-05) → bot chơi tiếp nhanh để ván kết thúc (xem tiếp, X-07)', () => {
    const h = harness(12);
    h.session.handle([0], { type: 'game.rollDice' });
    expect(h.session.handle([0], { type: 'game.resign' })).toBeNull();
    expect(h.session.state.eliminated.map((e) => e.seat)).toContain(0);
    const before = h.clock.now();
    const seq = h.session.seq;
    h.clock.step();
    expect(h.session.seq).toBe(seq + 1);
    expect(h.clock.now() - before).toBeLessThanOrEqual(300 + 3000);
    drive(h);
    expect(h.session.state.phase).toBe('over');
  });

  it('ván chỉ có bot: tự tung xúc xắc ngay và tự chơi tới hết (dùng cho tân thủ / kiểm thử)', () => {
    const bots: SeatSetup[] = [0, 1, 2, 3, 4, 5].map((seat) => ({ seat: seat as Seat, kind: 'bot', difficulty: 'easy' }));
    const h = harness(31, { botDelayMinMs: 0, botDelayMaxMs: 0 }, bots);
    h.clock.runAll();
    expect(h.session.state.phase).toBe('over');
  });
});

describe('loadSave: ván lưu là dữ liệu không tin cậy', () => {
  function sampleSave(): SavedGame {
    const h = harness(55);
    drive(h, 40);
    return JSON.parse(JSON.stringify(h.session.save())) as SavedGame;
  }

  it('sai định dạng → BAD_FORMAT; khác bản luật → RULES_VERSION', () => {
    expect(() => loadSave({ hello: 1 }, defaultConfig.rulesVersion)).toThrow(SaveError);
    try {
      loadSave(sampleSave(), '9.9.9');
      expect.unreachable();
    } catch (error) {
      expect((error as SaveError).code).toBe('RULES_VERSION');
    }
  });

  it('sửa log hành động → REPLAY_FAILED hoặc HASH_MISMATCH, không bao giờ nạp nhầm', () => {
    const save = sampleSave();
    const dropped = { ...save, actions: save.actions.slice(0, -1) };
    expect(() => loadSave(dropped, defaultConfig.rulesVersion)).toThrow(/mã kiểm tra|chơi lại/);

    const moves = save.actions.filter((a) => a.kind === 'move');
    const target = moves[3];
    const forged = {
      ...save,
      actions: save.actions.map((a) => (a === target && a.kind === 'move' ? { ...a, move: { ...a.move, to: { q: 0, r: 0 } } } : a)),
    };
    try {
      loadSave(forged, defaultConfig.rulesVersion);
      expect.unreachable();
    } catch (error) {
      expect(['REPLAY_FAILED', 'HASH_MISMATCH']).toContain((error as SaveError).code);
    }
  });
});
