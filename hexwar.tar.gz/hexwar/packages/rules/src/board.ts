// Bàn cờ, đội hình 18 quân, tạo ván mới. Nguồn: PLAN.md mục 3.3, 3.4, 6.5 và R-01.
import { defaultConfig, type RulesConfig } from './config';
import { cell, cellKey, isOnBoard, rotate, type Cell } from './hex';
import type { Elimination, GameState, Phase, Piece, PieceType, Seat } from './types';

export const SEATS: readonly Seat[] = [0, 1, 2, 3, 4, 5];
export const PIECE_TYPES: readonly PieceType[] = ['P', 'N', 'B', 'R', 'Q', 'K', 'J'];

/**
 * Đội hình của ghế 0, từ hàng sát góc (h = 2) lên tiền tuyến (h = 5). PLAN.md mục 3.4:
 *   hàng 5:  P P P P P P
 *   hàng 4:   N P P P N
 *   hàng 3:    R J B R
 *   hàng 2:     Q K B
 */
const FORMATION_ROWS: readonly { readonly h: number; readonly types: readonly PieceType[] }[] = [
  { h: 2, types: ['Q', 'K', 'B'] },
  { h: 3, types: ['R', 'J', 'B', 'R'] },
  { h: 4, types: ['N', 'P', 'P', 'P', 'N'] },
  { h: 5, types: ['P', 'P', 'P', 'P', 'P', 'P'] },
];

export interface FormationSlot {
  readonly type: PieceType;
  /** Toạ độ cục bộ (ghế 0). Ghế s = rotCW^s của ô này. */
  readonly local: Cell;
  readonly row: number;
  /** Số thứ tự trong cùng loại quân, tính từ 1 (dùng làm phần đuôi của id). */
  readonly ordinal: number;
}

/**
 * 18 vị trí của một ghế, thứ tự tất định (hàng 2 → 5, trái → phải).
 * Ô thứ i của hàng h: q = −h + 2i, r = seatCornerRing − i (suy từ 2r = 2A − h − q).
 */
export function formationSlots(seatCornerRing: number): FormationSlot[] {
  const counts = new Map<PieceType, number>();
  const slots: FormationSlot[] = [];
  for (const { h, types } of FORMATION_ROWS) {
    types.forEach((type, i) => {
      const ordinal = (counts.get(type) ?? 0) + 1;
      counts.set(type, ordinal);
      slots.push({ type, local: cell(-h + 2 * i, seatCornerRing - i), row: h, ordinal });
    });
  }
  return slots;
}

/** Tạo một quân mới ở trạng thái mặc định (hoạt động, 0 kill). */
export function createPiece(id: string, owner: Seat, type: PieceType, at: Cell): Piece {
  return { id, owner, type, origin: type, cell: at, kills: 0, status: 'active' };
}

/** Id tất định của quân trong đội hình: `s{ghế}-{loại}{số thứ tự}`, ví dụ `s0-K1`, `s3-P9`. */
export function initialPieceId(seat: Seat, type: PieceType, ordinal: number): string {
  return `s${seat}-${type}${ordinal}`;
}

/** 108 quân ở thế cờ đầu (6 ghế × 18 quân), theo thứ tự ghế 0 → 5. Ném lỗi nếu đội hình không vừa bàn cờ. */
export function initialPieces(config: RulesConfig): Piece[] {
  const slots = formationSlots(config.board.seatCornerRing);
  const pieces: Piece[] = [];
  for (const seat of SEATS) {
    for (const slot of slots) {
      const at = rotate(slot.local, seat);
      pieces.push(createPiece(initialPieceId(seat, slot.type, slot.ordinal), seat, slot.type, at));
    }
  }
  assertValidLayout(pieces, config.board.radius);
  return pieces;
}

/** Bất biến bàn cờ: id duy nhất, quân nằm trên bàn, không hai quân hoạt động cùng một ô. */
export function assertValidLayout(pieces: readonly Piece[], radius: number): void {
  const ids = new Set<string>();
  const occupied = new Set<number>();
  for (const p of pieces) {
    if (ids.has(p.id)) throw new Error(`Bố trí quân không hợp lệ: id trùng "${p.id}"`);
    ids.add(p.id);
    if (!isOnBoard(p.cell, radius)) {
      throw new Error(`Bố trí quân không hợp lệ: ${p.id} ở (${p.cell.q}, ${p.cell.r}) nằm ngoài bàn bán kính ${radius}`);
    }
    if (p.status === 'active') {
      const key = cellKey(p.cell);
      if (occupied.has(key)) {
        throw new Error(`Bố trí quân không hợp lệ: hai quân hoạt động cùng ô (${p.cell.q}, ${p.cell.r})`);
      }
      occupied.add(key);
    }
  }
}

/**
 * Ván mới ở pha tung xúc xắc. R-01: đúng 6 ghế, mỗi ghế một lần.
 * `order` là thứ tự tăng dần theo số ghế; `rollDice` (R-02/R-03) xoay nó và đặt `opener`, `turnSeat`.
 */
export function newGame(config: RulesConfig, seats: readonly Seat[], seed: number): GameState {
  // R-01
  const distinct = new Set<number>(seats);
  if (seats.length !== SEATS.length || distinct.size !== SEATS.length || !SEATS.every((s) => distinct.has(s))) {
    throw new Error(`R-01: cần đúng 6 ghế 0..5, mỗi ghế một lần (nhận được [${seats.join(', ')}])`);
  }
  return {
    rulesVersion: config.rulesVersion,
    config,
    seed,
    phase: 'dice',
    round: 0,
    order: SEATS,
    opener: null,
    turnSeat: null,
    pieces: initialPieces(config),
    radius: config.board.radius,
    eliminated: [],
    playerKills: SEATS.map(() => 0),
  };
}

export interface MakeStateInit {
  readonly pieces: readonly Piece[];
  readonly config?: RulesConfig;
  /** Mặc định: config.board.radius. */
  readonly radius?: number;
  readonly seed?: number;
  readonly phase?: Phase;
  readonly round?: number;
  /** Các ghế tham gia theo thứ tự đi (mặc định 0..5). Ví dụ `[0, 1]` cho một thế cờ hai người. */
  readonly seats?: readonly Seat[];
  /** Người đang tới lượt (mặc định ghế đầu tiên trong `seats`). */
  readonly turnSeat?: Seat;
  /** Người mở hiệp (mặc định ghế đầu tiên trong `seats`). */
  readonly opener?: Seat;
  /** Số kill của từng ghế (mặc định toàn 0). */
  readonly playerKills?: readonly number[];
  readonly eliminated?: readonly Elimination[];
}

/**
 * Dựng trạng thái từ danh sách quân tuỳ ý (test, bài tân thủ, gỡ lỗi). Mặc định là ván đang chơi,
 * hiệp 1, đủ 6 ghế theo thứ tự 0 → 5. Kiểm tra bất biến bố trí.
 */
export function makeState(init: MakeStateInit): GameState {
  const config = init.config ?? defaultConfig;
  const radius = init.radius ?? config.board.radius;
  assertValidLayout(init.pieces, radius);

  const order = init.seats ?? SEATS;
  if (order.length === 0 || new Set(order).size !== order.length) {
    throw new Error(`makeState: "seats" phải là danh sách ghế không rỗng, không trùng (nhận được [${order.join(', ')}])`);
  }
  const first = order[0] as Seat;
  const turnSeat = init.turnSeat ?? first;
  const opener = init.opener ?? first;
  for (const seat of [turnSeat, opener]) {
    if (!order.includes(seat)) throw new Error(`makeState: ghế ${seat} không nằm trong "seats"`);
  }

  return {
    rulesVersion: config.rulesVersion,
    config,
    seed: init.seed ?? 0,
    phase: init.phase ?? 'playing',
    round: init.round ?? 1,
    order,
    opener,
    turnSeat,
    pieces: init.pieces,
    radius,
    eliminated: init.eliminated ?? [],
    playerKills: init.playerKills ?? SEATS.map(() => 0),
  };
}
