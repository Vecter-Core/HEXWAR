// Ăn quân, tù binh, trưng dụng, Hề hồi sinh. Nguồn: PLAN.md R-30…R-37, R-40, R-50…R-52, R-60 và bảng 4.10.
//
// Vòng đời một tù binh (R-30, R-32, R-33, 4.10 bước 4):
//   lượt T của A: A ăn Y        → Y thành tù binh của A, armed = false (còn "đợi lượt kế")
//   cuối lượt T                  → armed = true
//   lượt T' kế tiếp của A        → A có thể trưng dụng Y đi 1 nước (R-32)
//   cuối lượt T' (dù dùng hay không, kể cả hết giờ) → Y bị loại (R-33)
import { dist, type Cell } from './hex';
import {
  activePieceAt,
  captivesAt,
  eliminatePlayer,
  emit,
  getPiece,
  nextBatch,
  releaseCaptives,
  releaseStillCaptive,
  removePieces,
  replacePiece,
  type Draft,
} from './draft';
import { promoteIfReady } from './promotion';
import type { Piece, Seat } from './types';

function addKill(d: Draft, seat: Seat): void {
  d.playerKills[seat] = (d.playerKills[seat] ?? 0) + 1;
}

/** R-30: quân bị ăn (không phải Vua) thành tù binh của người ăn, nằm chung ô. */
function makeCaptive(d: Draft, victim: Piece, holder: Seat): void {
  replacePiece(d, { ...victim, status: 'captive', holder, armed: false });
  emit(d, { type: 'CAPTIVE_CREATED', pieceId: victim.id, owner: victim.owner, holder, cell: victim.cell });
}

/**
 * R-34: quân giữ tù binh bị `capturer` ăn. Các tù binh khác nằm chung ô chuyển sang `capturer` (hạn mới: hết
 * lượt kế tiếp của họ); riêng tù binh thuộc chính `capturer` được giải cứu về ô trống gần nhất (R-36).
 * Nếu `captive.rescueByOwner` tắt (X-08 tắt) thì không có giải cứu; một người không thể giữ tù binh là quân của
 * chính mình nên quân đó mất luôn (giả định ghi ở docs/questions.md).
 */
function handleHolderCaptives(d: Draft, capturer: Seat, formerHolder: Seat, ids: readonly string[]): void {
  const rescued: string[] = [];
  for (const id of ids) {
    const captive = getPiece(d, id);
    if (captive.owner === capturer) {
      if (d.config.captive.rescueByOwner) {
        rescued.push(id);
      } else {
        removePieces(d, new Set([id]));
        emit(d, { type: 'CAPTIVE_EXPIRED', pieceId: id, owner: capturer, holder: formerHolder, cell: captive.cell });
      }
      continue;
    }
    replacePiece(d, { ...captive, holder: capturer, armed: false });
    emit(d, { type: 'CAPTIVE_TRANSFERRED', pieceId: id, owner: captive.owner, from: formerHolder, to: capturer });
  }
  releaseCaptives(d, rescued, 'rescued');
}

// ---- Vua và Hề (R-51, R-52, R-60) ---------------------------------------------------------------------------

/** R-51: Hề còn sống, không phải tù binh, và cách Vua không quá `jesterReviveDistance` ô. */
export function findRevivingJester(d: Draft, king: Piece): Piece | undefined {
  return d.pieces.find(
    (p) =>
      p.type === 'J' &&
      p.owner === king.owner &&
      p.status === 'active' &&
      dist(p.cell, king.cell) <= d.config.reach.jesterReviveDistance,
  );
}

/** Vua hồi sinh ngay tại ô Hề đang đứng; Hề bị loại (R-51, R-52: cứu được đúng một lần). */
export function reviveKing(d: Draft, king: Piece, jester: Piece, cause: 'capture' | 'collapse'): void {
  removePieces(d, new Set([jester.id]));
  replacePiece(d, { ...king, cell: jester.cell });
  emit(d, { type: 'JESTER_REVIVED', kingId: king.id, jesterId: jester.id, owner: king.owner, from: king.cell, to: jester.cell, cause });
}

/**
 * Vua bị ăn (R-51, R-60). Hề cứu được thì Vua hồi sinh và người chơi không mất quân nào khác; nếu không thì
 * toàn bộ quân của họ bị loại và tù binh họ đang giữ được giải phóng (R-35).
 * `heldIds` = tù binh đang nằm chung ô với Vua lúc bị ăn.
 */
function captureKing(d: Draft, mover: Seat, king: Piece, heldIds: readonly string[], viaConscript: boolean): void {
  emit(d, { type: 'KING_CAPTURED', kingId: king.id, owner: king.owner, by: mover, cell: king.cell });
  const jester = findRevivingJester(d, king);
  if (jester !== undefined) {
    reviveKing(d, king, jester, 'capture');
    if (viaConscript) releaseStillCaptive(d, heldIds, 'holder_lost');
    else handleHolderCaptives(d, mover, king.owner, heldIds);
    return;
  }
  // R-60 + R-35: người bị loại thì tù binh họ giữ (kể cả ở ô Vua) được giải phóng.
  eliminatePlayer(d, king.owner, 'king', nextBatch(d));
}

// ---- Nước đi thường (R-30) ---------------------------------------------------------------------------------------

/**
 * Thực hiện một nước đi của quân hoạt động (đã được kiểm tra hợp lệ). Bước 2–3 của mục 4.10:
 * di chuyển, ăn quân (tù binh / Vua), cập nhật kill, phong cấp.
 */
export function performNormalMove(d: Draft, mover: Seat, actor: Piece, to: Cell): void {
  emit(d, { type: 'MOVED', pieceId: actor.id, seat: mover, from: actor.cell, to, conscript: false });

  const victim = activePieceAt(d, to);
  if (victim === undefined) {
    replacePiece(d, { ...actor, cell: to });
    return;
  }

  const heldIds = captivesAt(d, to).map((p) => p.id); // tù binh của quân bị ăn, tính trước khi đổi chỗ
  const attacker: Piece = { ...actor, cell: to, kills: actor.kills + 1 }; // R-30, R-40
  replacePiece(d, attacker);
  addKill(d, mover);
  emit(d, { type: 'CAPTURED', attackerId: attacker.id, victimId: victim.id, seat: mover, victimOwner: victim.owner, cell: to, conscript: false });

  if (victim.type === 'K') {
    captureKing(d, mover, victim, heldIds, false);
  } else {
    makeCaptive(d, victim, mover); // R-30
    handleHolderCaptives(d, mover, victim.owner, heldIds); // R-34
  }
  promoteIfReady(d, attacker.id); // R-41: sau nước ăn, cùng lượt
}

// ---- Trưng dụng tù binh (R-32) -------------------------------------------------------------------------------------------

/**
 * A trưng dụng tù binh của mình và đi nó 1 nước. Quân bị tù binh ăn thì bị loại ngay, không tạo chuỗi tù binh
 * (R-32); chỉ tính +1 vào tổng kill của A, không tăng `kills` của quân nào (R-40). Ăn Vua bằng tù binh vẫn thắng.
 * Tù binh sẽ bị loại ở cuối lượt (R-33) dù đang đứng ở đâu.
 */
export function performConscriptMove(d: Draft, mover: Seat, captive: Piece, to: Cell): void {
  emit(d, { type: 'CAPTIVE_CONSCRIPTED', pieceId: captive.id, owner: captive.owner, holder: mover });
  emit(d, { type: 'MOVED', pieceId: captive.id, seat: mover, from: captive.cell, to, conscript: true });

  const victim = activePieceAt(d, to);
  const heldIds = victim === undefined ? [] : captivesAt(d, to).map((p) => p.id);
  replacePiece(d, { ...captive, cell: to }); // vẫn là tù binh (armed) cho tới cuối lượt
  if (victim === undefined) return;

  addKill(d, mover);
  emit(d, { type: 'CAPTURED', attackerId: captive.id, victimId: victim.id, seat: mover, victimOwner: victim.owner, cell: to, conscript: true });

  if (victim.type === 'K') {
    captureKing(d, mover, victim, heldIds, true);
  } else {
    removePieces(d, new Set([victim.id]));
    releaseStillCaptive(d, heldIds, 'holder_lost'); // quân giữ mất đi nên tù binh của nó được thả
  }
}

// ---- Cuối lượt (R-33, bước 4 của mục 4.10) ------------------------------------------------------------------------------

/**
 * Cuối lượt của `mover`: (1) mọi tù binh của họ đã tới hạn (armed) bị loại, dù dùng hay không, dù đang ở đâu
 * và kể cả khi họ hết giờ; (2) tù binh tạo ra ở lượt này chuyển sang "đợi lượt kế" (armed).
 */
export function finishTurnCaptives(d: Draft, mover: Seat): void {
  const expired = d.pieces.filter((p) => p.status === 'captive' && p.holder === mover && p.armed === true);
  for (const p of expired) {
    emit(d, { type: 'CAPTIVE_EXPIRED', pieceId: p.id, owner: p.owner, holder: mover, cell: p.cell });
  }
  removePieces(d, new Set(expired.map((p) => p.id)));

  d.pieces = d.pieces.map((p) => (p.status === 'captive' && p.holder === mover && p.armed !== true ? { ...p, armed: true } : p));
}
