// Thu hẹp bàn cờ. Nguồn: PLAN.md mục 3.5 và R-70, R-81.
// M1 chỉ có phần LỊCH (dữ liệu thuần, dùng để kiểm chứng cấu hình). Phần áp dụng thu hẹp lên
// trạng thái (loại quân, loại người chơi) làm ở M2.

export interface CollapseParams {
  /** Hiệp mà vòng ngoài cùng hiện tại biến mất (tăng dần). */
  readonly rounds: readonly number[];
  readonly extension: {
    readonly enabled: boolean;
    readonly firstRound: number;
    readonly every: number;
    readonly minRadius: number;
  };
}

export interface CollapseEvent {
  /** Hiệp mà vòng biến mất (ở đầu hiệp, D-08). */
  readonly round: number;
  /** Hạng của vòng biến mất. */
  readonly ring: number;
  /** Bán kính còn lại sau khi thu hẹp. */
  readonly radiusAfter: number;
  /** true nếu thuộc phần đề xuất kéo dài (D-07). */
  readonly extension: boolean;
}

/** Lịch thu hẹp đầy đủ: 14 lần gốc (hạng 24 → 11) rồi phần kéo dài (D-07) tới `minRadius`. */
export function collapseSchedule(radius: number, params: CollapseParams): CollapseEvent[] {
  const events: CollapseEvent[] = [];
  let current = radius;
  for (const round of params.rounds) {
    events.push({ round, ring: current, radiusAfter: current - 1, extension: false });
    current -= 1;
  }
  if (params.extension.enabled) {
    let round = params.extension.firstRound;
    while (current > params.extension.minRadius) {
      events.push({ round, ring: current, radiusAfter: current - 1, extension: true });
      current -= 1;
      round += params.extension.every;
    }
  }
  return events;
}
