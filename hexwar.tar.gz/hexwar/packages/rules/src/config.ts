// Cấu hình luật (rules.config.json). Nguồn: PLAN.md Phụ lục C và mục 2 (các cờ D-xx).
// Mọi con số luật nằm trong file JSON; code chỉ đọc qua RulesConfig.
import { z } from 'zod';
// Node ESM (chạy trực tiếp, không qua Vite — ví dụ trình chạy test của Playwright ở packages/client/e2e) đòi hỏi
// khai báo thuộc tính import cho module JSON kể từ Node 22; Vite/Vitest cũng hiểu cú pháp này nên vẫn khớp cả hai.
import rawDefaultConfig from '../rules.config.json' with { type: 'json' };
import { collapseSchedule } from './collapse';

const positiveInt = z.number().int().positive();
const nonNegativeInt = z.number().int().nonnegative();

const PresetSchema = z.strictObject({
  seconds: positiveInt,
  roundScale: z.number().positive(),
});

export const RulesConfigSchema = z
  .strictObject({
    rulesVersion: z.string().min(1),
    board: z.strictObject({
      // cellKey hỗ trợ |toạ độ| ≤ 31; chừa dư cho bước nhảy của Mã (3 ô).
      radius: positiveInt.max(28),
      seatCornerRing: positiveInt,
    }),
    reach: z.strictObject({
      // D-03: 'distance' = đo bằng khoảng cách lưới (mặc định); 'hops' = đếm số bước theo đường đi của quân.
      metric: z.enum(['distance', 'hops']),
      R: positiveInt,
      B: positiveInt,
      Q: positiveInt,
      J: positiveInt,
      jesterReviveDistance: nonNegativeInt,
    }),
    pawn: z.strictObject({
      // R-22: chưa có đặc tả cho nước đi đầu 2 ô (xem docs/questions.md), nên chỉ chấp nhận false.
      doubleStep: z.boolean().refine((v) => v === false, 'pawn.doubleStep = true chưa được đặc tả (R-22, docs/questions.md Q-02)'),
    }),
    captive: z.strictObject({
      conscript: z.boolean(),
      rescueByOwner: z.boolean(),
    }),
    promotion: z.strictObject({
      N: positiveInt,
      B: positiveInt,
      R: positiveInt,
      Q: positiveInt,
      cumulativeKills: z.boolean(),
    }),
    jester: z.strictObject({
      savesFromCollapse: z.boolean(),
    }),
    turn: z.strictObject({
      seconds: positiveInt,
      afkTimeoutsBeforeBot: positiveInt,
      reconnectGraceSeconds: nonNegativeInt,
    }),
    collapse: z.strictObject({
      rounds: z.array(positiveInt),
      warn: z.strictObject({
        yellowRoundsBefore: positiveInt,
        redRoundsBefore: positiveInt,
      }),
      extension: z.strictObject({
        enabled: z.boolean(),
        firstRound: positiveInt,
        every: positiveInt,
        minRadius: positiveInt,
      }),
      hardCapRound: positiveInt,
    }),
    score: z.strictObject({
      P: nonNegativeInt,
      N: nonNegativeInt,
      B: nonNegativeInt,
      R: nonNegativeInt,
      Q: nonNegativeInt,
      J: nonNegativeInt,
      K: nonNegativeInt,
      perKill: nonNegativeInt,
    }),
    presets: z.strictObject({
      classic: PresetSchema,
      standard: PresetSchema,
      blitz: PresetSchema,
    }),
  })
  .superRefine((cfg, ctx) => {
    const fail = (path: (string | number)[], message: string): void => {
      ctx.addIssue({ code: 'custom', path, message });
    };

    if (cfg.board.seatCornerRing > cfg.board.radius) {
      fail(['board', 'seatCornerRing'], 'seatCornerRing không được lớn hơn board.radius');
    }

    const p = cfg.promotion;
    if (!(p.N < p.B && p.B < p.R && p.R < p.Q)) {
      fail(['promotion'], 'ngưỡng phong cấp phải tăng dần: N < B < R < Q');
    }

    const rounds = cfg.collapse.rounds;
    if (rounds.some((round, i) => i > 0 && round <= (rounds[i - 1] ?? 0))) {
      fail(['collapse', 'rounds'], 'collapse.rounds phải tăng chặt');
    }
    if (rounds.length >= cfg.board.radius) {
      fail(['collapse', 'rounds'], 'số lần thu hẹp phải nhỏ hơn board.radius');
    }
    const last = rounds[rounds.length - 1] ?? 0;
    if (cfg.collapse.extension.enabled && cfg.collapse.extension.firstRound <= last) {
      fail(['collapse', 'extension', 'firstRound'], 'extension.firstRound phải sau hiệp thu hẹp cuối của lịch gốc');
    }

    const schedule = collapseSchedule(cfg.board.radius, cfg.collapse);
    const lastScheduled = schedule[schedule.length - 1]?.round ?? 0;
    if (cfg.collapse.hardCapRound <= lastScheduled) {
      fail(['collapse', 'hardCapRound'], 'hardCapRound phải sau hiệp thu hẹp cuối cùng');
    }
  });

export type RulesConfig = z.infer<typeof RulesConfigSchema>;

/** Đọc và kiểm tra một cấu hình từ dữ liệu ngoài (JSON, tin nhắn `room.setConfig`). Ném ZodError nếu sai. */
export function parseConfig(input: unknown): RulesConfig {
  return RulesConfigSchema.parse(input);
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

/** Trộn sâu, không sửa đầu vào; mảng được thay nguyên khối. */
function deepMerge(base: unknown, override: unknown): unknown {
  if (override === undefined) return base;
  if (isPlainObject(base) && isPlainObject(override)) {
    const out: Record<string, unknown> = {};
    for (const key of new Set([...Object.keys(base), ...Object.keys(override)])) {
      out[key] = deepMerge(base[key], override[key]);
    }
    return out;
  }
  return Array.isArray(override) ? [...override] : override;
}

function deepFreeze<T>(value: T): T {
  if (typeof value === 'object' && value !== null) {
    for (const child of Object.values(value)) deepFreeze(child);
    Object.freeze(value);
  }
  return value;
}

export type DeepPartial<T> = {
  [K in keyof T]?: T[K] extends readonly unknown[] ? T[K] : T[K] extends object ? DeepPartial<T[K]> : T[K];
};

/** Cấu hình mặc định (Phụ lục C), đóng băng để không ai vô tình sửa. */
export const defaultConfig: RulesConfig = deepFreeze(parseConfig(rawDefaultConfig));

/** Cấu hình mặc định cộng các thay đổi (dùng cho test, preset, phòng tuỳ chỉnh). Luôn được kiểm tra lại. */
export function configWith(overrides: DeepPartial<RulesConfig>): RulesConfig {
  return parseConfig(deepMerge(rawDefaultConfig, overrides));
}
