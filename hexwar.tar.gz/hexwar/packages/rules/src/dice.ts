// Tung xúc xắc chọn người đi đầu. Nguồn: PLAN.md R-02, R-03 (RNG do server cấp, tất định theo seed).
import { emit, snapshot, toDraft } from './draft';
import type { ActionResult, GameEvent } from './events';
import { createRng, type Rng } from './rng';
import type { GameState, Seat } from './types';
import { beginPlay } from './turn';

/** Chặn vòng lặp nếu RNG hỏng (xác suất đồng điểm mãi mãi bằng 0). */
const MAX_ATTEMPTS = 1000;

type DiceRolled = Extract<GameEvent, { type: 'DICE_ROLLED' }>;

function rollOne(rng: Rng): number {
  return rng.int(6) + 1;
}

/**
 * R-02: mỗi người tung 3 xúc xắc 6 mặt, tổng cao nhất đi trước; nếu nhiều người đồng điểm cao nhất thì CHỈ những người
 * đó tung lại, lặp tới khi có duy nhất một người. Thứ tự tung trong một lượt tung là thứ tự ghế tăng dần.
 */
export function rollForFirst(seats: readonly Seat[], rng: Rng): { winner: Seat; events: DiceRolled[] } {
  let contenders = [...seats];
  const events: DiceRolled[] = [];
  for (let attempt = 1; attempt <= MAX_ATTEMPTS; attempt++) {
    const rolls = contenders.map((seat) => {
      const dice: [number, number, number] = [rollOne(rng), rollOne(rng), rollOne(rng)]; // R-02: 3 xúc xắc 6 mặt
      return { seat, dice, total: dice[0] + dice[1] + dice[2] };
    });
    const best = Math.max(...rolls.map((roll) => roll.total));
    const top = rolls.filter((roll) => roll.total === best);
    const winner = top.length === 1 ? (top[0] as { seat: Seat }).seat : null;
    events.push({ type: 'DICE_ROLLED', attempt, rolls, winner });
    if (winner !== null) return { winner, events };
    contenders = top.map((roll) => roll.seat);
  }
  throw new Error(`rollForFirst: quá ${MAX_ATTEMPTS} lần tung vẫn đồng điểm (RNG lỗi?)`);
}

/**
 * Tung xúc xắc rồi bắt đầu ván (pha 'dice' → 'playing'). R-03: thứ tự đi là chiều kim đồng hồ từ người thắng,
 * tức `order` xoay để người thắng đứng đầu. Hiệp 1 bắt đầu ngay ở lượt của họ (R-10).
 * `rng` mặc định tạo từ `state.seed`; server có thể truyền RNG riêng của phòng.
 */
export function rollDice(state: GameState, rng: Rng = createRng(state.seed)): ActionResult {
  if (state.phase !== 'dice') throw new Error(`rollDice: ván đang ở pha "${state.phase}", không phải "dice"`);
  const d = toDraft(state);
  const { winner, events } = rollForFirst(state.order, rng);
  for (const event of events) emit(d, event);

  const start = state.order.indexOf(winner);
  d.order = [...state.order.slice(start), ...state.order.slice(0, start)]; // R-03
  beginPlay(d);
  return { state: snapshot(d), events: d.events };
}
