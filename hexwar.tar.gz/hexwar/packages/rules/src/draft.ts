// Bản nháp trạng thái có thể sửa, dùng nội bộ trong MỘT hành động (applyMove, timeoutTurn, resign, rollDice).
// Mỗi hành động: toDraft → biến đổi → snapshot. Trạng thái công khai vẫn bất biến: Piece không bao giờ bị sửa
// tại chỗ, chỉ được thay bằng đối tượng mới.
import type { RulesConfig } from './config';
import type { GameEvent, ReleaseCause } from './events';
import { cellKey, cellsAtDistance, isOnBoard, type Cell } from './hex';
import { rankPlayers, scoreOf } from './score';
import type { Elimination, GameOverReason, GameResult, GameState, Phase, Piece, Seat } from './types';

export interface Draft {
  readonly config: RulesConfig;
  readonly seed: number;
  phase: Phase;
  round: number;
  order: Seat[];
  opener: Seat | null;
  turnSeat: Seat | null;
  pieces: Piece[];
  radius: number;
  eliminated: Elimination[];
  playerKills: number[];
  result: GameResult | undefined;
  readonly events: GameEvent[];
}

export function toDraft(state: GameState): Draft {
  return {
    config: state.config,
    seed: state.seed,
    phase: state.phase,
    round: state.round,
    order: [...state.order],
    opener: state.opener,
    turnSeat: state.turnSeat,
    pieces: [...state.pieces],
    radius: state.radius,
    eliminated: [...state.eliminated],
    playerKills: [...state.playerKills],
    result: state.result,
    events: [],
  };
}

/** Trạng thái bất biến từ bản nháp (sao chép mảng nên bản nháp tiếp tục sửa được mà không ảnh hưởng). */
export function snapshot(d: Draft): GameState {
  const state: GameState = {
    rulesVersion: d.config.rulesVersion,
    config: d.config,
    seed: d.seed,
    phase: d.phase,
    round: d.round,
    order: [...d.order],
    opener: d.opener,
    turnSeat: d.turnSeat,
    pieces: [...d.pieces],
    radius: d.radius,
    eliminated: [...d.eliminated],
    playerKills: [...d.playerKills],
  };
  return d.result === undefined ? state : { ...state, result: d.result };
}

export function emit(d: Draft, event: GameEvent): void {
  d.events.push(event);
}

// ---- Quân và ô ----------------------------------------------------------------------------------------

export function getPiece(d: Draft, id: string): Piece {
  const piece = d.pieces.find((p) => p.id === id);
  if (piece === undefined) throw new Error(`Không tìm thấy quân "${id}"`);
  return piece;
}

/** Thay quân cùng id bằng bản mới (giữ nguyên vị trí trong mảng để thứ tự tất định). */
export function replacePiece(d: Draft, next: Piece): void {
  const index = d.pieces.findIndex((p) => p.id === next.id);
  if (index < 0) throw new Error(`replacePiece: không tìm thấy quân "${next.id}"`);
  d.pieces[index] = next;
}

export function removePieces(d: Draft, ids: ReadonlySet<string>): void {
  if (ids.size === 0) return;
  d.pieces = d.pieces.filter((p) => !ids.has(p.id));
}

/** Quân hoạt động đang đứng ở ô (tối đa một). */
export function activePieceAt(d: Draft, at: Cell): Piece | undefined {
  return d.pieces.find((p) => p.status === 'active' && p.cell.q === at.q && p.cell.r === at.r);
}

/** Tù binh nằm ở ô. */
export function captivesAt(d: Draft, at: Cell): Piece[] {
  return d.pieces.filter((p) => p.status === 'captive' && p.cell.q === at.q && p.cell.r === at.r);
}

/** Bỏ đặc điểm tù binh: quân trở lại hoạt động tại `at`. */
export function asActive(piece: Piece, at: Cell): Piece {
  const { holder: _holder, armed: _armed, ...rest } = piece;
  return { ...rest, status: 'active', cell: at };
}

// ---- Giải phóng tù binh (R-35, R-36) ---------------------------------------------------------------------

function occupiedKeys(d: Draft, exclude: ReadonlySet<string>): Set<number> {
  const keys = new Set<number>();
  for (const p of d.pieces) if (!exclude.has(p.id)) keys.add(cellKey(p.cell));
  return keys;
}

/**
 * R-36: ô trống gần nhất theo khoảng cách lưới tăng dần từ ô gốc (kể cả chính ô gốc nếu đã trống); hoà thì
 * ô có q nhỏ hơn, rồi r nhỏ hơn; ô phải còn trên bàn cờ. "Trống" = không có quân nào, kể cả tù binh.
 */
export function nearestEmptyCell(radius: number, origin: Cell, occupied: ReadonlySet<number>): Cell | undefined {
  for (let distance = 0; distance <= 2 * radius; distance++) {
    for (const candidate of cellsAtDistance(origin, distance)) {
      if (isOnBoard(candidate, radius) && !occupied.has(cellKey(candidate))) return candidate;
    }
  }
  return undefined;
}

/**
 * Trả các tù binh về thành quân hoạt động ở ô trống gần nhất (R-36). Xử lý lần lượt theo thứ tự truyền vào;
 * mỗi quân đặt xong thì ô đó coi như đã có quân. Các tù binh đang được giải phóng không cản nhau.
 */
export function releaseCaptives(d: Draft, ids: readonly string[], cause: ReleaseCause): void {
  if (ids.length === 0) return;
  const releasing = new Set(ids);
  const occupied = occupiedKeys(d, releasing);
  for (const id of ids) {
    const piece = getPiece(d, id);
    const to = nearestEmptyCell(d.radius, piece.cell, occupied);
    if (to === undefined) {
      // Bàn cờ không còn ô trống nào: quân mất luôn (gần như không thể xảy ra).
      removePieces(d, new Set([id]));
      emit(d, { type: 'CAPTIVE_EXPIRED', pieceId: id, owner: piece.owner, holder: piece.holder ?? piece.owner, cell: piece.cell });
      continue;
    }
    occupied.add(cellKey(to));
    replacePiece(d, asActive(piece, to));
    emit(d, { type: 'CAPTIVE_RELEASED', pieceId: id, owner: piece.owner, from: piece.cell, to, cause });
  }
}

/** Như releaseCaptives nhưng bỏ qua quân đã biến mất hoặc không còn là tù binh (do bước trước đã xử lý). */
export function releaseStillCaptive(d: Draft, ids: readonly string[], cause: ReleaseCause): void {
  const alive = ids.filter((id) => d.pieces.some((p) => p.id === id && p.status === 'captive'));
  releaseCaptives(d, alive, cause);
}

// ---- Người chơi -------------------------------------------------------------------------------------------

export function isAlive(d: Draft, seat: Seat): boolean {
  return d.order.includes(seat) && !d.eliminated.some((e) => e.seat === seat);
}

/** Các ghế còn trong ván, theo thứ tự đi. */
export function aliveSeats(d: Draft): Seat[] {
  return d.order.filter((seat) => !d.eliminated.some((e) => e.seat === seat));
}

/** Ghế còn sống kế tiếp sau `from` theo thứ tự đi (vòng tròn); undefined nếu không còn ai. */
export function nextAliveAfter(d: Draft, from: Seat): Seat | undefined {
  const start = d.order.indexOf(from);
  if (start < 0) throw new Error(`nextAliveAfter: ghế ${from} không nằm trong thứ tự đi`);
  for (let step = 1; step <= d.order.length; step++) {
    const seat = d.order[(start + step) % d.order.length] as Seat;
    if (isAlive(d, seat)) return seat;
  }
  return undefined;
}

/** Số hiệu "khoảnh khắc bị loại" kế tiếp (R-82: bị loại cùng lúc thì chung một batch). */
export function nextBatch(d: Draft): number {
  const last = d.eliminated[d.eliminated.length - 1];
  return (last?.batch ?? 0) + 1;
}

/** R-10: nếu người mở hiệp bị loại thì người còn sống kế tiếp làm người mở hiệp. */
export function refreshOpener(d: Draft): void {
  if (d.opener === null || isAlive(d, d.opener)) return;
  const next = nextAliveAfter(d, d.opener);
  if (next !== undefined) d.opener = next;
}

/**
 * Loại một người chơi (R-60, R-61, R-70). Toàn bộ quân của họ biến mất, kể cả tù binh của họ đang bị người
 * khác giữ. Tù binh của người khác mà họ đang giữ được giải phóng (R-35).
 */
export function eliminatePlayer(
  d: Draft,
  seat: Seat,
  reason: Elimination['reason'],
  batch: number,
  /**
   * Điểm đã chụp trước đó, dùng khi nhiều người bị loại cùng lúc (R-72). Với luật điểm hiện tại (R-31, R-82) việc
   * loại người này không đổi điểm người kia (có test bất biến ở score.test.ts), nên đây chỉ là phòng thủ để kết quả
   * không phụ thuộc thứ tự loại nếu luật điểm đổi sau này.
   */
  scoreBefore?: number,
): void {
  if (!isAlive(d, seat)) return;
  const score = scoreBefore ?? scoreOf(d, seat); // R-82: điểm ngay trước khi bị loại
  const removedIds = d.pieces.filter((p) => p.owner === seat).map((p) => p.id);
  removePieces(d, new Set(removedIds));

  const heldIds = d.pieces.filter((p) => p.status === 'captive' && p.holder === seat).map((p) => p.id);
  releaseCaptives(d, heldIds, 'holder_eliminated'); // R-35

  d.eliminated.push({ seat, round: d.round, reason, batch, score });
  emit(d, { type: 'PLAYER_ELIMINATED', seat, reason, removedPieceIds: removedIds });
  refreshOpener(d);
}

// ---- Kết thúc ván ---------------------------------------------------------------------------------------------

export function finishGame(d: Draft, reason: GameOverReason): void {
  d.phase = 'over';
  d.turnSeat = null;
  const ranking = rankPlayers(d);
  let winner: Seat | null;
  if (reason === 'lastKing') {
    winner = aliveSeats(d)[0] ?? null; // R-80
  } else if (reason === 'allEliminated') {
    winner = null; // R-72: hoà
  } else {
    const best = ranking.filter((entry) => entry.rank === 1); // R-81
    winner = best.length === 1 ? (best[0] as { seat: Seat }).seat : null;
  }
  d.result = { reason, winner, ranking };
  emit(d, { type: 'GAME_OVER', reason, winner, ranking });
}

/** R-80, R-72: còn đúng một người → người đó thắng; không còn ai → hoà. Trả về true nếu ván đã kết thúc. */
export function checkGameOver(d: Draft): boolean {
  if (d.phase === 'over') return true;
  const alive = aliveSeats(d).length;
  if (alive === 1) finishGame(d, 'lastKing');
  else if (alive === 0) finishGame(d, 'allEliminated');
  else return false;
  return true;
}
