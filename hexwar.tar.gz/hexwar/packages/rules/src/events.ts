// Sự kiện engine phát ra. Nguồn: PLAN.md mục 6.5. Lớp hoạt ảnh 3D chỉ đọc các sự kiện này (mục 6.1).
// Trạng thái logic luôn cập nhật ngay; sự kiện được phát theo đúng thứ tự xử lý ở mục 4.10.
import type { Cell } from './hex';
import type { GameOverReason, GameState, PieceType, RankEntry, Seat } from './types';

/** Vì sao một tù binh được trả lại thành quân hoạt động. */
export type ReleaseCause =
  /** Chủ của tù binh ăn lại người giữ (R-34). */
  | 'rescued'
  /** Người giữ bị loại khỏi ván (R-35, R-60). */
  | 'holder_eliminated'
  /** Quân giữ bị tù binh trưng dụng ăn mất, không tạo chuỗi tù binh (R-32). */
  | 'holder_lost';

export type GameEvent =
  | {
      readonly type: 'DICE_ROLLED';
      /** Lần tung thứ mấy (>1 nếu có đồng điểm cao nhất, R-02). */
      readonly attempt: number;
      readonly rolls: readonly { readonly seat: Seat; readonly dice: readonly [number, number, number]; readonly total: number }[];
      /** Người thắng nếu lần tung này phân định được, ngược lại null (sẽ tung lại). */
      readonly winner: Seat | null;
    }
  | { readonly type: 'ROUND_STARTED'; readonly round: number }
  | { readonly type: 'TURN_STARTED'; readonly seat: Seat; readonly round: number }
  | { readonly type: 'TURN_SKIPPED'; readonly seat: Seat; readonly reason: 'timeout' | 'no_moves' }
  | {
      readonly type: 'MOVED';
      readonly pieceId: string;
      readonly seat: Seat;
      readonly from: Cell;
      readonly to: Cell;
      /** true nếu là tù binh được trưng dụng. */
      readonly conscript: boolean;
    }
  | {
      readonly type: 'CAPTURED';
      readonly attackerId: string;
      readonly victimId: string;
      readonly seat: Seat;
      readonly victimOwner: Seat;
      readonly cell: Cell;
      readonly conscript: boolean;
    }
  | { readonly type: 'CAPTIVE_CREATED'; readonly pieceId: string; readonly owner: Seat; readonly holder: Seat; readonly cell: Cell }
  | {
      readonly type: 'CAPTIVE_TRANSFERRED';
      readonly pieceId: string;
      readonly owner: Seat;
      readonly from: Seat;
      readonly to: Seat;
    }
  | { readonly type: 'CAPTIVE_CONSCRIPTED'; readonly pieceId: string; readonly owner: Seat; readonly holder: Seat }
  | {
      readonly type: 'CAPTIVE_RELEASED';
      readonly pieceId: string;
      readonly owner: Seat;
      readonly from: Cell;
      readonly to: Cell;
      readonly cause: ReleaseCause;
    }
  | {
      readonly type: 'CAPTIVE_EXPIRED';
      readonly pieceId: string;
      readonly owner: Seat;
      readonly holder: Seat;
      readonly cell: Cell;
    }
  | {
      readonly type: 'PROMOTED';
      readonly pieceId: string;
      readonly owner: Seat;
      readonly from: PieceType;
      readonly to: PieceType;
      readonly kills: number;
    }
  | { readonly type: 'KING_CAPTURED'; readonly kingId: string; readonly owner: Seat; readonly by: Seat; readonly cell: Cell }
  | {
      readonly type: 'JESTER_REVIVED';
      readonly kingId: string;
      readonly jesterId: string;
      readonly owner: Seat;
      readonly from: Cell;
      readonly to: Cell;
      readonly cause: 'capture' | 'collapse';
    }
  | {
      readonly type: 'PLAYER_ELIMINATED';
      readonly seat: Seat;
      readonly reason: 'king' | 'collapse' | 'resign';
      readonly removedPieceIds: readonly string[];
    }
  | {
      readonly type: 'RING_WARNING';
      /** Hạng sẽ biến mất. */
      readonly ring: number;
      /** Còn bao nhiêu hiệp nữa thì biến mất (R-71). */
      readonly roundsLeft: number;
      readonly level: 'yellow' | 'red';
    }
  | {
      readonly type: 'RING_COLLAPSED';
      readonly round: number;
      readonly ring: number;
      /** Bán kính bàn cờ sau khi thu hẹp. */
      readonly radius: number;
      /** Mọi quân (kể cả tù binh) biến mất cùng vòng ngoài; không ai được kill (R-70). */
      readonly removedPieceIds: readonly string[];
    }
  | {
      readonly type: 'GAME_OVER';
      readonly reason: GameOverReason;
      readonly winner: Seat | null;
      readonly ranking: readonly RankEntry[];
    };

export type GameEventType = GameEvent['type'];

/** Kết quả của mọi hành động làm đổi trạng thái: trạng thái mới + sự kiện theo thứ tự xảy ra. */
export interface ActionResult {
  readonly state: GameState;
  readonly events: readonly GameEvent[];
}
