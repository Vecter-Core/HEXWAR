// Băm trạng thái (PLAN 6.5, 14): cùng seed + cùng chuỗi nước đi phải cho cùng hash ở mọi máy.
import type { GameState } from './types';

/** cyrb53: băm chuỗi 53 bit, chỉ dùng Math.imul nên tất định trên mọi engine JS. */
function cyrb53(text: string): number {
  let h1 = 0xdeadbeef;
  let h2 = 0x41c6ce57;
  for (let i = 0; i < text.length; i++) {
    const ch = text.charCodeAt(i);
    h1 = Math.imul(h1 ^ ch, 2654435761);
    h2 = Math.imul(h2 ^ ch, 1597334677);
  }
  h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507);
  h1 ^= Math.imul(h2 ^ (h2 >>> 13), 3266489909);
  h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507);
  h2 ^= Math.imul(h1 ^ (h1 >>> 13), 3266489909);
  return 4294967296 * (2097151 & h2) + (h1 >>> 0);
}

/** Chuỗi chuẩn tắc mô tả toàn bộ trạng thái (quân sắp theo id để không phụ thuộc thứ tự mảng). */
function canonical(state: GameState): string {
  const pieces = [...state.pieces]
    .sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0))
    .map(
      (p) =>
        `${p.id},${p.owner},${p.type},${p.origin},${p.cell.q},${p.cell.r},${p.kills},${p.status},${p.holder ?? '-'},${p.armed === true ? 1 : 0}`,
    )
    .join(';');
  const eliminated = state.eliminated.map((e) => `${e.seat},${e.round},${e.reason},${e.batch},${e.score}`).join(';');
  return [
    state.rulesVersion,
    JSON.stringify(state.config),
    state.seed,
    state.phase,
    state.round,
    state.order.join(','),
    state.opener ?? '-',
    state.turnSeat ?? '-',
    state.radius,
    state.playerKills.join(','),
    eliminated,
    pieces,
  ].join('|');
}

/** Hash thập lục phân 14 ký tự của trạng thái. */
export function hash(state: GameState): string {
  return cyrb53(canonical(state)).toString(16).padStart(14, '0');
}
