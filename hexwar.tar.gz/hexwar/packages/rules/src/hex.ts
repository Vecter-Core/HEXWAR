// Hình học lưới lục giác: toạ độ trục (q, r), khoảng cách, xoay 60°, đổi sang toạ độ thế giới.
// Nguồn: PLAN.md mục 3.1–3.3. Kiểm chứng chéo bằng tools/verify_board.py.

/** Toạ độ trục (axial) của một ô. Ô phẳng-đỉnh khi vẽ. */
export interface Cell {
  readonly q: number;
  readonly r: number;
}

/**
 * Tạo ô. `+ 0` chuẩn hoá -0 thành 0: phép xoay `-r` rất dễ sinh -0, và
 * `toEqual` / `Object.is` coi -0 khác 0 (gây lỗi khó thấy khi so sánh trạng thái).
 */
export function cell(q: number, r: number): Cell {
  return { q: q + 0, r: r + 0 };
}

export const ORIGIN: Cell = cell(0, 0);

/** Hạng (vòng) của ô: tâm = 0. Ô nằm trên bàn bán kính R khi ring ≤ R. */
export function ring(c: Cell): number {
  return Math.max(Math.abs(c.q), Math.abs(c.r), Math.abs(c.q + c.r));
}

/** Khoảng cách lưới (số ô theo đường ngắn nhất). */
export function dist(a: Cell, b: Cell): number {
  const dq = a.q - b.q;
  const dr = a.r - b.r;
  return Math.max(Math.abs(dq), Math.abs(dr), Math.abs(dq + dr));
}

/** a + k·b */
export function add(a: Cell, b: Cell, k = 1): Cell {
  return cell(a.q + k * b.q, a.r + k * b.r);
}

/** a − b */
export function sub(a: Cell, b: Cell): Cell {
  return cell(a.q - b.q, a.r - b.r);
}

export function sameCell(a: Cell, b: Cell): boolean {
  return a.q === b.q && a.r === b.r;
}

/** Số ô của bàn bán kính n: 3n(n+1)+1. R = 24 → 1801. */
export function cellCount(radius: number): number {
  return 3 * radius * (radius + 1) + 1;
}

/** Ô có toạ độ nguyên và nằm trên bàn bán kính `radius` (R-21). Chịu được dữ liệu rác (NaN, số thực). */
export function isOnBoard(c: Cell, radius: number): boolean {
  return Number.isInteger(c.q) && Number.isInteger(c.r) && ring(c) <= radius;
}

// ---- Xoay 60° -------------------------------------------------------------------------------

/** Xoay 60° THEO CHIỀU KIM ĐỒNG HỒ khi nhìn từ trên xuống: (q, r) → (−r, q + r). */
export function rotCW(c: Cell): Cell {
  return cell(-c.r, c.q + c.r);
}

/** Xoay `steps` bước 60° theo chiều kim đồng hồ (âm = ngược chiều). */
export function rotate(c: Cell, steps: number): Cell {
  const n = ((steps % 6) + 6) % 6;
  let out = c;
  for (let i = 0; i < n; i++) out = rotCW(out);
  return out;
}

// ---- Bộ hướng đi (đều bất biến khi xoay 60°) ---------------------------------------------------

/** 6 hướng cạnh, khoảng cách 1, theo chiều kim đồng hồ từ "lên". */
export const DIR = {
  N: cell(0, -1),
  NE: cell(1, -1),
  SE: cell(1, 0),
  S: cell(0, 1),
  SW: cell(-1, 1),
  NW: cell(-1, 0),
} as const;

/** Hướng cạnh (Xe, Hậu, Vua, Hề, Tốt). */
export const E_DIRS: readonly Cell[] = [DIR.N, DIR.NE, DIR.SE, DIR.S, DIR.SW, DIR.NW];

/**
 * Hướng đỉnh, khoảng cách 2, là tổng hai hướng cạnh kề nhau (NNE, E, SSE, SSW, W, NNW).
 * Hai ô trung gian (trên/dưới) của một bước nhảy đỉnh KHÔNG cản đường (R-20).
 */
export const V_DIRS: readonly Cell[] = [cell(1, -2), cell(2, -1), cell(1, 1), cell(-1, 2), cell(-2, 1), cell(-1, -1)];

/** 12 ô đích của Mã: đúng 12 ô "không phải góc" của hạng 3. */
export const KNIGHT_JUMPS: readonly Cell[] = [
  cell(1, -3),
  cell(2, -3),
  cell(3, -2),
  cell(3, -1),
  cell(2, 1),
  cell(1, 2),
  cell(-1, 3),
  cell(-2, 3),
  cell(-3, 2),
  cell(-3, 1),
  cell(-2, -1),
  cell(-1, -2),
];

// ---- Khoá số cho ô (Map/Set nhanh) -----------------------------------------------------------------

const KEY_OFFSET = 32;
const KEY_BASE = 64;
/** Toạ độ lớn nhất mà `cellKey` chấp nhận (bàn tối đa bán kính 28 vẫn còn dư chỗ). */
export const MAX_KEY_COORD = 31;

/** Khoá số duy nhất cho ô (|q|, |r| ≤ 31). Ném RangeError nếu ngoài miền để không va chạm ngầm. */
export function cellKey(c: Cell): number {
  if (!Number.isInteger(c.q) || !Number.isInteger(c.r) || Math.abs(c.q) > MAX_KEY_COORD || Math.abs(c.r) > MAX_KEY_COORD) {
    throw new RangeError(`cellKey: ô (${c.q}, ${c.r}) nằm ngoài miền hỗ trợ`);
  }
  return (c.q + KEY_OFFSET) * KEY_BASE + (c.r + KEY_OFFSET);
}

// ---- Liệt kê ô ---------------------------------------------------------------------------------------

/** Mọi ô có ring ≤ radius, thứ tự tất định: q tăng dần, rồi r tăng dần. */
export function cellsInRadius(radius: number): Cell[] {
  const out: Cell[] = [];
  for (let q = -radius; q <= radius; q++) {
    const rMin = Math.max(-radius, -radius - q);
    const rMax = Math.min(radius, radius - q);
    for (let r = rMin; r <= rMax; r++) out.push(cell(q, r));
  }
  return out;
}

/** Mọi ô có ring đúng bằng n (cùng thứ tự với cellsInRadius). */
export function cellsInRing(n: number): Cell[] {
  return cellsInRadius(n).filter((c) => ring(c) === n);
}

/**
 * Mọi ô cách `origin` đúng `d` theo khoảng cách lưới (không bị giới hạn bởi bàn cờ), thứ tự tất định:
 * q tăng dần rồi r tăng dần. Đúng thứ tự hoà của R-36 ("ô có q nhỏ hơn, rồi r nhỏ hơn").
 */
export function cellsAtDistance(origin: Cell, d: number): Cell[] {
  if (d === 0) return [origin];
  const out: Cell[] = [];
  for (let dq = -d; dq <= d; dq++) {
    const drMin = Math.max(-d, -d - dq);
    const drMax = Math.min(d, d - dq);
    for (let dr = drMin; dr <= drMax; dr++) {
      if (Math.max(Math.abs(dq), Math.abs(dr), Math.abs(dq + dr)) === d) out.push(cell(origin.q + dq, origin.r + dr));
    }
  }
  return out;
}

// ---- Tô 3 màu ------------------------------------------------------------------------------------------

/**
 * Tông màu 0..2 của ô: (q − r) mod 3. Hai ô kề cạnh luôn khác màu; bước nhảy đỉnh (V) giữ nguyên
 * màu (Tượng chỉ đi trên một màu); Mã luôn đổi màu.
 */
export function colorOf(c: Cell): 0 | 1 | 2 {
  return ((((c.q - c.r) % 3) + 3) % 3) as 0 | 1 | 2;
}

// ---- Toạ độ thế giới 3D --------------------------------------------------------------------------------

const SQRT3 = Math.sqrt(3);

/** Tâm ô trong không gian 3D (ô phẳng-đỉnh, cạnh ô = size): x = 1.5·s·q, z = √3·s·(r + q/2). */
export function worldPos(c: Cell, size = 1): { x: number; z: number } {
  return { x: 1.5 * size * c.q, z: SQRT3 * size * (c.r + c.q / 2) };
}

/** Nghịch đảo của worldPos + làm tròn lục giác (chọn ô O(1), PLAN.md mục 6.6). */
export function pixelToCell(x: number, z: number, size = 1): Cell {
  const q = x / (1.5 * size);
  const r = z / (SQRT3 * size) - q / 2;
  return roundAxial(q, r);
}

function roundAxial(q: number, r: number): Cell {
  const s = -q - r;
  let rq = Math.round(q);
  let rr = Math.round(r);
  const rs = Math.round(s);
  const dq = Math.abs(rq - q);
  const dr = Math.abs(rr - r);
  const ds = Math.abs(rs - s);
  // Sửa thành phần bị làm tròn lệch nhất để giữ q + r + s = 0.
  if (dq > dr && dq > ds) rq = -rr - rs;
  else if (dr > ds) rr = -rq - rs;
  return cell(rq, rr);
}

// ---- Ghế -----------------------------------------------------------------------------------------------

export const SEAT_COUNT = 6;

/** Ô góc xuất phát của ghế: rotCW^seat(0, seatCornerRing). */
export function seatCorner(seat: number, seatCornerRing: number): Cell {
  return rotate(cell(0, seatCornerRing), seat);
}

/** Đổi một hướng/ô theo khung của ghế: khung ghế 0 xoay `seat × 60°`. */
export function toSeatFrame(c: Cell, seat: number): Cell {
  return rotate(c, seat);
}
