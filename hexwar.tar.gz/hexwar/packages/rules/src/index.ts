// @hexwar/rules — engine luật thuần và tất định (PLAN.md mục 6.1).
// M1: hình học, bàn cờ, đội hình, nước đi 7 loại quân.
// M2: ăn quân/tù binh, kill/phong cấp, Hề, Vua, thu hẹp, xúc xắc, hiệp/lượt, xếp hạng, sự kiện.
export * from './hex';
export * from './types';
export * from './config';
export * from './collapse';
export { applyPreset, PRESET_NAMES, type PresetName } from './presets';
export * from './board';
export * from './moves';
export * from './events';
export { createRng, type Rng } from './rng';
export { scoreOf, rankPlayers } from './score';
export { hash } from './hash';
export { nearestEmptyCell } from './draft';
export { scheduleOf, collapseEventAt, upcomingCollapses, nextCollapse, type UpcomingCollapse, type WarningLevel } from './shrink';
export { IllegalMoveError, checkMove, applyMove, timeoutTurn, resign } from './turn';
export { rollDice, rollForFirst } from './dice';
export { validateState, assertValidState, type ValidateOptions } from './validate';
