// Nước đi của 7 loại quân. Nguồn: PLAN.md mục 4.3, R-20, R-21, R-22.
// M1 chưa có tù binh / thu hẹp / lượt (M2): chỉ sinh nước đi theo hình học và luật từng quân,
// không kiểm tra "tới lượt ai".
//
// Thiết kế: `legalTargets` là NGUỒN DUY NHẤT quyết định một nước có hợp lệ hay không.
// `legalMoves` gom kết quả của nó; `explainIllegal` hỏi lại chính nó, và chỉ khi nước bị từ chối
// mới chạy `diagnose` để chọn lý do. Vì vậy hai hàm không thể lệch nhau.
import {
  DIR,
  E_DIRS,
  KNIGHT_JUMPS,
  V_DIRS,
  add,
  cellKey,
  isOnBoard,
  rotate,
  sameCell,
  sub,
  type Cell,
} from './hex';
import type { RulesConfig } from './config';
import type { GameState, IllegalReason, Move, Piece, Seat } from './types';

// ---- Bản đồ ô ---------------------------------------------------------------------------------

interface Occupant {
  /** Quân hoạt động đang đứng ở ô (tối đa 1). */
  active: Piece | undefined;
  /** Tù binh nằm chung ô (M2). Ô chỉ có tù binh vẫn chặn đường. */
  captives: Piece[];
}

type Occupancy = ReadonlyMap<number, Occupant>;

function buildOccupancy(pieces: readonly Piece[]): Occupancy {
  const map = new Map<number, Occupant>();
  for (const piece of pieces) {
    const key = cellKey(piece.cell);
    let occupant = map.get(key);
    if (occupant === undefined) {
      occupant = { active: undefined, captives: [] };
      map.set(key, occupant);
    }
    if (piece.status === 'active') occupant.active = piece;
    else occupant.captives.push(piece);
  }
  return map;
}

function occupantAt(occ: Occupancy, at: Cell): Occupant | undefined {
  return occ.get(cellKey(at));
}

/** Ô có quân địch hoạt động (đối tượng bị ăn). */
function hasEnemy(occupant: Occupant | undefined, owner: Seat): boolean {
  return occupant?.active !== undefined && occupant.active.owner !== owner;
}

// ---- Tầm đi -------------------------------------------------------------------------------------

type Slider = 'R' | 'B' | 'Q' | 'J';
type RayKind = 'E' | 'V';

interface Ray {
  readonly dir: Cell;
  readonly kind: RayKind;
}

const E_RAYS: readonly Ray[] = E_DIRS.map((dir) => ({ dir, kind: 'E' as const }));
const V_RAYS: readonly Ray[] = V_DIRS.map((dir) => ({ dir, kind: 'V' as const }));
const ALL_RAYS: readonly Ray[] = [...E_RAYS, ...V_RAYS];

const RAYS_OF: Record<Slider, readonly Ray[]> = { R: E_RAYS, B: V_RAYS, Q: ALL_RAYS, J: ALL_RAYS };

/**
 * Số bước tối đa của quân trượt theo một tia (D-03).
 * 'distance': tầm là khoảng cách lưới; bước cạnh dài 1, bước nhảy đỉnh dài 2 (Tượng 9 → 4 bước nhảy).
 * 'hops': tầm là số bước theo đường đi của quân.
 */
function maxSteps(type: Slider, kind: RayKind, config: RulesConfig): number {
  const reach = config.reach[type];
  if (config.reach.metric === 'hops') return reach;
  return Math.floor(reach / (kind === 'E' ? 1 : 2));
}

// ---- Nguồn duy nhất: ô đích hợp lệ của một quân ---------------------------------------------------

function legalTargets(state: GameState, occ: Occupancy, piece: Piece): Cell[] {
  switch (piece.type) {
    case 'P':
      return pawnTargets(state, occ, piece);
    case 'N':
      return jumpTargets(state, occ, piece, KNIGHT_JUMPS);
    case 'K':
      return jumpTargets(state, occ, piece, [...E_DIRS, ...V_DIRS]);
    default:
      return slideTargets(state, occ, piece, piece.type);
  }
}

/** Tốt: 1 ô tiến/lùi vào ô trống; ăn chéo 4 ô kề theo khung ghế; không ăn thẳng (R-22 tắt nước đi 2 ô). */
function pawnTargets(state: GameState, occ: Occupancy, piece: Piece): Cell[] {
  const out: Cell[] = [];
  for (const dir of [DIR.N, DIR.S]) {
    const to = add(piece.cell, rotate(dir, piece.owner));
    if (isOnBoard(to, state.radius) && occupantAt(occ, to) === undefined) out.push(to);
  }
  for (const dir of [DIR.NE, DIR.NW, DIR.SE, DIR.SW]) {
    const to = add(piece.cell, rotate(dir, piece.owner));
    if (isOnBoard(to, state.radius) && hasEnemy(occupantAt(occ, to), piece.owner)) out.push(to);
  }
  return out;
}

/** Mã (12 ô, nhảy qua quân chắn) và Vua (12 hướng, 1 bước): đích không được có quân mình hoặc tù binh chặn. */
function jumpTargets(state: GameState, occ: Occupancy, piece: Piece, offsets: readonly Cell[]): Cell[] {
  const out: Cell[] = [];
  for (const offset of offsets) {
    const to = add(piece.cell, offset);
    if (!isOnBoard(to, state.radius)) continue; // R-21
    const occupant = occupantAt(occ, to);
    if (occupant === undefined || hasEnemy(occupant, piece.owner)) out.push(to);
  }
  return out;
}

/** Xe, Tượng, Hậu, Hề: trượt theo tia tới khi gặp biên, tầm tối đa hoặc quân chắn (R-20, R-21). */
function slideTargets(state: GameState, occ: Occupancy, piece: Piece, type: Slider): Cell[] {
  const out: Cell[] = [];
  const canCapture = type !== 'J'; // R-50: Hề không bao giờ ăn quân
  for (const { dir, kind } of RAYS_OF[type]) {
    const limit = maxSteps(type, kind, state.config);
    for (let k = 1; k <= limit; k++) {
      const to = add(piece.cell, dir, k);
      if (!isOnBoard(to, state.radius)) break; // R-21
      const occupant = occupantAt(occ, to);
      if (occupant === undefined) {
        out.push(to);
        continue;
      }
      // R-20: mọi ô có quân (kể cả tù binh) chặn đường; gặp địch hoạt động thì ăn rồi dừng.
      if (canCapture && hasEnemy(occupant, piece.owner)) out.push(to);
      break;
    }
  }
  return out;
}

// ---- Trưng dụng tù binh (R-32) ------------------------------------------------------------------------

/** Tù binh này có thể được người giữ trưng dụng ngay bây giờ không? */
function isConscriptable(state: GameState, piece: Piece): boolean {
  return piece.status === 'captive' && state.config.captive.conscript && piece.holder !== undefined && piece.armed === true;
}

/**
 * R-32: tù binh được trưng dụng đi "như quân của mình": theo luật loại quân của nó, trong khung ghế của
 * người giữ, và chỉ ăn được quân không phải của người giữ.
 */
function asConscripted(piece: Piece): Piece {
  if (piece.holder === undefined) throw new Error(`asConscripted: ${piece.id} không có người giữ`);
  return { ...piece, owner: piece.holder, status: 'active' };
}

// ---- API công khai --------------------------------------------------------------------------------

/**
 * Mọi nước đi hợp lệ của một ghế (không xét tới lượt; xét tới lượt là việc của `checkMove`).
 * Gồm cả nước trưng dụng tù binh đã "sẵn sàng" của ghế đó (R-32), đánh dấu `conscript: true`.
 * Thứ tự tất định: theo thứ tự quân trong `state.pieces`, rồi theo thứ tự hướng đi.
 */
export function legalMoves(state: GameState, seat: Seat): Move[] {
  const occ = buildOccupancy(state.pieces);
  const moves: Move[] = [];
  for (const piece of state.pieces) {
    if (piece.status === 'active') {
      if (piece.owner !== seat) continue;
      for (const to of legalTargets(state, occ, piece)) moves.push({ pieceId: piece.id, to });
    } else if (piece.holder === seat && isConscriptable(state, piece)) {
      for (const to of legalTargets(state, occ, asConscripted(piece))) {
        moves.push({ pieceId: piece.id, to, conscript: true });
      }
    }
  }
  return moves;
}

/**
 * Nước đi hợp lệ của một quân (để tô ô khi người chơi chọn quân). Với tù binh sẵn sàng thì trả về các nước
 * trưng dụng. Rỗng nếu quân không tồn tại hoặc không đi được.
 */
export function legalMovesOfPiece(state: GameState, pieceId: string): Move[] {
  const piece = state.pieces.find((p) => p.id === pieceId);
  if (piece === undefined) return [];
  const occ = buildOccupancy(state.pieces);
  if (piece.status === 'active') return legalTargets(state, occ, piece).map((to) => ({ pieceId, to }));
  if (!isConscriptable(state, piece)) return [];
  return legalTargets(state, occ, asConscripted(piece)).map((to) => ({ pieceId, to, conscript: true }));
}

/**
 * Trả về `null` nếu nước đi hợp lệ, ngược lại là mã lý do để UI giải thích (PLAN.md mục 10.1).
 * Luôn khớp `legalMoves`: nước hợp lệ ⇔ `null`. Chỉ xét luật của quân; kiểm tra pha ván và lượt
 * (NOT_YOUR_TURN, GAME_NOT_PLAYING) là việc của `checkMove` trong turn.ts.
 */
export function explainIllegal(state: GameState, move: Move): IllegalReason | null {
  const piece = state.pieces.find((p) => p.id === move.pieceId);
  if (piece === undefined) return 'UNKNOWN_PIECE';

  let actor: Piece;
  if (move.conscript === true) {
    if (piece.status !== 'captive') return 'NOT_A_CAPTIVE';
    if (!state.config.captive.conscript) return 'CONSCRIPT_DISABLED';
    if (!isConscriptable(state, piece)) return 'CAPTIVE_NOT_READY';
    actor = asConscripted(piece);
  } else {
    if (piece.status !== 'active') return 'PIECE_IS_CAPTIVE'; // R-31: tù binh bị đóng băng
    actor = piece;
  }

  if (!isOnBoard(move.to, state.radius)) return 'TARGET_OFF_BOARD'; // R-21
  if (sameCell(actor.cell, move.to)) return 'SAME_CELL';

  const occ = buildOccupancy(state.pieces);
  if (legalTargets(state, occ, actor).some((to) => sameCell(to, move.to))) return null;
  return diagnose(state, occ, actor, move.to);
}

// ---- Chẩn đoán lý do (chỉ chạy khi nước đã bị từ chối) ---------------------------------------------------

/** Nếu `delta` = k·dir với k ≥ 1 nguyên thì trả về k. */
function multipleOf(delta: Cell, dir: Cell): number | undefined {
  const k = dir.q !== 0 ? delta.q / dir.q : delta.r / dir.r;
  if (!Number.isInteger(k) || k < 1) return undefined;
  return delta.q === k * dir.q && delta.r === k * dir.r ? k : undefined;
}

function findRay(delta: Cell, rays: readonly Ray[]): { ray: Ray; k: number } | undefined {
  for (const ray of rays) {
    const k = multipleOf(delta, ray.dir);
    if (k !== undefined) return { ray, k };
  }
  return undefined;
}

/** Lý do khi đích đã "đi tới được" về hình học nhưng bị chính ô đích từ chối. */
function targetBlockReason(occupant: Occupant | undefined, piece: Piece): IllegalReason | undefined {
  if (occupant === undefined) return undefined;
  if (occupant.active === undefined) return 'TARGET_BLOCKED'; // ô chỉ có tù binh
  if (occupant.active.owner === piece.owner) return 'TARGET_OWN_PIECE';
  return undefined;
}

function diagnose(state: GameState, occ: Occupancy, piece: Piece, to: Cell): IllegalReason {
  const delta = sub(to, piece.cell);
  const occupant = occupantAt(occ, to);
  const blocked = targetBlockReason(occupant, piece);

  switch (piece.type) {
    case 'P': {
      const forward = rotate(DIR.N, piece.owner);
      const backward = rotate(DIR.S, piece.owner);
      const straight = [forward, backward].some((d) => sameCell(d, delta));
      const diagonal = [DIR.NE, DIR.NW, DIR.SE, DIR.SW].some((d) => sameCell(rotate(d, piece.owner), delta));
      if (straight) return blocked ?? 'PAWN_CAPTURE_STRAIGHT'; // đích có địch: Tốt không ăn thẳng
      if (diagonal) return blocked ?? 'PAWN_DIAGONAL_NEEDS_CAPTURE'; // đích trống: chỉ đi chéo để ăn
      const far = multipleOf(delta, forward) ?? multipleOf(delta, backward);
      if (far !== undefined) return 'OUT_OF_RANGE'; // R-22: không đi 2 ô
      return 'BAD_DIRECTION';
    }
    case 'N': {
      if (!KNIGHT_JUMPS.some((j) => sameCell(j, delta))) return 'BAD_DIRECTION';
      return blocked ?? 'NOT_ALLOWED';
    }
    case 'K': {
      if ([...E_DIRS, ...V_DIRS].some((d) => sameCell(d, delta))) return blocked ?? 'NOT_ALLOWED';
      return findRay(delta, ALL_RAYS) !== undefined ? 'OUT_OF_RANGE' : 'BAD_DIRECTION';
    }
    default: {
      const type = piece.type;
      const hit = findRay(delta, RAYS_OF[type]);
      if (hit === undefined) return 'BAD_DIRECTION';
      if (hit.k > maxSteps(type, hit.ray.kind, state.config)) return 'OUT_OF_RANGE';
      for (let j = 1; j < hit.k; j++) {
        if (occupantAt(occ, add(piece.cell, hit.ray.dir, j)) !== undefined) return 'PATH_BLOCKED'; // R-20
      }
      if (blocked !== undefined) return blocked;
      if (type === 'J' && hasEnemy(occupant, piece.owner)) return 'JESTER_CANNOT_CAPTURE'; // R-50
      return 'NOT_ALLOWED';
    }
  }
}
