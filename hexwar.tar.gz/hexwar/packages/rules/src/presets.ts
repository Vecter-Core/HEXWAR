// X-09 (PLAN mục 5, Phụ lục C `presets`): Cổ điển / Tiêu chuẩn / Nhanh chỉ đổi NHỊP TRẬN — đồng hồ lượt (R-12) và
// lịch thu hẹp co giãn theo `roundScale` — không đổi bất kỳ luật nào khác (đội hình, nước đi, tù binh, phong cấp,
// điểm...). Việc này từng bị hoãn ở M2 ("chưa có gì cần nó", xem docs/decisions.md) vì lúc đó chưa có nơi nào gọi;
// M6 cần nó thật để phòng/ghép trận cho chọn preset (PLAN 7.2), nên làm ở đây thay vì đợi M9.
import { collapseSchedule } from './collapse';
import { configWith, defaultConfig, type RulesConfig } from './config';

export const PRESET_NAMES = ['classic', 'standard', 'blitz'] as const;
export type PresetName = (typeof PRESET_NAMES)[number];

const baseSchedule = collapseSchedule(defaultConfig.board.radius, defaultConfig.collapse);
const BASE_LAST_ROUND = baseSchedule[baseSchedule.length - 1]?.round ?? 0;
/** Khoảng đệm giữa hiệp thu hẹp cuối và hiệp giới hạn cứng trong cấu hình gốc (450 − 430 = 20), co giãn theo preset. */
const BASE_HARD_CAP_BUFFER = defaultConfig.collapse.hardCapRound - BASE_LAST_ROUND;

/** Nhân một hiệp theo `roundScale`, ép tăng chặt so với `minAfter` — `round()` đơn thuần có thể trùng số ở thang nhỏ. */
function scaleRound(round: number, scale: number, minAfter: number): number {
  return Math.max(minAfter, Math.round(round * scale));
}

/**
 * Áp một preset X-09 lên `base` (mặc định `defaultConfig`). `roundScale = 1` (Cổ điển) chỉ đổi đồng hồ lượt, không
 * đụng gì tới lịch thu hẹp (tránh làm tròn vô ích trên cấu hình vốn đã đúng). Kết quả luôn qua `configWith`, tức
 * được kiểm lại bằng đúng schema — kể cả bất biến "hardCapRound sau hiệp thu hẹp cuối" (M1).
 */
export function applyPreset(name: PresetName, base: RulesConfig = defaultConfig): RulesConfig {
  const preset = base.presets[name];
  if (preset.roundScale === 1) return configWith({ turn: { seconds: preset.seconds } });

  let prev = 0;
  const rounds = base.collapse.rounds.map((r) => {
    prev = scaleRound(r, preset.roundScale, prev + 1);
    return prev;
  });
  const firstRound = scaleRound(base.collapse.extension.firstRound, preset.roundScale, prev + 1);
  const every = Math.max(1, Math.round(base.collapse.extension.every * preset.roundScale));

  const scaledSchedule = collapseSchedule(base.board.radius, {
    rounds,
    extension: { ...base.collapse.extension, firstRound, every },
  });
  const lastRound = scaledSchedule[scaledSchedule.length - 1]?.round ?? firstRound;
  const hardCapRound = lastRound + Math.max(1, Math.round(BASE_HARD_CAP_BUFFER * preset.roundScale));

  return configWith({
    turn: { seconds: preset.seconds },
    collapse: { rounds, extension: { firstRound, every }, hardCapRound },
  });
}
