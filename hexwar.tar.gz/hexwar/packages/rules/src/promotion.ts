// Phong cấp Tốt theo số kill. Nguồn: PLAN.md R-41, R-42, D-05.
import { emit, getPiece, replacePiece, type Draft } from './draft';
import type { Piece, PieceType } from './types';

const LADDER: readonly PieceType[] = ['P', 'N', 'B', 'R', 'Q'];

/**
 * R-41: chỉ quân có nguồn gốc Tốt được phong cấp: 6 kill → Mã, 10 → Tượng, 15 → Xe, 20 → Hậu (Hậu là bậc cuối).
 * Phong xảy ra ngay sau nước ăn, tại chỗ, cùng lượt. `promotion.cumulativeKills` (D-05): true thì `kills` giữ
 * nguyên qua các lần phong; false thì đặt lại về 0 sau mỗi lần phong.
 * R-42: quân đã phong tuân theo luật đi của loại mới (moves.ts đọc `type`).
 */
export function promoteIfReady(d: Draft, pieceId: string): void {
  let piece = getPiece(d, pieceId);
  if (piece.origin !== 'P') return;
  for (;;) {
    const index = LADDER.indexOf(piece.type);
    const next = LADDER[index + 1] as 'N' | 'B' | 'R' | 'Q' | undefined;
    if (index < 0 || next === undefined) return;
    if (piece.kills < d.config.promotion[next]) return;

    const promoted: Piece = { ...piece, type: next, kills: d.config.promotion.cumulativeKills ? piece.kills : 0 };
    replacePiece(d, promoted);
    emit(d, { type: 'PROMOTED', pieceId: piece.id, owner: piece.owner, from: piece.type, to: next, kills: piece.kills });
    piece = promoted;
  }
}
