// Bộ sinh số ngẫu nhiên có seed (mulberry32). Engine tuyệt đối không dùng Math.random (PLAN 6.1).
// Cùng seed cho ra cùng dãy số trên mọi máy: nền tảng của replay (X-11) và test tất định.

export interface Rng {
  /** Số thực trong [0, 1). */
  next(): number;
  /** Số nguyên trong [0, maxExclusive). */
  int(maxExclusive: number): number;
}

export function createRng(seed: number): Rng {
  let a = seed >>> 0;
  const next = (): number => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
  return {
    next,
    int(maxExclusive: number): number {
      if (!Number.isInteger(maxExclusive) || maxExclusive < 1) {
        throw new RangeError(`Rng.int: maxExclusive phải là số nguyên ≥ 1 (nhận được ${maxExclusive})`);
      }
      return Math.floor(next() * maxExclusive);
    },
  };
}
