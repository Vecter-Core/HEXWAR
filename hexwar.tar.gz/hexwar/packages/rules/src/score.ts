// Điểm và xếp hạng. Nguồn: PLAN.md R-82.
import type { GameState, RankEntry, Seat } from './types';

/** Phần trạng thái đủ để tính điểm (dùng được cả cho bản nháp nội bộ). */
export type ScoreView = Pick<GameState, 'config' | 'pieces' | 'playerKills'>;
export type RankView = Pick<GameState, 'config' | 'pieces' | 'playerKills' | 'eliminated' | 'order'>;

/**
 * R-82: điểm = tổng giá trị quân còn lại + tổng kill (giá trị: P=1, N=3, B=3, R=5, Q=9, J=2, K=0).
 * Tù binh vẫn tính là quân của chủ cũ cho tới khi bị loại (R-31).
 */
export function scoreOf(state: ScoreView, seat: Seat): number {
  let total = 0;
  for (const piece of state.pieces) {
    if (piece.owner === seat) total += state.config.score[piece.type];
  }
  return total + (state.playerKills[seat] ?? 0) * state.config.score.perKill;
}

interface Row {
  readonly entry: Omit<RankEntry, 'rank'>;
  /** Thời điểm bị loại (batch); Infinity nếu còn sống. */
  readonly batch: number;
}

function compare(a: Row, b: Row): number {
  if (a.entry.alive !== b.entry.alive) return a.entry.alive ? -1 : 1; // người còn sống xếp trên
  if (!a.entry.alive && a.batch !== b.batch) return b.batch - a.batch; // bị loại muộn hơn xếp cao hơn
  if (a.entry.score !== b.entry.score) return b.entry.score - a.entry.score; // điểm cao hơn xếp trên
  return a.entry.seat - b.entry.seat; // chỉ để thứ tự hiển thị ổn định; không đổi hạng
}

function tied(a: Row, b: Row): boolean {
  return a.entry.alive === b.entry.alive && a.batch === b.batch && a.entry.score === b.entry.score;
}

/**
 * R-82: xếp hạng mọi ghế. Người còn sống xếp trên người bị loại. Giữa người còn sống: điểm cao hơn xếp trên.
 * Giữa người bị loại: bị loại muộn hơn xếp cao hơn; cùng lúc thì so điểm tại thời điểm đó.
 * Đồng hạng chia sẻ cùng số hạng (1, 2, 2, 4).
 */
export function rankPlayers(state: RankView): RankEntry[] {
  const rows: Row[] = state.order.map((seat) => {
    const elimination = state.eliminated.find((e) => e.seat === seat);
    return {
      batch: elimination?.batch ?? Number.POSITIVE_INFINITY,
      entry: {
        seat,
        alive: elimination === undefined,
        score: elimination !== undefined ? elimination.score : scoreOf(state, seat),
        kills: state.playerKills[seat] ?? 0,
        pieces: state.pieces.filter((p) => p.owner === seat).length,
        eliminatedRound: elimination?.round ?? null,
      },
    };
  });
  rows.sort(compare);

  const ranked: RankEntry[] = [];
  let firstOfTie = 0;
  rows.forEach((row, index) => {
    const head = rows[firstOfTie] as Row;
    if (index > 0 && !tied(head, row)) firstOfTie = index;
    ranked.push({ ...row.entry, rank: firstOfTie + 1 });
  });
  return ranked;
}
