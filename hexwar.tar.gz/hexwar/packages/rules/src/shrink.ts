// Áp dụng thu hẹp bàn cờ lên trạng thái. Nguồn: PLAN.md R-70, R-71, R-72, D-08, D-09.
// (Lịch thu hẹp thuần dữ liệu nằm ở collapse.ts.)
import { findRevivingJester, reviveKing } from './captives';
import { collapseSchedule, type CollapseEvent } from './collapse';
import type { RulesConfig } from './config';
import { eliminatePlayer, emit, isAlive, nextBatch, removePieces, type Draft } from './draft';
import { ring } from './hex';
import { scoreOf } from './score';
import type { GameState, Piece } from './types';

const scheduleCache = new WeakMap<RulesConfig, readonly CollapseEvent[]>();

/** Lịch thu hẹp đầy đủ của một cấu hình (gồm phần kéo dài D-07 nếu bật). Có nhớ đệm theo đối tượng cấu hình. */
export function scheduleOf(config: RulesConfig): readonly CollapseEvent[] {
  let schedule = scheduleCache.get(config);
  if (schedule === undefined) {
    schedule = collapseSchedule(config.board.radius, config.collapse);
    scheduleCache.set(config, schedule);
  }
  return schedule;
}

/** Sự kiện thu hẹp xảy ra ở đầu hiệp `round` (nếu có). D-08. */
export function collapseEventAt(config: RulesConfig, round: number): CollapseEvent | undefined {
  return scheduleOf(config).find((event) => event.round === round);
}

export type WarningLevel = 'yellow' | 'red';

export interface UpcomingCollapse {
  readonly event: CollapseEvent;
  /** Còn bao nhiêu hiệp nữa thì vòng biến mất (≥ 1). */
  readonly roundsLeft: number;
  /** null = chưa tới ngưỡng cảnh báo. */
  readonly level: WarningLevel | null;
}

/**
 * R-71: các lần thu hẹp sắp tới kèm mức cảnh báo, gần nhất trước. `yellowRoundsBefore` hiệp trước: vàng;
 * `redRoundsBefore` hiệp trước: đỏ. Dùng cho HUD (đếm ngược) và cho sự kiện RING_WARNING.
 */
export function upcomingCollapses(state: Pick<GameState, 'config' | 'round'>): UpcomingCollapse[] {
  const { yellowRoundsBefore, redRoundsBefore } = state.config.collapse.warn;
  return scheduleOf(state.config)
    .filter((event) => event.round > state.round)
    .map((event) => {
      const roundsLeft = event.round - state.round;
      const level: WarningLevel | null = roundsLeft <= redRoundsBefore ? 'red' : roundsLeft <= yellowRoundsBefore ? 'yellow' : null;
      return { event, roundsLeft, level };
    });
}

/** Lần thu hẹp kế tiếp (bất kể đã tới ngưỡng cảnh báo hay chưa); undefined nếu lịch đã hết. */
export function nextCollapse(state: Pick<GameState, 'config' | 'round'>): UpcomingCollapse | undefined {
  return upcomingCollapses(state)[0];
}

/** R-71: phát RING_WARNING cho mọi vòng đã vào ngưỡng cảnh báo ở đầu hiệp hiện tại. */
export function announceWarnings(d: Draft): void {
  for (const { event, roundsLeft, level } of upcomingCollapses(d)) {
    if (level !== null) emit(d, { type: 'RING_WARNING', ring: event.ring, roundsLeft, level });
  }
}

/**
 * R-70: vòng ngoài cùng hiện tại biến mất. Mọi quân trên các ô đó (kể cả tù binh) bị loại và KHÔNG ai được kill.
 * Vua nằm trên vòng biến mất thì người đó bị loại, Hề không cứu (D-09) trừ khi `jester.savesFromCollapse` bật.
 * Những người bị loại trong cùng đợt thu hẹp dùng chung một `batch` (R-72, R-82).
 *
 * Thứ tự: (1) Hề cứu Vua nếu được phép; (2) xoá quân trên vòng và giảm bán kính (để tù binh được thả ở bước 3
 * đặt vào ô còn tồn tại, R-35); (3) loại người có Vua vừa biến mất.
 */
export function applyCollapse(d: Draft): void {
  const vanishing = d.radius;
  if (vanishing <= 0) return;
  const newRadius = vanishing - 1;
  const beyond = (piece: Piece): boolean => ring(piece.cell) > newRadius;

  if (d.config.jester.savesFromCollapse) {
    for (const king of d.pieces.filter((p) => p.type === 'K' && beyond(p))) {
      const jester = findRevivingJester(d, king);
      if (jester !== undefined && !beyond(jester)) reviveKing(d, king, jester, 'collapse');
    }
  }

  const removed = d.pieces.filter(beyond);
  removePieces(d, new Set(removed.map((p) => p.id)));
  d.radius = newRadius;
  emit(d, { type: 'RING_COLLAPSED', round: d.round, ring: vanishing, radius: newRadius, removedPieceIds: removed.map((p) => p.id) });

  const doomed = d.order.filter((seat) => isAlive(d, seat) && removed.some((p) => p.type === 'K' && p.owner === seat));
  if (doomed.length === 0) return;
  const batch = nextBatch(d);
  const scores = doomed.map((seat) => scoreOf(d, seat)); // chụp điểm trước khi loại bất kỳ ai trong đợt (phòng thủ, xem draft.ts)
  doomed.forEach((seat, index) => eliminatePlayer(d, seat, 'collapse', batch, scores[index]));
}
