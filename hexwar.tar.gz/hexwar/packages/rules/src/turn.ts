// Lượt, hiệp, hết giờ, đầu hàng. Nguồn: PLAN.md R-10…R-14, R-33, R-61, R-80, R-81 và mục 4.10.
//
// Thứ tự xử lý một lượt (4.10):
//   1 kiểm tra hợp lệ → 2 di chuyển/ăn → 3 kill + phong cấp → 4 cuối lượt (tù binh) → 5 hết ván? →
//   6 chuyển lượt (round += 1 khi quay về người mở hiệp) → 7 thu hẹp nếu hiệp mới nằm trong lịch → 8 lượt kế bắt đầu.
import { finishTurnCaptives, performConscriptMove, performNormalMove } from './captives';
import {
  checkGameOver,
  eliminatePlayer,
  emit,
  finishGame,
  getPiece,
  isAlive,
  nextAliveAfter,
  nextBatch,
  snapshot,
  toDraft,
  type Draft,
} from './draft';
import type { ActionResult } from './events';
import { cell } from './hex';
import { legalMoves, explainIllegal } from './moves';
import { announceWarnings, applyCollapse, collapseEventAt } from './shrink';
import type { GameState, IllegalReason, Move, Seat } from './types';

/** Hành động bị từ chối. `reason` là mã để UI dịch (PLAN 10.1) và để server trả `game.rejected`. */
export class IllegalMoveError extends Error {
  readonly reason: IllegalReason;

  constructor(reason: IllegalReason) {
    super(`Hành động không hợp lệ: ${reason}`);
    this.name = 'IllegalMoveError';
    this.reason = reason;
  }
}

/**
 * Bước 1 của 4.10: `null` nếu `seat` được phép đi `move` ngay bây giờ, ngược lại là mã lý do.
 * Thêm các kiểm tra cấp ván/lượt/quyền sở hữu lên trên `explainIllegal` (vốn chỉ xét luật của quân).
 * Bất biến (có test): khi `seat` là người tới lượt, `checkMove(...) === null` ⇔ move ∈ `legalMoves(state, seat)`.
 */
export function checkMove(state: GameState, seat: Seat, move: Move): IllegalReason | null {
  if (state.phase !== 'playing' || state.turnSeat === null) return 'GAME_NOT_PLAYING';
  if (seat !== state.turnSeat) return 'NOT_YOUR_TURN';
  const piece = state.pieces.find((p) => p.id === move.pieceId);
  if (piece !== undefined) {
    // R-11: chỉ đi quân của mình, hoặc trưng dụng tù binh do mình giữ (R-32).
    const foreign = move.conscript === true ? piece.status === 'captive' && piece.holder !== seat : piece.owner !== seat;
    if (foreign) return 'NOT_YOUR_PIECE';
  }
  return explainIllegal(state, move);
}

// ---- Bắt đầu hiệp / lượt ---------------------------------------------------------------------------------------

/**
 * Bắt đầu hiệp `round` (D-08): thu hẹp nếu nằm trong lịch (R-70), rồi kiểm tra hết ván (bước 5 làm lại),
 * hiệp giới hạn cứng (R-81) và phát cảnh báo (R-71). Trả về false nếu ván đã kết thúc.
 */
function startRound(d: Draft, round: number): boolean {
  d.round = round;
  emit(d, { type: 'ROUND_STARTED', round });
  if (collapseEventAt(d.config, round) !== undefined) applyCollapse(d);
  if (checkGameOver(d)) return false;
  if (round >= d.config.collapse.hardCapRound) {
    finishGame(d, 'hardCap');
    return false;
  }
  announceWarnings(d);
  return true;
}

/** R-13: người chơi có ít nhất một nước đi (kể cả trưng dụng tù binh) không? */
function hasLegalMove(d: Draft, seat: Seat): boolean {
  return legalMoves(snapshot(d), seat).length > 0;
}

/**
 * Bước 8: lượt của `seat` bắt đầu. Trả về true nếu họ có nước để đi; false nếu lượt tự bỏ vì không có nước
 * hợp lệ (R-13). Lượt bị bỏ vẫn là một lượt: tù binh tới hạn của họ bị loại (R-33).
 */
function beginTurn(d: Draft, seat: Seat): boolean {
  d.turnSeat = seat;
  emit(d, { type: 'TURN_STARTED', seat, round: d.round });
  if (hasLegalMove(d, seat)) return true;
  emit(d, { type: 'TURN_SKIPPED', seat, reason: 'no_moves' });
  finishTurnCaptives(d, seat);
  return false;
}

/** true nếu đi từ `from` tới `to` (người còn sống kế tiếp) thì vượt qua vị trí của người mở hiệp `opener`. */
function crossesOpener(d: Draft, from: Seat, to: Seat, opener: Seat): boolean {
  const n = d.order.length;
  const fromIndex = d.order.indexOf(from);
  const toNext = (d.order.indexOf(to) - fromIndex + n) % n || n;
  const toOpener = (d.order.indexOf(opener) - fromIndex + n) % n || n;
  return toOpener <= toNext;
}

/**
 * Bước 6–8: chuyển lượt cho người còn sống kế tiếp sau `from`. Quay về người mở hiệp thì sang hiệp mới (R-10).
 *
 * `opener` là người mở hiệp TẠI THỜI ĐIỂM BẮT ĐẦU hành động, không phải `d.opener` hiện tại: nếu người mở hiệp
 * vừa tự đầu hàng ở lượt của mình thì lượt kế KHÔNG phải hiệp mới (những người sau còn chưa đi trong hiệp này);
 * `d.opener` (đã chuyển cho người còn sống kế tiếp, R-10) chỉ có hiệu lực từ hiệp sau.
 */
function advanceTurn(d: Draft, from: Seat, opener: Seat): void {
  let current = from;
  let reference = opener;
  const limit = d.order.length * (d.config.collapse.hardCapRound + 2); // hiệp giới hạn cứng chặn vòng lặp (R-81)
  for (let step = 0; step < limit; step++) {
    const next = nextAliveAfter(d, current);
    if (next === undefined) return; // không còn ai: checkGameOver đã kết thúc ván trước đó
    let seat = next;
    if (crossesOpener(d, current, next, reference)) {
      if (!startRound(d, d.round + 1)) return;
      seat = d.opener ?? next; // người mở hiệp có thể đã đổi nếu thu hẹp loại người mở hiệp cũ (R-10)
      reference = seat;
    }
    if (beginTurn(d, seat)) return;
    current = seat;
  }
  throw new Error('advanceTurn: vượt giới hạn tự động bỏ lượt (lỗi engine)');
}

/** Bước 4–8 sau khi người `mover` đã hoàn tất phần hành động của lượt (đi quân hoặc hết giờ). */
function settleTurn(d: Draft, mover: Seat, opener: Seat | null): ActionResult {
  finishTurnCaptives(d, mover); // bước 4, R-33
  if (!checkGameOver(d)) advanceTurn(d, mover, opener ?? mover); // bước 5–8
  return { state: snapshot(d), events: d.events };
}

/** Vào pha chơi: hiệp 1 bắt đầu ở lượt đầu tiên của người thắng xúc xắc (R-10). `d.order` đã được xoay (R-03). */
export function beginPlay(d: Draft): void {
  const first = d.order[0];
  if (first === undefined) throw new Error('beginPlay: ván không có người chơi');
  d.phase = 'playing';
  d.opener = first;
  if (!startRound(d, 1)) return;
  const opener = d.opener ?? first; // thu hẹp ở hiệp 1 (cấu hình lạ) có thể đã đổi người mở hiệp
  if (!beginTurn(d, opener)) advanceTurn(d, opener, opener);
}

// ---- Hành động công khai ------------------------------------------------------------------------------------------

/**
 * Người tới lượt (`state.turnSeat`) đi một nước. Ném `IllegalMoveError` nếu không hợp lệ; server nên gọi
 * `checkMove(state, seatCuaNguoiGui, move)` trước để trả `game.rejected` thay vì bắt ngoại lệ.
 */
export function applyMove(state: GameState, move: Move): ActionResult {
  const seat = state.turnSeat;
  if (state.phase !== 'playing' || seat === null) throw new IllegalMoveError('GAME_NOT_PLAYING');
  const reason = checkMove(state, seat, move);
  if (reason !== null) throw new IllegalMoveError(reason);

  const d = toDraft(state);
  const to = cell(move.to.q, move.to.r); // bản sao chuẩn hoá: không giữ tham chiếu vào đối tượng của người gọi
  const piece = getPiece(d, move.pieceId);
  if (move.conscript === true) performConscriptMove(d, seat, piece, to);
  else performNormalMove(d, seat, piece, to);
  return settleTurn(d, seat, state.opener);
}

/** R-12: hết giờ, lượt bị bỏ qua (không đi). Tù binh tới hạn của người đó vẫn bị loại cuối lượt (R-33). */
export function timeoutTurn(state: GameState): ActionResult {
  const seat = state.turnSeat;
  if (state.phase !== 'playing' || seat === null) throw new IllegalMoveError('GAME_NOT_PLAYING');
  const d = toDraft(state);
  emit(d, { type: 'TURN_SKIPPED', seat, reason: 'timeout' });
  return settleTurn(d, seat, state.opener);
}

/**
 * R-61, X-05: `seat` đầu hàng, bị loại như khi mất Vua (R-60). Có thể xảy ra ngoài lượt của họ. Nếu đang là lượt
 * của họ thì lượt chuyển tiếp ngay.
 */
export function resign(state: GameState, seat: Seat): ActionResult {
  if (state.phase !== 'playing') throw new IllegalMoveError('GAME_NOT_PLAYING');
  const d = toDraft(state);
  if (!isAlive(d, seat)) throw new IllegalMoveError('NOT_IN_GAME');
  eliminatePlayer(d, seat, 'resign', nextBatch(d));
  if (!checkGameOver(d) && state.turnSeat === seat) advanceTurn(d, seat, state.opener ?? seat);
  return { state: snapshot(d), events: d.events };
}
