// Kiểu dữ liệu của engine. Nguồn: PLAN.md mục 6.5 (có bổ sung, xem docs/decisions.md).
import type { RulesConfig } from './config';
import type { Cell } from './hex';

export type Seat = 0 | 1 | 2 | 3 | 4 | 5;
export type PieceType = 'P' | 'N' | 'B' | 'R' | 'Q' | 'K' | 'J';

export interface Piece {
  readonly id: string;
  readonly owner: Seat;
  readonly type: PieceType;
  /** 'P' nếu xuất thân là Tốt (chỉ quân này được phong cấp, R-41). */
  readonly origin: PieceType;
  readonly cell: Cell;
  readonly kills: number;
  readonly status: 'active' | 'captive';
  /** Người đang giữ tù binh (chỉ có khi status = 'captive'). */
  readonly holder?: Seat;
  /** true: tới lượt kế tiếp của holder thì có thể trưng dụng, và bị loại khi hết lượt đó (R-32, R-33). */
  readonly armed?: boolean;
}

export type Phase = 'dice' | 'playing' | 'over';

export interface Elimination {
  readonly seat: Seat;
  readonly round: number;
  readonly reason: 'king' | 'collapse' | 'resign';
  /** Cùng `batch` = bị loại cùng một khoảnh khắc (R-82). Tăng dần theo thời gian. */
  readonly batch: number;
  /** Điểm (R-82) ngay trước khi bị loại, để xếp hạng khi bị loại cùng lúc. */
  readonly score: number;
}

export type GameOverReason = 'lastKing' | 'allEliminated' | 'hardCap';

export interface RankEntry {
  readonly seat: Seat;
  /** Hạng 1..6; đồng hạng chia sẻ cùng số (1, 2, 2, 4...). */
  readonly rank: number;
  readonly alive: boolean;
  readonly score: number;
  /** Tổng số quân địch đã ăn (kể cả nước ăn bằng tù binh trưng dụng). */
  readonly kills: number;
  readonly pieces: number;
  readonly eliminatedRound: number | null;
}

export interface GameResult {
  readonly reason: GameOverReason;
  /** null = hoà (R-72) hoặc đồng hạng nhất khi hết hiệp giới hạn cứng. */
  readonly winner: Seat | null;
  readonly ranking: readonly RankEntry[];
}

export interface GameState {
  readonly rulesVersion: string;
  readonly config: RulesConfig;
  readonly seed: number;
  readonly phase: Phase;
  /** 0 trước khi tung xúc xắc; hiệp 1 bắt đầu ở lượt đầu tiên (R-10). */
  readonly round: number;
  /**
   * Các ghế tham gia theo thứ tự đi (chiều kim đồng hồ). Trước khi tung xúc xắc là thứ tự tăng dần theo
   * số ghế; `rollDice` xoay để người thắng đứng đầu (R-03). Người bị loại vẫn nằm trong mảng.
   */
  readonly order: readonly Seat[];
  /** Người mở hiệp (R-10). null cho tới khi tung xúc xắc. */
  readonly opener: Seat | null;
  /** Người đang tới lượt. null trước khi tung xúc xắc và sau khi ván kết thúc. */
  readonly turnSeat: Seat | null;
  readonly pieces: readonly Piece[];
  /** Bán kính bàn cờ hiện tại (giảm dần theo lịch thu hẹp). */
  readonly radius: number;
  /** Theo thứ tự thời gian. */
  readonly eliminated: readonly Elimination[];
  /** Số quân địch mỗi ghế đã ăn, chỉ số theo ghế (R-40, R-82). */
  readonly playerKills: readonly number[];
  /** Có khi phase = 'over'. */
  readonly result?: GameResult;
}

export interface Move {
  readonly pieceId: string;
  readonly to: Cell;
  /** true: trưng dụng tù binh của mình (R-32). */
  readonly conscript?: boolean;
}

/**
 * Mã lý do một nước đi không hợp lệ (UI dịch qua i18n, PLAN.md mục 10.1).
 * `NOT_ALLOWED` chỉ là lưới an toàn: test khẳng định nó không bao giờ xuất hiện.
 */
export type IllegalReason =
  // Cấp ván / lượt (chỉ `checkMove`)
  | 'GAME_NOT_PLAYING'
  | 'NOT_IN_GAME'
  | 'NOT_YOUR_TURN'
  | 'NOT_YOUR_PIECE'
  // Cấp quân (`explainIllegal`)
  | 'UNKNOWN_PIECE'
  | 'PIECE_IS_CAPTIVE'
  | 'NOT_A_CAPTIVE'
  | 'CONSCRIPT_DISABLED'
  | 'CAPTIVE_NOT_READY'
  // Hình học và luật từng quân
  | 'TARGET_OFF_BOARD'
  | 'SAME_CELL'
  | 'BAD_DIRECTION'
  | 'OUT_OF_RANGE'
  | 'PATH_BLOCKED'
  | 'TARGET_OWN_PIECE'
  | 'TARGET_BLOCKED'
  | 'PAWN_CAPTURE_STRAIGHT'
  | 'PAWN_DIAGONAL_NEEDS_CAPTURE'
  | 'JESTER_CANNOT_CAPTURE'
  | 'NOT_ALLOWED';
