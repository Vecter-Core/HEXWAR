// Kiểm tra bất biến của trạng thái (PLAN.md mục 14: "Thuộc tính"). Dùng trong test, mô phỏng và (tuỳ chọn) server
// ở chế độ gỡ lỗi. Không phải một phần của luật: nó chỉ khẳng định các hành động của engine không bao giờ tạo ra
// trạng thái vô lý.
import { cellKey, isOnBoard } from './hex';
import type { GameState, Seat } from './types';

export interface ValidateOptions {
  /**
   * true (mặc định): mỗi người còn sống có đúng một Vua hoạt động. Đặt false cho thế cờ dựng tay trong test
   * (`makeState`) không có đủ Vua.
   */
  readonly requireKings?: boolean;
}

/** Trả về danh sách vi phạm (rỗng = hợp lệ). */
export function validateState(state: GameState, options: ValidateOptions = {}): string[] {
  const requireKings = options.requireKings ?? true;
  const problems: string[] = [];
  const fail = (message: string): void => {
    problems.push(message);
  };

  // ---- Người chơi -------------------------------------------------------------------------------------------
  const order = state.order;
  if (new Set(order).size !== order.length) fail(`order có ghế trùng: [${order.join(',')}]`);
  const eliminatedSeats = state.eliminated.map((e) => e.seat);
  if (new Set(eliminatedSeats).size !== eliminatedSeats.length) fail('một ghế bị loại hai lần');
  for (const e of state.eliminated) {
    if (!order.includes(e.seat)) fail(`ghế bị loại ${e.seat} không nằm trong order`);
  }
  for (let i = 1; i < state.eliminated.length; i++) {
    if ((state.eliminated[i] as { batch: number }).batch < (state.eliminated[i - 1] as { batch: number }).batch) {
      fail('batch bị loại không tăng dần theo thời gian');
    }
  }
  const alive: Seat[] = order.filter((seat) => !eliminatedSeats.includes(seat));
  const isAliveSeat = (seat: Seat | undefined): boolean => seat !== undefined && alive.includes(seat);

  if (state.playerKills.some((k) => !Number.isInteger(k) || k < 0)) fail('playerKills có số không hợp lệ');

  // ---- Pha ván --------------------------------------------------------------------------------------------------
  if (state.phase === 'playing') {
    if (state.round < 1) fail(`đang chơi nhưng round = ${state.round}`);
    if (alive.length < 2) fail(`đang chơi nhưng chỉ còn ${alive.length} người sống`);
    if (state.turnSeat === null || !isAliveSeat(state.turnSeat)) fail(`turnSeat ${String(state.turnSeat)} không phải người còn sống`);
    if (state.opener === null || !isAliveSeat(state.opener)) fail(`opener ${String(state.opener)} không phải người còn sống`);
    if (state.result !== undefined) fail('đang chơi nhưng đã có result');
  } else if (state.phase === 'over') {
    if (state.result === undefined) fail('ván đã kết thúc nhưng không có result');
    if (state.turnSeat !== null) fail('ván đã kết thúc nhưng turnSeat khác null');
  } else if (state.round !== 0) {
    fail(`pha xúc xắc nhưng round = ${state.round}`);
  }

  // ---- Quân ---------------------------------------------------------------------------------------------------------
  const ids = new Set<string>();
  const activeAt = new Map<number, (typeof state.pieces)[number]>();
  for (const piece of state.pieces) {
    if (ids.has(piece.id)) fail(`id quân trùng: ${piece.id}`);
    ids.add(piece.id);
    if (!isOnBoard(piece.cell, state.radius)) fail(`${piece.id} ở (${piece.cell.q},${piece.cell.r}) ngoài bàn bán kính ${state.radius}`);
    if (!order.includes(piece.owner)) fail(`${piece.id} thuộc ghế ${piece.owner} không nằm trong order`);
    if (eliminatedSeats.includes(piece.owner)) fail(`${piece.id} vẫn còn dù chủ (ghế ${piece.owner}) đã bị loại`);
    if (!Number.isInteger(piece.kills) || piece.kills < 0) fail(`${piece.id} có kills = ${piece.kills}`);

    if (piece.type !== piece.origin && !(piece.origin === 'P' && ['N', 'B', 'R', 'Q'].includes(piece.type))) {
      fail(`${piece.id} đổi loại ${piece.origin} → ${piece.type} (chỉ Tốt được phong cấp, R-41)`);
    }

    if (piece.status === 'active') {
      if (piece.holder !== undefined || piece.armed !== undefined) fail(`${piece.id} hoạt động nhưng còn holder/armed`);
      const key = cellKey(piece.cell);
      if (activeAt.has(key)) fail(`hai quân hoạt động cùng ô (${piece.cell.q},${piece.cell.r})`);
      activeAt.set(key, piece);
    }
  }

  // Kill: `playerKills` chỉ tăng cùng lúc với `kills` của quân (hoặc một mình khi trưng dụng tù binh, R-40),
  // nên tổng kill của các quân còn lại của một ghế không thể vượt kill của ghế đó.
  for (const seat of order) {
    const sum = state.pieces.filter((p) => p.owner === seat).reduce((total, p) => total + p.kills, 0);
    if (sum > (state.playerKills[seat] ?? 0)) fail(`ghế ${seat}: tổng kills của quân (${sum}) vượt playerKills (${state.playerKills[seat] ?? 0})`);
  }

  // Tù binh: ở ô có quân hoạt động của người giữ (PLAN 14). Kiểm sau khi đã dựng `activeAt`.
  for (const piece of state.pieces) {
    if (piece.status !== 'captive') continue;
    if (piece.type === 'K') fail(`${piece.id}: Vua không bao giờ là tù binh (R-37)`);
    if (piece.holder === undefined) {
      fail(`${piece.id} là tù binh nhưng không có holder`);
      continue;
    }
    if (typeof piece.armed !== 'boolean') fail(`${piece.id} là tù binh nhưng armed không phải boolean`);
    if (piece.holder === piece.owner) fail(`${piece.id} là tù binh của chính chủ`);
    if (!isAliveSeat(piece.holder)) fail(`${piece.id} do ghế ${piece.holder} giữ, nhưng người đó không còn sống`);
    const guard = activeAt.get(cellKey(piece.cell));
    if (guard === undefined || guard.owner !== piece.holder) {
      fail(`${piece.id} (tù binh của ghế ${piece.holder}) ở (${piece.cell.q},${piece.cell.r}) không có quân của người giữ đứng cùng ô`);
    }
  }

  // ---- Vua -------------------------------------------------------------------------------------------------------
  if (requireKings) {
    for (const seat of alive) {
      const kings = state.pieces.filter((p) => p.owner === seat && p.type === 'K' && p.status === 'active').length;
      if (kings !== 1) fail(`ghế ${seat} còn sống nhưng có ${kings} Vua hoạt động`);
    }
  }

  return problems;
}

/** Như `validateState` nhưng ném lỗi liệt kê mọi vi phạm. */
export function assertValidState(state: GameState, options: ValidateOptions = {}): void {
  const problems = validateState(state, options);
  if (problems.length > 0) throw new Error(`Trạng thái vi phạm bất biến:\n- ${problems.join('\n- ')}`);
}
