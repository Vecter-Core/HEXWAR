// Bàn cờ, đội hình 18 quân, newGame. Ghi chú [verify #n] trỏ tới tools/verify_board.py.
import { describe, expect, it } from 'vitest';
import {
  SEATS,
  assertValidLayout,
  colorOf,
  configWith,
  defaultConfig,
  dist,
  formationSlots,
  initialPieces,
  makeState,
  newGame,
  ring,
  type Piece,
  type PieceType,
  type Seat,
} from '../src';
import { P, k } from './helpers';

const state = newGame(defaultConfig, SEATS, 12345);
const piecesOf = (seat: Seat): Piece[] => state.pieces.filter((p) => p.owner === seat);
const countBy = (pieces: readonly Piece[]): Record<string, number> => {
  const out: Record<string, number> = {};
  for (const p of pieces) out[p.type] = (out[p.type] ?? 0) + 1;
  return out;
};

describe('đội hình của ghế 0 (PLAN 3.4)', () => {
  it('khớp từng ô trong bảng mục 3.4', () => {
    const table: readonly [PieceType, number, number][] = [
      ['Q', -2, 23],
      ['K', 0, 22],
      ['B', 2, 21],
      ['R', -3, 23],
      ['J', -1, 22],
      ['B', 1, 21],
      ['R', 3, 20],
      ['N', -4, 23],
      ['P', -2, 22],
      ['P', 0, 21],
      ['P', 2, 20],
      ['N', 4, 19],
      ['P', -5, 23],
      ['P', -3, 22],
      ['P', -1, 21],
      ['P', 1, 20],
      ['P', 3, 19],
      ['P', 5, 18],
    ];
    const slots = formationSlots(23).map((s) => `${s.type}@${k(s.local)}`);
    // Bảng liệt kê P hàng 4 theo thứ tự trái → phải, N ở hai đầu: đúng thứ tự hàng 4 là N P P P N.
    expect([...slots].sort()).toEqual(table.map(([t, q, r]) => `${t}@${q},${r}`).sort());
  });

  it('[verify #15] mỗi ghế đúng 18 quân', () => {
    expect(formationSlots(23)).toHaveLength(18);
    for (const seat of SEATS) expect(piecesOf(seat)).toHaveLength(18);
  });

  it('[verify #16] 9 tốt, 2 xe, 2 tượng, 2 mã, 1 vua, 1 hậu, 1 hề', () => {
    for (const seat of SEATS) {
      expect(countBy(piecesOf(seat))).toEqual({ P: 9, R: 2, B: 2, N: 2, K: 1, Q: 1, J: 1 });
    }
  });

  it('[verify #17] 18 ô của một ghế đều khác nhau', () => {
    expect(new Set(piecesOf(0).map((p) => k(p.cell))).size).toBe(18);
  });

  it('[verify #18] đội hình nằm gọn trong hạng ≤ 23 (hạng 24 là vòng đệm)', () => {
    expect(Math.max(...piecesOf(0).map((p) => ring(p.cell)))).toBeLessThanOrEqual(23);
  });

  it('mọi quân cùng một hàng cùng màu ô (lý do hai Tượng đứng ở hai hàng khác nhau)', () => {
    const rows = new Map<number, Set<number>>();
    for (const slot of formationSlots(23)) {
      const colors = rows.get(slot.row) ?? new Set<number>();
      colors.add(colorOf(slot.local));
      rows.set(slot.row, colors);
    }
    for (const colors of rows.values()) expect(colors.size).toBe(1);
  });

  it('PLAN 3.5: mỗi ghế có 8 quân ở vòng 23, 7 ở vòng 22, 3 ở vòng 21', () => {
    const byRing: Record<number, number> = {};
    for (const p of piecesOf(0)) byRing[ring(p.cell)] = (byRing[ring(p.cell)] ?? 0) + 1;
    expect(byRing).toEqual({ 23: 8, 22: 7, 21: 3 });
  });
});

describe('toàn bàn 108 quân (PLAN 3.4)', () => {
  it('[verify #19] 108 quân, không ô nào trùng, id duy nhất', () => {
    expect(state.pieces).toHaveLength(108);
    expect(new Set(state.pieces.map((p) => k(p.cell))).size).toBe(108);
    expect(new Set(state.pieces.map((p) => p.id)).size).toBe(108);
  });

  it('[verify #20] không quân nào đứng trên hạng 24 lúc bắt đầu', () => {
    expect(state.pieces.every((p) => ring(p.cell) <= 23)).toBe(true);
  });

  it('id tất định dạng s{ghế}-{loại}{số}, quân sinh ra ở trạng thái mặc định', () => {
    const ids = piecesOf(3).map((p) => p.id);
    expect(ids).toContain('s3-K1');
    expect(ids).toContain('s3-P9');
    expect(ids).toContain('s3-B2');
    for (const p of state.pieces) {
      expect(p.origin).toBe(p.type);
      expect(p.kills).toBe(0);
      expect(p.status).toBe('active');
    }
  });

  it('ghế s là ghế 0 xoay s × 60°', () => {
    const seat0 = piecesOf(0);
    for (const seat of SEATS) {
      const ring0 = seat0.map((p) => p.id.replace('s0-', ''));
      const ringS = piecesOf(seat).map((p) => p.id.replace(`s${seat}-`, ''));
      expect(ringS).toEqual(ring0); // cùng thứ tự đội hình
    }
    expect(k(piecesOf(3).find((p) => p.type === 'K')!.cell)).toBe('0,-22');
  });

  it('[verify #21] hai Tượng của mỗi ghế đứng trên hai màu ô khác nhau', () => {
    for (const seat of SEATS) {
      const colors = piecesOf(seat)
        .filter((p) => p.type === 'B')
        .map((p) => colorOf(p.cell));
      expect(new Set(colors).size).toBe(2);
    }
  });

  it('[verify #22] Hề cách Vua ≤ 5 ô (thực tế 1 ô) nên hồi sinh dùng được từ hiệp 1', () => {
    for (const seat of SEATS) {
      const king = piecesOf(seat).find((p) => p.type === 'K')!;
      const jester = piecesOf(seat).find((p) => p.type === 'J')!;
      expect(dist(king.cell, jester.cell)).toBe(1);
    }
  });

  it('[verify #23-24] khoảng cách gần nhất giữa hai ghế: kề nhau = 13, đối diện = 41, đều nhau', () => {
    const minDist = (a: Seat, b: Seat): number =>
      Math.min(...piecesOf(a).flatMap((x) => piecesOf(b).map((y) => dist(x.cell, y.cell))));
    for (const a of SEATS) {
      expect(minDist(a, ((a + 1) % 6) as Seat)).toBe(13);
      expect(minDist(a, ((a + 3) % 6) as Seat)).toBe(41);
    }
  });
});

describe('newGame (R-01) và makeState', () => {
  it('R-01: ván mới ở pha tung xúc xắc, chưa có người đi', () => {
    expect(state.phase).toBe('dice');
    expect(state.round).toBe(0);
    // M1 để `order` rỗng vì chưa có khái niệm người tham gia; từ M2, `order` = 6 ghế tăng dần cho tới khi `rollDice`
    // xoay nó (R-03), để xếp hạng/kiểm tra bất biến luôn biết ai có mặt.
    expect(state.order).toEqual([0, 1, 2, 3, 4, 5]);
    expect(state.playerKills).toEqual([0, 0, 0, 0, 0, 0]);
    expect(state.opener).toBeNull();
    expect(state.turnSeat).toBeNull();
    expect(state.radius).toBe(24);
    expect(state.seed).toBe(12345);
    expect(state.rulesVersion).toBe('1.0.0');
    expect(state.eliminated).toEqual([]);
  });

  it('R-01: từ chối nếu không đúng 6 ghế, mỗi ghế một lần', () => {
    expect(() => newGame(defaultConfig, [0, 1, 2, 3, 4], 1)).toThrow(/R-01/);
    expect(() => newGame(defaultConfig, [0, 1, 2, 3, 4, 4], 1)).toThrow(/R-01/);
    expect(() => newGame(defaultConfig, [0, 1, 2, 3, 4, 5, 5], 1)).toThrow(/R-01/);
    expect(() => newGame(defaultConfig, [5, 4, 3, 2, 1, 0], 1)).not.toThrow(); // thứ tự truyền vào không quan trọng
  });

  it('tất định: cùng đầu vào cho ra trạng thái giống hệt', () => {
    expect(newGame(defaultConfig, SEATS, 7)).toEqual(newGame(defaultConfig, SEATS, 7));
    expect(initialPieces(defaultConfig)).toEqual(state.pieces);
  });

  it('bán kính bàn lấy từ cấu hình', () => {
    // Bàn lớn hơn kéo dài lịch thu hẹp tới hiệp 450, nên hiệp giới hạn cứng phải dời theo (xem config.test.ts).
    const config = configWith({ board: { radius: 26 }, collapse: { hardCapRound: 500 } });
    expect(newGame(config, SEATS, 1).radius).toBe(26);
  });

  it('makeState và assertValidLayout từ chối id trùng, hai quân hoạt động cùng ô, quân ngoài bàn', () => {
    expect(() => makeState({ pieces: [P('a', 0, 'R', 0, 0), P('a', 1, 'R', 1, 0)] })).toThrow(/id trùng/);
    expect(() => makeState({ pieces: [P('a', 0, 'R', 0, 0), P('b', 1, 'R', 0, 0)] })).toThrow(/cùng ô/);
    expect(() => makeState({ pieces: [P('a', 0, 'R', 0, 25)] })).toThrow(/ngoài bàn/);
    expect(() => makeState({ pieces: [P('a', 0, 'R', 0, 6)], radius: 5 })).toThrow(/ngoài bàn/);
    expect(() => assertValidLayout([P('a', 0, 'R', Number.NaN, 0)], 24)).toThrow(/ngoài bàn/);
  });

  it('makeState cho phép tù binh chung ô với quân giữ', () => {
    const holder = P('x', 1, 'R', 3, 3);
    const captive = { ...P('c', 0, 'Q', 3, 3), status: 'captive' as const, holder: 1 as Seat };
    expect(() => makeState({ pieces: [holder, captive] })).not.toThrow();
  });

  it('makeState dùng mặc định: đang chơi, hiệp 1, ghế 0 đi', () => {
    const s = makeState({ pieces: [P('a', 2, 'K', 1, 1)] });
    expect(s.phase).toBe('playing');
    expect(s.round).toBe(1);
    expect(s.turnSeat).toBe(0);
    expect(s.order).toEqual(SEATS);
  });
});
