// M2: ăn quân, tù binh, trưng dụng, kill/phong cấp, Hề, Vua (PLAN R-30…R-37, R-40…R-42, R-50…R-52, R-60,
// và các ca biên 4.10). Mỗi `it` ghi mã luật để truy vết.
import * as fc from 'fast-check';
import { describe, expect, it } from 'vitest';
import {
  IllegalMoveError,
  KNIGHT_JUMPS,
  add,
  applyMove,
  cell,
  cellKey,
  cellsInRadius,
  checkMove,
  configWith,
  dist,
  explainIllegal,
  isOnBoard,
  legalMoves,
  legalMovesOfPiece,
  nearestEmptyCell,
  scoreOf,
  type Piece,
  type PieceType,
  type Seat,
} from '../src';
import { P, captive, eventsOf, k, mv, need, pieceOf, play, stateOf, targets, typesOf } from './helpers';

/** Ba Vua ở xa nhau (vòng 20) làm "người đứng ngoài": có nước đi để `idle`, không dính vào chỗ đang thử. */
const kings = (): Piece[] => [P('k0', 0, 'K', -20, 20), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)];
const three = (pieces: readonly Piece[], init: Parameters<typeof stateOf>[1] = {}) =>
  stateOf([...kings(), ...pieces], { seats: [0, 1, 2], ...init });

/** Quân đã phong cấp / mang sẵn kill: xuất thân Tốt. */
const veteran = (id: string, owner: Seat, type: PieceType, q: number, r: number, kills: number): Piece => ({
  ...P(id, owner, type, q, r),
  origin: 'P',
  kills,
});

describe('R-30, R-31: ăn quân tạo tù binh', () => {
  const start = three([P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0)]);

  it('R-30: quân bị ăn (không phải Vua) thành tù binh của người ăn, chung ô với quân ăn; quân ăn +1 kill', () => {
    const { state, events } = play(start, [mv('r0', 3, 0)]);
    expect(need(state, 'r0')).toMatchObject({ cell: { q: 3, r: 0 }, kills: 1, status: 'active' });
    expect(need(state, 'n1')).toMatchObject({ owner: 1, status: 'captive', holder: 0, cell: { q: 3, r: 0 } });
    expect(state.playerKills).toEqual([1, 0, 0, 0, 0, 0]);
    expect(typesOf(events)).toEqual(['MOVED', 'CAPTURED', 'CAPTIVE_CREATED', 'TURN_STARTED']);
  });

  it('R-30: cuối lượt tù binh mới "đợi lượt kế" (armed) để người giữ trưng dụng được ở lượt sau (4.10 bước 4)', () => {
    const { state } = play(start, [mv('r0', 3, 0)]);
    expect(need(state, 'n1').armed).toBe(true);
  });

  it('R-31: tù binh vẫn tính điểm cho chủ cũ (không cho người giữ) cho tới khi bị loại', () => {
    const { state } = play(start, [mv('r0', 3, 0)]);
    expect(scoreOf(state, 1)).toBe(3); // Mã
    expect(scoreOf(state, 0)).toBe(5 + 1); // Xe + 1 kill
  });

  it('R-31: tù binh bị đóng băng: chủ cũ không đi được, không có nước nào của nó trong legalMoves', () => {
    const { state } = play(start, [mv('r0', 3, 0)]);
    expect(state.turnSeat).toBe(1);
    expect(explainIllegal(state, mv('n1', 4, 0))).toBe('PIECE_IS_CAPTIVE');
    expect(() => applyMove(state, mv('n1', 4, 2))).toThrowError(IllegalMoveError);
    expect(legalMoves(state, 1).every((m) => m.pieceId !== 'n1')).toBe(true);
    // Chỉ người giữ mới có nước trưng dụng, và chỉ ở lượt của họ (R-32): ngoài lượt thì checkMove từ chối.
    const conscripts = legalMoves(state, 0).filter((m) => m.pieceId === 'n1');
    expect(conscripts.length).toBeGreaterThan(0);
    expect(conscripts.every((m) => m.conscript === true)).toBe(true);
    expect(checkMove(state, 0, conscripts[0] as (typeof conscripts)[number])).toBe('NOT_YOUR_TURN');
  });
});

describe('R-32: trưng dụng tù binh', () => {
  it('R-32 + R-60 (ca biên 4.10): Tốt ăn Hậu ở hiệp 1, hiệp 2 dùng Hậu ăn Vua → ăn Vua thành công, người đó bị loại', () => {
    const s = stateOf(
      [
        P('k0', 0, 'K', -20, 20),
        P('p0', 0, 'P', 0, 0),
        P('q1', 1, 'Q', 1, -1),
        P('k1', 1, 'K', 1, -4),
        P('r1', 1, 'R', 20, -5),
        P('k2', 2, 'K', 20, -20),
      ],
      { seats: [0, 1, 2] },
    );
    const afterRound1 = play(s, [mv('p0', 1, -1), mv('r1', 20, -6), 'idle']);
    expect(afterRound1.state).toMatchObject({ round: 2, turnSeat: 0 });
    expect(need(afterRound1.state, 'q1')).toMatchObject({ status: 'captive', holder: 0, armed: true });
    expect(legalMoves(afterRound1.state, 0).some((m) => m.pieceId === 'q1' && m.conscript === true)).toBe(true);

    const { state, events } = play(afterRound1.state, [mv('q1', 1, -4, true)]);
    expect(typesOf(events)).toEqual(['CAPTIVE_CONSCRIPTED', 'MOVED', 'CAPTURED', 'KING_CAPTURED', 'PLAYER_ELIMINATED', 'TURN_STARTED']);
    expect(state.eliminated).toEqual([{ seat: 1, round: 2, reason: 'king', batch: 1, score: 9 + 5 + 0 }]);
    expect(state.pieces.filter((p) => p.owner === 1)).toHaveLength(0);
    expect(state.playerKills).toEqual([2, 0, 0, 0, 0, 0]); // R-32: +1 kill của người chơi
    expect(need(state, 'p0').kills).toBe(1); // R-40: nước ăn của tù binh không tăng kills của quân nào
    expect(state).toMatchObject({ phase: 'playing', round: 2, turnSeat: 2 });
  });

  it('R-32: trưng dụng đi "như quân của mình" (khung ghế của người giữ), không phải khung ghế của chủ cũ', () => {
    // Tốt của ghế 1 bị ghế 0 giữ: đi tiến/lùi theo trục của ghế 0 (0,∓1), không phải trục của ghế 1 ((1,-1)/(-1,1)).
    const s = stateOf([P('x0', 0, 'R', 0, 0), captive('cp', 1, 'P', 0, 0, 0, true)], { seats: [0, 1] });
    expect(targets(s, 'cp')).toEqual(['0,-1', '0,1']);
    expect(legalMovesOfPiece(s, 'cp').every((m) => m.conscript === true)).toBe(true);
  });

  it('R-32: tù binh trưng dụng ăn được quân không phải của người giữ (kể cả người cùng phe cũ), không ăn quân của người giữ', () => {
    const s = stateOf(
      [P('x0', 0, 'P', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true), P('e1', 1, 'P', 0, -2), P('e2', 2, 'P', 2, 0), P('own', 0, 'P', 0, 2)],
      { seats: [0, 1, 2] },
    );
    const t = targets(s, 'cq');
    expect(t).toContain('0,-2'); // quân của chính chủ cũ vẫn ăn được
    expect(t).toContain('2,0'); // quân của người thứ ba
    expect(t).not.toContain('0,2'); // quân của người giữ
  });

  it('R-32: không chuỗi tù binh — quân bị tù binh ăn bị loại ngay, chỉ +1 kill của người chơi', () => {
    const s = three([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true), P('v2', 2, 'N', 0, -3)]);
    const { state, events } = play(s, [mv('cq', 0, -3, true)]);
    expect(pieceOf(state, 'v2')).toBeUndefined();
    expect(typesOf(events)).not.toContain('CAPTIVE_CREATED');
    expect(state.playerKills[0]).toBe(1);
    expect(state.pieces.every((p) => p.kills === 0)).toBe(true);
  });

  it('R-33: tù binh bị loại cuối lượt của người giữ dù đứng ở đâu (đã được trưng dụng và đi xa)', () => {
    const s = three([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true)]);
    const { state, events } = play(s, [mv('cq', 5, -5, true)]);
    expect(pieceOf(state, 'cq')).toBeUndefined();
    expect(eventsOf(events, 'CAPTIVE_EXPIRED')).toMatchObject([{ pieceId: 'cq', holder: 0, cell: { q: 5, r: -5 } }]);
  });

  it('R-33: không dùng tù binh thì nó vẫn bị loại cuối lượt đó (đi quân khác)', () => {
    const s = three([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true)]);
    const { state, events } = play(s, [mv('x0', 3, 0)]);
    expect(pieceOf(state, 'cq')).toBeUndefined();
    expect(typesOf(events)).toContain('CAPTIVE_EXPIRED');
  });

  it('R-33: hạn tính theo LƯỢT của người giữ, không phải hiệp: tù binh sống qua lượt của mọi người khác', () => {
    const s = three([P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0)]);
    const { state } = play(s, [mv('r0', 3, 0), 'idle', 'idle']);
    expect(state.turnSeat).toBe(0);
    expect(need(state, 'n1').status).toBe('captive'); // vẫn còn tới lượt của ghế 0
  });

  it('R-32: lỗi trưng dụng có mã lý do rõ ràng (chưa tới hạn / không phải tù binh / không phải của mình / bị tắt)', () => {
    const notReady = stateOf([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, false)], { seats: [0, 1] });
    expect(explainIllegal(notReady, mv('cq', 0, -3, true))).toBe('CAPTIVE_NOT_READY');

    const s = three([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true), P('a2', 2, 'R', 5, 5)]);
    expect(explainIllegal(s, mv('a2', 5, 6, true))).toBe('NOT_A_CAPTIVE');
    expect(explainIllegal(s, mv('cq', 0, -3))).toBe('PIECE_IS_CAPTIVE'); // không có cờ conscript
    expect(checkMove(s, 0, mv('cq', 0, -3, true))).toBeNull();

    const theirs = { ...s, turnSeat: 2 } as typeof s;
    expect(checkMove(theirs, 2, mv('cq', 0, -3, true))).toBe('NOT_YOUR_PIECE'); // tù binh do ghế 0 giữ

    const off = three([P('x0', 0, 'R', 0, 0), captive('cq', 1, 'Q', 0, 0, 0, true)], { config: configWith({ captive: { conscript: false } }) });
    expect(explainIllegal(off, mv('cq', 0, -3, true))).toBe('CONSCRIPT_DISABLED');
    expect(legalMoves(off, 0).some((m) => m.conscript === true)).toBe(false);
  });

  it('D-04 (captive.conscript = false): tù binh chỉ nằm im nhưng vẫn bị loại cuối lượt kế tiếp của người giữ', () => {
    const config = configWith({ captive: { conscript: false } });
    const s = three([P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0)], { config });
    const { state } = play(s, [mv('r0', 3, 0), 'idle', 'idle']);
    expect(need(state, 'n1').status).toBe('captive');
    const after = play(state, ['idle']).state;
    expect(pieceOf(after, 'n1')).toBeUndefined();
  });
});

describe('R-34: người giữ tù binh bị ăn', () => {
  // Ghế 0 (x0, Xe) ăn Mã y1 của ghế 1 tại (0,0). Ghế 1 có Xe z1, ghế 2 có Xe z2 cùng nhắm vào (0,0).
  const setup = (bystanders: readonly Piece[] = [], init: Parameters<typeof stateOf>[1] = {}) =>
    three(
      [P('x0', 0, 'R', 0, -3), P('y1', 1, 'N', 0, 0), P('z1', 1, 'R', 3, -3), P('z2', 2, 'R', 3, 0), ...bystanders],
      init,
    );

  it('R-34 + R-36 (ca biên 4.10): chủ tù binh ăn lại người giữ → tù binh của họ về ô trống gần nhất; người giữ thành tù binh của họ', () => {
    // Hai ô kề (-1,0) và (-1,1) đã bị chiếm, nên ô trống gần nhất theo (q nhỏ, rồi r nhỏ) là (0,-1).
    const first = play(setup([P('b1', 2, 'P', -1, 0), P('b2', 2, 'P', -1, 1)]), [mv('x0', 0, 0)]);
    const { state, events } = play(first.state, [mv('z1', 0, 0)]);

    expect(need(state, 'y1')).toMatchObject({ status: 'active', cell: { q: 0, r: -1 }, owner: 1 });
    expect(need(state, 'y1').holder).toBeUndefined();
    expect(need(state, 'x0')).toMatchObject({ status: 'captive', owner: 0, holder: 1, cell: { q: 0, r: 0 } });
    expect(need(state, 'z1')).toMatchObject({ status: 'active', kills: 1, cell: { q: 0, r: 0 } });
    expect(need(state, 'y1').kills).toBe(0);
    expect(state.playerKills).toEqual([1, 1, 0, 0, 0, 0]);

    expect(typesOf(events)).toEqual(['MOVED', 'CAPTURED', 'CAPTIVE_CREATED', 'CAPTIVE_RELEASED', 'TURN_STARTED']);
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'y1', cause: 'rescued', from: { q: 0, r: 0 }, to: { q: 0, r: -1 } }]);
  });

  it('R-34 (ca biên 4.10): người thứ ba ăn người giữ → người giữ và các tù binh cũ đều thuộc người thứ ba', () => {
    const { state, events } = play(setup(), [mv('x0', 0, 0), 'idle', mv('z2', 0, 0)]);
    expect(need(state, 'x0')).toMatchObject({ status: 'captive', owner: 0, holder: 2 });
    expect(need(state, 'y1')).toMatchObject({ status: 'captive', owner: 1, holder: 2, cell: { q: 0, r: 0 } });
    expect(need(state, 'z2')).toMatchObject({ kills: 1, status: 'active' });
    expect(eventsOf(events, 'CAPTIVE_TRANSFERRED')).toMatchObject([{ pieceId: 'y1', owner: 1, from: 0, to: 2 }]);
    expect(state.playerKills).toEqual([1, 0, 1, 0, 0, 0]);
  });

  it('R-34: hạn mới của tù binh chuyển giao là hết lượt kế tiếp của người ăn (không còn theo hạn cũ của người giữ cũ)', () => {
    const afterSteal = play(setup(), [mv('x0', 0, 0), 'idle', mv('z2', 0, 0)]).state;
    // Ghế 0 đi lượt kế: tù binh của ghế 0 (không còn cái nào) — nhưng x0 và y1 giờ do ghế 2 giữ, chưa hết hạn.
    const next = play(afterSteal, ['idle', 'idle']).state; // lượt ghế 0 (hiệp 2) rồi ghế 1
    expect(next.turnSeat).toBe(2);
    expect(need(next, 'x0').status).toBe('captive');
    expect(need(next, 'y1').status).toBe('captive');
    const later = play(next, ['idle']).state; // hết lượt của ghế 2
    expect(pieceOf(later, 'x0')).toBeUndefined();
    expect(pieceOf(later, 'y1')).toBeUndefined();
  });

  it('R-34 (ca biên 4.10): người giữ mang tù binh của hai chủ, bị một trong hai chủ ăn → tù binh của chủ đó được giải cứu, tù binh của chủ kia và người giữ chuyển sang chủ đó', () => {
    const s = stateOf(
      [
        ...kings(),
        P('x0', 0, 'Q', 0, 0),
        captive('y1', 1, 'N', 0, 0, 0, true),
        captive('y2', 2, 'B', 0, 0, 0, true),
        P('z1', 1, 'R', 3, -3),
      ],
      { seats: [0, 1, 2], turnSeat: 1 },
    );
    const { state, events } = play(s, [mv('z1', 0, 0)]);
    expect(need(state, 'y1')).toMatchObject({ status: 'active' }); // giải cứu
    expect(need(state, 'y2')).toMatchObject({ status: 'captive', owner: 2, holder: 1 });
    expect(need(state, 'x0')).toMatchObject({ status: 'captive', owner: 0, holder: 1 });
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'y1', cause: 'rescued' }]);
    expect(eventsOf(events, 'CAPTIVE_TRANSFERRED')).toMatchObject([{ pieceId: 'y2', from: 0, to: 1 }]);
  });

  it('captive.rescueByOwner = false (X-08 tắt): không giải cứu; quân đó không thể là tù binh của chính chủ nên mất luôn', () => {
    const config = configWith({ captive: { rescueByOwner: false } });
    const { state, events } = play(setup([], { config }), [mv('x0', 0, 0), mv('z1', 0, 0)]);
    expect(pieceOf(state, 'y1')).toBeUndefined();
    expect(eventsOf(events, 'CAPTIVE_EXPIRED')).toMatchObject([{ pieceId: 'y1', owner: 1 }]);
    expect(need(state, 'x0')).toMatchObject({ status: 'captive', holder: 1 });
  });

  it('R-34 + R-32: tù binh trưng dụng ăn quân giữ tù binh → các tù binh trên ô đó được thả, không chuyển chủ', () => {
    // Ghế 0 trưng dụng tù binh cq (của ghế 2) để ăn quân x1 của ghế 1; x1 đang giữ tù binh w2 (của ghế 2) ở cùng ô.
    const s = stateOf(
      [
        ...kings(),
        P('x0', 0, 'R', 0, 0),
        captive('cq', 2, 'Q', 0, 0, 0, true),
        P('x1', 1, 'R', 0, -3),
        captive('w2', 2, 'N', 0, -3, 1, true),
      ],
      { seats: [0, 1, 2] },
    );
    const { state, events } = play(s, [mv('cq', 0, -3, true)]);
    expect(pieceOf(state, 'x1')).toBeUndefined();
    expect(need(state, 'w2').status).toBe('active');
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'w2', cause: 'holder_lost' }]);
    expect(typesOf(events)).not.toContain('CAPTIVE_TRANSFERRED');
  });
});

describe('R-35, R-36: giải phóng tù binh', () => {
  it('R-35 (ca biên 4.10): người giữ tù binh bị loại giữa hiệp → tù binh được giải phóng, đặt vào ô trống gần nhất', () => {
    const s = stateOf(
      [
        P('k0', 0, 'K', 4, -4),
        P('x0', 0, 'R', 0, 0),
        captive('y1', 1, 'N', 0, 0, 0, true),
        P('k1', 1, 'K', -20, 0),
        P('k2', 2, 'K', 20, -20),
        P('z2', 2, 'R', 4, -6),
      ],
      { seats: [0, 1, 2], turnSeat: 2 },
    );
    const { state, events } = play(s, [mv('z2', 4, -4)]); // Xe ghế 2 ăn Vua ghế 0
    expect(state.eliminated).toMatchObject([{ seat: 0, reason: 'king' }]);
    expect(pieceOf(state, 'x0')).toBeUndefined();
    expect(need(state, 'y1')).toMatchObject({ status: 'active', cell: { q: 0, r: 0 } }); // ô của x0 giờ trống → khoảng cách 0
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'y1', cause: 'holder_eliminated' }]);
  });

  describe('nearestEmptyCell (R-36)', () => {
    it('ô gốc trống → chính nó (khoảng cách 0)', () => {
      expect(nearestEmptyCell(5, cell(1, 1), new Set())).toEqual(cell(1, 1));
    });

    it('hoà khoảng cách → q nhỏ hơn, rồi r nhỏ hơn', () => {
      const o = cell(0, 0);
      const occupied = new Set([cellKey(o)]);
      expect(nearestEmptyCell(5, o, occupied)).toEqual(cell(-1, 0));
      occupied.add(cellKey(cell(-1, 0)));
      expect(nearestEmptyCell(5, o, occupied)).toEqual(cell(-1, 1));
      occupied.add(cellKey(cell(-1, 1)));
      expect(nearestEmptyCell(5, o, occupied)).toEqual(cell(0, -1));
    });

    it('ô phải còn trên bàn cờ: ở mép bàn thì bỏ qua các ô ngoài', () => {
      const edge = cell(0, 5); // hạng 5 của bàn bán kính 5
      const found = nearestEmptyCell(5, edge, new Set([cellKey(edge)]));
      expect(found).toEqual(cell(-1, 5)); // (-1,5): hạng 5, q nhỏ nhất trong các ô kề còn trên bàn
      expect(found !== undefined && isOnBoard(found, 5)).toBe(true);
    });

    it('không còn ô trống nào → undefined', () => {
      const all = new Set(cellsInRadius(2).map(cellKey));
      expect(nearestEmptyCell(2, cell(0, 0), all)).toBeUndefined();
    });

    it('thuộc tính: kết quả trống, trên bàn, không có ô trống nào gần hơn, và hoà thì theo thứ tự (q, r)', () => {
      const radius = 4;
      const board = cellsInRadius(radius);
      fc.assert(
        fc.property(
          fc.subarray(board, { minLength: 0, maxLength: board.length - 1 }),
          fc.constantFrom(...board),
          (taken, origin) => {
            const occupied = new Set(taken.map(cellKey));
            const found = nearestEmptyCell(radius, origin, occupied);
            const empties = board.filter((c) => !occupied.has(cellKey(c)));
            if (empties.length === 0) return found === undefined;
            if (found === undefined || occupied.has(cellKey(found)) || !isOnBoard(found, radius)) return false;
            const best = Math.min(...empties.map((c) => dist(origin, c)));
            const tied = empties.filter((c) => dist(origin, c) === best).sort((a, b) => a.q - b.q || a.r - b.r);
            return dist(origin, found) === best && k(found) === k(tied[0] as (typeof tied)[number]);
          },
        ),
        { numRuns: 200 },
      );
    });
  });
});

describe('R-37, R-51, R-52, R-60: Vua, Hề, loại người chơi', () => {
  // Xe r0 của ghế 0 ăn Vua k1 của ghế 1 tại (0,0) sau 3 bước.
  const attack = (jesterAt: { q: number; r: number } | undefined, extra: readonly Piece[] = []) =>
    stateOf(
      [
        P('k0', 0, 'K', -20, 20),
        P('r0', 0, 'R', -3, 0),
        P('k1', 1, 'K', 0, 0),
        ...(jesterAt === undefined ? [] : [P('j1', 1, 'J', jesterAt.q, jesterAt.r)]),
        P('s1', 1, 'R', 20, -5),
        P('k2', 2, 'K', 20, -20),
        ...extra,
      ],
      { seats: [0, 1, 2] },
    );

  it('R-51 (ca biên 4.10): Vua bị ăn khi Hề cách 5 ô → Vua hồi sinh tại ô Hề, Hề mất, người đó không mất quân nào khác', () => {
    const { state, events } = play(attack({ q: 0, r: 5 }), [mv('r0', 0, 0)]);
    expect(need(state, 'k1')).toMatchObject({ status: 'active', cell: { q: 0, r: 5 } });
    expect(pieceOf(state, 'j1')).toBeUndefined();
    expect(pieceOf(state, 's1')).toBeDefined();
    expect(state.eliminated).toEqual([]);
    expect(need(state, 'r0')).toMatchObject({ cell: { q: 0, r: 0 }, kills: 1 }); // vẫn tính kill, ở lại ô cũ
    expect(state.playerKills[0]).toBe(1);
    expect(typesOf(events)).toEqual(['MOVED', 'CAPTURED', 'KING_CAPTURED', 'JESTER_REVIVED', 'TURN_STARTED']);
    expect(eventsOf(events, 'JESTER_REVIVED')).toMatchObject([{ owner: 1, from: { q: 0, r: 0 }, to: { q: 0, r: 5 }, cause: 'capture' }]);
  });

  it('R-37: khi Hề cứu Vua, Vua không bao giờ trở thành tù binh', () => {
    const { state, events } = play(attack({ q: 0, r: 5 }), [mv('r0', 0, 0)]);
    expect(state.pieces.some((p) => p.status === 'captive')).toBe(false);
    expect(typesOf(events)).not.toContain('CAPTIVE_CREATED');
  });

  it('R-51 (ca biên 4.10): Hề cách 6 ô → không cứu được, người đó bị loại cùng toàn bộ quân', () => {
    const { state, events } = play(attack({ q: 0, r: 6 }), [mv('r0', 0, 0)]);
    expect(state.pieces.filter((p) => p.owner === 1)).toHaveLength(0);
    expect(state.eliminated).toEqual([{ seat: 1, round: 1, reason: 'king', batch: 1, score: 5 + 2 }]); // Xe s1 + Hề j1
    expect(typesOf(events)).toContain('PLAYER_ELIMINATED');
    expect(typesOf(events)).not.toContain('JESTER_REVIVED');
    expect(state.playerKills[0]).toBe(1); // R-60: người ăn +1 kill
  });

  it('R-51: ngưỡng lấy từ cấu hình (jesterReviveDistance)', () => {
    const config = configWith({ reach: { jesterReviveDistance: 6 } });
    const { state } = play(attack({ q: 0, r: 6 }, []), [mv('r0', 0, 0)]);
    expect(state.eliminated).toHaveLength(1);
    const custom = stateOf(attack({ q: 0, r: 6 }).pieces, { seats: [0, 1, 2], config });
    expect(play(custom, [mv('r0', 0, 0)]).state.eliminated).toHaveLength(0);
  });

  it('R-51: Hề đã là tù binh thì không cứu được (R-37)', () => {
    const s = attack(undefined, [P('h2', 2, 'R', 0, 5), captive('j1', 1, 'J', 0, 5, 2, true)]);
    const { state } = play(s, [mv('r0', 0, 0)]);
    expect(state.eliminated).toMatchObject([{ seat: 1, reason: 'king' }]);
  });

  it('R-52: Hề chỉ cứu được một lần (Hề mất sau khi cứu), lần ăn Vua sau là bị loại', () => {
    const { state } = play(attack({ q: 0, r: 5 }), [mv('r0', 0, 0), mv('s1', 20, -6), 'idle', mv('r0', 0, 5)]);
    expect(state.eliminated).toMatchObject([{ seat: 1, round: 2, reason: 'king' }]);
  });

  describe('R-34 + R-51 (ca biên 4.10): Vua bị ăn nhưng được Hề cứu, trong khi ô của Vua đang có tù binh do Vua giữ', () => {
    // Ghế 1 (Vua k1 ở (0,0)) đang giữ: Tượng c2 của ghế 2 và Mã c0 của chính ghế 0 (người sắp ăn Vua).
    // Ghế 0 còn giữ Xe x2 của ghế 2 ở ô Xe r0, dùng để trưng dụng ăn Vua.
    const held = [captive('c2', 2, 'B', 0, 0, 1, true), captive('c0', 0, 'N', 0, 0, 1, true)];
    const withConscript = () => attack({ q: 0, r: 5 }, [...held, captive('x2', 2, 'R', -3, 0, 0, true)]);

    it('ăn thường (R-34): tù binh của người thứ ba chuyển sang người ăn với hạn mới; tù binh của chính người ăn được giải cứu (R-36)', () => {
      const { state, events } = play(attack({ q: 0, r: 5 }, held), [mv('r0', 0, 0)]);
      expect(need(state, 'k1')).toMatchObject({ status: 'active', cell: { q: 0, r: 5 } }); // Hề cứu
      expect(need(state, 'c2')).toMatchObject({ status: 'captive', holder: 0, armed: true, cell: { q: 0, r: 0 } }); // hạn mới: tới lượt kế của ghế 0
      expect(need(state, 'c0')).toMatchObject({ owner: 0, status: 'active', cell: { q: -1, r: 0 } });
      expect(need(state, 'c0').holder).toBeUndefined();
      expect(eventsOf(events, 'CAPTIVE_TRANSFERRED')).toMatchObject([{ pieceId: 'c2', owner: 2, from: 1, to: 0 }]);
      expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'c0', owner: 0, cause: 'rescued', to: { q: -1, r: 0 } }]);
      expect(typesOf(events)).toEqual(['MOVED', 'CAPTURED', 'KING_CAPTURED', 'JESTER_REVIVED', 'CAPTIVE_TRANSFERRED', 'CAPTIVE_RELEASED', 'TURN_STARTED']);
    });

    it('ăn bằng trưng dụng (R-32): quân giữ không "bị ăn" theo nghĩa thường nên KHÔNG chuyển giao / giải cứu; mọi tù binh được thả tại chỗ (holder_lost)', () => {
      const { state, events } = play(withConscript(), [mv('x2', 0, 0, true)]);
      expect(need(state, 'k1')).toMatchObject({ status: 'active', cell: { q: 0, r: 5 } }); // Hề vẫn cứu Vua
      expect(need(state, 'c2')).toMatchObject({ owner: 2, status: 'active', cell: { q: -1, r: 0 } });
      expect(need(state, 'c0')).toMatchObject({ owner: 0, status: 'active', cell: { q: -1, r: 1 } });
      expect(need(state, 'c2').holder).toBeUndefined();
      expect(typesOf(events)).not.toContain('CAPTIVE_TRANSFERRED');
      expect(eventsOf(events, 'CAPTIVE_RELEASED').map((e) => [e.pieceId, e.cause])).toEqual([
        ['c2', 'holder_lost'],
        ['c0', 'holder_lost'], // kể cả Mã của chính ghế 0: không phải "giải cứu" (R-34 chỉ áp dụng khi Vua bị ăn thường)
      ]);
      // R-32/R-33: tù binh trưng dụng vẫn hết hạn cuối lượt; kill tính cho người chơi, không cho quân nào.
      expect(pieceOf(state, 'x2')).toBeUndefined();
      expect(state.playerKills[0]).toBe(1);
      expect(need(state, 'r0').kills).toBe(0);
    });
  });

  it('R-50: Hề không bao giờ ăn quân', () => {
    const s = stateOf([P('k0', 0, 'K', -20, 20), P('j0', 0, 'J', 0, 0), P('e1', 1, 'P', 0, -1), P('k1', 1, 'K', -20, 0)], { seats: [0, 1] });
    expect(explainIllegal(s, mv('j0', 0, -1))).toBe('JESTER_CANNOT_CAPTURE');
    expect(() => applyMove(s, mv('j0', 0, -1))).toThrowError(IllegalMoveError);
  });

  it('R-60: Vua bị ăn không có Hề → toàn bộ quân bị loại (kể cả tù binh của họ bị người khác giữ); tù binh họ đang giữ được thả (R-35)', () => {
    const s = stateOf(
      [
        P('k0', 0, 'K', -20, 20),
        P('r0', 0, 'R', -3, 0),
        P('k1', 1, 'K', 0, 0),
        P('q1', 1, 'Q', 10, -10),
        P('x1', 1, 'R', 6, -3),
        captive('c2', 2, 'B', 6, -3, 1, true), // ghế 1 giữ Tượng của ghế 2
        P('g2', 2, 'R', -6, 3),
        captive('n1c', 1, 'N', -6, 3, 2, true), // ghế 2 giữ Mã của ghế 1
        P('k2', 2, 'K', 20, -20),
      ],
      { seats: [0, 1, 2] },
    );
    const { state, events } = play(s, [mv('r0', 0, 0)]);
    expect(state.pieces.filter((p) => p.owner === 1)).toHaveLength(0); // k1, q1, x1 và Mã tù binh n1c
    expect(need(state, 'c2')).toMatchObject({ status: 'active', cell: { q: 6, r: -3 } }); // được thả tại chỗ x1 đứng
    expect(state.eliminated).toEqual([{ seat: 1, round: 1, reason: 'king', batch: 1, score: 9 + 5 + 3 }]); // Q + R + N tù binh
    expect(eventsOf(events, 'PLAYER_ELIMINATED')).toHaveLength(1);
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'c2', cause: 'holder_eliminated' }]);
  });

  it('R-80: còn đúng một người còn Vua thì người đó thắng ngay; ván dừng, không còn lượt', () => {
    const s = stateOf([P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', -3, 0), P('k1', 1, 'K', 0, 0)], { seats: [0, 1] });
    const { state, events } = play(s, [mv('r0', 0, 0)]);
    expect(state.phase).toBe('over');
    expect(state.turnSeat).toBeNull();
    expect(state.result).toMatchObject({ reason: 'lastKing', winner: 0 });
    expect(state.result?.ranking.map((r) => [r.seat, r.rank])).toEqual([
      [0, 1],
      [1, 2],
    ]);
    expect(typesOf(events).at(-1)).toBe('GAME_OVER');
    expect(() => applyMove(state, mv('r0', 0, 1))).toThrowError(/GAME_NOT_PLAYING/);
  });
});

describe('R-40, R-41, R-42: kill và phong cấp', () => {
  const duel = (mover: Piece, victimType: PieceType, victimAt: { q: number; r: number }, kills: number, config = configWith({})) =>
    stateOf([P('k0', 0, 'K', -20, 20), mover, P('v1', 1, victimType, victimAt.q, victimAt.r), P('k1', 1, 'K', -20, 0)], {
      seats: [0, 1],
      playerKills: [kills, 0, 0, 0, 0, 0],
      config,
    });

  it('R-41 (ca biên 4.10): Tốt ăn quân thứ 6 là Mã địch → phong thành Mã sau nước ăn, quân bị ăn thành tù binh', () => {
    const s = duel(veteran('p0', 0, 'P', 0, 0, 5), 'N', { q: 1, r: -1 }, 5);
    const { state, events } = play(s, [mv('p0', 1, -1)]);
    expect(need(state, 'p0')).toMatchObject({ type: 'N', origin: 'P', kills: 6, cell: { q: 1, r: -1 } });
    expect(need(state, 'v1')).toMatchObject({ status: 'captive', holder: 0 });
    const own = events.slice(0, events.findIndex((e) => e.type === 'TURN_STARTED'));
    expect(typesOf(own)).toEqual(['MOVED', 'CAPTURED', 'CAPTIVE_CREATED', 'PROMOTED']);
    expect(eventsOf(events, 'PROMOTED')).toMatchObject([{ pieceId: 'p0', from: 'P', to: 'N', kills: 6 }]);
  });

  it('R-42: quân đã phong tuân theo luật đi của loại mới (Mã nhảy đủ 12 ô)', () => {
    const s = duel(veteran('p0', 0, 'P', 0, 0, 5), 'N', { q: 1, r: -1 }, 5);
    const { state } = play(s, [mv('p0', 1, -1)]);
    expect(targets(state, 'p0')).toEqual(KNIGHT_JUMPS.map((j) => k(add(cell(1, -1), j))).sort());
  });

  it.each<[string, PieceType, PieceType, number, { q: number; r: number }, number]>([
    ['Tốt → Mã ở kill 6', 'P', 'N', 5, { q: 1, r: -1 }, 6],
    ['Mã → Tượng ở kill 10', 'N', 'B', 9, { q: 1, r: -3 }, 10],
    ['Tượng → Xe ở kill 15', 'B', 'R', 14, { q: 1, r: -2 }, 15],
    ['Xe → Hậu ở kill 20', 'R', 'Q', 19, { q: 0, r: -3 }, 20],
    ['Hậu là bậc cuối: 25 kill vẫn là Hậu', 'Q', 'Q', 24, { q: 0, r: -3 }, 25],
  ])('R-41: %s', (_name, from, to, before, victimAt, after) => {
    const s = duel(veteran('p0', 0, from, 0, 0, before), 'P', victimAt, before);
    const { state, events } = play(s, [mv('p0', victimAt.q, victimAt.r)]);
    expect(need(state, 'p0')).toMatchObject({ type: to, kills: after });
    expect(eventsOf(events, 'PROMOTED')).toHaveLength(from === to ? 0 : 1);
  });

  it('R-41: chỉ quân xuất thân Tốt mới phong cấp (Mã gốc có 99 kill vẫn là Mã)', () => {
    const s = duel({ ...P('n0', 0, 'N', 0, 0), kills: 99 }, 'P', { q: 1, r: -3 }, 99);
    const { state } = play(s, [mv('n0', 1, -3)]);
    expect(need(state, 'n0')).toMatchObject({ type: 'N', kills: 100 });
  });

  it('R-41 + D-05: kills tích luỹ nên Tốt mang sẵn 14 kill ăn thêm 1 → nhảy qua Mã, Tượng tới Xe trong một nước', () => {
    const s = duel(veteran('p0', 0, 'P', 0, 0, 14), 'P', { q: 1, r: -1 }, 14);
    const { state, events } = play(s, [mv('p0', 1, -1)]);
    expect(need(state, 'p0')).toMatchObject({ type: 'R', kills: 15 });
    expect(eventsOf(events, 'PROMOTED').map((e) => e.to)).toEqual(['N', 'B', 'R']);
  });

  it('D-05 (promotion.cumulativeKills = false): kills đặt lại về 0 sau mỗi lần phong', () => {
    const config = configWith({ promotion: { cumulativeKills: false } });
    const s = duel(veteran('p0', 0, 'P', 0, 0, 5), 'N', { q: 1, r: -1 }, 5, config);
    const { state } = play(s, [mv('p0', 1, -1)]);
    expect(need(state, 'p0')).toMatchObject({ type: 'N', kills: 0 });
  });

  it('R-40: ăn Hề cũng được +1 kill (ăn Vua: xem các ca R-51)', () => {
    const s = duel(P('r0', 0, 'R', 0, 0), 'J', { q: 0, r: -3 }, 0);
    expect(need(play(s, [mv('r0', 0, -3)]).state, 'r0').kills).toBe(1);
  });

  it('R-40: chỉ quân trực tiếp ăn mới được kill (không phải quân khác cùng phe)', () => {
    const s = stateOf(
      [P('k0', 0, 'K', -20, 20), P('a0', 0, 'R', 0, 0), P('b0', 0, 'R', 5, 5), P('v1', 1, 'P', 0, -3), P('k1', 1, 'K', -20, 0)],
      { seats: [0, 1] },
    );
    const { state } = play(s, [mv('a0', 0, -3)]);
    expect(need(state, 'a0').kills).toBe(1);
    expect(need(state, 'b0').kills).toBe(0);
  });
});
