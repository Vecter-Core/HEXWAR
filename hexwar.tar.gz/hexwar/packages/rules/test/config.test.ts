// Cấu hình luật và lịch thu hẹp. Ghi chú [verify #n] trỏ tới tools/verify_board.py.
import { describe, expect, it } from 'vitest';
import { ZodError } from 'zod';
import { cellCount, collapseSchedule, configWith, defaultConfig, parseConfig } from '../src';
import rawDefault from '../rules.config.json';

describe('rules.config.json (PLAN Phụ lục C)', () => {
  it('cấu hình mặc định đúng các giá trị chốt ở mục 2 và mục 4', () => {
    const c = defaultConfig;
    expect(c.board).toEqual({ radius: 24, seatCornerRing: 23 }); // D-01
    expect(c.reach).toEqual({ metric: 'distance', R: 9, B: 9, Q: 9, J: 3, jesterReviveDistance: 5 }); // D-03
    expect(c.pawn.doubleStep).toBe(false); // R-22
    expect(c.captive).toEqual({ conscript: true, rescueByOwner: true }); // D-04
    expect(c.promotion).toEqual({ N: 6, B: 10, R: 15, Q: 20, cumulativeKills: true }); // D-05
    expect(c.jester.savesFromCollapse).toBe(false); // D-09
    expect(c.turn).toEqual({ seconds: 60, afkTimeoutsBeforeBot: 3, reconnectGraceSeconds: 90 });
    expect(c.collapse.hardCapRound).toBe(450);
    expect(c.score).toEqual({ P: 1, N: 3, B: 3, R: 5, Q: 9, J: 2, K: 0, perKill: 1 });
    expect(c.presets.standard).toEqual({ seconds: 45, roundScale: 0.6 });
  });

  it('D-06: lịch gốc giữ đúng như yêu cầu, KHÔNG có hiệp 270', () => {
    expect(defaultConfig.collapse.rounds).toEqual([50, 110, 180, 250, 260, 280, 290, 300, 310, 320, 330, 340, 350, 360]);
    expect(defaultConfig.collapse.rounds).not.toContain(270);
  });

  it('cấu hình mặc định bị đóng băng (không ai sửa nhầm)', () => {
    expect(Object.isFrozen(defaultConfig)).toBe(true);
    expect(Object.isFrozen(defaultConfig.collapse.rounds)).toBe(true);
    expect(() => {
      (defaultConfig.board as { radius: number }).radius = 3;
    }).toThrow(TypeError);
  });

  it('parseConfig trả về bản sao mới, không dùng lại đối tượng đầu vào', () => {
    const parsed = parseConfig(rawDefault);
    expect(parsed).toEqual(defaultConfig);
    expect(parsed).not.toBe(defaultConfig);
    expect(Object.isFrozen(parsed)).toBe(false);
  });
});

describe('kiểm tra cấu hình', () => {
  // Bản nháp JSON tuỳ ý để cố tình làm hỏng từng trường; chỉ dùng trong test nên cho phép `any`.
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  type Draft = Record<string, any>;
  const bad = (mutate: (draft: Draft) => void): unknown => {
    const draft = JSON.parse(JSON.stringify(rawDefault)) as Draft;
    mutate(draft);
    return draft;
  };

  it('từ chối khoá lạ (bắt lỗi gõ sai tên)', () => {
    expect(() => parseConfig(bad((d) => (d.board.radus = 24)))).toThrow(ZodError);
    expect(() => parseConfig(bad((d) => (d.extra = 1)))).toThrow(ZodError);
  });

  it('từ chối thiếu trường và sai kiểu', () => {
    expect(() => parseConfig(bad((d) => delete d.reach))).toThrow(ZodError);
    expect(() => parseConfig(bad((d) => (d.reach.R = '9')))).toThrow(ZodError);
    expect(() => parseConfig(bad((d) => (d.reach.metric = 'manhattan')))).toThrow(ZodError);
    expect(() => parseConfig(bad((d) => (d.board.radius = 24.5)))).toThrow(ZodError);
  });

  it('R-22: pawn.doubleStep = true chưa được đặc tả nên bị từ chối rõ ràng', () => {
    expect(() => parseConfig(bad((d) => (d.pawn.doubleStep = true)))).toThrow(/doubleStep/);
  });

  it('từ chối bán kính vượt khả năng cellKey, seatCornerRing > radius, ngưỡng phong cấp không tăng dần', () => {
    expect(() => parseConfig(bad((d) => (d.board.radius = 29)))).toThrow(ZodError);
    expect(() => parseConfig(bad((d) => (d.board.seatCornerRing = 25)))).toThrow(/seatCornerRing/);
    expect(() => parseConfig(bad((d) => (d.promotion.B = 6)))).toThrow(/phong cấp/);
  });

  it('từ chối lịch thu hẹp không tăng chặt, quá nhiều lần, extension chen vào lịch gốc, hiệp giới hạn cứng quá sớm', () => {
    expect(() => parseConfig(bad((d) => (d.collapse.rounds = [50, 50, 60])))).toThrow(/tăng chặt/);
    expect(() => parseConfig(bad((d) => (d.collapse.rounds = Array.from({ length: 24 }, (_, i) => 10 + i))))).toThrow(/nhỏ hơn board.radius/);
    expect(() => parseConfig(bad((d) => (d.collapse.extension.firstRound = 360)))).toThrow(/firstRound/);
    expect(() => parseConfig(bad((d) => (d.collapse.hardCapRound = 430)))).toThrow(/hardCapRound/);
  });
});

describe('ràng buộc giữa bàn cờ và lịch thu hẹp', () => {
  it('bàn bán kính 26 kéo dài lịch tới hiệp 450, trùng hiệp giới hạn cứng nên bị từ chối cho tới khi dời hardCapRound', () => {
    expect(() => configWith({ board: { radius: 26 } })).toThrow(/hardCapRound/);
    expect(() => configWith({ board: { radius: 26 }, collapse: { hardCapRound: 500 } })).not.toThrow();
  });
});

describe('configWith', () => {
  it('trộn sâu lên cấu hình mặc định và không làm đổi bản mặc định', () => {
    const c = configWith({ reach: { metric: 'hops', B: 12 } });
    expect(c.reach).toEqual({ metric: 'hops', R: 9, B: 12, Q: 9, J: 3, jesterReviveDistance: 5 });
    expect(defaultConfig.reach.metric).toBe('distance');
    expect(defaultConfig.reach.B).toBe(9);
  });

  it('mảng được thay nguyên khối và vẫn được kiểm tra lại', () => {
    const c = configWith({ collapse: { rounds: [10, 20, 30], extension: { enabled: false } } });
    expect(c.collapse.rounds).toEqual([10, 20, 30]);
    expect(() => configWith({ collapse: { rounds: [30, 20] } })).toThrow(ZodError);
  });
});

describe('lịch thu hẹp (PLAN 3.5)', () => {
  // [hiệp, hạng biến mất, ô mất, ô còn lại, bán kính còn] — chép nguyên bảng mục 3.5.
  const table: readonly [number, number, number, number, number][] = [
    [50, 24, 144, 1657, 23],
    [110, 23, 138, 1519, 22],
    [180, 22, 132, 1387, 21],
    [250, 21, 126, 1261, 20],
    [260, 20, 120, 1141, 19],
    [280, 19, 114, 1027, 18],
    [290, 18, 108, 919, 17],
    [300, 17, 102, 817, 16],
    [310, 16, 96, 721, 15],
    [320, 15, 90, 631, 14],
    [330, 14, 84, 547, 13],
    [340, 13, 78, 469, 12],
    [350, 12, 72, 397, 11],
    [360, 11, 66, 331, 10],
    [370, 10, 60, 271, 9],
    [380, 9, 54, 217, 8],
    [390, 8, 48, 169, 7],
    [400, 7, 42, 127, 6],
    [410, 6, 36, 91, 5],
    [420, 5, 30, 61, 4],
    [430, 4, 24, 37, 3],
  ];

  const schedule = collapseSchedule(defaultConfig.board.radius, defaultConfig.collapse);

  it('21 dòng, khớp từng số trong bảng mục 3.5', () => {
    expect(schedule).toHaveLength(21);
    schedule.forEach((event, i) => {
      const [round, ring, lost, remaining, radius] = table[i] as [number, number, number, number, number];
      expect(event.round).toBe(round);
      expect(event.ring).toBe(ring);
      expect(6 * event.ring).toBe(lost); // vòng n có 6n ô
      expect(cellCount(event.radiusAfter)).toBe(remaining);
      expect(event.radiusAfter).toBe(radius);
    });
  });

  it('[verify #28] lịch gốc gồm 14 lần thu hẹp, từ hạng 24 xuống bán kính 10', () => {
    const base = schedule.filter((e) => !e.extension);
    expect(base).toHaveLength(14);
    expect(base[13]?.radiusAfter).toBe(10);
  });

  it('[verify #29] phần kéo dài (D-07) kết thúc ở bán kính 3, hiệp 430', () => {
    const ext = schedule.filter((e) => e.extension);
    expect(ext.map((e) => e.round)).toEqual([370, 380, 390, 400, 410, 420, 430]);
    expect(ext[ext.length - 1]?.radiusAfter).toBe(3);
  });

  it('[verify #30] hiệp giới hạn cứng (450) đứng sau hiệp thu hẹp cuối (430)', () => {
    expect(defaultConfig.collapse.hardCapRound).toBeGreaterThan(schedule[schedule.length - 1]?.round ?? Infinity);
  });

  it('D-07: tắt extension thì chỉ còn 14 lần thu hẹp', () => {
    const c = configWith({ collapse: { extension: { enabled: false } } });
    expect(collapseSchedule(c.board.radius, c.collapse)).toHaveLength(14);
  });

  it('hạng biến mất giảm dần từng đơn vị, hiệp tăng chặt', () => {
    schedule.forEach((e, i) => {
      expect(e.ring).toBe(24 - i);
      if (i > 0) expect(e.round).toBeGreaterThan(schedule[i - 1]?.round ?? 0);
    });
  });
});
