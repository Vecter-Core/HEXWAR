// Hình học lưới lục giác. Ghi chú [verify #n] trỏ tới kiểm tra thứ n trong tools/verify_board.py.
import * as fc from 'fast-check';
import { describe, expect, it } from 'vitest';
import {
  DIR,
  E_DIRS,
  KNIGHT_JUMPS,
  ORIGIN,
  V_DIRS,
  add,
  cell,
  cellCount,
  cellKey,
  cellsInRadius,
  cellsInRing,
  colorOf,
  dist,
  isOnBoard,
  pixelToCell,
  ring,
  rotCW,
  rotate,
  seatCorner,
  sub,
  toSeatFrame,
  worldPos,
  type Cell,
} from '../src';
import { k } from './helpers';

const sortedKeys = (cells: readonly Cell[]): string[] => cells.map(k).sort();
const anyCell = fc
  .record({ q: fc.integer({ min: -24, max: 24 }), r: fc.integer({ min: -24, max: 24 }) })
  .filter((c) => ring(c) <= 24);

describe('số ô (PLAN 3.1)', () => {
  it('[verify #1] bàn R = 24 có 1801 ô', () => {
    expect(cellCount(24)).toBe(1801);
  });

  it('[verify #2] hạng 24 có 144 ô', () => {
    expect(cellCount(24) - cellCount(23)).toBe(144);
    expect(cellsInRing(24)).toHaveLength(144);
  });

  it('[verify #3] liệt kê trực tiếp cũng ra 1801 ô, không trùng, đều có ring ≤ 24', () => {
    const cells = cellsInRadius(24);
    expect(cells).toHaveLength(1801);
    expect(new Set(cells.map(k)).size).toBe(1801);
    expect(cells.every((c) => ring(c) <= 24)).toBe(true);
  });

  it('cellCount khớp việc đếm trực tiếp với mọi bán kính 0..24', () => {
    for (let n = 0; n <= 24; n++) expect(cellsInRadius(n)).toHaveLength(cellCount(n));
  });

  it('cellKey duy nhất trên 1801 ô và từ chối toạ độ ngoài miền hoặc không nguyên', () => {
    expect(new Set(cellsInRadius(24).map(cellKey)).size).toBe(1801);
    expect(() => cellKey(cell(32, 0))).toThrow(RangeError);
    expect(() => cellKey(cell(0, -32))).toThrow(RangeError);
    expect(() => cellKey(cell(0.5, 0))).toThrow(RangeError);
  });

  it('isOnBoard chịu được dữ liệu rác', () => {
    expect(isOnBoard(cell(0, 24), 24)).toBe(true);
    expect(isOnBoard(cell(0, 25), 24)).toBe(false);
    expect(isOnBoard(cell(Number.NaN, 0), 24)).toBe(false);
    expect(isOnBoard(cell(1.5, 0), 24)).toBe(false);
    expect(isOnBoard(cell(Number.POSITIVE_INFINITY, 0), 24)).toBe(false);
  });
});

describe('khoảng cách và hạng', () => {
  it('ring và dist theo công thức mục 3.1', () => {
    expect(ring(cell(0, 0))).toBe(0);
    expect(ring(cell(0, 23))).toBe(23);
    expect(ring(cell(-23, 23))).toBe(23);
    expect(ring(cell(12, 12))).toBe(24);
    expect(dist(cell(0, 22), cell(-1, 22))).toBe(1);
  });

  it('dist đối xứng, dist(a, a) = 0, và dist(a, b) = ring(b − a)', () => {
    fc.assert(
      fc.property(anyCell, anyCell, (a, b) => {
        expect(dist(a, b)).toBe(dist(b, a));
        expect(dist(a, a)).toBe(0);
        expect(dist(a, b)).toBe(ring(sub(b, a)));
      }),
    );
  });
});

describe('xoay 60° (PLAN 3.1)', () => {
  it('rotCW(q, r) = (−r, q + r) và không sinh -0', () => {
    expect(rotCW(cell(1, 2))).toEqual({ q: -2, r: 3 });
    const r = rotCW(cell(3, 0));
    expect(Object.is(r.q, 0)).toBe(true); // -0 sẽ làm toEqual thất bại một cách khó hiểu
    expect(r).toEqual({ q: 0, r: 3 });
  });

  it('sáu lần xoay trở về chỗ cũ; xoay âm là nghịch đảo; giữ nguyên ring', () => {
    fc.assert(
      fc.property(anyCell, fc.integer({ min: -12, max: 12 }), (c, n) => {
        expect(rotate(c, 6)).toEqual(c);
        expect(rotate(rotate(c, n), -n)).toEqual(c);
        expect(ring(rotate(c, n))).toBe(ring(c));
      }),
    );
  });

  it('xoay bảo toàn khoảng cách', () => {
    fc.assert(
      fc.property(anyCell, anyCell, fc.integer({ min: 0, max: 5 }), (a, b, n) => {
        expect(dist(rotate(a, n), rotate(b, n))).toBe(dist(a, b));
      }),
    );
  });

  it('[verify #4] E_DIRS bất biến khi xoay 60°', () => {
    expect(sortedKeys(E_DIRS.map(rotCW))).toEqual(sortedKeys(E_DIRS));
  });

  it('[verify #5] V_DIRS bất biến khi xoay 60°', () => {
    expect(sortedKeys(V_DIRS.map(rotCW))).toEqual(sortedKeys(V_DIRS));
  });

  it('[verify #6] 12 nước nhảy của Mã bất biến khi xoay 60°', () => {
    expect(sortedKeys(KNIGHT_JUMPS.map(rotCW))).toEqual(sortedKeys(KNIGHT_JUMPS));
  });
});

describe('bộ hướng đi (PLAN 3.2)', () => {
  it('hướng cạnh theo chiều kim đồng hồ từ "lên": N, NE, SE, S, SW, NW', () => {
    expect(E_DIRS.map(k)).toEqual(['0,-1', '1,-1', '1,0', '0,1', '-1,1', '-1,0']);
    expect(E_DIRS).toEqual([DIR.N, DIR.NE, DIR.SE, DIR.S, DIR.SW, DIR.NW]);
  });

  it('hướng đỉnh: NNE, E (ngang phải), SSE, SSW, W (ngang trái), NNW', () => {
    expect(V_DIRS.map(k)).toEqual(['1,-2', '2,-1', '1,1', '-1,2', '-2,1', '-1,-1']);
  });

  it('mỗi hướng đỉnh là tổng hai hướng cạnh kề nhau', () => {
    E_DIRS.forEach((d, i) => {
      expect(V_DIRS[i]).toEqual(add(d, E_DIRS[(i + 1) % 6] as Cell));
    });
  });

  it('[verify #7] Mã = đúng 12 ô "không phải góc" của hạng 3', () => {
    const corners = new Set(E_DIRS.map((d) => k(add(ORIGIN, d, 3))));
    const nonCorners = cellsInRing(3).filter((c) => !corners.has(k(c)));
    expect(nonCorners).toHaveLength(12);
    expect(sortedKeys(KNIGHT_JUMPS)).toEqual(sortedKeys(nonCorners));
  });

  it('[verify #8] hướng cạnh có khoảng cách 1, hướng đỉnh có khoảng cách 2', () => {
    expect(E_DIRS.every((d) => dist(ORIGIN, d) === 1)).toBe(true);
    expect(V_DIRS.every((d) => dist(ORIGIN, d) === 2)).toBe(true);
  });
});

describe('tô 3 màu (PLAN 3.4, 12.2)', () => {
  it('[verify #9] mọi hướng cạnh đổi màu ô', () => {
    expect(E_DIRS.every((d) => colorOf(d) !== colorOf(ORIGIN))).toBe(true);
  });

  it('[verify #10] mọi hướng đỉnh giữ nguyên màu (Tượng không bao giờ đổi màu)', () => {
    expect(V_DIRS.every((d) => colorOf(d) === colorOf(ORIGIN))).toBe(true);
  });

  it('[verify #11] Mã luôn đổi màu sau mỗi nước nhảy', () => {
    expect(KNIGHT_JUMPS.every((d) => colorOf(d) !== colorOf(ORIGIN))).toBe(true);
  });

  it('hai ô kề cạnh luôn khác màu trên toàn bàn; màu luôn thuộc {0, 1, 2}', () => {
    fc.assert(
      fc.property(anyCell, fc.constantFrom(...E_DIRS), (c, d) => {
        expect(colorOf(add(c, d))).not.toBe(colorOf(c));
        expect([0, 1, 2]).toContain(colorOf(c));
      }),
    );
  });
});

describe('sáu ghế và chiều kim đồng hồ (PLAN 3.3)', () => {
  const RING = 23;

  it('bảng ghế mục 3.3: ô góc và hướng tiến về tâm', () => {
    const expected: readonly [number, string, string][] = [
      [0, '0,23', '0,-1'],
      [1, '-23,23', '1,-1'],
      [2, '-23,0', '1,0'],
      [3, '0,-23', '0,1'],
      [4, '23,-23', '-1,1'],
      [5, '23,0', '-1,0'],
    ];
    for (const [seat, corner, forward] of expected) {
      expect(k(seatCorner(seat, RING))).toBe(corner);
      expect(k(toSeatFrame(DIR.N, seat))).toBe(forward);
    }
  });

  it('[verify #12] ghế 0..5 xếp theo chiều kim đồng hồ trên màn hình (định thức > 0)', () => {
    const pos = [0, 1, 2, 3, 4, 5].map((s) => worldPos(seatCorner(s, RING)));
    for (let i = 0; i < 6; i++) {
      const a = pos[i] as { x: number; z: number };
      const b = pos[(i + 1) % 6] as { x: number; z: number };
      expect(a.x * b.z - a.z * b.x).toBeGreaterThan(0);
    }
  });

  it('[verify #13] ghế 0 nằm đáy màn hình (x = 0, z > 0)', () => {
    const p = worldPos(seatCorner(0, RING));
    expect(p.x).toBeCloseTo(0, 9);
    expect(p.z).toBeGreaterThan(0);
  });

  it('[verify #14] đi 23 bước "tiến" từ góc ghế s thì tới tâm, với mọi ghế', () => {
    for (let seat = 0; seat < 6; seat++) {
      expect(add(seatCorner(seat, RING), toSeatFrame(DIR.N, seat), RING)).toEqual(ORIGIN);
    }
  });
});

describe('toạ độ thế giới 3D (PLAN 3.1, 6.6)', () => {
  it('worldPos theo công thức x = 1.5·s·q, z = √3·s·(r + q/2)', () => {
    const p = worldPos(cell(2, 1), 2);
    expect(p.x).toBeCloseTo(6, 9);
    expect(p.z).toBeCloseTo(Math.sqrt(3) * 2 * 2, 9);
  });

  it('pixelToCell(worldPos(c)) = c với cả 1801 ô, ở vài cỡ ô', () => {
    for (const size of [1, 1.3, 7.5]) {
      for (const c of cellsInRadius(24)) {
        const p = worldPos(c, size);
        expect(pixelToCell(p.x, p.z, size)).toEqual(c);
      }
    }
  });

  it('điểm lệch khỏi tâm ô trong bán kính nội tiếp vẫn chọn đúng ô', () => {
    const size = 1.3;
    const inradius = (Math.sqrt(3) / 2) * size;
    fc.assert(
      fc.property(anyCell, fc.double({ min: 0, max: 0.95, noNaN: true }), fc.double({ min: 0, max: 2 * Math.PI, noNaN: true }), (c, frac, angle) => {
        const p = worldPos(c, size);
        const x = p.x + Math.cos(angle) * frac * inradius;
        const z = p.z + Math.sin(angle) * frac * inradius;
        expect(pixelToCell(x, z, size)).toEqual(c);
      }),
    );
  });
});
