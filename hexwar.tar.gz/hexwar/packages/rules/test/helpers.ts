import {
  applyMove,
  assertValidState,
  cellKey,
  createPiece,
  legalMovesOfPiece,
  makeState,
  ring,
  type ActionResult,
  type Cell,
  type GameEvent,
  type GameEventType,
  type GameState,
  type MakeStateInit,
  type Move,
  type Piece,
  type PieceType,
  type Seat,
  type ValidateOptions,
} from '../src';

/** Chuỗi "q,r" để so sánh tập ô. */
export const k = (c: Cell): string => `${c.q},${c.r}`;

/** Tạo quân hoạt động tại (q, r). */
export function P(id: string, owner: Seat, type: PieceType, q: number, r: number): Piece {
  return createPiece(id, owner, type, { q, r });
}

/**
 * Tù binh của `owner` do `holder` giữ, nằm ở (q, r) (đặt quân giữ của `holder` cùng ô để thế cờ hợp lệ).
 * `armed` = true: tới hạn, holder có thể trưng dụng ở lượt kế (R-32) và nó bị loại cuối lượt đó (R-33).
 */
export function captive(id: string, owner: Seat, type: PieceType, q: number, r: number, holder: Seat, armed?: boolean): Piece {
  const piece: Piece = { ...createPiece(id, owner, type, { q, r }), status: 'captive', holder };
  return armed === undefined ? piece : { ...piece, armed };
}

/** Nước đi thường, hoặc trưng dụng tù binh nếu `conscript`. */
export function mv(pieceId: string, q: number, r: number, conscript = false): Move {
  return conscript ? { pieceId, to: { q, r }, conscript: true } : { pieceId, to: { q, r } };
}

/** Bước "bỏ qua" cho người tới lượt: Vua `k{ghế}` đi vào ô hợp lệ gần tâm nhất (không làm Vua trôi ra vòng sắp biến mất). */
export function idleMove(state: GameState): Move {
  const id = `k${String(state.turnSeat)}`;
  const moves = legalMovesOfPiece(state, id);
  const best = moves.reduce<Move | undefined>((acc, m) => (acc === undefined || ring(m.to) < ring(acc.to) ? m : acc), undefined);
  if (best === undefined) throw new Error(`Test: ${id} không có nước đi để "idle"`);
  return best;
}

export type Step = Move | 'idle';

/**
 * Áp dụng lần lượt các bước (mỗi nước phải hợp lệ với người tới lượt lúc đó, 'idle' = `idleMove`); mọi trạng thái
 * trung gian phải qua `assertValidState`. Trả về trạng thái cuối và toàn bộ sự kiện theo thứ tự.
 */
export function play(start: GameState, steps: readonly Step[], validate: ValidateOptions = { requireKings: false }): ActionResult {
  let state = start;
  const events: GameEvent[] = [];
  for (const step of steps) {
    const result = applyMove(state, step === 'idle' ? idleMove(state) : step);
    assertValidState(result.state, validate);
    state = result.state;
    events.push(...result.events);
  }
  return { state, events };
}

export function pieceOf(state: GameState, id: string): Piece | undefined {
  return state.pieces.find((p) => p.id === id);
}

/** Quân phải tồn tại (dùng trong khẳng định để có kiểu Piece thay vì Piece | undefined). */
export function need(state: GameState, id: string): Piece {
  const piece = pieceOf(state, id);
  if (piece === undefined) throw new Error(`Test: không thấy quân ${id}`);
  return piece;
}

export function eventsOf<T extends GameEventType>(events: readonly GameEvent[], type: T): Extract<GameEvent, { type: T }>[] {
  return events.filter((e): e is Extract<GameEvent, { type: T }> => e.type === type);
}

/** Danh sách kiểu sự kiện theo thứ tự (dễ so sánh chuỗi sự kiện). */
export const typesOf = (events: readonly GameEvent[]): GameEventType[] => events.map((e) => e.type);

export function stateOf(pieces: readonly Piece[], init: Omit<MakeStateInit, 'pieces'> = {}): GameState {
  return makeState({ ...init, pieces });
}

/** Các ô đích hợp lệ của một quân, dạng chuỗi "q,r" đã sắp xếp. */
export function targets(state: GameState, pieceId: string): string[] {
  return legalMovesOfPiece(state, pieceId)
    .map((m) => k(m.to))
    .sort();
}

/** Tập nước đi dạng chuỗi ổn định để so sánh: "pieceId>q,r". */
export function moveKeys(moves: readonly Move[]): string[] {
  return moves.map((m) => `${m.pieceId}>${k(m.to)}`).sort();
}

/** Khoá số của ô, dùng làm bộ chọn tính duy nhất trong fast-check. */
export const cellId = (c: Cell): number => cellKey(c);
