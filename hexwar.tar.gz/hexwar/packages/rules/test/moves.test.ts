// Nước đi của 7 loại quân (PLAN 4.3, R-20, R-21, R-22) và golden test thế cờ đầu (PLAN 3.4).
import { describe, expect, it } from 'vitest';
import {
  SEATS,
  cellsInRadius,
  configWith,
  defaultConfig,
  explainIllegal,
  legalMoves,
  legalMovesOfPiece,
  newGame,
  sameCell,
  type IllegalReason,
  type Move,
  type Seat,
} from '../src';
import { P, captive, k, moveKeys, stateOf, targets } from './helpers';

const opening = newGame(defaultConfig, SEATS, 1);

describe('golden: thế cờ đầu (PLAN 3.4: 57 nước đi ở cả 6 ghế)', () => {
  const byType = (seat: Seat): Record<string, number> => {
    const typeOf = new Map(opening.pieces.map((p) => [p.id, p.type]));
    const out: Record<string, number> = {};
    for (const m of legalMoves(opening, seat)) {
      const t = typeOf.get(m.pieceId) ?? '?';
      out[t] = (out[t] ?? 0) + 1;
    }
    return out;
  };

  it.each(SEATS)('ghế %i: Hậu 7, Vua 5, Hề 6, Xe 4, Tượng 12, Mã 12, Tốt 11 → 57', (seat) => {
    expect(byType(seat)).toEqual({ Q: 7, K: 5, J: 6, R: 4, B: 12, N: 12, P: 11 });
    expect(legalMoves(opening, seat)).toHaveLength(57);
  });

  it('[verify #25-26] số nước giống hệt nhau ở cả 6 ghế và không ghế nào bị kẹt', () => {
    const [first, ...rest] = SEATS.map(byType);
    for (const other of rest) expect(other).toEqual(first);
    expect(legalMoves(opening, 0).length).toBeGreaterThan(0);
  });

  it('[verify #27] không có nước ăn quân nào ở thế cờ đầu', () => {
    const occupied = new Set(opening.pieces.map((p) => k(p.cell)));
    for (const seat of SEATS) {
      for (const m of legalMoves(opening, seat)) expect(occupied.has(k(m.to))).toBe(false);
    }
  });

  it('mọi nước đi hợp lệ đều được explainIllegal chấp nhận, và mọi ô còn lại của ghế 0 bị từ chối có lý do', () => {
    const cells = cellsInRadius(24);
    for (const piece of opening.pieces.filter((p) => p.owner === 0)) {
      const legal = new Set(legalMovesOfPiece(opening, piece.id).map((m) => k(m.to)));
      for (const to of cells) {
        const reason = explainIllegal(opening, { pieceId: piece.id, to });
        if (legal.has(k(to))) expect(reason).toBeNull();
        else {
          expect(reason).not.toBeNull();
          expect(reason).not.toBe('NOT_ALLOWED');
        }
      }
    }
  });
});

describe('Tốt (P): 1 ô tiến/lùi vào ô trống, ăn chéo, không ăn thẳng', () => {
  it('trên bàn trống: chỉ 2 nước tiến/lùi dọc trục hướng-tâm của ghế', () => {
    const s = stateOf([P('p', 0, 'P', 0, 0)]);
    expect(targets(s, 'p')).toEqual(['0,-1', '0,1']);
  });

  it('bao quanh bằng 6 địch: chỉ ăn được 4 ô chéo, KHÔNG ăn thẳng tiến/lùi', () => {
    const ring6 = [P('n', 1, 'R', 0, -1), P('ne', 1, 'R', 1, -1), P('se', 1, 'R', 1, 0), P('s', 1, 'R', 0, 1), P('sw', 1, 'R', -1, 1), P('nw', 1, 'R', -1, 0)];
    const s = stateOf([P('p', 0, 'P', 0, 0), ...ring6]);
    expect(targets(s, 'p')).toEqual(['-1,0', '-1,1', '1,-1', '1,0']);
  });

  it('khung ghế xoay theo ghế: Tốt ghế 1 tiến dọc NE/SW và ăn chéo theo N, S, SE, NW', () => {
    expect(targets(stateOf([P('p', 1, 'P', 0, 0)]), 'p')).toEqual(['-1,1', '1,-1']);
    const ring6 = [P('n', 0, 'R', 0, -1), P('ne', 0, 'R', 1, -1), P('se', 0, 'R', 1, 0), P('s', 0, 'R', 0, 1), P('sw', 0, 'R', -1, 1), P('nw', 0, 'R', -1, 0)];
    const s = stateOf([P('p', 1, 'P', 0, 0), ...ring6]);
    expect(targets(s, 'p')).toEqual(['-1,0', '0,-1', '0,1', '1,0']);
  });

  it('không đi vào ô có quân mình, không ăn quân mình chéo', () => {
    const s = stateOf([P('p', 0, 'P', 0, 0), P('a', 0, 'R', 0, -1), P('b', 0, 'R', 1, -1)]);
    expect(targets(s, 'p')).toEqual(['0,1']);
  });

  it('R-22: không có nước đi đầu 2 ô', () => {
    const s = stateOf([P('p', 0, 'P', 0, 0)]);
    expect(targets(s, 'p')).not.toContain('0,-2');
    expect(targets(s, 'p')).not.toContain('0,2');
    expect(explainIllegal(s, { pieceId: 'p', to: { q: 0, r: -2 } })).toBe('OUT_OF_RANGE');
  });

  it('R-21: ở mép bàn thì không lùi ra ngoài', () => {
    const s = stateOf([P('p', 0, 'P', 0, 24)]);
    expect(targets(s, 'p')).toEqual(['0,23']);
  });
});

describe('Mã (N): nhảy 12 ô, bỏ qua quân chắn, ăn ở ô đến', () => {
  it('trên bàn trống có đúng 12 nước', () => {
    expect(targets(stateOf([P('n', 0, 'N', 0, 0)]), 'n')).toHaveLength(12);
  });

  it('nhảy qua quân chắn xung quanh; ăn địch ở ô đến, không đến ô có quân mình', () => {
    const around = [P('a', 0, 'R', 0, -1), P('b', 1, 'R', 1, -1), P('c', 0, 'R', 1, 0), P('d', 1, 'R', 0, 1), P('e', 0, 'R', -1, 1), P('f', 1, 'R', -1, 0)];
    const s = stateOf([P('n', 0, 'N', 0, 0), ...around, P('own', 0, 'P', 1, -3), P('foe', 1, 'P', 2, -3)]);
    const t = targets(s, 'n');
    expect(t).toHaveLength(11); // mất ô (1,-3) vì có quân mình
    expect(t).not.toContain('1,-3');
    expect(t).toContain('2,-3'); // ăn địch
  });

  it('R-21: không nhảy ra ngoài bàn', () => {
    const s = stateOf([P('n', 0, 'N', 0, 24)]);
    for (const t of targets(s, 'n')) {
      const [q, r] = t.split(',').map(Number) as [number, number];
      expect(Math.max(Math.abs(q), Math.abs(r), Math.abs(q + r))).toBeLessThanOrEqual(24);
    }
  });
});

describe('Vua (K): 1 bước theo 12 hướng', () => {
  it('trên bàn trống có 12 nước, đều cách 1 hoặc 2 ô', () => {
    expect(targets(stateOf([P('k', 0, 'K', 0, 0)]), 'k')).toHaveLength(12);
  });

  it('ăn địch, không đi vào quân mình, được đi vào ô đang bị đe doạ (R-14)', () => {
    const s = stateOf([P('k', 0, 'K', 0, 0), P('foe', 1, 'P', 0, -1), P('own', 0, 'P', 1, -1), P('guard', 1, 'R', 0, -5)]);
    const t = targets(s, 'k');
    expect(t).toContain('0,-1');
    expect(t).not.toContain('1,-1');
    expect(t).toHaveLength(11);
  });
});

describe('Xe (R): trượt 6 hướng cạnh, ≤ 9 ô', () => {
  it('trên bàn trống: 6 hướng × 9 ô = 54 nước; ô thứ 10 không tới được', () => {
    const t = targets(stateOf([P('r', 0, 'R', 0, 0)]), 'r');
    expect(t).toHaveLength(54);
    expect(t).toContain('0,-9');
    expect(t).not.toContain('0,-10');
  });

  it('R-20: quân mình chặn (dừng trước), địch chặn (ăn rồi dừng)', () => {
    const own = stateOf([P('r', 0, 'R', 0, 0), P('x', 0, 'P', 0, -3)]);
    expect(targets(own, 'r').filter((t) => t.startsWith('0,-'))).toEqual(['0,-1', '0,-2']);
    const foe = stateOf([P('r', 0, 'R', 0, 0), P('x', 1, 'P', 0, -3)]);
    expect(targets(foe, 'r').filter((t) => t.startsWith('0,-'))).toEqual(['0,-1', '0,-2', '0,-3']);
  });

  it('không đi theo hướng đỉnh (D-02: Xe chỉ có 6 hướng cạnh)', () => {
    const t = targets(stateOf([P('r', 0, 'R', 0, 0)]), 'r');
    for (const d of ['1,-2', '2,-1', '1,1', '-1,2', '-2,1', '-1,-1']) expect(t).not.toContain(d);
  });

  it('R-21: dừng ở biên bàn hiện tại', () => {
    const shrunk = stateOf([P('r', 0, 'R', 0, 0)], { radius: 5 });
    expect(targets(shrunk, 'r')).toHaveLength(30); // 6 hướng × 5 ô
    const edge = stateOf([P('r', 0, 'R', 0, 24)]);
    expect(targets(edge, 'r')).toContain('0,15');
    expect(targets(edge, 'r')).not.toContain('0,25');
  });
});

describe('Tượng (B): trượt 6 hướng đỉnh, ≤ 9 ô (4 bước nhảy)', () => {
  it('trên bàn trống: 6 hướng × 4 bước = 24 nước, gồm đường ngang zíc-zắc', () => {
    const t = targets(stateOf([P('b', 0, 'B', 0, 0)]), 'b');
    expect(t).toHaveLength(24);
    expect(t).toContain('2,-1'); // ngang phải
    expect(t).toContain('-8,4'); // ngang trái, 4 bước nhảy
    expect(t).not.toContain('-10,5'); // bước thứ 5 vượt tầm
  });

  it('R-20: hai ô trung gian (trên/dưới) của bước nhảy KHÔNG cản đường', () => {
    const s = stateOf([P('b', 0, 'B', 0, 0), P('up', 1, 'P', 1, -1), P('down', 0, 'P', 1, 0)]);
    expect(targets(s, 'b')).toContain('2,-1');
  });

  it('R-20: quân đứng ở ô đáp của một bước nhảy thì chặn các bước sau', () => {
    const s = stateOf([P('b', 0, 'B', 0, 0), P('x', 1, 'P', 4, -2)]);
    const east = targets(s, 'b').filter((t) => ['2,-1', '4,-2', '6,-3', '8,-4'].includes(t));
    expect(east).toEqual(['2,-1', '4,-2']); // ăn được (4,-2), không qua được
  });

  it('D-03: metric "hops" cho phép tới 9 bước nhảy', () => {
    const cfg = configWith({ reach: { metric: 'hops' } });
    const t = targets(stateOf([P('b', 0, 'B', 0, 0)], { config: cfg }), 'b');
    expect(t).toHaveLength(54); // 6 hướng × 9 bước nhảy (mỗi bước nhảy tăng ring 2, 9×2 = 18 ≤ 24)
    expect(t).toContain('18,-9');
  });
});

describe('Hậu (Q): 12 hướng, ≤ 9 ô', () => {
  it('trên bàn trống: 54 (cạnh) + 24 (đỉnh) = 78 nước', () => {
    expect(targets(stateOf([P('q', 0, 'Q', 0, 0)]), 'q')).toHaveLength(78);
  });

  it('trượt và bị chặn độc lập theo từng hướng', () => {
    const s = stateOf([P('q', 0, 'Q', 0, 0), P('x', 0, 'P', 0, -2), P('y', 1, 'P', 2, -1)]);
    const t = targets(s, 'q');
    expect(t).toContain('0,-1');
    expect(t).not.toContain('0,-2');
    expect(t).toContain('2,-1'); // ăn địch ở ô đáp của bước nhảy E
    expect(t).not.toContain('4,-2');
  });
});

describe('Hề (J): 12 hướng, ≤ 3 ô, không bao giờ ăn quân (R-50)', () => {
  it('trên bàn trống: 6 hướng cạnh × 3 + 6 hướng đỉnh × 1 = 24 nước', () => {
    expect(targets(stateOf([P('j', 0, 'J', 0, 0)]), 'j')).toHaveLength(24);
  });

  it('metric "hops": 12 hướng × 3 bước = 36 nước', () => {
    const cfg = configWith({ reach: { metric: 'hops' } });
    expect(targets(stateOf([P('j', 0, 'J', 0, 0)], { config: cfg }), 'j')).toHaveLength(36);
  });

  it('gặp địch thì dừng nhưng không ăn; gặp quân mình cũng dừng', () => {
    const s = stateOf([P('j', 0, 'J', 0, 0), P('foe', 1, 'Q', 0, -2), P('own', 0, 'P', 0, 2)]);
    const t = targets(s, 'j');
    expect(t).toContain('0,-1');
    expect(t).not.toContain('0,-2');
    expect(t).toContain('0,1');
    expect(t).not.toContain('0,2');
  });
});

describe('tù binh trong bản đồ ô (chuẩn bị cho M2)', () => {
  it('R-20: ô có quân giữ + tù binh: ăn được quân giữ, không đi xuyên qua', () => {
    const s = stateOf([P('r', 0, 'R', 0, 0), P('holder', 1, 'P', 0, -3), captive('c', 2, 'Q', 0, -3, 1)]);
    const north = targets(s, 'r').filter((t) => t.startsWith('0,-'));
    expect(north).toEqual(['0,-1', '0,-2', '0,-3']);
  });

  it('R-20: ô chỉ có tù binh (không quân giữ) vẫn chặn đường và không thể đáp xuống', () => {
    const s = stateOf([P('r', 0, 'R', 0, 0), captive('c', 2, 'Q', 0, -2, 1)]);
    expect(targets(s, 'r').filter((t) => t.startsWith('0,-'))).toEqual(['0,-1']);
    expect(explainIllegal(s, { pieceId: 'r', to: { q: 0, r: -2 } })).toBe('TARGET_BLOCKED');
    expect(explainIllegal(s, { pieceId: 'r', to: { q: 0, r: -3 } })).toBe('PATH_BLOCKED');
  });

  it('R-31: tù binh không đi được (chờ M2 cho phép trưng dụng)', () => {
    const s = stateOf([P('holder', 1, 'P', 3, 3), captive('c', 0, 'Q', 3, 3, 1)]);
    expect(legalMoves(s, 0)).toEqual([]);
    expect(legalMovesOfPiece(s, 'c')).toEqual([]);
    expect(explainIllegal(s, { pieceId: 'c', to: { q: 3, r: 4 } })).toBe('PIECE_IS_CAPTIVE');
  });
});

describe('explainIllegal: mã lý do (PLAN 10.1)', () => {
  const at = (q: number, r: number): { q: number; r: number } => ({ q, r });

  const cases: readonly [string, () => ReturnType<typeof stateOf>, Move, IllegalReason | null][] = [
    ['nước hợp lệ trả về null', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(0, -4) }, null],
    ['quân không tồn tại', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'zz', to: at(0, -1) }, 'UNKNOWN_PIECE'],
    ['cờ trưng dụng trên quân hoạt động', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(0, -1), conscript: true }, 'NOT_A_CAPTIVE'],
    ['ô đích ngoài bàn', () => stateOf([P('r', 0, 'R', 0, 24)]), { pieceId: 'r', to: at(0, 25) }, 'TARGET_OFF_BOARD'],
    ['ô đích không nguyên (dữ liệu rác)', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(0.5, 0) }, 'TARGET_OFF_BOARD'],
    ['ô đích NaN (dữ liệu rác)', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(Number.NaN, 0) }, 'TARGET_OFF_BOARD'],
    ['đứng yên', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(0, 0) }, 'SAME_CELL'],
    ['Tốt ăn thẳng', () => stateOf([P('p', 0, 'P', 0, 0), P('x', 1, 'P', 0, -1)]), { pieceId: 'p', to: at(0, -1) }, 'PAWN_CAPTURE_STRAIGHT'],
    ['Tốt đi chéo vào ô trống', () => stateOf([P('p', 0, 'P', 0, 0)]), { pieceId: 'p', to: at(1, -1) }, 'PAWN_DIAGONAL_NEEDS_CAPTURE'],
    ['Tốt tiến vào quân mình', () => stateOf([P('p', 0, 'P', 0, 0), P('x', 0, 'P', 0, -1)]), { pieceId: 'p', to: at(0, -1) }, 'TARGET_OWN_PIECE'],
    ['Tốt đi kiểu Mã', () => stateOf([P('p', 0, 'P', 0, 0)]), { pieceId: 'p', to: at(1, -3) }, 'BAD_DIRECTION'],
    ['Xe vượt tầm 9 ô', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(0, -10) }, 'OUT_OF_RANGE'],
    ['Xe đi hướng đỉnh', () => stateOf([P('r', 0, 'R', 0, 0)]), { pieceId: 'r', to: at(2, -1) }, 'BAD_DIRECTION'],
    ['Xe bị chặn giữa đường', () => stateOf([P('r', 0, 'R', 0, 0), P('x', 1, 'P', 0, -2)]), { pieceId: 'r', to: at(0, -4) }, 'PATH_BLOCKED'],
    ['Xe đáp vào quân mình', () => stateOf([P('r', 0, 'R', 0, 0), P('x', 0, 'P', 0, -3)]), { pieceId: 'r', to: at(0, -3) }, 'TARGET_OWN_PIECE'],
    ['Tượng đi hướng cạnh', () => stateOf([P('b', 0, 'B', 0, 0)]), { pieceId: 'b', to: at(0, -1) }, 'BAD_DIRECTION'],
    ['Tượng vượt 4 bước nhảy', () => stateOf([P('b', 0, 'B', 0, 0)]), { pieceId: 'b', to: at(10, -5) }, 'OUT_OF_RANGE'],
    ['Mã đi ô không phải nước nhảy', () => stateOf([P('n', 0, 'N', 0, 0)]), { pieceId: 'n', to: at(0, -2) }, 'BAD_DIRECTION'],
    ['Mã đáp vào quân mình', () => stateOf([P('n', 0, 'N', 0, 0), P('x', 0, 'P', 1, -3)]), { pieceId: 'n', to: at(1, -3) }, 'TARGET_OWN_PIECE'],
    ['Vua đi 2 bước theo hướng cạnh', () => stateOf([P('k', 0, 'K', 0, 0)]), { pieceId: 'k', to: at(0, -2) }, 'OUT_OF_RANGE'],
    ['Vua đi ô không thẳng hàng', () => stateOf([P('k', 0, 'K', 0, 0)]), { pieceId: 'k', to: at(1, -3) }, 'BAD_DIRECTION'],
    ['Hề cố ăn quân', () => stateOf([P('j', 0, 'J', 0, 0), P('x', 1, 'Q', 0, -2)]), { pieceId: 'j', to: at(0, -2) }, 'JESTER_CANNOT_CAPTURE'],
    ['Hề vượt 3 ô', () => stateOf([P('j', 0, 'J', 0, 0)]), { pieceId: 'j', to: at(0, -4) }, 'OUT_OF_RANGE'],
  ];

  it.each(cases)('%s', (_name, build, move, expected) => {
    expect(explainIllegal(build(), move)).toBe(expected);
  });

  it('chỉ Hề bị "JESTER_CANNOT_CAPTURE": Hậu cùng vị trí thì ăn được', () => {
    const s = stateOf([P('q', 0, 'Q', 0, 0), P('x', 1, 'Q', 0, -2)]);
    expect(explainIllegal(s, { pieceId: 'q', to: at(0, -2) })).toBeNull();
    expect(sameCell(legalMovesOfPiece(s, 'q').find((m) => k(m.to) === '0,-2')!.to, at(0, -2))).toBe(true);
  });

  it('moveKeys: legalMoves và moveKeys sắp xếp ổn định', () => {
    const s = stateOf([P('r', 0, 'R', 0, 0)]);
    const keys = moveKeys(legalMoves(s, 0));
    expect(keys).toEqual([...keys].sort());
    expect(keys[0]).toMatch(/^r>/);
  });
});
