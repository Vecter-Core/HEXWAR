// X-09 (PLAN mục 5): preset Cổ điển / Tiêu chuẩn / Nhanh chỉ đổi nhịp trận (đồng hồ + lịch thu hẹp co giãn).
import { describe, expect, it } from 'vitest';
import { applyPreset, collapseSchedule, defaultConfig, newGame, SEATS } from '../src';

describe('applyPreset (X-09)', () => {
  it('Cổ điển (roundScale = 1): chỉ khớp lại turn.seconds, lịch thu hẹp giữ nguyên hệt cấu hình gốc', () => {
    const c = applyPreset('classic');
    expect(c.turn.seconds).toBe(60);
    expect(c.collapse.rounds).toEqual(defaultConfig.collapse.rounds);
    expect(c.collapse.hardCapRound).toBe(defaultConfig.collapse.hardCapRound);
    expect(c.collapse.extension).toEqual(defaultConfig.collapse.extension);
  });

  it('Tiêu chuẩn: đồng hồ 45 giây, lịch thu hẹp co lại nhưng vẫn tăng chặt và có đủ 14 hiệp gốc', () => {
    const c = applyPreset('standard');
    expect(c.turn.seconds).toBe(45);
    expect(c.collapse.rounds).toHaveLength(defaultConfig.collapse.rounds.length);
    for (let i = 1; i < c.collapse.rounds.length; i++) expect(c.collapse.rounds[i]).toBeGreaterThan(c.collapse.rounds[i - 1] ?? 0);
    // Co giãn đúng hướng: mọi hiệp phải nhỏ hơn (hoặc bằng, ở đầu thang do chặn dưới) bản gốc.
    for (let i = 0; i < c.collapse.rounds.length; i++) expect(c.collapse.rounds[i]).toBeLessThanOrEqual(defaultConfig.collapse.rounds[i] ?? Infinity);
  });

  it('Nhanh: đồng hồ 30 giây, lịch co lại nhiều nhất trong ba preset', () => {
    const c = applyPreset('blitz');
    expect(c.turn.seconds).toBe(30);
    const lastBlitz = c.collapse.rounds[c.collapse.rounds.length - 1] ?? 0;
    const lastStandard = applyPreset('standard').collapse.rounds[c.collapse.rounds.length - 1] ?? 0;
    expect(lastBlitz).toBeLessThan(lastStandard);
  });

  it('hardCapRound luôn sau hiệp thu hẹp cuối cùng (kể cả phần kéo dài) — cấu hình vẫn hợp lệ vì đi qua configWith', () => {
    for (const name of ['classic', 'standard', 'blitz'] as const) {
      const c = applyPreset(name);
      const schedule = collapseSchedule(c.board.radius, c.collapse);
      const last = schedule[schedule.length - 1]?.round ?? 0;
      expect(c.collapse.hardCapRound).toBeGreaterThan(last);
    }
  });

  it('không đổi luật nào khác ngoài turn.seconds và collapse (đội hình, nước đi, tù binh, điểm... giữ nguyên)', () => {
    const c = applyPreset('blitz');
    expect(c.board).toEqual(defaultConfig.board);
    expect(c.reach).toEqual(defaultConfig.reach);
    expect(c.pawn).toEqual(defaultConfig.pawn);
    expect(c.captive).toEqual(defaultConfig.captive);
    expect(c.promotion).toEqual(defaultConfig.promotion);
    expect(c.score).toEqual(defaultConfig.score);
    expect(c.turn.afkTimeoutsBeforeBot).toBe(defaultConfig.turn.afkTimeoutsBeforeBot);
  });

  it('ván mới dựng được bình thường với cấu hình đã co giãn (không vỡ bất biến hình học)', () => {
    for (const name of ['classic', 'standard', 'blitz'] as const) {
      const state = newGame(applyPreset(name), SEATS, 1);
      expect(state.pieces).toHaveLength(108);
      expect(state.phase).toBe('dice');
    }
  });
});
