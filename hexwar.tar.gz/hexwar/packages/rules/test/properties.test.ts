// Kiểm thử thuộc tính (fast-check), PLAN mục 14: bất biến xoay và tính nhất quán legalMoves ⇔ explainIllegal.
import * as fc from 'fast-check';
import { describe, expect, it } from 'vitest';
import {
  SEATS,
  cellsInRadius,
  explainIllegal,
  legalMoves,
  legalMovesOfPiece,
  makeState,
  ring,
  rotate,
  type GameState,
  type Piece,
  type PieceType,
  type Seat,
} from '../src';
import { P, k } from './helpers';

const RADIUS = 12; // bàn nhỏ để quân dễ gặp nhau; luật không phụ thuộc kích thước bàn
const CELLS = cellsInRadius(RADIUS);
const PIECE_TYPES: readonly PieceType[] = ['P', 'N', 'B', 'R', 'Q', 'K', 'J'];

/** Thế cờ ngẫu nhiên: 3–40 quân đủ loại, đủ chủ, ở các ô khác nhau. */
const positionArb: fc.Arbitrary<Piece[]> = fc
  .uniqueArray(
    fc.tuple(
      fc.integer({ min: 0, max: CELLS.length - 1 }),
      fc.constantFrom<Seat>(...SEATS),
      fc.constantFrom<PieceType>(...PIECE_TYPES),
    ),
    { selector: ([cellIndex]) => cellIndex, minLength: 3, maxLength: 40 },
  )
  .map((specs) =>
    specs.map(([cellIndex, owner, type], i) => {
      const c = CELLS[cellIndex]!;
      return P(`x${i}`, owner, type, c.q, c.r);
    }),
  );

const stateFrom = (pieces: Piece[]): GameState => makeState({ pieces, radius: RADIUS });
const allMoveKeys = (state: GameState, seat: Seat, mapTo?: (q: number, r: number) => string): string[] =>
  legalMoves(state, seat)
    .map((m) => `${m.pieceId}>${mapTo ? mapTo(m.to.q, m.to.r) : k(m.to)}`)
    .sort();

describe('bất biến xoay 60° (PLAN 14)', () => {
  it('xoay cả thế cờ k × 60° (ghế s → s + k) thì tập nước đi cũng xoay đúng như vậy', () => {
    fc.assert(
      fc.property(positionArb, fc.integer({ min: 1, max: 5 }), (pieces, steps) => {
        const rotated = pieces.map((p) => ({
          ...p,
          owner: ((p.owner + steps) % 6) as Seat,
          cell: rotate(p.cell, steps),
        }));
        const before = stateFrom(pieces);
        const after = stateFrom(rotated);
        for (const seat of SEATS) {
          const expected = legalMoves(before, seat)
            .map((m) => `${m.pieceId}>${k(rotate(m.to, steps))}`)
            .sort();
          const actual = allMoveKeys(after, ((seat + steps) % 6) as Seat);
          expect(actual).toEqual(expected);
        }
      }),
      { numRuns: 80 },
    );
  });
});

describe('legalMoves ⇔ explainIllegal (PLAN 6.5)', () => {
  it('với mọi quân và mọi ô: hợp lệ ⇔ explainIllegal = null; bị từ chối thì có lý do cụ thể (không NOT_ALLOWED)', () => {
    fc.assert(
      fc.property(positionArb, (pieces) => {
        const state = stateFrom(pieces);
        for (const piece of pieces) {
          const legal = new Set(legalMovesOfPiece(state, piece.id).map((m) => k(m.to)));
          for (const to of CELLS) {
            const reason = explainIllegal(state, { pieceId: piece.id, to });
            if (legal.has(k(to))) {
              expect(reason).toBeNull();
            } else {
              expect(reason).not.toBeNull();
              expect(reason).not.toBe('NOT_ALLOWED');
            }
          }
        }
      }),
      { numRuns: 25 },
    );
  });

  it('ô ngoài bàn luôn bị từ chối với TARGET_OFF_BOARD', () => {
    fc.assert(
      fc.property(positionArb, fc.integer({ min: RADIUS + 1, max: 30 }), fc.integer({ min: -30, max: 30 }), (pieces, q, r) => {
        const state = stateFrom(pieces);
        const to = { q, r };
        fc.pre(ring(to) > RADIUS);
        for (const piece of pieces) expect(explainIllegal(state, { pieceId: piece.id, to })).toBe('TARGET_OFF_BOARD');
      }),
      { numRuns: 30 },
    );
  });
});

describe('bất biến của nước đi hợp lệ', () => {
  it('đích luôn nằm trên bàn, khác ô xuất phát, không có quân mình; không có nước ăn của Hề; số nước tất định', () => {
    fc.assert(
      fc.property(positionArb, fc.constantFrom<Seat>(...SEATS), (pieces, seat) => {
        const state = stateFrom(pieces);
        const byId = new Map(pieces.map((p) => [p.id, p]));
        const at = new Map(pieces.map((p) => [k(p.cell), p]));
        const moves = legalMoves(state, seat);
        for (const m of moves) {
          const piece = byId.get(m.pieceId)!;
          expect(piece.owner).toBe(seat);
          expect(ring(m.to)).toBeLessThanOrEqual(RADIUS);
          expect(k(m.to)).not.toBe(k(piece.cell));
          const occupant = at.get(k(m.to));
          if (occupant !== undefined) {
            expect(occupant.owner).not.toBe(seat);
            expect(piece.type).not.toBe('J');
          }
        }
        expect(legalMoves(state, seat)).toEqual(moves);
        expect(new Set(moves.map((m) => `${m.pieceId}>${k(m.to)}`)).size).toBe(moves.length);
      }),
      { numRuns: 60 },
    );
  });
});
