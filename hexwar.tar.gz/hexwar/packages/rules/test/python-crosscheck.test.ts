// Đối chiếu độc lập với bản Python: fixture do tools/gen_golden.py sinh từ tools/verify_board.py.
// Hai bên được viết riêng nên trùng khớp từng nước đi ở thế cờ đầu của cả 6 ghế là bằng chứng mạnh.
import { describe, expect, it } from 'vitest';
import { SEATS, defaultConfig, legalMoves, newGame, type Seat } from '../src';
import fixture from './fixtures/initial-moves.json';
import { k } from './helpers';

const state = newGame(defaultConfig, SEATS, 1);
const typeOf = new Map(state.pieces.map((p) => [p.id, p.type]));
const cellOwner = new Map(state.pieces.map((p) => [k(p.cell), p.owner]));

describe('đối chiếu với tools/verify_board.py (fixture initial-moves.json)', () => {
  it('bán kính và số liệu tổng khớp', () => {
    expect(fixture.radius).toBe(defaultConfig.board.radius);
    expect(fixture.adjacentMinDistance).toBe(13);
    expect(fixture.oppositeMinDistance).toBe(41);
    expect(fixture.seat0MovesByType).toEqual({ B: 12, J: 6, K: 5, N: 12, P: 11, Q: 7, R: 4 });
  });

  it('108 quân: cùng ghế, loại và ô với bản Python', () => {
    const ts = state.pieces.map((p) => `${p.owner}|${p.type}|${k(p.cell)}`).sort();
    const py = (fixture.pieces as [number, string, number, number][]).map(([seat, type, q, r]) => `${seat}|${type}|${q},${r}`).sort();
    expect(py).toHaveLength(108);
    expect(ts).toEqual(py);
  });

  it.each(SEATS)('ghế %i: 57 nước đi, cùng (loại quân, ô đến, có ăn) với bản Python', (seat) => {
    const ts = legalMoves(state, seat as Seat)
      .map((m) => {
        const capture = cellOwner.has(k(m.to)) ? 1 : 0;
        return `${typeOf.get(m.pieceId)}|${k(m.to)}|${capture}`;
      })
      .sort();
    const py = (fixture.moves[String(seat) as keyof typeof fixture.moves] as [string, number, number, number][])
      .map(([type, q, r, capture]) => `${type}|${q},${r}|${capture}`)
      .sort();
    expect(py).toHaveLength(57);
    expect(ts).toEqual(py);
  });
});
