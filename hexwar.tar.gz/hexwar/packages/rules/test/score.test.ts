// M2: điểm và xếp hạng (PLAN R-82), băm trạng thái (PLAN 6.5, 14).
import { describe, expect, it } from 'vitest';
import { SEATS, configWith, defaultConfig, hash, newGame, rankPlayers, scoreOf, type Elimination } from '../src';
import { eliminatePlayer, isAlive, nextBatch, toDraft } from '../src/draft';
import { P, captive, mv, play, stateOf } from './helpers';
import { runGame } from './sim';

describe('R-82: điểm = giá trị quân còn lại + tổng kill', () => {
  it('giá trị P=1, N=3, B=3, R=5, Q=9, J=2, K=0 và mỗi kill +1', () => {
    const s = stateOf(
      [P('p', 0, 'P', 0, 0), P('n', 0, 'N', 1, 0), P('b', 0, 'B', 2, 0), P('r', 0, 'R', 3, 0), P('q', 0, 'Q', 4, 0), P('j', 0, 'J', 5, 0), P('k', 0, 'K', 6, 0)],
      { playerKills: [4, 0, 0, 0, 0, 0] },
    );
    expect(scoreOf(s, 0)).toBe(1 + 3 + 3 + 5 + 9 + 2 + 0 + 4);
  });

  it('tù binh tính cho chủ cũ, không tính cho người giữ (R-31)', () => {
    const s = stateOf([P('x', 0, 'R', 0, 0), captive('c', 1, 'Q', 0, 0, 0, true)], { seats: [0, 1] });
    expect(scoreOf(s, 0)).toBe(5);
    expect(scoreOf(s, 1)).toBe(9);
  });

  it('giá trị và điểm mỗi kill lấy từ cấu hình', () => {
    const config = configWith({ score: { Q: 10, perKill: 2 } });
    const s = stateOf([P('q', 0, 'Q', 0, 0)], { config, playerKills: [3, 0, 0, 0, 0, 0] });
    expect(scoreOf(s, 0)).toBe(10 + 6);
  });

  it('thế cờ đầu: mỗi ghế 9·1 + 2·5 + 2·3 + 2·3 + 9 + 2 + 0 = 42 điểm', () => {
    const s = newGame(defaultConfig, SEATS, 1);
    for (const seat of SEATS) expect(scoreOf(s, seat)).toBe(42);
  });

  // Bất biến này là lý do việc "chụp điểm trước khi loại cả đợt" ở shrink.ts (R-72) chỉ mang tính phòng thủ:
  // hiện tại điểm không phụ thuộc thứ tự loại. Đột biến bỏ phần chụp điểm (H05) là mutant tương đương; nếu
  // luật điểm đổi (vd. tù binh tính cho người giữ) thì test này đỏ và phần chụp điểm trở nên bắt buộc.
  it('R-31 + R-72: loại một người không đổi điểm của bất kỳ người nào khác (kể cả khi họ giữ/bị giữ tù binh)', () => {
    let checked = 0;
    let withCaptives = 0;
    for (const seed of [1, 2, 3, 4, 5, 6]) {
      for (const state of runGame(seed, defaultConfig, { sampleEvery: 1 }).samples) {
        if (state.pieces.some((p) => p.status === 'captive')) withCaptives++;
        for (const removed of state.order) {
          for (const other of state.order) {
            const d = toDraft(state);
            if (removed === other || !isAlive(d, removed) || !isAlive(d, other)) continue;
            const before = scoreOf(d, other);
            eliminatePlayer(d, removed, 'resign', nextBatch(d));
            expect(scoreOf(d, other), `seed ${seed}: loại ghế ${removed} đổi điểm ghế ${other}`).toBe(before);
            checked++;
          }
        }
      }
    }
    expect(checked).toBeGreaterThan(1000);
    expect(withCaptives).toBeGreaterThan(50); // có đủ thế cờ chứa tù binh để phép thử có ý nghĩa
  });
});

describe('R-82: xếp hạng', () => {
  const eliminated = (seat: 0 | 1 | 2 | 3 | 4 | 5, batch: number, score: number, round = batch): Elimination => ({
    seat,
    round,
    reason: 'king',
    batch,
    score,
  });

  it('người còn sống trên người bị loại; sống thì điểm cao hơn xếp trên; bị loại muộn hơn xếp cao hơn; cùng lúc thì so điểm; đồng hạng chia sẻ hạng', () => {
    const s = stateOf([P('q2', 2, 'Q', 0, 0), P('r0', 0, 'R', 3, 0)], {
      seats: [0, 1, 2, 3, 4, 5],
      eliminated: [eliminated(3, 1, 10), eliminated(4, 2, 2), eliminated(1, 3, 7), eliminated(5, 3, 7)],
      playerKills: [0, 0, 0, 0, 0, 0],
    });
    expect(rankPlayers(s).map((r) => [r.seat, r.rank])).toEqual([
      [2, 1], // sống, 9 điểm
      [0, 2], // sống, 5 điểm
      [1, 3], // bị loại ở batch 3, 7 điểm
      [5, 3], // đồng hạng với ghế 1
      [4, 5], // batch 2
      [3, 6], // batch 1 (dù có 10 điểm)
    ]);
  });

  it('mỗi dòng có đủ thông tin cho màn kết quả: điểm, kill, số quân, hiệp bị loại', () => {
    const s = stateOf([P('q0', 0, 'Q', 0, 0), P('p0', 0, 'P', 1, 0)], {
      seats: [0, 1],
      eliminated: [eliminated(1, 1, 3, 12)],
      playerKills: [2, 5, 0, 0, 0, 0],
    });
    expect(rankPlayers(s)).toEqual([
      { seat: 0, rank: 1, alive: true, score: 9 + 1 + 2, kills: 2, pieces: 2, eliminatedRound: null },
      { seat: 1, rank: 2, alive: false, score: 3, kills: 5, pieces: 0, eliminatedRound: 12 },
    ]);
  });

  it('người bị loại ghi điểm tại thời điểm bị loại (không phải điểm hiện tại)', () => {
    const s = stateOf([P('k0', 0, 'K', -20, 20), P('r0', 0, 'R', -3, 0), P('k1', 1, 'K', 0, 0), P('q1', 1, 'Q', 10, -10), P('k2', 2, 'K', 20, -20)], {
      seats: [0, 1, 2],
    });
    const { state } = play(s, [mv('r0', 0, 0)]);
    expect(state.eliminated).toEqual([{ seat: 1, round: 1, reason: 'king', batch: 1, score: 9 }]);
    expect(rankPlayers(state).find((r) => r.seat === 1)).toMatchObject({ alive: false, score: 9, pieces: 0 });
  });
});

describe('hash (PLAN 6.5, 14)', () => {
  const base = newGame(defaultConfig, SEATS, 9);

  it('cùng trạng thái → cùng hash, độ dài cố định 14 ký tự thập lục phân', () => {
    expect(hash(base)).toBe(hash(newGame(defaultConfig, SEATS, 9)));
    expect(hash(base)).toMatch(/^[0-9a-f]{14}$/);
  });

  it('không phụ thuộc thứ tự quân trong mảng', () => {
    expect(hash({ ...base, pieces: [...base.pieces].reverse() })).toBe(hash(base));
  });

  it.each<[string, () => typeof base]>([
    ['seed', () => ({ ...base, seed: 10 })],
    ['vị trí một quân', () => ({ ...base, pieces: base.pieces.map((p, i) => (i === 0 ? { ...p, cell: { q: p.cell.q + 1, r: p.cell.r } } : p)) })],
    ['kills một quân', () => ({ ...base, pieces: base.pieces.map((p, i) => (i === 0 ? { ...p, kills: 1 } : p)) })],
    ['trạng thái tù binh', () => ({ ...base, pieces: base.pieces.map((p, i) => (i === 0 ? { ...p, status: 'captive' as const, holder: 1 as const, armed: true } : p)) })],
    ['armed', () => ({ ...base, pieces: base.pieces.map((p, i) => (i === 0 ? { ...p, status: 'captive' as const, holder: 1 as const, armed: false } : p)) })],
    ['hiệp', () => ({ ...base, round: 1 })],
    ['người tới lượt', () => ({ ...base, turnSeat: 2 as const })],
    ['bán kính', () => ({ ...base, radius: 23 })],
    ['kill người chơi', () => ({ ...base, playerKills: [1, 0, 0, 0, 0, 0] })],
    ['danh sách bị loại', () => ({ ...base, eliminated: [{ seat: 3 as const, round: 1, reason: 'king' as const, batch: 1, score: 0 }] })],
    ['cấu hình luật', () => ({ ...base, config: configWith({ reach: { R: 8 } }) })],
  ])('hash đổi khi %s đổi', (_name, change) => {
    expect(hash(change())).not.toBe(hash(base));
  });
});
