// M2: thu hẹp bàn cờ, cảnh báo, hiệp giới hạn cứng (PLAN R-70, R-71, R-72, R-81, D-09) và các ca biên 4.10 liên quan.
import { describe, expect, it } from 'vitest';
import { configWith, defaultConfig, nextCollapse, upcomingCollapses, type Piece } from '../src';
import { P, captive, eventsOf, mv, need, pieceOf, play, stateOf, typesOf } from './helpers';

const kings = (): Piece[] => [P('k0', 0, 'K', -20, 20), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)];

/** Ba ghế, hiệp 49, ghế 2 (người đi cuối hiệp) tới lượt: sau nước đi của họ, hiệp 50 bắt đầu và vòng 24 biến mất. */
const beforeFirstCollapse = (pieces: readonly Piece[], init: Parameters<typeof stateOf>[1] = {}) =>
  stateOf(pieces, { seats: [0, 1, 2], round: 49, turnSeat: 2, ...init });

describe('R-70: vòng ngoài cùng biến mất ở đầu hiệp trong lịch', () => {
  it('hiệp 50: vòng 24 biến mất, bán kính còn 23; quân trên vòng bị loại, không ai được kill', () => {
    const s = beforeFirstCollapse([...kings(), P('a0', 0, 'R', 10, 14), P('a1', 1, 'N', 24, -12), P('b1', 1, 'P', 0, 23)]);
    // (10,14): hạng 24; (24,-12): hạng 24; (0,23): hạng 23 (còn lại)
    const { state, events } = play(s, ['idle']);
    expect(state).toMatchObject({ round: 50, radius: 23, turnSeat: 0 });
    expect(pieceOf(state, 'a0')).toBeUndefined();
    expect(pieceOf(state, 'a1')).toBeUndefined();
    expect(pieceOf(state, 'b1')).toBeDefined();
    expect(state.playerKills).toEqual([0, 0, 0, 0, 0, 0]);
    expect(eventsOf(events, 'RING_COLLAPSED')).toMatchObject([{ round: 50, ring: 24, radius: 23, removedPieceIds: ['a0', 'a1'] }]);
  });

  it('thứ tự sự kiện đúng 4.10: đi → hiệp mới → thu hẹp → lượt kế', () => {
    const s = beforeFirstCollapse(kings());
    expect(typesOf(play(s, ['idle']).events)).toEqual(['MOVED', 'ROUND_STARTED', 'RING_COLLAPSED', 'TURN_STARTED']);
  });

  it('ca biên 4.10: vòng biến mất có tù binh + người giữ → tất cả biến mất, không ai được kill', () => {
    const s = beforeFirstCollapse([...kings(), P('x0', 0, 'R', 0, 24), captive('y1', 1, 'N', 0, 24, 0, true)]);
    const { state, events } = play(s, ['idle']);
    expect(pieceOf(state, 'x0')).toBeUndefined();
    expect(pieceOf(state, 'y1')).toBeUndefined();
    expect(eventsOf(events, 'RING_COLLAPSED')[0]?.removedPieceIds).toEqual(['x0', 'y1']);
    expect(state.playerKills).toEqual([0, 0, 0, 0, 0, 0]);
    expect(state.eliminated).toEqual([]);
    expect(typesOf(events)).not.toContain('CAPTIVE_EXPIRED');
    expect(typesOf(events)).not.toContain('CAPTIVE_RELEASED');
  });

  it('R-70: Vua nằm trên vòng biến mất → người đó bị loại (lý do collapse), kể cả khi có Hề trong tầm (D-09 mặc định)', () => {
    const s = beforeFirstCollapse([P('k0', 0, 'K', 0, 24), P('j0', 0, 'J', 0, 21), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)]);
    const { state, events } = play(s, ['idle']);
    expect(state.eliminated).toMatchObject([{ seat: 0, round: 50, reason: 'collapse' }]);
    expect(pieceOf(state, 'j0')).toBeUndefined();
    expect(typesOf(events)).not.toContain('JESTER_REVIVED');
  });

  it('D-09 (jester.savesFromCollapse = true): Hề trong tầm 5 và còn trên bàn cứu Vua, hồi sinh tại ô Hề', () => {
    const config = configWith({ jester: { savesFromCollapse: true } });
    const s = beforeFirstCollapse([P('k0', 0, 'K', 0, 24), P('j0', 0, 'J', 0, 21), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)], { config });
    const { state, events } = play(s, ['idle']);
    expect(state.eliminated).toEqual([]);
    expect(need(state, 'k0').cell).toEqual({ q: 0, r: 21 });
    expect(pieceOf(state, 'j0')).toBeUndefined();
    expect(eventsOf(events, 'JESTER_REVIVED')).toMatchObject([{ owner: 0, cause: 'collapse', to: { q: 0, r: 21 } }]);
  });

  it('D-09 (bật): Hề xa hơn 5 ô, hoặc chính Hề cũng nằm trên vòng biến mất → không cứu được', () => {
    const config = configWith({ jester: { savesFromCollapse: true } });
    const far = beforeFirstCollapse([P('k0', 0, 'K', 0, 24), P('j0', 0, 'J', 0, 18), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)], { config });
    expect(play(far, ['idle']).state.eliminated).toMatchObject([{ seat: 0, reason: 'collapse' }]);
    const doomed = beforeFirstCollapse([P('k0', 0, 'K', 0, 24), P('j0', 0, 'J', 1, 23), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)], { config });
    expect(play(doomed, ['idle']).state.eliminated).toMatchObject([{ seat: 0, reason: 'collapse' }]);
  });

  it('R-35 + R-70: người giữ bị loại vì thu hẹp → tù binh ở ô còn tồn tại được thả; tù binh ở ô biến mất thì mất theo ô', () => {
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('x0', 0, 'R', 0, 20),
      captive('y1', 1, 'N', 0, 20, 0, true),
      P('x0b', 0, 'R', 24, 0),
      captive('y2', 2, 'B', 24, 0, 0, true),
      P('k1', 1, 'K', -20, 0),
      P('k2', 2, 'K', 20, -20),
    ]);
    const { state, events } = play(s, ['idle']);
    expect(state.eliminated).toMatchObject([{ seat: 0, reason: 'collapse' }]);
    expect(need(state, 'y1')).toMatchObject({ status: 'active', cell: { q: 0, r: 20 } });
    expect(pieceOf(state, 'y2')).toBeUndefined();
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'y1', cause: 'holder_eliminated' }]);
  });

  it('lịch kéo dài (D-07): hiệp 370 làm vòng 10 biến mất', () => {
    const s = stateOf([P('k0', 0, 'K', 0, 0), P('e0', 0, 'R', 0, 10), P('k1', 1, 'K', 0, -3)], {
      seats: [0, 1],
      round: 369,
      radius: 10,
      turnSeat: 1,
    });
    const { state, events } = play(s, ['idle']);
    expect(state).toMatchObject({ round: 370, radius: 9 });
    expect(eventsOf(events, 'RING_COLLAPSED')).toMatchObject([{ ring: 10, radius: 9, removedPieceIds: ['e0'] }]);
  });

  it('hiệp không nằm trong lịch: không thu hẹp', () => {
    const s = stateOf([...kings(), P('a0', 0, 'R', 0, 24)], { seats: [0, 1, 2], round: 50, turnSeat: 2 });
    const { state, events } = play(s, ['idle']);
    expect(state.radius).toBe(24);
    expect(typesOf(events)).not.toContain('RING_COLLAPSED');
    expect(pieceOf(state, 'a0')).toBeDefined();
  });
});

describe('R-10 + R-70: người mở hiệp bị loại vì thu hẹp', () => {
  it('ca biên 4.10: người mở hiệp bị loại → người còn sống kế tiếp mở hiệp, `round` vẫn là 50 (không tăng thêm)', () => {
    const s = beforeFirstCollapse([P('k0', 0, 'K', 0, 24), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)]);
    const { state, events } = play(s, ['idle']);
    expect(state).toMatchObject({ round: 50, opener: 1, turnSeat: 1, phase: 'playing' });
    expect(eventsOf(events, 'TURN_STARTED')).toMatchObject([{ seat: 1, round: 50 }]);
    expect(eventsOf(events, 'ROUND_STARTED')).toHaveLength(1);
  });
});

describe('R-72, R-82: thu hẹp loại nhiều người cùng lúc', () => {
  it('ca biên 4.10: tất cả bị loại cùng lúc → hoà, xếp hạng theo điểm', () => {
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('k1', 1, 'K', 24, -24),
      P('k2', 2, 'K', -24, 0),
      P('q0', 0, 'Q', 5, 5),
      P('r1', 1, 'R', -6, 3),
      P('n2', 2, 'N', 0, 0),
    ]);
    const { state, events } = play(s, [mv('n2', 1, -3)]);
    expect(state.phase).toBe('over');
    expect(state.turnSeat).toBeNull();
    expect(state.result).toMatchObject({ reason: 'allEliminated', winner: null });
    expect(state.result?.ranking.map((r) => [r.seat, r.rank, r.score])).toEqual([
      [0, 1, 9],
      [1, 2, 5],
      [2, 3, 3],
    ]);
    expect(new Set(state.eliminated.map((e) => e.batch)).size).toBe(1); // cùng một khoảnh khắc
    expect(typesOf(events).at(-1)).toBe('GAME_OVER');
    expect(typesOf(events)).not.toContain('TURN_STARTED');
  });

  it('R-82: đồng điểm khi bị loại cùng lúc → đồng hạng (1, 1, 3)', () => {
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('k1', 1, 'K', 24, -24),
      P('k2', 2, 'K', -24, 0),
      P('q0', 0, 'Q', 5, 5),
      P('q1', 1, 'Q', -6, 3),
      P('n2', 2, 'N', 0, 0),
    ]);
    const { state } = play(s, [mv('n2', 1, -3)]);
    expect(state.result?.ranking.map((r) => [r.seat, r.rank])).toEqual([
      [0, 1],
      [1, 1],
      [2, 3],
    ]);
  });

  it('R-72 (một phần): hai người bị loại cùng đợt, người còn lại thắng (R-80); hai người kia chung batch', () => {
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('k1', 1, 'K', 24, -24),
      P('k2', 2, 'K', 20, -20),
      P('q0', 0, 'Q', 5, 5),
    ]);
    const { state } = play(s, ['idle']);
    expect(state.result).toMatchObject({ reason: 'lastKing', winner: 2 });
    expect(state.eliminated.map((e) => e.batch)).toEqual([1, 1]);
    expect(state.result?.ranking.map((r) => r.seat)).toEqual([2, 0, 1]); // sống > bị loại; cùng batch: điểm 9 > 0
  });

  it('điểm khi bị loại chụp SAU khi quân trên vòng đã biến mất và TRƯỚC khi loại bất kỳ ai trong đợt (giả định, docs/questions.md)', () => {
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('q0', 0, 'Q', 1, 23), // hạng 24: biến mất cùng vòng nên không tính
      P('r0', 0, 'R', 5, 5),
      P('k1', 1, 'K', -20, 0),
      P('k2', 2, 'K', 20, -20),
    ]);
    const { state } = play(s, ['idle']);
    expect(state.eliminated).toEqual([{ seat: 0, round: 50, reason: 'collapse', batch: 1, score: 5 }]);
  });

  it('R-31 + R-82: hai người bị loại cùng đợt, người này giữ tù binh của người kia → điểm của người kia vẫn gồm tù binh đó, dù thứ tự loại thế nào', () => {
    // Ghế 0 (Vua trên vòng 24) giữ Hậu c1 của ghế 1 (Vua cũng trên vòng 24) ở ô Xe r0. Ghế 2 đứng ngoài.
    const s = beforeFirstCollapse([
      P('k0', 0, 'K', 0, 24),
      P('r0', 0, 'R', 5, 5),
      captive('c1', 1, 'Q', 5, 5, 0, true),
      P('k1', 1, 'K', 24, -24),
      P('k2', 2, 'K', 20, -20),
    ]);
    const { state, events } = play(s, ['idle']);
    expect(state.eliminated).toEqual([
      { seat: 0, round: 50, reason: 'collapse', batch: 1, score: 5 }, // Xe
      { seat: 1, round: 50, reason: 'collapse', batch: 1, score: 9 }, // chỉ còn Hậu tù binh, vẫn là quân của ghế 1 (R-31)
    ]);
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ pieceId: 'c1', owner: 1, cause: 'holder_eliminated' }]);
    expect(pieceOf(state, 'c1')).toBeUndefined(); // được thả rồi mất theo chủ
    expect(state.result).toMatchObject({ reason: 'lastKing', winner: 2 });
    expect(state.result?.ranking.map((r) => r.seat)).toEqual([2, 1, 0]); // cùng batch: điểm 9 > 5
  });
});

describe('R-71: cảnh báo trước khi thu hẹp', () => {
  const base = stateOf(kings(), { seats: [0, 1, 2], round: 46, turnSeat: 2 });

  it('3 hiệp trước: vàng; 2 hiệp trước: vàng; 1 hiệp trước: đỏ; tới hiệp thì thu hẹp và hết cảnh báo', () => {
    const r47 = play(base, ['idle']);
    const r48 = play(r47.state, ['idle', 'idle', 'idle']);
    const r49 = play(r48.state, ['idle', 'idle', 'idle']);
    const r50 = play(r49.state, ['idle', 'idle', 'idle']);
    expect(eventsOf(r47.events, 'RING_WARNING')).toEqual([{ type: 'RING_WARNING', ring: 24, roundsLeft: 3, level: 'yellow' }]);
    expect(eventsOf(r48.events, 'RING_WARNING')).toEqual([{ type: 'RING_WARNING', ring: 24, roundsLeft: 2, level: 'yellow' }]);
    expect(eventsOf(r49.events, 'RING_WARNING')).toEqual([{ type: 'RING_WARNING', ring: 24, roundsLeft: 1, level: 'red' }]);
    expect(eventsOf(r50.events, 'RING_WARNING')).toEqual([]);
    expect(eventsOf(r50.events, 'RING_COLLAPSED')).toHaveLength(1);
    expect(r50.state.round).toBe(50);
  });

  it('4 hiệp trước chưa cảnh báo', () => {
    const r46 = play(stateOf(kings(), { seats: [0, 1, 2], round: 45, turnSeat: 2 }), ['idle']);
    expect(eventsOf(r46.events, 'RING_WARNING')).toEqual([]);
  });

  it('upcomingCollapses / nextCollapse cho HUD: đếm ngược và mức cảnh báo', () => {
    const at = (round: number) => nextCollapse({ config: defaultConfig, round });
    expect(at(0)).toMatchObject({ roundsLeft: 50, level: null, event: { round: 50, ring: 24 } });
    expect(at(46)).toMatchObject({ roundsLeft: 4, level: null });
    expect(at(47)).toMatchObject({ roundsLeft: 3, level: 'yellow' });
    expect(at(48)).toMatchObject({ roundsLeft: 2, level: 'yellow' });
    expect(at(49)).toMatchObject({ roundsLeft: 1, level: 'red' });
    expect(at(50)).toMatchObject({ roundsLeft: 60, event: { round: 110, ring: 23 } });
    expect(upcomingCollapses({ config: defaultConfig, round: 0 })).toHaveLength(21);
    expect(nextCollapse({ config: defaultConfig, round: 430 })).toBeUndefined();
  });

  it('ngưỡng cảnh báo lấy từ cấu hình', () => {
    const config = configWith({ collapse: { warn: { yellowRoundsBefore: 5, redRoundsBefore: 2 } } });
    const levels = [44, 45, 46, 47, 48, 49].map((round) => nextCollapse({ config, round })?.level);
    expect(levels).toEqual([null, 'yellow', 'yellow', 'yellow', 'red', 'red']);
  });

  it('nhiều vòng cùng nằm trong vùng cảnh báo → mỗi vòng một sự kiện, gần nhất trước', () => {
    // Lịch dày: vòng 24 ở hiệp 50, vòng 23 ở hiệp 51, vòng 22 ở hiệp 52, ...
    const rounds = Array.from({ length: 14 }, (_, i) => 50 + i);
    const config = configWith({ collapse: { rounds, extension: { firstRound: 70 } } });
    const s = stateOf(kings(), { seats: [0, 1, 2], round: 48, turnSeat: 2, config });
    const warnings = eventsOf(play(s, ['idle']).events, 'RING_WARNING'); // bắt đầu hiệp 49
    expect(warnings).toEqual([
      { type: 'RING_WARNING', ring: 24, roundsLeft: 1, level: 'red' },
      { type: 'RING_WARNING', ring: 23, roundsLeft: 2, level: 'yellow' },
      { type: 'RING_WARNING', ring: 22, roundsLeft: 3, level: 'yellow' },
    ]);
  });
});

describe('R-81: hiệp giới hạn cứng', () => {
  const late = (second: 'Q' | 'R', round = 449) =>
    stateOf([P('k0', 0, 'K', 0, 0), P('q0', 0, 'Q', -3, 3), P('k1', 1, 'K', 2, 0), P('x1', 1, second, 3, -3)], {
      seats: [0, 1],
      round,
      radius: 3,
      turnSeat: 1,
    });

  it('bắt đầu hiệp 450: ván kết thúc, xếp hạng theo điểm; điểm cao nhất duy nhất thì thắng', () => {
    const { state, events } = play(late('R'), ['idle']);
    expect(state).toMatchObject({ phase: 'over', round: 450, turnSeat: null });
    expect(state.result).toMatchObject({ reason: 'hardCap', winner: 0 });
    expect(state.result?.ranking.map((r) => [r.seat, r.rank, r.score, r.alive])).toEqual([
      [0, 1, 9, true],
      [1, 2, 5, true],
    ]);
    expect(typesOf(events)).toEqual(['MOVED', 'ROUND_STARTED', 'GAME_OVER']);
  });

  it('đồng điểm cao nhất → không có người thắng, đồng hạng nhất', () => {
    const { state } = play(late('Q'), ['idle']);
    expect(state.result).toMatchObject({ reason: 'hardCap', winner: null });
    expect(state.result?.ranking.map((r) => r.rank)).toEqual([1, 1]);
  });

  it('hiệp 449 vẫn chơi bình thường (hiệp 450 mới kết thúc)', () => {
    const { state, events } = play(late('R', 448), ['idle']);
    expect(state).toMatchObject({ phase: 'playing', round: 449, turnSeat: 0 });
    expect(typesOf(events)).not.toContain('GAME_OVER');
  });

  it('hardCapRound lấy từ cấu hình', () => {
    const config = configWith({ collapse: { rounds: [50], extension: { enabled: false }, hardCapRound: 100 } });
    const s = stateOf(kings(), { seats: [0, 1, 2], round: 99, radius: 23, turnSeat: 2, config });
    expect(play(s, ['idle']).state.result).toMatchObject({ reason: 'hardCap' });
  });
});
