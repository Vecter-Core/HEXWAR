// Công cụ mô phỏng cho test: chơi ngẫu nhiên có seed, kiểm tra bất biến sau MỌI nước đi, xoay cả thế cờ.
import {
  SEATS,
  applyMove,
  assertValidState,
  createRng,
  hash,
  legalMoves,
  newGame,
  rollDice,
  rotate,
  type ActionResult,
  type GameEvent,
  type GameState,
  type Move,
  type Piece,
  type RulesConfig,
  type Rng,
  type Seat,
} from '../src';

/** Quân hoạt động đang đứng ở ô đích của nước đi (nếu có). */
export function targetOf(state: GameState, move: Move): Piece | undefined {
  return state.pieces.find((p) => p.status === 'active' && p.cell.q === move.to.q && p.cell.r === move.to.r);
}

/** Nước đi là nước ăn quân khi ô đích có quân hoạt động không thuộc người đi. */
export function isCapture(state: GameState, move: Move): boolean {
  const target = targetOf(state, move);
  return target !== undefined && target.owner !== state.turnSeat;
}

function pick<T>(items: readonly T[], rng: Rng): T {
  const item = items[rng.int(items.length)];
  if (item === undefined) throw new Error('pick: danh sách rỗng');
  return item;
}

/**
 * Chọn nước đi ngẫu nhiên nhưng thiên về hành động có ý nghĩa để ván có kill, tù binh, trưng dụng, phong cấp:
 * ăn Vua nếu được (95%), trưng dụng tù binh (50%), ăn quân (`captureBias`), còn lại đều ngẫu nhiên.
 */
export function chooseMove(state: GameState, rng: Rng, captureBias = 0.5): Move {
  const moves = legalMoves(state, state.turnSeat as Seat);
  if (moves.length === 0) throw new Error('chooseMove: người tới lượt không có nước đi (R-13 lẽ ra đã bỏ lượt)');
  const kingHits = moves.filter((m) => targetOf(state, m)?.type === 'K');
  if (kingHits.length > 0 && rng.next() < 0.95) return pick(kingHits, rng);
  const conscripts = moves.filter((m) => m.conscript === true);
  if (conscripts.length > 0 && rng.next() < 0.5) return pick(conscripts, rng);
  const captures = moves.filter((m) => isCapture(state, m));
  if (captures.length > 0 && rng.next() < captureBias) return pick(captures, rng);
  return pick(moves, rng);
}

export interface GameRecord {
  readonly seed: number;
  readonly final: GameState;
  readonly events: readonly GameEvent[];
  /** Hash sau mỗi nước đi (dùng so tính tất định). */
  readonly trace: readonly string[];
  readonly turns: number;
  /** Các trạng thái đã đi qua, thưa (mỗi `sampleEvery` nước) để test thuộc tính. */
  readonly samples: readonly GameState[];
}

export interface RunOptions {
  readonly maxTurns?: number;
  readonly captureBias?: number;
  readonly sampleEvery?: number;
  /** Gọi trước mỗi nước đi, để test bổ sung khẳng định riêng. */
  readonly onTurn?: (state: GameState, move: Move) => void;
}

/** Ván hoàn chỉnh: newGame → rollDice(seed) → chơi tới khi kết thúc. Kiểm bất biến sau mỗi bước. */
export function runGame(seed: number, config: RulesConfig, options: RunOptions = {}): GameRecord {
  const maxTurns = options.maxTurns ?? 20_000;
  const rng = createRng(seed ^ 0x9e3779b9);
  const events: GameEvent[] = [];
  const trace: string[] = [];
  const samples: GameState[] = [];

  const start = rollDice(newGame(config, SEATS, seed), createRng(seed));
  assertValidState(start.state);
  let state = start.state;
  events.push(...start.events);

  let turns = 0;
  while (state.phase === 'playing') {
    if (turns >= maxTurns) throw new Error(`Ván seed=${seed} chưa kết thúc sau ${maxTurns} nước`);
    const move = chooseMove(state, rng, options.captureBias);
    options.onTurn?.(state, move);
    const result: ActionResult = applyMove(state, move);
    assertValidState(result.state);
    assertMonotone(state, result.state);
    events.push(...result.events);
    trace.push(hash(result.state));
    if (options.sampleEvery !== undefined && turns % options.sampleEvery === 0) samples.push(result.state);
    state = result.state;
    turns++;
  }
  return { seed, final: state, events, trace, turns, samples };
}

/** Những đại lượng chỉ đổi theo một chiều qua mọi hành động. */
export function assertMonotone(before: GameState, after: GameState): void {
  if (after.pieces.length > before.pieces.length) throw new Error('số quân tăng');
  if (after.round < before.round) throw new Error('round giảm');
  if (after.radius > before.radius) throw new Error('bán kính tăng');
  if (after.eliminated.length < before.eliminated.length) throw new Error('số người bị loại giảm');
  after.playerKills.forEach((kills, seat) => {
    if (kills < (before.playerKills[seat] ?? 0)) throw new Error(`playerKills[${seat}] giảm`);
  });
  const alive = new Set(before.order.filter((s) => !before.eliminated.some((e) => e.seat === s)));
  for (const e of after.eliminated) alive.delete(e.seat);
  if (after.phase === 'playing' && after.turnSeat !== null && !alive.has(after.turnSeat)) throw new Error('người tới lượt không còn sống');
}

// ---- Xoay cả thế cờ (bất biến xoay, PLAN 14) ---------------------------------------------------------------------

const rotSeat = (seat: Seat, steps: number): Seat => ((seat + steps) % 6) as Seat;

/** Xoay toàn bộ thế cờ `steps` × 60°: ô xoay theo chiều kim đồng hồ, ghế s → s + steps. */
export function rotateState(state: GameState, steps: number): GameState {
  const kills = new Array<number>(6).fill(0);
  state.playerKills.forEach((k, seat) => {
    kills[(seat + steps) % 6] = k;
  });
  const orNull = (seat: Seat | null): Seat | null => (seat === null ? null : rotSeat(seat, steps));
  return {
    ...state,
    order: state.order.map((s) => rotSeat(s, steps)),
    opener: orNull(state.opener),
    turnSeat: orNull(state.turnSeat),
    playerKills: kills,
    eliminated: state.eliminated.map((e) => ({ ...e, seat: rotSeat(e.seat, steps) })),
    pieces: state.pieces.map((p) => ({
      ...p,
      owner: rotSeat(p.owner, steps),
      cell: rotate(p.cell, steps),
      ...(p.holder !== undefined ? { holder: rotSeat(p.holder, steps) } : {}),
    })),
  };
}

export function rotateMove(move: Move, steps: number): Move {
  const to = rotate(move.to, steps);
  return move.conscript === true ? { pieceId: move.pieceId, to, conscript: true } : { pieceId: move.pieceId, to };
}

/** Chiếu trạng thái thành dữ liệu so sánh được (không phụ thuộc thứ tự mảng quân, không dính -0). */
export function project(state: GameState) {
  return {
    phase: state.phase,
    round: state.round,
    radius: state.radius,
    order: [...state.order],
    opener: state.opener,
    turnSeat: state.turnSeat,
    playerKills: [...state.playerKills],
    eliminated: state.eliminated.map((e) => `${e.seat},${e.round},${e.reason},${e.batch},${e.score}`),
    pieces: [...state.pieces]
      .sort((a, b) => (a.id < b.id ? -1 : 1))
      .map((p) => `${p.id},${p.owner},${p.type},${p.origin},${p.cell.q},${p.cell.r},${p.kills},${p.status},${p.holder ?? '-'},${p.armed ?? '-'}`),
  };
}
