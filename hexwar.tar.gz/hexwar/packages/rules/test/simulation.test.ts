// M2: ván mô phỏng ngẫu nhiên chạy trọn không lỗi (PLAN mục 15, tiêu chí nghiệm thu M2), tính tất định (mục 14),
// khớp giữa `checkMove` và `legalMoves`, bất biến xoay của `applyMove`.
import { describe, expect, it } from 'vitest';
import { applyMove, checkMove, configWith, createRng, defaultConfig, legalMoves, rankPlayers, type GameEventType, type Seat } from '../src';
import { chooseMove, project, rotateMove, rotateState, runGame, type GameRecord } from './sim';

/**
 * Bàn nhỏ R=16 với lịch thu hẹp thưa hơn mặc định nhưng đủ dày để ván nào cũng có giao tranh rồi mới thu hẹp:
 * các quân gặp nhau sớm hơn ở R=24 (khoảng cách hai ghế kề chỉ còn 5), nên ván có nhiều kill, tù binh, trưng dụng.
 */
const small = {
  board: { radius: 16, seatCornerRing: 15 },
  collapse: { rounds: [20, 45, 70, 95, 120, 145, 170, 195, 220, 245], extension: { firstRound: 270, every: 25 }, hardCapRound: 500 },
};

const configs = {
  'luật chuẩn R=24 (rules.config.json)': defaultConfig,
  'bàn R=16, lịch thu hẹp thưa': configWith(small),
  'bàn R=16, phong cấp dễ (1/2/3/4 kill)': configWith({ ...small, promotion: { N: 1, B: 2, R: 3, Q: 4 } }),
  'bàn R=16, biến thể: tù binh nằm im, không giải cứu, Hề cứu khỏi thu hẹp, kill không tích luỹ': configWith({
    ...small,
    captive: { conscript: false, rescueByOwner: false },
    jester: { savesFromCollapse: true },
    promotion: { cumulativeKills: false },
  }),
};
type ConfigName = keyof typeof configs;

const SEEDS = [1, 2, 3, 4, 5, 6, 7, 8];
const games = new Map<ConfigName, GameRecord[]>();
const gamesOf = (name: ConfigName): GameRecord[] => {
  let list = games.get(name);
  if (list === undefined) {
    list = SEEDS.map((seed) => runGame(seed, configs[name], { sampleEvery: 6 }));
    games.set(name, list);
  }
  return list;
};

describe.each(Object.keys(configs) as ConfigName[])('ván ngẫu nhiên: %s', (name) => {
  it('chạy trọn tới khi kết thúc, không lỗi, bất biến đúng sau mọi nước đi (runGame kiểm từng bước)', () => {
    for (const game of gamesOf(name)) {
      expect(game.final.phase, `seed ${game.seed}`).toBe('over');
      expect(game.final.result, `seed ${game.seed}`).toBeDefined();
      expect(game.turns).toBeGreaterThan(50);
    }
  });

  it('kết quả nhất quán: lý do, người thắng, xếp hạng', () => {
    for (const { final, seed } of gamesOf(name)) {
      const result = final.result;
      if (result === undefined) throw new Error(`seed ${seed}: thiếu result`);
      const alive = final.order.filter((s) => !final.eliminated.some((e) => e.seat === s));
      expect(result.ranking, `seed ${seed}`).toHaveLength(6);
      expect(result.ranking).toEqual(rankPlayers(final));
      if (result.reason === 'lastKing') {
        expect(alive).toHaveLength(1);
        expect(result.winner).toBe(alive[0]);
      } else if (result.reason === 'allEliminated') {
        expect(alive).toHaveLength(0);
        expect(result.winner).toBeNull();
      } else {
        expect(alive.length).toBeGreaterThanOrEqual(2);
        expect(final.round).toBe(final.config.collapse.hardCapRound);
      }
      const winners = result.ranking.filter((r) => r.rank === 1);
      expect(result.winner === null ? true : winners.length === 1 && winners[0]?.seat === result.winner).toBe(true);
    }
  });

  it('dòng sự kiện hợp lý: hiệp tăng dần từng đơn vị, mỗi lượt của người còn sống, kết thúc bằng GAME_OVER', () => {
    for (const { events, seed } of gamesOf(name)) {
      const rounds = events.flatMap((e) => (e.type === 'ROUND_STARTED' ? [e.round] : []));
      expect(rounds, `seed ${seed}`).toEqual(rounds.map((_, i) => i + 1));
      expect(events.at(-1)?.type).toBe('GAME_OVER');
      expect(events.filter((e) => e.type === 'GAME_OVER')).toHaveLength(1);
      const dead = new Set<Seat>();
      for (const e of events) {
        if (e.type === 'PLAYER_ELIMINATED') dead.add(e.seat);
        if (e.type === 'TURN_STARTED') expect(dead.has(e.seat), `seed ${seed}: lượt của người đã bị loại`).toBe(false);
        if (e.type === 'MOVED') expect(dead.has(e.seat)).toBe(false);
      }
    }
  });

  it('tất định: chạy lại cùng seed cho cùng chuỗi hash và cùng sự kiện', () => {
    const [first] = gamesOf(name);
    if (first === undefined) throw new Error('không có ván');
    const again = runGame(first.seed, configs[name]);
    expect(again.trace).toEqual(first.trace);
    expect(again.events).toEqual(first.events);
  });
});

describe('độ phủ sự kiện qua các ván mô phỏng', () => {
  const seen = (): Set<GameEventType> => new Set(Object.keys(configs).flatMap((n) => gamesOf(n as ConfigName).flatMap((g) => g.events.map((e) => e.type))));

  it('mọi loại sự kiện quan trọng đã xảy ra ít nhất một lần', () => {
    const required: GameEventType[] = [
      'DICE_ROLLED',
      'ROUND_STARTED',
      'TURN_STARTED',
      'MOVED',
      'CAPTURED',
      'CAPTIVE_CREATED',
      'CAPTIVE_EXPIRED',
      'CAPTIVE_CONSCRIPTED',
      'PROMOTED',
      'KING_CAPTURED',
      'PLAYER_ELIMINATED',
      'RING_WARNING',
      'RING_COLLAPSED',
      'GAME_OVER',
    ];
    const types = seen();
    for (const type of required) expect(types.has(type), `thiếu sự kiện ${type}`).toBe(true);
  });
});

describe('checkMove khớp legalMoves trên các thế cờ thật', () => {
  it('mọi nước hợp lệ được chấp nhận; nước ngẫu nhiên khác bị từ chối với lý do cụ thể (không NOT_ALLOWED)', () => {
    const rng = createRng(4242);
    let checked = 0;
    for (const game of gamesOf('bàn R=16, lịch thu hẹp thưa')) {
      for (const state of game.samples) {
        if (state.phase !== 'playing') continue;
        const seat = state.turnSeat as Seat;
        const legal = legalMoves(state, seat);
        const legalKeys = new Set(legal.map((m) => `${m.pieceId}>${m.to.q},${m.to.r}>${m.conscript === true}`));
        for (const move of legal) expect(checkMove(state, seat, move)).toBeNull();
        for (let i = 0; i < 40; i++) {
          const piece = state.pieces[rng.int(state.pieces.length)];
          if (piece === undefined) continue;
          const to = { q: rng.int(2 * state.radius + 1) - state.radius, r: rng.int(2 * state.radius + 1) - state.radius };
          const conscript = piece.status === 'captive' && rng.next() < 0.5;
          const move = conscript ? { pieceId: piece.id, to, conscript: true as const } : { pieceId: piece.id, to };
          const reason = checkMove(state, seat, move);
          const isLegal = legalKeys.has(`${move.pieceId}>${to.q},${to.r}>${conscript}`);
          expect(reason === null, `seed ${game.seed} vòng ${state.round}`).toBe(isLegal);
          expect(reason).not.toBe('NOT_ALLOWED');
          checked++;
        }
      }
    }
    expect(checked).toBeGreaterThan(500);
  });
});

describe('bất biến xoay của applyMove (PLAN 14)', () => {
  it('xoay cả thế cờ k × 60° rồi đi nước tương ứng cho ra đúng thế cờ xoay của kết quả gốc', () => {
    const rng = createRng(99);
    let compared = 0;
    for (const game of gamesOf('bàn R=16, lịch thu hẹp thưa')) {
      for (const state of game.samples) {
        if (state.phase !== 'playing') continue;
        const steps = 1 + rng.int(5);
        const rotated = rotateState(state, steps);

        const seat = state.turnSeat as Seat;
        const rotatedSeat = rotated.turnSeat as Seat;
        const key = (m: { pieceId: string; to: { q: number; r: number }; conscript?: boolean }) => `${m.pieceId}>${m.to.q},${m.to.r}>${m.conscript === true}`;
        expect(legalMoves(rotated, rotatedSeat).map(key).sort()).toEqual(legalMoves(state, seat).map((m) => key(rotateMove(m, steps))).sort());

        const move = chooseMove(state, rng);
        const original = applyMove(state, move);
        const mirrored = applyMove(rotated, rotateMove(move, steps));
        // R-36 chọn ô trống gần nhất theo (q, r) nhỏ hơn nên không đối xứng khi hoà: bỏ qua nước có thả tù binh.
        if (original.events.some((e) => e.type === 'CAPTIVE_RELEASED') || mirrored.events.some((e) => e.type === 'CAPTIVE_RELEASED')) continue;
        expect(project(rotateState(original.state, steps))).toEqual(project(mirrored.state));
        expect(mirrored.events.map((e) => e.type)).toEqual(original.events.map((e) => e.type));
        compared++;
      }
    }
    expect(compared).toBeGreaterThan(50);
  });
});
