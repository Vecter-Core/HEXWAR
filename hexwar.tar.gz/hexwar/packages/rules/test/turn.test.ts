// M2: xúc xắc, hiệp, lượt, hết giờ, đầu hàng, kiểm tra nước đi (PLAN R-01…R-03, R-10…R-14, R-33, R-61)
// và các ca biên 4.10 về người mở hiệp / hết giờ.
import { describe, expect, it } from 'vitest';
import {
  IllegalMoveError,
  SEATS,
  applyMove,
  checkMove,
  createRng,
  defaultConfig,
  hash,
  legalMoves,
  newGame,
  resign,
  rollDice,
  rollForFirst,
  timeoutTurn,
  type GameState,
  type Piece,
  type Rng,
  type Seat,
} from '../src';
import { P, captive, eventsOf, mv, need, pieceOf, play, stateOf, typesOf } from './helpers';

/** RNG kịch bản: `int(6)` trả lần lượt các mặt xúc xắc (0..5 ứng với 1..6) đã định sẵn. */
function scripted(faces: readonly number[]): Rng & { readonly left: () => number } {
  let index = 0;
  return {
    next(): number {
      throw new Error('scripted RNG: chỉ dùng int()');
    },
    int(maxExclusive: number): number {
      const face = faces[index++];
      if (face === undefined || face >= maxExclusive) throw new Error(`scripted RNG: hết kịch bản hoặc giá trị ${String(face)} không hợp lệ`);
      return face;
    },
    left: () => faces.length - index,
  };
}

const kings = (): Piece[] => [P('k0', 0, 'K', -20, 20), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)];
const opening = newGame(defaultConfig, SEATS, 2024);

/** Ván mở đầu có `winner` là người đi đầu (các ghế khác tung 1-1-1). */
function startedWith(winner: Seat): GameState {
  const faces = SEATS.flatMap((seat) => (seat === winner ? [5, 5, 5] : [0, 0, 0]));
  return rollDice(opening, scripted(faces)).state;
}

/** Nước đi đầu tiên hợp lệ của người tới lượt (Hậu tiến một ô: chậm, không đụng ai trong vài hiệp đầu). */
const firstMove = (state: GameState) => {
  const move = legalMoves(state, state.turnSeat as Seat)[0];
  if (move === undefined) throw new Error('Test: không có nước đi');
  return move;
};

function deepFreeze<T>(value: T): T {
  if (typeof value === 'object' && value !== null && !Object.isFrozen(value)) {
    Object.freeze(value);
    for (const child of Object.values(value)) deepFreeze(child);
  }
  return value;
}

describe('R-02: tung xúc xắc', () => {
  it('đồng điểm cao nhất thì CHỈ những người đó tung lại, lặp tới khi có duy nhất một người', () => {
    const rng = scripted([
      5, 5, 5, /* ghế 0: 18 */ 5, 5, 5, /* ghế 1: 18 */ 0, 0, 0, /* 3 */ 1, 1, 1, /* 6 */ 2, 2, 2, /* 9 */ 4, 4, 4, /* 15 */
      0, 1, 2, /* ghế 0: 6 */ 1, 1, 1, /* ghế 1: 6 → lại đồng điểm */
      0, 0, 0, /* ghế 0: 3 */ 3, 3, 3, /* ghế 1: 12 → thắng */
    ]);
    const { state, events } = rollDice(opening, rng);
    expect(rng.left()).toBe(0);

    const rolls = eventsOf(events, 'DICE_ROLLED');
    expect(rolls.map((e) => [e.attempt, e.rolls.map((r) => r.seat), e.winner])).toEqual([
      [1, [0, 1, 2, 3, 4, 5], null],
      [2, [0, 1], null],
      [3, [0, 1], 1],
    ]);
    expect(rolls[0]?.rolls[0]).toEqual({ seat: 0, dice: [6, 6, 6], total: 18 });
    expect(rolls[1]?.rolls.map((r) => r.dice)).toEqual([
      [1, 2, 3],
      [2, 2, 2],
    ]);
    expect(state).toMatchObject({ phase: 'playing', round: 1, opener: 1, turnSeat: 1 });
  });

  it('người có tổng cao nhất duy nhất thắng ngay ở lần tung đầu', () => {
    const { winner, events } = rollForFirst(SEATS, scripted([...[0, 0, 0], ...[0, 0, 1], ...[5, 5, 4], ...[1, 1, 1], ...[2, 0, 0], ...[3, 3, 0]]));
    expect(winner).toBe(2);
    expect(events).toHaveLength(1);
    expect(events[0]?.rolls.map((r) => r.total)).toEqual([3, 4, 17, 6, 5, 9]);
  });

  it('xúc xắc luôn nằm trong 1..6 và tổng đúng', () => {
    for (let seed = 0; seed < 50; seed++) {
      for (const event of rollForFirst(SEATS, createRng(seed)).events) {
        for (const roll of event.rolls) {
          expect(roll.dice.every((d) => Number.isInteger(d) && d >= 1 && d <= 6)).toBe(true);
          expect(roll.total).toBe(roll.dice[0] + roll.dice[1] + roll.dice[2]);
        }
      }
    }
  });

  it('tất định theo seed: cùng seed → cùng kết quả và cùng hash; RNG mặc định lấy từ state.seed', () => {
    const a = rollDice(newGame(defaultConfig, SEATS, 77));
    const b = rollDice(newGame(defaultConfig, SEATS, 77));
    expect(a.events).toEqual(b.events);
    expect(hash(a.state)).toBe(hash(b.state));
    expect(rollDice(newGame(defaultConfig, SEATS, 77), createRng(77)).events).toEqual(a.events);
  });

  it('phân bố người đi đầu xấp xỉ đều trên 6 ghế (600 seed)', () => {
    const wins = new Array<number>(6).fill(0);
    for (let seed = 1; seed <= 600; seed++) {
      const first = rollDice(newGame(defaultConfig, SEATS, seed)).state.turnSeat as number;
      wins[first] = (wins[first] ?? 0) + 1;
    }
    for (const count of wins) expect(count).toBeGreaterThan(60); // kỳ vọng 100, độ lệch chuẩn ≈ 9
    for (const count of wins) expect(count).toBeLessThan(140);
  });

  it('chỉ tung được ở pha xúc xắc', () => {
    expect(() => rollDice(startedWith(0))).toThrow(/dice/);
  });
});

describe('R-03, R-10: thứ tự đi và hiệp', () => {
  it('R-03: thứ tự đi theo chiều kim đồng hồ từ người thắng (ghế s, s+1, … mod 6)', () => {
    const state = startedWith(4);
    expect(state.order).toEqual([4, 5, 0, 1, 2, 3]);
    expect(state).toMatchObject({ opener: 4, turnSeat: 4, round: 1 });
  });

  it('R-10: mỗi hiệp mỗi người còn sống đi đúng một lượt, theo thứ tự; hiệp mới khi quay về người mở hiệp', () => {
    let state = startedWith(4);
    const seen: { seat: Seat; round: number }[] = [];
    const rounds: number[] = [];
    for (let turn = 0; turn < 18; turn++) {
      expect(state.turnSeat).not.toBeNull();
      seen.push({ seat: state.turnSeat as Seat, round: state.round });
      const result = applyMove(state, firstMove(state));
      rounds.push(...eventsOf(result.events, 'ROUND_STARTED').map((e) => e.round));
      state = result.state;
    }
    expect(seen.map((t) => t.seat)).toEqual([4, 5, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3, 4, 5, 0, 1, 2, 3]);
    expect(seen.map((t) => t.round)).toEqual([1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3]);
    expect(rounds).toEqual([2, 3, 4]);
    expect(state).toMatchObject({ round: 4, turnSeat: 4 });
  });

  it('R-03: người đã bị loại bị bỏ qua trong thứ tự đi', () => {
    const state = stateOf([P('k0', 0, 'K', -20, 20), P('k2', 2, 'K', 20, -20), P('k3', 3, 'K', 20, 0)], {
      seats: [0, 1, 2, 3],
      eliminated: [{ seat: 1, round: 1, reason: 'king', batch: 1, score: 0 }],
    });
    const { state: after } = play(state, ['idle', 'idle', 'idle', 'idle']);
    expect(after).toMatchObject({ turnSeat: 2, round: 2 }); // 0 → 2 → 3 → 0 (hiệp 2) → 2
  });
});

describe('R-10 + R-61: người mở hiệp bị loại giữa hiệp (ca biên 4.10)', () => {
  const four = () =>
    stateOf([P('k0', 0, 'K', 0, -6), P('r1', 1, 'R', 0, -3), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20), P('k3', 3, 'K', 20, 0)], {
      seats: [0, 1, 2, 3],
      round: 3,
      opener: 0,
      turnSeat: 1,
    });

  it('người mở hiệp bị ăn Vua ở lượt người khác → người còn sống kế tiếp mở hiệp; hiệp sau bắt đầu đúng chỗ', () => {
    const afterCapture = play(four(), [mv('r1', 0, -6)]);
    expect(afterCapture.state).toMatchObject({ round: 3, opener: 1, turnSeat: 2 });
    expect(afterCapture.state.eliminated).toMatchObject([{ seat: 0, reason: 'king' }]);
    expect(typesOf(afterCapture.events)).not.toContain('ROUND_STARTED');

    const next = play(afterCapture.state, ['idle', 'idle']); // ghế 2, ghế 3
    expect(next.state).toMatchObject({ round: 4, opener: 1, turnSeat: 1 });
    expect(eventsOf(next.events, 'ROUND_STARTED')).toEqual([{ type: 'ROUND_STARTED', round: 4 }]);
  });

  it('người mở hiệp tự đầu hàng ở lượt của mình → lượt kế vẫn thuộc hiệp này (những người sau chưa đi)', () => {
    const s = stateOf(kings(), { seats: [0, 1, 2], round: 3, opener: 0, turnSeat: 0 });
    const { state, events } = resign(s, 0);
    expect(state).toMatchObject({ round: 3, opener: 1, turnSeat: 1 });
    expect(typesOf(events)).toEqual(['PLAYER_ELIMINATED', 'TURN_STARTED']);
    expect(eventsOf(events, 'PLAYER_ELIMINATED')).toMatchObject([{ seat: 0, reason: 'resign' }]);

    const next = play(state, ['idle', 'idle']); // ghế 1 rồi ghế 2 → hiệp 4 do ghế 1 mở
    expect(next.state).toMatchObject({ round: 4, turnSeat: 1 });
  });
});

describe('R-61: đầu hàng', () => {
  it('đầu hàng ngoài lượt: bị loại như mất Vua, lượt hiện tại không đổi', () => {
    const s = stateOf(kings(), { seats: [0, 1, 2], turnSeat: 0 });
    const { state } = resign(s, 2);
    expect(state.turnSeat).toBe(0);
    expect(state.eliminated).toMatchObject([{ seat: 2, reason: 'resign', round: 1, batch: 1 }]);
    expect(state.pieces.some((p) => p.owner === 2)).toBe(false);
  });

  it('R-35: đầu hàng thả tù binh mà người đó đang giữ', () => {
    const s = stateOf([...kings(), P('x0', 0, 'R', 0, 0), captive('y1', 1, 'N', 0, 0, 0, true)], { seats: [0, 1, 2], turnSeat: 1 });
    const { state, events } = resign(s, 0);
    expect(need(state, 'y1')).toMatchObject({ status: 'active', cell: { q: 0, r: 0 } });
    expect(eventsOf(events, 'CAPTIVE_RELEASED')).toMatchObject([{ cause: 'holder_eliminated' }]);
  });

  it('R-80: người còn lại thắng ngay khi đối thủ đầu hàng', () => {
    const s = stateOf([P('k0', 0, 'K', 0, 0), P('k1', 1, 'K', 5, 5)], { seats: [0, 1] });
    const { state, events } = resign(s, 1);
    expect(state).toMatchObject({ phase: 'over', turnSeat: null });
    expect(state.result).toMatchObject({ reason: 'lastKing', winner: 0 });
    expect(typesOf(events).at(-1)).toBe('GAME_OVER');
  });

  it('từ chối: ván chưa bắt đầu / đã kết thúc / người đã bị loại', () => {
    expect(() => resign(opening, 0)).toThrowError(IllegalMoveError);
    const over = resign(stateOf([P('k0', 0, 'K', 0, 0), P('k1', 1, 'K', 5, 5)], { seats: [0, 1] }), 1).state;
    expect(() => resign(over, 0)).toThrowError(/GAME_NOT_PLAYING/);
    const s = stateOf(kings(), { seats: [0, 1, 2] });
    const after = resign(s, 1).state;
    expect(() => resign(after, 1)).toThrowError(/NOT_IN_GAME/);
  });
});

describe('R-12: hết giờ', () => {
  it('lượt bị bỏ qua (không đi quân nào), lượt chuyển cho người kế tiếp', () => {
    const state = startedWith(2);
    const { state: after, events } = timeoutTurn(state);
    expect(after.pieces).toEqual(state.pieces);
    expect(typesOf(events)).toEqual(['TURN_SKIPPED', 'TURN_STARTED']);
    expect(eventsOf(events, 'TURN_SKIPPED')).toEqual([{ type: 'TURN_SKIPPED', seat: 2, reason: 'timeout' }]);
    expect(after).toMatchObject({ turnSeat: 3, round: 1 });
  });

  it('người cuối hiệp hết giờ → sang hiệp mới', () => {
    let state = startedWith(0);
    for (let i = 0; i < 5; i++) state = timeoutTurn(state).state;
    expect(state.turnSeat).toBe(5);
    const after = timeoutTurn(state);
    expect(after.state).toMatchObject({ turnSeat: 0, round: 2 });
    expect(eventsOf(after.events, 'ROUND_STARTED')).toHaveLength(1);
  });

  it('ca biên 4.10 (R-33): hết giờ ở lượt có tù binh tới hạn → tù binh vẫn bị loại cuối lượt', () => {
    const s = stateOf([...kings(), P('r0', 0, 'R', 0, 0), P('n1', 1, 'N', 3, 0)], { seats: [0, 1, 2] });
    const round1 = play(s, [mv('r0', 3, 0), 'idle', 'idle']).state;
    expect(round1.turnSeat).toBe(0);
    expect(need(round1, 'n1').status).toBe('captive');
    const { state, events } = timeoutTurn(round1);
    expect(pieceOf(state, 'n1')).toBeUndefined();
    expect(typesOf(events).slice(0, 2)).toEqual(['TURN_SKIPPED', 'CAPTIVE_EXPIRED']);
  });

  it('không hết giờ được khi ván chưa bắt đầu hoặc đã kết thúc', () => {
    expect(() => timeoutTurn(opening)).toThrowError(/GAME_NOT_PLAYING/);
  });
});

describe('R-13: không có nước đi thì lượt tự bỏ qua', () => {
  // Tốt `bp` của ghế 1 ở (0,0): ô tiến (1,-1) và ô lùi (-1,1) bị quân ghế 0 chiếm, không có địch ở 4 ô chéo.
  const stuck = (extra: readonly Piece[] = []) =>
    stateOf(
      [P('bp', 1, 'P', 0, 0), P('kk', 0, 'K', 1, -1), P('qq', 0, 'Q', -1, 1), P('r0', 0, 'R', 10, 10), P('k2', 2, 'K', 20, -20), ...extra],
      { seats: [0, 1, 2] },
    );

  it('lượt của người không có nước đi tự bỏ qua, lượt sang người kế tiếp', () => {
    expect(legalMoves(stuck(), 1)).toEqual([]);
    const { state, events } = play(stuck(), [mv('r0', 10, 9)]);
    expect(typesOf(events)).toEqual(['MOVED', 'TURN_STARTED', 'TURN_SKIPPED', 'TURN_STARTED']);
    expect(eventsOf(events, 'TURN_SKIPPED')).toEqual([{ type: 'TURN_SKIPPED', seat: 1, reason: 'no_moves' }]);
    expect(state).toMatchObject({ turnSeat: 2, round: 1 });
  });

  it('lượt tự bỏ qua vẫn là một lượt: tù binh tới hạn của người đó bị loại (R-33)', () => {
    // Ghế 1 giữ tù binh `cp` (Tốt của ghế 0) ở (0,0); đi tù binh như Tốt của ghế 1 cũng không có nước nào.
    const s = stuck([captive('cp', 0, 'P', 0, 0, 1, true)]);
    expect(legalMoves(s, 1)).toEqual([]);
    const { state, events } = play(s, [mv('r0', 10, 9)]);
    expect(pieceOf(state, 'cp')).toBeUndefined();
    expect(typesOf(events)).toEqual(['MOVED', 'TURN_STARTED', 'TURN_SKIPPED', 'CAPTIVE_EXPIRED', 'TURN_STARTED']);
  });

  it('người có nước đi (kể cả chỉ có nước trưng dụng) thì không bị bỏ qua', () => {
    const s = stateOf([P('bp', 1, 'P', 0, 0), P('kk', 0, 'K', 1, -1), P('qq', 0, 'Q', -1, 1), captive('cq', 0, 'Q', 0, 0, 1, true), P('r0', 0, 'R', 10, 10), P('k2', 2, 'K', 20, -20)], {
      seats: [0, 1, 2],
    });
    expect(legalMoves(s, 1).every((m) => m.conscript === true)).toBe(true);
    const { state, events } = play(s, [mv('r0', 10, 9)]);
    expect(state.turnSeat).toBe(1);
    expect(typesOf(events)).toEqual(['MOVED', 'TURN_STARTED']);
  });
});

describe('R-11, R-14: kiểm tra nước đi', () => {
  const s = stateOf([P('k0', 0, 'K', 0, 0), P('q1', 1, 'Q', 0, -5), P('k1', 1, 'K', -20, 0), P('a0', 0, 'R', 8, 8)], { seats: [0, 1] });

  it('R-14: không có chiếu — Vua được đi vào ô đang bị đe dọa, và không bị buộc phản ứng khi đang bị đe dọa', () => {
    expect(checkMove(s, 0, mv('k0', 0, -1))).toBeNull(); // (0,-1) nằm trên đường của Hậu địch
    expect(legalMoves(s, 0).some((m) => m.pieceId === 'a0')).toBe(true); // Vua đang bị Hậu nhắm nhưng vẫn đi quân khác được
    expect(() => applyMove(s, mv('a0', 8, 7))).not.toThrow();
  });

  it('mã lý do theo thứ tự: chưa chơi → sai lượt → không phải quân của mình → không có quân → luật quân', () => {
    expect(checkMove(opening, 0, mv('s0-P1', 0, 0))).toBe('GAME_NOT_PLAYING');
    expect(checkMove(s, 1, mv('q1', 0, -4))).toBe('NOT_YOUR_TURN');
    expect(checkMove(s, 0, mv('q1', 0, -4))).toBe('NOT_YOUR_PIECE');
    expect(checkMove(s, 0, mv('ghost', 0, -4))).toBe('UNKNOWN_PIECE');
    expect(checkMove(s, 0, mv('a0', 9, 9))).toBe('BAD_DIRECTION');
  });

  it('applyMove ném IllegalMoveError mang đúng mã lý do', () => {
    try {
      applyMove(s, mv('q1', 0, -4));
      expect.unreachable();
    } catch (error) {
      expect(error).toBeInstanceOf(IllegalMoveError);
      expect((error as IllegalMoveError).reason).toBe('NOT_YOUR_PIECE');
    }
  });

  it('không có NOT_ALLOWED: mọi nước bị từ chối trên thế cờ đầu đều có lý do cụ thể', () => {
    const state = startedWith(0);
    const legal = new Set(legalMoves(state, 0).map((m) => `${m.pieceId}>${m.to.q},${m.to.r}`));
    for (const piece of state.pieces.filter((p) => p.owner === 0)) {
      for (let q = -6; q <= 6; q++) {
        for (let r = 14; r <= 24; r++) {
          const reason = checkMove(state, 0, mv(piece.id, q, r));
          if (legal.has(`${piece.id}>${q},${r}`)) expect(reason).toBeNull();
          else expect([null, 'NOT_ALLOWED']).not.toContain(reason);
        }
      }
    }
  });
});

describe('tính thuần khiết', () => {
  it('mọi hành động không sửa trạng thái đầu vào (đóng băng sâu) và không giữ tham chiếu vào nước đi của người gọi', () => {
    const state = deepFreeze(startedWith(0));
    const move = firstMove(state);
    const to = { q: move.to.q, r: move.to.r };
    const result = applyMove(state, { ...move, to });
    to.q = 999;
    expect(result.state.pieces.every((p) => p.cell.q !== 999)).toBe(true);
    expect(() => timeoutTurn(state)).not.toThrow();
    expect(() => resign(state, 3)).not.toThrow();
    expect(() => rollDice(deepFreeze(newGame(defaultConfig, SEATS, 5)))).not.toThrow();
    expect(state.turnSeat).toBe(0);
  });

  it('ván đã kết thúc từ chối mọi hành động', () => {
    const over = resign(stateOf([P('k0', 0, 'K', 0, 0), P('k1', 1, 'K', 5, 5)], { seats: [0, 1] }), 1).state;
    expect(() => applyMove(over, mv('k0', 0, 1))).toThrowError(/GAME_NOT_PLAYING/);
    expect(() => timeoutTurn(over)).toThrowError(/GAME_NOT_PLAYING/);
    expect(() => resign(over, 0)).toThrowError(/GAME_NOT_PLAYING/);
  });
});
