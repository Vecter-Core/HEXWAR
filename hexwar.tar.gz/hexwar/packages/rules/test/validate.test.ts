// Kiểm tra chính bộ kiểm tra bất biến: mỗi bất biến phải bắt được một thế cờ cố tình làm hỏng.
// (Mô phỏng ngẫu nhiên chỉ đáng tin nếu validateState thật sự phát hiện lỗi.)
import { describe, expect, it } from 'vitest';
import { SEATS, assertValidState, defaultConfig, newGame, rollDice, validateState, type GameState, type Piece } from '../src';
import { P, captive, stateOf } from './helpers';

const kings = (): Piece[] => [P('k0', 0, 'K', -20, 20), P('k1', 1, 'K', -20, 0), P('k2', 2, 'K', 20, -20)];
const good = (extra: readonly Piece[] = []): GameState => stateOf([...kings(), ...extra], { seats: [0, 1, 2] });

/** Dựng trạng thái hỏng bằng cách đè trường (bỏ qua các kiểm tra của makeState). */
const broken = (state: GameState, patch: Partial<GameState>): GameState => ({ ...state, ...patch });
const hasProblem = (state: GameState, pattern: RegExp, options?: Parameters<typeof validateState>[1]): boolean =>
  validateState(state, options).some((message) => pattern.test(message));

describe('validateState: thế cờ hợp lệ', () => {
  it('thế cờ đầu, sau xúc xắc, và thế cờ dựng tay đều hợp lệ', () => {
    const opening = newGame(defaultConfig, SEATS, 3);
    expect(validateState(opening)).toEqual([]);
    expect(validateState(rollDice(opening).state)).toEqual([]);
    expect(validateState(good())).toEqual([]);
  });

  it('assertValidState không ném khi hợp lệ, ném và liệt kê mọi vi phạm khi hỏng', () => {
    expect(() => assertValidState(good())).not.toThrow();
    const bad = broken(good(), { round: 0, turnSeat: null });
    expect(() => assertValidState(bad)).toThrowError(/round = 0[\s\S]*turnSeat/);
  });
});

describe('validateState: bắt được từng loại vi phạm', () => {
  it('id quân trùng, quân ngoài bàn, hai quân hoạt động cùng ô', () => {
    const s = good([P('a', 0, 'R', 0, 0)]);
    expect(hasProblem(broken(s, { pieces: [...s.pieces, P('a', 1, 'R', 3, 3)] }), /id quân trùng/)).toBe(true);
    expect(hasProblem(broken(s, { pieces: [...s.pieces, P('far', 0, 'R', 30, 0)] }), /ngoài bàn/)).toBe(true);
    expect(hasProblem(broken(s, { pieces: [...s.pieces, P('twin', 1, 'R', 0, 0)] }), /cùng ô/)).toBe(true);
  });

  it('quân của người đã bị loại, quân của ghế lạ', () => {
    const s = good([P('a', 1, 'R', 0, 0)]);
    const dead = broken(s, { eliminated: [{ seat: 1, round: 1, reason: 'king', batch: 1, score: 0 }] });
    expect(hasProblem(dead, /đã bị loại/)).toBe(true);
    expect(hasProblem(good([P('x', 4, 'R', 0, 0)]), /không nằm trong order/)).toBe(true);
  });

  it('tù binh: thiếu holder / armed / của chính chủ / người giữ đã chết / không có quân giữ cùng ô / quân đứng cùng ô là của người khác / là Vua', () => {
    const noHolder = { ...captive('c', 1, 'N', 0, 0, 0, true), holder: undefined } as unknown as Piece;
    expect(hasProblem(good([P('x', 0, 'R', 0, 0), noHolder]), /không có holder/)).toBe(true);
    expect(hasProblem(good([P('x', 0, 'R', 0, 0), captive('c', 1, 'N', 0, 0, 0)]), /armed không phải boolean/)).toBe(true);
    expect(hasProblem(good([P('x', 0, 'R', 0, 0), captive('c', 0, 'N', 0, 0, 0, true)]), /của chính chủ/)).toBe(true);
    expect(hasProblem(good([captive('c', 1, 'N', 0, 0, 0, true)]), /không có quân của người giữ đứng cùng ô/)).toBe(true);
    expect(hasProblem(good([P('x', 2, 'R', 0, 0), captive('c', 1, 'N', 0, 0, 0, true)]), /không có quân của người giữ đứng cùng ô/)).toBe(true);
    expect(hasProblem(good([P('x', 0, 'R', 0, 0), captive('kc', 1, 'K', 0, 0, 0, true)]), /Vua không bao giờ là tù binh/)).toBe(true);
    const dead = broken(good([P('x', 0, 'R', 0, 0), captive('c', 1, 'N', 0, 0, 0, true)]), {
      eliminated: [{ seat: 0, round: 1, reason: 'king', batch: 1, score: 0 }],
    });
    expect(hasProblem(dead, /không còn sống/)).toBe(true);
  });

  it('quân hoạt động còn mang holder/armed', () => {
    const p: Piece = { ...P('x', 0, 'R', 0, 0), holder: 1 };
    expect(hasProblem(good([p]), /còn holder\/armed/)).toBe(true);
  });

  it('phong cấp sai: đổi loại không phải từ Tốt', () => {
    expect(hasProblem(good([{ ...P('x', 0, 'Q', 0, 0), origin: 'R' }]), /chỉ Tốt được phong cấp/)).toBe(true);
    expect(hasProblem(good([{ ...P('x', 0, 'K', 0, 0), origin: 'P' }]), /chỉ Tốt được phong cấp/)).toBe(true);
    expect(validateState(good([{ ...P('x', 0, 'Q', 0, 0), origin: 'P' }]))).toEqual([]);
  });

  it('kill: tổng kills của quân vượt playerKills, số âm/không nguyên', () => {
    expect(hasProblem(good([{ ...P('x', 0, 'R', 0, 0), kills: 3 }]), /vượt playerKills/)).toBe(true);
    expect(hasProblem(good([{ ...P('x', 0, 'R', 0, 0), kills: -1 }]), /kills = -1/)).toBe(true);
    expect(hasProblem(broken(good(), { playerKills: [0, -2, 0, 0, 0, 0] }), /playerKills có số không hợp lệ/)).toBe(true);
  });

  it('Vua: người còn sống phải có đúng một Vua hoạt động (bỏ qua được bằng requireKings: false)', () => {
    const none = stateOf([P('k0', 0, 'K', 0, 0), P('k1', 1, 'R', 5, 5)], { seats: [0, 1] });
    expect(hasProblem(none, /ghế 1 còn sống nhưng có 0 Vua/)).toBe(true);
    expect(hasProblem(none, /Vua/, { requireKings: false })).toBe(false);
    const two = stateOf([P('k0', 0, 'K', 0, 0), P('k0b', 0, 'K', 1, 0), P('k1', 1, 'K', 5, 5)], { seats: [0, 1] });
    expect(hasProblem(two, /ghế 0 còn sống nhưng có 2 Vua/)).toBe(true);
  });

  it('người chơi: order trùng, bị loại hai lần, batch giảm dần', () => {
    expect(hasProblem(broken(good(), { order: [0, 1, 1] }), /order có ghế trùng/)).toBe(true);
    const e = (seat: 0 | 1 | 2, batch: number) => ({ seat, round: 1, reason: 'king' as const, batch, score: 0 });
    expect(hasProblem(broken(good(), { eliminated: [e(1, 1), e(1, 2)] }), /bị loại hai lần/)).toBe(true);
    expect(hasProblem(broken(good(), { eliminated: [e(1, 2), e(2, 1)] }), /batch bị loại không tăng dần/)).toBe(true);
  });

  it('pha ván: đang chơi cần round ≥ 1, ≥ 2 người sống, turnSeat và opener còn sống, chưa có result', () => {
    const s = good();
    expect(hasProblem(broken(s, { round: 0 }), /round = 0/)).toBe(true);
    expect(hasProblem(broken(s, { turnSeat: null }), /turnSeat/)).toBe(true);
    expect(hasProblem(broken(s, { opener: null }), /opener/)).toBe(true);
    const dead = [{ seat: 2 as const, round: 1, reason: 'king' as const, batch: 1, score: 0 }];
    expect(hasProblem(broken(s, { eliminated: dead, turnSeat: 2 }), /turnSeat 2 không phải người còn sống/)).toBe(true);
    expect(hasProblem(broken(s, { eliminated: dead, opener: 2 }), /opener 2 không phải người còn sống/)).toBe(true);
    const lone = [dead[0] as (typeof dead)[number], { seat: 1 as const, round: 1, reason: 'king' as const, batch: 2, score: 0 }];
    expect(hasProblem(broken(s, { eliminated: lone }), /chỉ còn 1 người sống/)).toBe(true);
    expect(hasProblem(broken(s, { result: { reason: 'lastKing', winner: 0, ranking: [] } }), /đã có result/)).toBe(true);
  });

  it('pha ván kết thúc cần result và turnSeat = null; pha xúc xắc cần round = 0', () => {
    expect(hasProblem(broken(good(), { phase: 'over', turnSeat: null }), /không có result/)).toBe(true);
    expect(hasProblem(broken(good(), { phase: 'over', result: { reason: 'lastKing', winner: 0, ranking: [] } }), /turnSeat khác null/)).toBe(true);
    expect(hasProblem(broken(good(), { phase: 'dice', round: 3 }), /pha xúc xắc nhưng round = 3/)).toBe(true);
  });
});
