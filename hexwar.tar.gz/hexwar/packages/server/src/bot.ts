// Bộ não bot + đồng hồ thật để chạy `GameSession` trên server (PLAN 9). Cùng đúng mẫu với
// packages/client/src/net/local-host.ts (ván solo cục bộ chạy trong Worker) — cố ý chép lại thay vì tách một gói
// dùng chung, để @hexwar/bot không phải phụ thuộc ngược vào @hexwar/protocol chỉ để lấy hai kiểu BotBrain/Clock
// (xem docs/decisions.md, mục M6).
import { botRngFor, chooseMove } from '@hexwar/bot';
import type { BotBrain, Clock } from '@hexwar/protocol';

export const botBrain: BotBrain = {
  decide: (state, seat, difficulty, actionIndex, personality) =>
    chooseMove(state, seat, difficulty, botRngFor(state, seat, actionIndex), personality)?.move ?? null,
};

/** Đồng hồ thật của tiến trình server — tầng DUY NHẤT ở đây được đọc Date.now/setTimeout; GameSession/engine/bot
 * vẫn thuần và tất định, chỉ nhận thời gian qua giao diện `Clock` này (PLAN 6.1). */
export const realClock: Clock = {
  now: () => Date.now(),
  setTimer: (ms, fn) => ({ id: setTimeout(fn, ms) as unknown as number }),
  clearTimer: (handle) => clearTimeout(handle.id),
};
