// Tiện ích cho một kết nối WebSocket: gửi JSON an toàn (bỏ qua nếu socket đã đóng) + giới hạn tốc độ gửi lên
// (PLAN 7.6 "không tin client": một client hỏng/ác ý gửi dồn dập không được làm nghẽn cả phòng). Giới hạn kích
// thước một message (byte) nằm ở `maxPayload` của WebSocketServer trong server.ts — thư viện `ws` tự đóng kết nối
// khi vượt, không cần code riêng ở đây.
import type { ChatServerMessage, LobbyServerMessage, ServerMessage } from '@hexwar/protocol';

/** Phía server dùng để gửi tới đúng một kết nối — tách khỏi `ws.WebSocket` để room.ts/server.ts không phải import
 * kiểu của thư viện `ws` khắp nơi và để test có thể giả lập dễ dàng. */
export interface PlayerConnection {
  send(message: ServerMessage | LobbyServerMessage | ChatServerMessage): void;
}

/** Token bucket đơn giản: tối đa `capacity` message tức thời, hồi lại `refillPerSecond` mỗi giây. */
export class RateLimiter {
  private tokens: number;
  private lastRefillMs: number;

  constructor(
    private readonly capacity: number,
    private readonly refillPerSecond: number,
    now = Date.now(),
  ) {
    this.tokens = capacity;
    this.lastRefillMs = now;
  }

  /** true nếu message này được phép; false thì phải bỏ (và có thể báo lỗi RATE_LIMITED cho người gửi). */
  allow(now = Date.now()): boolean {
    const elapsedSeconds = Math.max(0, now - this.lastRefillMs) / 1000;
    this.tokens = Math.min(this.capacity, this.tokens + elapsedSeconds * this.refillPerSecond);
    this.lastRefillMs = now;
    if (this.tokens < 1) return false;
    this.tokens -= 1;
    return true;
  }
}
