// Danh tính khách (PLAN 7.1, 7.5). Steam thật chưa mở khoá được ở M0 (cần Windows + Steam client, xem
// docs/progress.md) và PLAN 7.1 cho phép "chế độ khách chỉ dành cho bản dev" — nên M6 cấp danh tính khách tạm cho
// mỗi kết nối: "hello" không kèm token (hoặc token lạ/đã hết hạn vào lại) được cấp một danh tính mới; gửi lại đúng
// token đó ở lần "hello" sau (cùng phiên trình duyệt, mất mạng rồi nối lại...) sẽ được nhận diện là cùng một người,
// cho phép vào lại phòng/ván đang chờ (xem room.ts — cửa sổ vào lại chịu quản lý bởi `turn.reconnectGraceSeconds`,
// KHÔNG phải bởi tuổi thọ của danh tính ở đây: danh tính tồn tại vô thời hạn trong bộ nhớ tiến trình, chỉ có chỗ
// đứng của nó trong một phòng cụ thể là hết hạn — xem docs/decisions.md).
import { randomUUID } from 'node:crypto';

export interface Identity {
  readonly id: string;
  readonly name: string;
  readonly token: string;
}

export class IdentityStore {
  private readonly byToken = new Map<string, Identity>();

  createGuest(name: string): Identity {
    const identity: Identity = { id: randomUUID(), name, token: randomUUID() };
    this.byToken.set(identity.token, identity);
    return identity;
  }

  find(token: string): Identity | undefined {
    return this.byToken.get(token);
  }
}
