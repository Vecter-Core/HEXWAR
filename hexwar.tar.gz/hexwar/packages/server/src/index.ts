// @hexwar/server — server online thật (PLAN mục 7, Milestone M6): WebSocket, danh tính khách, phòng/ghép trận, và
// chạy GameSession (dùng chung với ván solo cục bộ, @hexwar/protocol) có thẩm quyền cho nhiều kết nối cùng lúc.
export { HexwarServer, type HexwarServerOptions } from './server';
export { Room, type HostResult, type JoinResult, type ReconnectResult, type RoomDeps, type SimpleResult } from './room';
export { Matchmaker } from './matchmaker';
export { IdentityStore, type Identity } from './identity';
export { RateLimiter, type PlayerConnection } from './connection';
export { botBrain, realClock } from './bot';
