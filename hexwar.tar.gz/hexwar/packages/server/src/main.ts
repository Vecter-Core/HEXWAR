// Điểm chạy thật (`pnpm --filter @hexwar/server start`, hoặc `tsx src/main.ts`): đọc cổng từ biến môi trường PORT,
// dựng HexwarServer và lắng nghe. Không có logic ở đây — chỉ nối dây (server.ts mới là nơi có logic, dễ test).
import { defaultConfig } from '@hexwar/rules';
import { HexwarServer } from './server';

const port = Number(process.env.PORT ?? 8080);
new HexwarServer({ rulesVersion: defaultConfig.rulesVersion }, { port });
console.log(`HEXWAR server: đang lắng nghe cổng ${port} (luật ${defaultConfig.rulesVersion})`);
