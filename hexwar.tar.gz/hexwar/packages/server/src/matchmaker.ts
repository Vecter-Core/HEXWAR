// Hàng chờ ghép nhanh (PLAN 7.2 "Ghép nhanh"): một hàng riêng cho mỗi preset (X-09) — vào hàng thì hoặc ghép chung
// với một phòng công khai cùng preset còn ghế trống, hoặc tạo phòng mới nếu không có (phòng mới cũng tự vào đúng
// hàng đó cho những người tới sau). Việc phòng khi nào tự bắt đầu (đủ 6, hoặc bot lấp chỗ sau một khoảng chờ) do
// chính `Room` lo (`quickMatch: true`); lớp này chỉ chọn/-tạo phòng.
import type { PresetName } from '@hexwar/rules';
import type { Room } from './room';

export class Matchmaker {
  private readonly queues = new Map<PresetName, Room[]>();

  constructor(private readonly createRoom: (preset: PresetName) => Room) {}

  /** Trả về phòng công khai cùng preset để vào — có sẵn ghế trống thì dùng lại, không thì tạo phòng mới. */
  join(preset: PresetName): Room {
    const waiting = (this.queues.get(preset) ?? []).filter((room) => room.isLobby);
    const existing = waiting.find((room) => room.hasEmptySeat);
    if (existing !== undefined) {
      this.queues.set(preset, waiting);
      return existing;
    }
    const room = this.createRoom(preset);
    waiting.push(room);
    this.queues.set(preset, waiting);
    return room;
  }
}
