// Một phòng (PLAN 7.2): LOBBY (chờ đủ người + Sẵn sàng, hoặc bot lấp chỗ ở ghép nhanh) rồi tự chuyển sang chạy một
// `GameSession` thật (DICE → PLAYING → RESULT nằm hết trong `GameState.phase` của chính GameSession — Room không
// cần biết, chỉ cần biết ván đã bắt đầu hay chưa). Dùng chung cho CẢ ghép nhanh (`quickMatch: true`, công khai,
// không mã, tự sẵn sàng, bot lấp chỗ trống sau `botFillDelayMs`) LẪN phòng riêng (`quickMatch: false`, có mã 6 ký
// tự, phải bấm Sẵn sàng, chủ phòng tự thêm/bớt bot) — hai loại chỉ khác nhau ở điều kiện "khi nào tự bắt đầu", nên
// không tách hai lớp (xem docs/decisions.md, M6). KHÔNG có message `room.start`/`game.start` riêng: phòng tự bắt
// đầu ngay khi đủ điều kiện, và client đã biết đọc `game.snapshot` cho cả ba trường hợp bắt đầu/tiếp tục/vào lại.
//
// GameSession (packages/protocol) được viết cho một client hotseat điều khiển nhiều ghế cùng lúc (M4), nên có hai
// chỗ lệch với online (mỗi kết nối chỉ điều khiển đúng một ghế) mà lớp này phải vá:
//   1. `SessionOptions.reply` cố định lúc tạo — ở đây route lại theo NGƯỜI GỬI của từng lệnh gọi `handle()` bằng một
//      biến "đích trả lời hiện tại" gán/xoá đồng bộ quanh lệnh gọi đó (an toàn vì `handle()` chạy hết trong một lượt,
//      không có gì hoãn lại — `commit()` chỉ HẸN giờ việc sau, không tự gọi lại đồng bộ).
//   2. `game.snapshot` quảng bá `you = mọi ghế người` (đúng cho hotseat) — ở đây chặn lại broadcast này và gửi riêng
//      cho từng kết nối với `you` chỉ gồm đúng ghế của họ.
import { randomUUID } from 'node:crypto';
import { botChatRngFor, decideBotChat, type BotPhraseId } from '@hexwar/bot';
import {
  CHAT_RATE_LIMIT,
  GameSession,
  type BotBrain,
  type ChatChannel,
  type ChatClientMessage,
  type ChatMessage,
  type Clock,
  type Difficulty,
  type Personality,
  type PhraseId,
  type ReportPlayer,
  type SeatSetup,
  type ServerMessage,
  type SessionTiming,
  type VoiceSignal,
} from '@hexwar/protocol';
import type { RoomSeatView } from '@hexwar/protocol';
import { applyPreset, type PresetName, type RulesConfig, type Seat } from '@hexwar/rules';
import { RateLimiter, type PlayerConnection } from './connection';

/** `BotPhraseId` (packages/bot, không phụ thuộc protocol) phải luôn là tập con của `PhraseId` thật (packages/protocol)
 * — nếu không, `entry.phraseId` dưới đây gán một chuỗi không phải `PhraseId` hợp lệ. `server` là gói DUY NHẤT phụ
 * thuộc cả hai nên phép ép kiểu này (và bài test đối chiếu ở `packages/server/test/bot-chat.test.ts`) là chỗ hợp lý
 * nhất để bắt lệch (xem docs/decisions.md mục M9 "Bot chat").
 */
function asPhraseId(id: BotPhraseId): PhraseId {
  return id as PhraseId;
}

interface EmptySeat {
  readonly kind: 'empty';
}
interface BotSeat {
  readonly kind: 'bot';
  readonly difficulty: Difficulty;
  /** PLAN 9.4, M9. Bỏ trống = 'balanced' (GameSession/bot brain tự hiểu là mặc định). */
  readonly personality?: Personality;
}
/** PLAN 8.4 "lưu tối đa 50 tin gần nhất của người bị báo cáo" — ghi cho MỌI người (không chỉ sau khi bị báo cáo),
 * vì báo cáo có thể tới bất cứ lúc nào và cần bằng chứng của những tin TRƯỚC đó. */
interface ChatLogEntry {
  readonly at: number;
  readonly channel: ChatChannel;
  readonly kind: 'text' | 'phrase';
  readonly text?: string;
  readonly phraseId?: PhraseId;
}
interface HumanSeat {
  readonly kind: 'human';
  readonly identityId: string;
  readonly name: string;
  ready: boolean;
  conn: PlayerConnection | null;
  disconnectedAt: number | null;
  graceTimer: ReturnType<typeof setTimeout> | null;
  /** true = đã quá `turn.reconnectGraceSeconds` mà không vào lại — token cũ không còn nhận lại ghế này nữa. */
  expired: boolean;
  /** PLAN 8.4 "tối đa 5 tin/10 giây" — riêng cho chat, tách khỏi giới hạn tốc độ chung của cả kết nối (server.ts). */
  readonly chatLimiter: RateLimiter;
  readonly recentMessages: ChatLogEntry[];
  /** Mỗi lần NGƯỜI NÀY bị báo cáo, tỉa dần theo `CHAT_REPORT_WINDOW_MS`. Đếm ngưỡng (PLAN 8.4 "bị báo cáo nhiều
   * lần") theo SỐ NGƯỜI BÁO CÁO KHÁC NHAU (`identityId`), không theo tổng số lượt báo cáo — một người bấm báo cáo
   * nhiều lần không được có sức nặng bằng nhiều người khác nhau cùng báo cáo (chống tự ý "câm" người khác một mình). */
  reportedAt: { readonly at: number; readonly reporterId: string }[];
  /** khác null và > giờ hiện tại: đang bị hạn chế chat do bị báo cáo nhiều lần trong ngày (PLAN 8.4). */
  chatRestrictedUntil: number | null;
}
type RoomSeat = EmptySeat | BotSeat | HumanSeat;

function newHumanSeat(identityId: string, name: string, conn: PlayerConnection, now: number): HumanSeat {
  return {
    kind: 'human',
    identityId,
    name,
    ready: false,
    conn,
    disconnectedAt: null,
    graceTimer: null,
    expired: false,
    chatLimiter: new RateLimiter(CHAT_RATE_LIMIT.capacity, CHAT_RATE_LIMIT.refillPerSecond, now),
    recentMessages: [],
    reportedAt: [],
    chatRestrictedUntil: null,
  };
}

const CHAT_LOG_CAPACITY = 50; // PLAN 8.4
const CHAT_REPORT_THRESHOLD = 3; // PLAN 8.4 "bị báo cáo nhiều lần" — ngưỡng khởi điểm, xem docs/questions.md Q-29
const CHAT_REPORT_WINDOW_MS = 24 * 60 * 60 * 1000; // "...trong ngày"
const CHAT_RESTRICTION_MS = 15 * 60 * 1000; // "hạn chế tạm thời"

export interface RoomDeps {
  readonly id: string;
  /** null = phòng ghép nhanh (không có mã để chia sẻ). */
  readonly code: string | null;
  readonly quickMatch: boolean;
  readonly initialPreset: PresetName;
  readonly bot: BotBrain;
  /** Đồng hồ thật tiêm vào GameSession (PLAN 6.1) — Room tự dùng setTimeout/Date.now của mình cho việc chờ-ở-sảnh
   * (bot lấp chỗ, vào lại), vì đó không phải một phần của luật hay của việc phát lại ván (X-11). */
  readonly clock: Clock;
  readonly timing?: SessionTiming | Partial<SessionTiming>;
  /** Ghép nhanh: sau chừng này (ms) kể từ người đầu tiên vào phòng mà vẫn còn ghế trống thì lấp hết bằng bot. */
  readonly botFillDelayMs: number;
  /** Chỗ đứng của một danh tính trong phòng này hết hạn (rời sảnh mà không quay lại kịp, hoặc mất kết nối giữa ván
   * quá lâu) — server.ts dùng để dọn bảng "danh tính đang ở phòng nào", không liên quan gì tới việc ván có tiếp tục
   * hay không (X-04 của GameSession tự lo bot lái tạm ghế đó, độc lập với việc này — xem docs/decisions.md). */
  readonly onSeatExpired: (identityId: string) => void;
  /** CHỈ để test: ghi đè `turn.reconnectGraceSeconds` (mặc định 90 giây thật, quá lâu để chờ trong một bài test) —
   * ván thật luôn dùng đúng giá trị trong rules.config.json qua preset (X-09 không đụng tới trường này). */
  readonly reconnectGraceSecondsOverride?: number;
}

export type JoinResult = Seat | 'ROOM_FULL' | 'ROOM_STARTED';
export type SimpleResult = 'OK' | 'NOT_IN_ROOM' | 'ROOM_STARTED';
export type HostResult = 'OK' | 'NOT_HOST' | 'ROOM_STARTED' | 'ROOM_FULL';
export type ReconnectResult = 'OK' | 'MISS';

const SEAT_COUNT = 6;

export class Room {
  readonly id: string;
  private phase: 'lobby' | 'game' = 'lobby';
  private presetName: PresetName;
  private config: RulesConfig;
  private hostIdentityId: string | null = null;
  private readonly seats: RoomSeat[] = Array.from({ length: SEAT_COUNT }, (): RoomSeat => ({ kind: 'empty' }));
  private session: GameSession | null = null;
  private replyTarget: ((message: ServerMessage) => void) | undefined;
  private botFillTimer: ReturnType<typeof setTimeout> | null = null;
  private botFillArmedAt = 0;

  constructor(private readonly deps: RoomDeps) {
    this.id = deps.id;
    this.presetName = deps.initialPreset;
    this.config = this.deriveConfig(this.presetName);
  }

  private deriveConfig(preset: PresetName): RulesConfig {
    const base = applyPreset(preset);
    if (this.deps.reconnectGraceSecondsOverride === undefined) return base;
    return { ...base, turn: { ...base.turn, reconnectGraceSeconds: this.deps.reconnectGraceSecondsOverride } };
  }

  get code(): string | null {
    return this.deps.code;
  }

  get quickMatch(): boolean {
    return this.deps.quickMatch;
  }

  get isLobby(): boolean {
    return this.phase === 'lobby';
  }

  get hasEmptySeat(): boolean {
    return this.seats.some((s) => s.kind === 'empty');
  }

  addHuman(identityId: string, name: string, conn: PlayerConnection): JoinResult {
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    const seat = this.seats.findIndex((s) => s.kind === 'empty');
    if (seat === -1) return 'ROOM_FULL';
    this.seats[seat] = newHumanSeat(identityId, name, conn, this.deps.clock.now());
    if (this.hostIdentityId === null) this.hostIdentityId = identityId;
    this.armBotFillTimer();
    this.broadcastRoomState();
    this.tryStart();
    return seat as Seat;
  }

  /** PLAN 7.2 "rời phòng" — chỉ có nghĩa ở sảnh; giữa ván dùng `disconnect()` (không có cách "trả ghế" giữa chừng). */
  removeHuman(identityId: string): SimpleResult {
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return 'NOT_IN_ROOM';
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    this.clearSeatTimer(seat);
    this.seats[seat] = { kind: 'empty' };
    this.promoteHostIfNeeded();
    this.broadcastRoomState();
    return 'OK';
  }

  setReady(identityId: string, ready: boolean): SimpleResult {
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return 'NOT_IN_ROOM';
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    (this.seats[seat] as HumanSeat).ready = ready;
    this.broadcastRoomState();
    this.tryStart();
    return 'OK';
  }

  addBot(identityId: string, difficulty: Difficulty, personality?: Personality): HostResult {
    if (!this.isHost(identityId)) return 'NOT_HOST';
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    const seat = this.seats.findIndex((s) => s.kind === 'empty');
    if (seat === -1) return 'ROOM_FULL';
    this.seats[seat] = { kind: 'bot', difficulty, ...(personality !== undefined ? { personality } : {}) };
    this.broadcastRoomState();
    this.tryStart();
    return 'OK';
  }

  /** Bỏ qua lặng lẽ nếu ghế đó không phải bot (không có mã lỗi riêng cho việc này, xem LobbyErrorCode) — vô hại. */
  removeBot(identityId: string, seat: Seat): HostResult {
    if (!this.isHost(identityId)) return 'NOT_HOST';
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    if (this.seats[seat].kind === 'bot') {
      this.seats[seat] = { kind: 'empty' };
      this.broadcastRoomState();
    }
    return 'OK';
  }

  setConfig(identityId: string, preset: PresetName): HostResult {
    if (!this.isHost(identityId)) return 'NOT_HOST';
    if (this.phase !== 'lobby') return 'ROOM_STARTED';
    this.presetName = preset;
    this.config = this.deriveConfig(preset);
    this.broadcastRoomState();
    return 'OK';
  }

  /** Mất kết nối (đóng socket) — dù đang ở sảnh hay giữa ván, đều chỉ đánh dấu và hẹn giờ ân hạn giống nhau (PLAN
   * 7.5); một mạng chập chờn ở sảnh không nên đá người chơi ngay lập tức. */
  disconnect(identityId: string): void {
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return;
    const s = this.seats[seat] as HumanSeat;
    s.conn = null;
    s.disconnectedAt = Date.now();
    this.armGraceTimer(seat, identityId);
    this.broadcastRoomState();
  }

  /** `hello` với token khớp một ghế đang giữ ở phòng này, còn trong hạn ân hạn. */
  reconnect(identityId: string, conn: PlayerConnection): ReconnectResult {
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return 'MISS';
    const s = this.seats[seat] as HumanSeat;
    if (s.expired) return 'MISS';
    this.clearSeatTimer(seat);
    s.conn = conn;
    s.disconnectedAt = null;
    this.broadcastRoomState();
    if (this.phase === 'game' && this.session !== null) conn.send(this.session.snapshotFor([seat as Seat]));
    return 'OK';
  }

  /** Một message tầng ván (`game.*`) từ đúng một kết nối — vá lỗi (1) nêu ở đầu file: route reply theo người gửi. */
  handleGameMessage(identityId: string, raw: unknown): void {
    if (this.session === null) return;
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return;
    const conn = (this.seats[seat] as HumanSeat).conn;
    this.replyTarget = conn === null ? undefined : (message) => conn.send(message);
    try {
      this.session.handle([seat as Seat], raw);
    } finally {
      this.replyTarget = undefined;
    }
  }

  /** `chat.send` / `report.player` / `voice.signal` (PLAN mục 8) — có nghĩa cả ở sảnh lẫn giữa ván, không đi qua
   * GameSession (không phải luật chơi). Chỉ người đang giữ một ghế trong phòng này mới gửi được. */
  handleChatMessage(identityId: string, msg: ChatClientMessage): void {
    const seat = this.findHumanSeat(identityId);
    if (seat === null) return;
    const s = this.seats[seat] as HumanSeat;
    switch (msg.type) {
      case 'chat.send':
        this.handleChatSend(seat, s, msg);
        return;
      case 'report.player':
        this.handleReport(seat, s, msg);
        return;
      case 'voice.signal':
        this.handleVoiceSignal(seat, msg);
        return;
    }
  }

  // ---- Nội bộ -----------------------------------------------------------------------------------------------------

  private isHost(identityId: string): boolean {
    return this.hostIdentityId === identityId;
  }

  private findHumanSeat(identityId: string): Seat | null {
    for (let seat = 0; seat < SEAT_COUNT; seat++) {
      const s = this.seats[seat];
      if (s.kind === 'human' && s.identityId === identityId) return seat as Seat;
    }
    return null;
  }

  private humanSeatsMatching(predicate: (seat: Seat, s: HumanSeat) => boolean): HumanSeat[] {
    const out: HumanSeat[] = [];
    for (let seat = 0; seat < SEAT_COUNT; seat++) {
      const s = this.seats[seat];
      if (s.kind === 'human' && predicate(seat as Seat, s)) out.push(s);
    }
    return out;
  }

  /** R-14: chỉ có nghĩa giữa ván (`session !== null`) — chưa vào ván thì chưa ai bị loại (kênh "dead" chưa dùng được). */
  private isEliminated(seat: Seat): boolean {
    return this.session?.state.eliminated.some((e) => e.seat === seat) ?? false;
  }

  private chatError(s: HumanSeat, code: 'RATE_LIMITED' | 'RESTRICTED' | 'INVALID_TARGET' | 'NOT_ALLOWED', message: string): void {
    s.conn?.send({ type: 'chat.error', code, message });
  }

  private handleChatSend(seat: Seat, s: HumanSeat, msg: Extract<ChatClientMessage, { type: 'chat.send' }>): void {
    const now = this.deps.clock.now();
    if (s.chatRestrictedUntil !== null && now < s.chatRestrictedUntil) {
      this.chatError(s, 'RESTRICTED', 'bạn đang bị hạn chế chat tạm thời do bị báo cáo nhiều lần');
      return;
    }
    if (!s.chatLimiter.allow(now)) {
      this.chatError(s, 'RATE_LIMITED', 'gửi chat quá nhanh, chậm lại một chút');
      return;
    }
    let targets: HumanSeat[];
    if (msg.channel === 'whisper') {
      // Schema đã bảo đảm `to` có mặt đúng lúc channel === 'whisper' (xem ChatSendSchema, packages/protocol).
      const to = msg.to as Seat;
      const target = this.seats[to];
      if (target.kind !== 'human' || to === seat) {
        this.chatError(s, 'INVALID_TARGET', 'không nhắn riêng được cho ghế này'); // PLAN 8.2: không nhắn được cho bot
        return;
      }
      targets = [s, target]; // vọng lại cho chính người gửi để UI của họ cập nhật (không có kênh "đã gửi" riêng)
    } else if (msg.channel === 'dead') {
      if (!this.isEliminated(seat)) {
        this.chatError(s, 'NOT_ALLOWED', 'chỉ người đã bị loại mới chat được ở kênh này'); // PLAN 8.1
        return;
      }
      targets = this.humanSeatsMatching((x) => this.isEliminated(x));
    } else {
      targets = this.humanSeatsMatching(() => true);
    }
    const entry: ChatMessage =
      msg.kind === 'text'
        ? { type: 'chat.message', id: randomUUID(), channel: msg.channel, from: seat, ...(msg.to !== undefined ? { to: msg.to } : {}), kind: 'text', text: msg.text, at: now }
        : {
            type: 'chat.message',
            id: randomUUID(),
            channel: msg.channel,
            from: seat,
            ...(msg.to !== undefined ? { to: msg.to } : {}),
            kind: 'phrase',
            phraseId: msg.phraseId,
            at: now,
          };
    s.recentMessages.push({ at: now, channel: msg.channel, kind: msg.kind, ...(msg.kind === 'text' ? { text: msg.text } : { phraseId: msg.phraseId }) });
    if (s.recentMessages.length > CHAT_LOG_CAPACITY) s.recentMessages.shift();
    for (const t of targets) t.conn?.send(entry);
  }

  private handleReport(seat: Seat, s: HumanSeat, msg: ReportPlayer): void {
    const target = this.seats[msg.seat];
    if (target.kind !== 'human' || msg.seat === seat) {
      this.chatError(s, 'INVALID_TARGET', 'không báo cáo được ghế này');
      return;
    }
    const now = this.deps.clock.now();
    target.reportedAt = target.reportedAt.filter((r) => now - r.at < CHAT_REPORT_WINDOW_MS);
    // Một người báo cáo lại (đổi ý lý do, hay bấm nhầm) chỉ CẬP NHẬT mốc giờ của chính họ, không cộng thêm một suất
    // đếm nữa — ngưỡng đếm theo NGƯỜI báo cáo khác nhau (PLAN 8.4 "bị báo cáo nhiều lần", xem docs/questions.md Q-29).
    target.reportedAt = [...target.reportedAt.filter((r) => r.reporterId !== s.identityId), { at: now, reporterId: s.identityId }];
    if (target.reportedAt.length >= CHAT_REPORT_THRESHOLD) target.chatRestrictedUntil = now + CHAT_RESTRICTION_MS; // PLAN 8.4
    s.conn?.send({ type: 'report.ack' });
  }

  private handleVoiceSignal(seat: Seat, msg: VoiceSignal): void {
    const target = this.seats[msg.to];
    // Không tin/không hiểu nội dung (PLAN 8.5): chỉ relay nguyên văn `data` cho đúng một ghế đích đang kết nối.
    if (target.kind !== 'human' || target.conn === null || msg.to === seat) return;
    target.conn.send({ type: 'voice.signal', from: seat, data: msg.data });
  }

  private promoteHostIfNeeded(): void {
    if (this.hostIdentityId !== null && this.findHumanSeat(this.hostIdentityId) !== null) return;
    this.hostIdentityId = null;
    for (const s of this.seats) {
      if (s.kind === 'human') {
        this.hostIdentityId = s.identityId;
        break;
      }
    }
  }

  private clearSeatTimer(seat: Seat): void {
    const s = this.seats[seat];
    if (s.kind === 'human' && s.graceTimer !== null) {
      clearTimeout(s.graceTimer);
      s.graceTimer = null;
    }
  }

  private armGraceTimer(seat: Seat, identityId: string): void {
    this.clearSeatTimer(seat);
    const graceMs = this.config.turn.reconnectGraceSeconds * 1000;
    (this.seats[seat] as HumanSeat).graceTimer = setTimeout(() => this.expireSeat(seat, identityId), graceMs);
  }

  private expireSeat(seat: Seat, identityId: string): void {
    const s = this.seats[seat];
    if (s.kind !== 'human' || s.identityId !== identityId || s.conn !== null) return; // đã vào lại hoặc ghế đã đổi chủ
    s.expired = true;
    s.graceTimer = null;
    if (this.phase === 'lobby') {
      this.seats[seat] = { kind: 'empty' };
      this.promoteHostIfNeeded();
    }
    // Giữa ván: ghế vẫn là 'human' đối với GameSession — X-04 tự lo bot lái tạm khi hết giờ liên tiếp, độc lập với
    // việc này. Ở đây chỉ khoá không cho token cũ nối lại ghế nữa.
    this.deps.onSeatExpired(identityId);
    this.broadcastRoomState();
  }

  private armBotFillTimer(): void {
    if (!this.deps.quickMatch || this.botFillTimer !== null || this.phase !== 'lobby') return;
    this.botFillArmedAt = Date.now();
    this.botFillTimer = setTimeout(() => this.fillWithBots(), this.deps.botFillDelayMs);
  }

  private clearBotFillTimer(): void {
    if (this.botFillTimer !== null) clearTimeout(this.botFillTimer);
    this.botFillTimer = null;
  }

  private fillWithBots(): void {
    this.botFillTimer = null;
    if (this.phase !== 'lobby') return;
    for (let seat = 0; seat < SEAT_COUNT; seat++) {
      if (this.seats[seat].kind === 'empty') this.seats[seat] = { kind: 'bot', difficulty: 'normal' };
    }
    this.broadcastRoomState();
    this.tryStart();
  }

  private tryStart(): void {
    if (this.phase !== 'lobby' || this.hasEmptySeat) return;
    if (!this.deps.quickMatch && !this.seats.every((s) => s.kind !== 'human' || s.ready)) return;
    this.start();
  }

  private start(): void {
    this.clearBotFillTimer();
    this.phase = 'game';
    const seatSetups: SeatSetup[] = this.seats.map((s, seat) =>
      s.kind === 'bot'
        ? { seat: seat as Seat, kind: 'bot', difficulty: s.difficulty, ...(s.personality !== undefined ? { personality: s.personality } : {}) }
        : { seat: seat as Seat, kind: 'human' },
    );
    // Duy nhất chỗ này dùng ngẫu nhiên thật cho hạt giống ván — không đụng tới tính tất định CỦA engine (GameSession
    // tất định THEO seed đã cho; seed sinh ra sao là việc của nơi chạy nó, PLAN 6.1), mỗi ván online một hạt giống
    // khác nhau như đời thật.
    const seed = Math.floor(Math.random() * 0x1_0000_0000);
    this.session = GameSession.create(
      { config: this.config, seed, seats: seatSetups },
      {
        clock: this.deps.clock,
        bot: this.deps.bot,
        ...(this.deps.timing !== undefined ? { timing: this.deps.timing } : {}),
        broadcast: (message) => this.broadcastGame(message),
        reply: (message) => this.replyTarget?.(message),
      },
    );
    this.broadcastRoomState();
    this.session.start();
  }

  /** Vá lỗi (2) nêu ở đầu file: `game.snapshot` gửi riêng cho từng kết nối với `you` đúng một ghế của họ;
   * `game.events` không có trường `you` nên quảng bá giống hệt cho mọi người. */
  private broadcastGame(message: ServerMessage): void {
    if (message.type === 'game.snapshot') {
      for (let seat = 0; seat < SEAT_COUNT; seat++) {
        const s = this.seats[seat];
        if (s.kind === 'human' && s.conn !== null) s.conn.send({ ...message, you: [seat as Seat] });
      }
      return;
    }
    for (const s of this.seats) {
      if (s.kind === 'human' && s.conn !== null) s.conn.send(message);
    }
    // PLAN 9.4 (đề xuất từ M9, hoãn tới giờ mới làm): sau MỖI nước đi của một ghế bot, hỏi @hexwar/bot xem có nên "nói"
    // gì không — không đụng gì tới GameSession/@hexwar/bot ở phía luật (đúng như đã ghi ở docs/decisions.md),
    // chỉ cắm thêm ở đây vì Room đã sẵn mọi thứ cần để gửi một ChatMessage thật (randomUUID, đích theo kênh).
    if (message.type === 'game.events') this.maybeSendBotChat(message);
  }

  /** Chỉ kích hoạt khi hành động vừa broadcast là MỘT NƯỚC ĐI THẬT của một ghế ĐANG LÀ BOT (không phải lượt hết
   * giờ/tung xúc xắc/đầu hàng, và không phải ghế người đang bị bot lái tạm — X-04 — vì đó vẫn là ghế của một
   * người thật). RNG dùng `botChatRngFor` (dòng riêng, không phải dòng chọn nước của `botRngFor`) nên có/không
   * "nói" gì không bao giờ ảnh hưởng tới nước đi đã chọn (X-11 phát lại vẫn đúng bit-for-bit). */
  private maybeSendBotChat(message: Extract<ServerMessage, { type: 'game.events' }>): void {
    if (message.action.kind !== 'move') return;
    const seat = message.action.seat;
    const seatData = this.seats[seat];
    if (seatData.kind !== 'bot') return;
    const rng = botChatRngFor(message.state, seat, message.seq);
    const decision = decideBotChat(message.state, seat, message.events, seatData.personality ?? 'balanced', rng);
    if (decision === null) return;
    const entry: ChatMessage = {
      type: 'chat.message',
      id: randomUUID(),
      channel: decision.channel,
      from: seat,
      ...(decision.to !== undefined ? { to: decision.to } : {}),
      kind: 'phrase',
      phraseId: asPhraseId(decision.phraseId),
      at: this.deps.clock.now(),
    };
    // 'whisper': chỉ đúng một ghế đích (nếu đích là ghế bot/trống thì không ai nhận — im lặng, không lỗi).
    // 'all': mọi ghế người đang kết nối, giống hệt targets của chat.send kênh "all" (handleChatSend).
    const targets = decision.channel === 'whisper' ? this.humanSeatsMatching((s) => s === decision.to) : this.humanSeatsMatching(() => true);
    for (const t of targets) t.conn?.send(entry);
  }

  private broadcastRoomState(): void {
    const base: RoomSeatView[] = this.seats.map((s, seat) => {
      if (s.kind === 'empty') return { seat: seat as Seat, kind: 'empty', ready: false, connected: true, you: false };
      if (s.kind === 'bot') {
        return {
          seat: seat as Seat,
          kind: 'bot',
          difficulty: s.difficulty,
          ...(s.personality !== undefined ? { personality: s.personality } : {}),
          ready: true,
          connected: true,
          you: false,
        };
      }
      return { seat: seat as Seat, kind: 'human', name: s.name, ready: this.deps.quickMatch || s.ready, connected: s.conn !== null, you: false };
    });
    const hostSeat = this.hostIdentityId === null ? null : this.findHumanSeat(this.hostIdentityId);
    const botFillInMs = this.botFillTimer === null ? null : Math.max(0, this.deps.botFillDelayMs - (Date.now() - this.botFillArmedAt));
    for (let seat = 0; seat < SEAT_COUNT; seat++) {
      const s = this.seats[seat];
      if (s.kind !== 'human' || s.conn === null) continue;
      const seats = base.map((v, i) => (i === seat ? { ...v, you: true } : v));
      s.conn.send({
        type: 'room.state',
        code: this.deps.code,
        preset: this.presetName,
        seats,
        host: hostSeat,
        quickMatch: this.deps.quickMatch,
        botFillInMs,
      });
    }
  }
}
