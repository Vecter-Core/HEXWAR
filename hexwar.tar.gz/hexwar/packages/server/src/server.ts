// HexwarServer (PLAN 7): điểm vào WebSocket duy nhất — nhận "hello" để cấp/nhận lại danh tính khách (PLAN 7.1,
// 7.5), rồi định tuyến message theo hai tầng trên CÙNG một kết nối (PLAN 7.3 header): message phòng/ghép trận
// (`LOBBY_MESSAGE_TYPES`, xử lý ở đây) và message ván (`game.*`, chuyển thẳng cho đúng `Room.handleGameMessage`,
// bản thân Room/GameSession tự kiểm schema — PLAN 7.6 "không tin dữ liệu client").
//
// Không tin dữ liệu client (PLAN 7.6): kích thước message chặn bằng `maxPayload` của WebSocketServer (thư viện tự
// đóng kết nối khi vượt), tốc độ gửi chặn bằng RateLimiter mỗi kết nối, nội dung luôn qua schema Zod trước khi chạm
// logic phòng hay engine.
import { randomUUID } from 'node:crypto';
import {
  CHAT_MESSAGE_TYPES,
  ChatClientMessageSchema,
  LOBBY_MESSAGE_TYPES,
  LobbyClientMessageSchema,
  ROOM_CODE_ALPHABET,
  type ChatServerMessage,
  type LobbyClientMessage,
  type LobbyErrorCode,
  type LobbyServerMessage,
  type ServerMessage,
  type SessionTiming,
} from '@hexwar/protocol';
import type { PresetName } from '@hexwar/rules';
import { WebSocketServer, type RawData, type ServerOptions, type WebSocket } from 'ws';
import { botBrain, realClock } from './bot';
import { RateLimiter, type PlayerConnection } from './connection';
import { IdentityStore, type Identity } from './identity';
import { Matchmaker } from './matchmaker';
import { Room } from './room';

export interface HexwarServerOptions {
  /** Client "hello" khác `rulesVersion` này bị từ chối (PLAN 7.1) — tránh ghép nhầm hai bản luật khác nhau. */
  readonly rulesVersion: string;
  /** Ghép nhanh: chờ chừng này (ms) trước khi lấp bot vào ghế trống. Mặc định 20 giây thật; test truyền nhỏ lại. */
  readonly botFillDelayMs?: number;
  /** Ghi đè nhịp trình bày của GameSession (PLAN 7.4) — test dùng để chạy cả ván gần như tức thì với đồng hồ thật. */
  readonly timing?: Partial<SessionTiming>;
  /** CHỈ để test (xem room.ts) — ghi đè `turn.reconnectGraceSeconds` (mặc định thật 90 giây). */
  readonly reconnectGraceSecondsOverride?: number;
}

interface ConnectionState {
  identity: Identity | null;
  roomId: string | null;
  readonly rateLimiter: RateLimiter;
}

const MAX_MESSAGE_BYTES = 16 * 1024;
const DEFAULT_BOT_FILL_DELAY_MS = 20_000;
const RATE_LIMIT_CAPACITY = 40;
const RATE_LIMIT_REFILL_PER_SECOND = 20;

export class HexwarServer {
  private readonly wss: WebSocketServer;
  private readonly identities = new IdentityStore();
  private readonly rooms = new Map<string, Room>();
  /** identityId -> id phòng đang giữ ghế cho họ (sảnh hoặc giữa ván) — dùng để định tuyến "hello" có token vào lại
   * đúng phòng, và để định tuyến message `game.*` sau đó (PLAN 7.5). */
  private readonly placement = new Map<string, string>();
  private readonly conns = new Map<WebSocket, ConnectionState>();
  private readonly matchmaker: Matchmaker;

  constructor(
    private readonly options: HexwarServerOptions,
    wsOptions: ServerOptions,
  ) {
    this.matchmaker = new Matchmaker((preset) => this.createRoom(preset, true, null));
    this.wss = new WebSocketServer({ ...wsOptions, maxPayload: MAX_MESSAGE_BYTES });
    this.wss.on('connection', (ws) => this.onConnection(ws));
  }

  /** Cổng TCP thật đang lắng nghe — tiện cho test dùng `{ port: 0 }` (cổng do hệ điều hành chọn). */
  get port(): number {
    const address = this.wss.address();
    if (address === null || typeof address === 'string') throw new Error('HexwarServer: chưa lắng nghe trên một cổng TCP');
    return address.port;
  }

  close(): Promise<void> {
    return new Promise((resolve, reject) => {
      for (const ws of this.wss.clients) ws.terminate();
      this.wss.close((err) => (err !== undefined ? reject(err) : resolve()));
    });
  }

  // ---- Kết nối --------------------------------------------------------------------------------------------------

  private onConnection(ws: WebSocket): void {
    const conn: ConnectionState = { identity: null, roomId: null, rateLimiter: new RateLimiter(RATE_LIMIT_CAPACITY, RATE_LIMIT_REFILL_PER_SECOND) };
    this.conns.set(ws, conn);
    ws.on('message', (data) => this.onRawMessage(ws, conn, data));
    ws.on('close', () => this.onClose(ws, conn));
    // Không có listener 'error' thì EventEmitter ném lỗi này ra ngoài tiến trình (ví dụ: message vượt maxPayload,
    // PLAN 7.6) — 'close' ngay sau đó đã đủ để dọn dẹp (onClose), ở đây chỉ cần không để nó làm sập server.
    ws.on('error', () => {});
  }

  private onClose(ws: WebSocket, conn: ConnectionState): void {
    if (conn.roomId !== null && conn.identity !== null) this.rooms.get(conn.roomId)?.disconnect(conn.identity.id);
    this.conns.delete(ws);
  }

  private onRawMessage(ws: WebSocket, conn: ConnectionState, data: RawData): void {
    if (!conn.rateLimiter.allow()) {
      this.sendLobbyError(ws, 'RATE_LIMITED', 'gửi quá nhanh, chậm lại một chút');
      return;
    }
    let raw: unknown;
    try {
      raw = JSON.parse(data.toString());
    } catch {
      this.sendLobbyError(ws, 'BAD_MESSAGE', 'không phải JSON hợp lệ');
      return;
    }
    this.onMessage(ws, conn, raw);
  }

  private onMessage(ws: WebSocket, conn: ConnectionState, raw: unknown): void {
    const typeField = raw !== null && typeof raw === 'object' ? (raw as { type?: unknown }).type : undefined;
    if (typeof typeField === 'string' && LOBBY_MESSAGE_TYPES.has(typeField as LobbyClientMessage['type'])) {
      const parsed = LobbyClientMessageSchema.safeParse(raw);
      if (!parsed.success) {
        this.sendLobbyError(ws, 'BAD_MESSAGE', 'message phòng/ghép trận không hợp lệ');
        return;
      }
      this.handleLobbyMessage(ws, conn, parsed.data);
      return;
    }
    // Chat/báo cáo/tín hiệu voice (PLAN mục 8) — có nghĩa cả ở sảnh lẫn giữa ván, không phải tầng ván (`game.*`) nên
    // tách riêng khỏi nó TRƯỚC khi rơi vào nhánh mặc định bên dưới.
    if (typeof typeField === 'string' && CHAT_MESSAGE_TYPES.has(typeField as 'chat.send' | 'report.player' | 'voice.signal')) {
      const parsed = ChatClientMessageSchema.safeParse(raw);
      if (!parsed.success) {
        this.sendLobbyError(ws, 'BAD_MESSAGE', 'message chat/báo cáo/voice không hợp lệ');
        return;
      }
      if (conn.identity === null) {
        this.sendLobbyError(ws, 'BAD_MESSAGE', 'cần "hello" trước');
        return;
      }
      if (conn.roomId === null) {
        this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
        return;
      }
      this.rooms.get(conn.roomId)?.handleChatMessage(conn.identity.id, parsed.data);
      return;
    }
    // Không phải hai tầng trên: coi là message tầng ván (`game.*`) — GameSession tự kiểm schema (PLAN 7.6).
    if (conn.identity === null) {
      this.sendLobbyError(ws, 'BAD_MESSAGE', 'cần "hello" trước');
      return;
    }
    if (conn.roomId === null) {
      this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
      return;
    }
    this.rooms.get(conn.roomId)?.handleGameMessage(conn.identity.id, raw);
  }

  // ---- Tầng phòng/ghép trận ---------------------------------------------------------------------------------------

  private handleLobbyMessage(ws: WebSocket, conn: ConnectionState, msg: LobbyClientMessage): void {
    if (msg.type === 'hello') {
      this.handleHello(ws, conn, msg);
      return;
    }
    if (conn.identity === null) {
      this.sendLobbyError(ws, 'BAD_MESSAGE', 'cần "hello" trước');
      return;
    }
    this.handleRoomMessage(ws, conn, conn.identity, msg);
  }

  private handleHello(ws: WebSocket, conn: ConnectionState, msg: Extract<LobbyClientMessage, { type: 'hello' }>): void {
    if (msg.rulesVersion !== this.options.rulesVersion) {
      this.sendLobbyError(ws, 'RULES_VERSION', `server đang chạy luật phiên bản "${this.options.rulesVersion}"`);
      return;
    }
    const existing = msg.token !== undefined ? this.identities.find(msg.token) : undefined;
    const identity = existing ?? this.identities.createGuest(msg.name);
    conn.identity = identity;
    this.send(ws, { type: 'hello.ack', token: identity.token, identityId: identity.id, name: identity.name });

    const roomId = this.placement.get(identity.id);
    if (roomId === undefined) return;
    const room = this.rooms.get(roomId);
    const result = room?.reconnect(identity.id, this.connectionFor(ws));
    if (room !== undefined && result === 'OK') {
      conn.roomId = roomId;
      return;
    }
    // Hết hạn vào lại (PLAN 7.5) hoặc phòng không còn: coi như chưa ở phòng nào, dọn ánh xạ cũ.
    this.placement.delete(identity.id);
  }

  private handleRoomMessage(ws: WebSocket, conn: ConnectionState, identity: Identity, msg: Exclude<LobbyClientMessage, { type: 'hello' }>): void {
    switch (msg.type) {
      case 'queue.join': {
        if (conn.roomId !== null) {
          this.sendLobbyError(ws, 'ALREADY_IN_ROOM', 'đã ở trong một phòng rồi');
          return;
        }
        const room = this.matchmaker.join(msg.preset);
        const result = room.addHuman(identity.id, identity.name, this.connectionFor(ws));
        if (result === 'ROOM_FULL' || result === 'ROOM_STARTED') {
          this.sendLobbyError(ws, 'ROOM_FULL', 'phòng vừa đầy, thử lại');
          return;
        }
        conn.roomId = room.id;
        this.placement.set(identity.id, room.id);
        return;
      }
      case 'queue.leave':
      case 'room.leave': {
        if (conn.roomId === null) return;
        this.rooms.get(conn.roomId)?.removeHuman(identity.id);
        this.placement.delete(identity.id);
        conn.roomId = null;
        return;
      }
      case 'room.create': {
        if (conn.roomId !== null) {
          this.sendLobbyError(ws, 'ALREADY_IN_ROOM', 'đã ở trong một phòng rồi');
          return;
        }
        const room = this.createRoom(msg.preset, false, this.generateRoomCode());
        room.addHuman(identity.id, identity.name, this.connectionFor(ws));
        conn.roomId = room.id;
        this.placement.set(identity.id, room.id);
        return;
      }
      case 'room.join': {
        if (conn.roomId !== null) {
          this.sendLobbyError(ws, 'ALREADY_IN_ROOM', 'đã ở trong một phòng rồi');
          return;
        }
        const room = this.findRoomByCode(msg.code);
        if (room === undefined) {
          this.sendLobbyError(ws, 'ROOM_NOT_FOUND', 'không thấy phòng với mã này');
          return;
        }
        const result = room.addHuman(identity.id, identity.name, this.connectionFor(ws));
        if (result === 'ROOM_FULL' || result === 'ROOM_STARTED') {
          this.sendLobbyError(ws, result, result === 'ROOM_FULL' ? 'phòng đã đầy' : 'ván đã bắt đầu');
          return;
        }
        conn.roomId = room.id;
        this.placement.set(identity.id, room.id);
        return;
      }
      case 'room.ready': {
        const room = this.roomOf(conn);
        if (room === undefined) {
          this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
          return;
        }
        const result = room.setReady(identity.id, msg.ready);
        if (result !== 'OK') this.sendLobbyError(ws, result, 'không đổi được trạng thái sẵn sàng');
        return;
      }
      case 'room.addBot': {
        const room = this.roomOf(conn);
        if (room === undefined) {
          this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
          return;
        }
        const result = room.addBot(identity.id, msg.difficulty, msg.personality);
        if (result !== 'OK') this.sendLobbyError(ws, result, 'không thêm được bot');
        return;
      }
      case 'room.removeBot': {
        const room = this.roomOf(conn);
        if (room === undefined) {
          this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
          return;
        }
        const result = room.removeBot(identity.id, msg.seat);
        if (result !== 'OK') this.sendLobbyError(ws, result, 'không bỏ được bot');
        return;
      }
      case 'room.setConfig': {
        const room = this.roomOf(conn);
        if (room === undefined) {
          this.sendLobbyError(ws, 'NOT_IN_ROOM', 'chưa vào phòng nào');
          return;
        }
        const result = room.setConfig(identity.id, msg.preset);
        if (result !== 'OK') this.sendLobbyError(ws, result, 'không đổi được luật chơi');
        return;
      }
    }
  }

  private roomOf(conn: ConnectionState): Room | undefined {
    return conn.roomId !== null ? this.rooms.get(conn.roomId) : undefined;
  }

  private createRoom(preset: PresetName, quickMatch: boolean, code: string | null): Room {
    const id = randomUUID();
    const room = new Room({
      id,
      code,
      quickMatch,
      initialPreset: preset,
      bot: botBrain,
      clock: realClock,
      ...(this.options.timing !== undefined ? { timing: this.options.timing } : {}),
      botFillDelayMs: this.options.botFillDelayMs ?? DEFAULT_BOT_FILL_DELAY_MS,
      onSeatExpired: (identityId) => this.placement.delete(identityId),
      ...(this.options.reconnectGraceSecondsOverride !== undefined
        ? { reconnectGraceSecondsOverride: this.options.reconnectGraceSecondsOverride }
        : {}),
    });
    this.rooms.set(id, room);
    return room;
  }

  private findRoomByCode(code: string): Room | undefined {
    for (const room of this.rooms.values()) if (room.code === code) return room;
    return undefined;
  }

  private generateRoomCode(): string {
    for (;;) {
      let code = '';
      for (let i = 0; i < 6; i++) code += ROOM_CODE_ALPHABET[Math.floor(Math.random() * ROOM_CODE_ALPHABET.length)];
      if (this.findRoomByCode(code) === undefined) return code;
    }
  }

  // ---- Gửi --------------------------------------------------------------------------------------------------------

  private connectionFor(ws: WebSocket): PlayerConnection {
    return { send: (message) => this.send(ws, message) };
  }

  private send(ws: WebSocket, message: ServerMessage | LobbyServerMessage | ChatServerMessage): void {
    if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(message));
  }

  private sendLobbyError(ws: WebSocket, code: LobbyErrorCode, message: string): void {
    this.send(ws, { type: 'lobby.error', code, message });
  }
}
