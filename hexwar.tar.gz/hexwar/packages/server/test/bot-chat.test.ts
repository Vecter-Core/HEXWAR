// Bot chat (PLAN 9.4, để dành từ M9, làm sau M10): bot thỉnh thoảng gửi câu chat có sẵn sau nước đi của nó
// (packages/server/src/room.ts `maybeSendBotChat`, quyết định thật nằm ở `@hexwar/bot` `decideBotChat`).
//
// `@hexwar/server` là gói DUY NHẤT phụ thuộc CẢ `@hexwar/bot` LẪN `@hexwar/protocol` (bot cố tình không phụ
// thuộc protocol, xem đầu file room.ts và docs/decisions.md mục M9) — nên bài test đối chiếu "tập câu bot biết
// dùng vẫn là tập con hợp lệ của giao thức chat thật" chỉ có thể sống ở đây.
import { afterEach, describe, expect, it } from 'vitest';
import { BOT_PHRASE_IDS } from '@hexwar/bot';
import { PHRASE_IDS, type ChatServerMessage, type LobbyServerMessage, type PhraseId, type ServerMessage } from '@hexwar/protocol';
import { defaultConfig, type Seat } from '@hexwar/rules';
import type { HexwarServer } from '../src/index';
import { isType, startServer, TestClient } from './support';

type HelloAck = Extract<LobbyServerMessage, { type: 'hello.ack' }>;
type RoomState = Extract<LobbyServerMessage, { type: 'room.state' }>;
type GameEvents = Extract<ServerMessage, { type: 'game.events' }>;
type ChatMessage = Extract<ChatServerMessage, { type: 'chat.message' }>;

let server: HexwarServer | null = null;
let clients: TestClient[] = [];

afterEach(async () => {
  await Promise.all(clients.map((c) => c.close()));
  clients = [];
  await server?.close();
  server = null;
});

describe('BOT_PHRASE_IDS (packages/bot) là tập con hợp lệ của PhraseId thật (packages/protocol)', () => {
  it('mọi câu bot biết dùng đều là một PhraseId thật, không lệch tay khi một bên đổi', () => {
    const real = new Set<string>(PHRASE_IDS);
    for (const id of BOT_PHRASE_IDS) {
      const asReal: PhraseId = id; // lỗi biên dịch ở đây tự nó đã là một cách bắt lệch kiểu (không cần ép kiểu)
      expect(real.has(asReal)).toBe(true);
    }
  });
});

describe('bot chat thật qua WebSocket (PLAN 9.4, hoãn từ M9): bot tự nhắn sau nước đi của nó', () => {
  it('phòng 1 người thật (tự đầu hàng ngay) + 5 bot chơi nhanh: sớm muộn cũng thấy một câu chat từ ghế bot', async () => {
    server = startServer();
    const human = await TestClient.connect(server.port);
    clients.push(human);
    human.send({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name: 'Người xem' });
    await human.waitFor(isType<HelloAck>('hello.ack'));
    human.send({ type: 'room.create', preset: 'classic' });
    await human.waitFor(isType<RoomState>('room.state'));
    let state: RoomState | undefined;
    for (let i = 0; i < 5; i++) {
      human.send({ type: 'room.addBot', difficulty: 'normal' });
      state = await human.waitFor(isType<RoomState>('room.state'));
    }
    const botSeats = new Set((state as RoomState).seats.filter((s) => s.kind === 'bot').map((s) => s.seat as Seat));
    expect(botSeats.size).toBe(5);
    human.send({ type: 'room.ready', ready: true });
    await human.waitFor((m): m is GameEvents => isType<GameEvents>('game.events')(m) && m.state.phase === 'playing');
    // Rời khỏi bàn ngay (X-05) để 5 bot còn lại chơi ở "chế độ khán giả" (spectatorBotDelayMs, FAST_TIMING = 0)
    // — chạy hết nhiều lượt bot thật nhanh, tăng cơ hội gặp ít nhất một câu chat trong thời gian chờ hợp lý.
    human.send({ type: 'game.resign' });

    const msg = await human.waitFor(isType<ChatMessage>('chat.message'), 10_000);
    expect(msg.kind).toBe('phrase');
    if (msg.kind !== 'phrase') throw new Error('không tới đây');
    expect(BOT_PHRASE_IDS as readonly string[]).toContain(msg.phraseId);
    expect(botSeats.has(msg.from)).toBe(true); // luôn xuất phát từ một ghế BOT, không phải từ người
    if (msg.channel === 'whisper') expect(msg.to).toBeDefined();
  }, 15_000);
});
