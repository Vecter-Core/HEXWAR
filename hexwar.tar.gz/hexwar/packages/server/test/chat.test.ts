// Test tích hợp chat/báo cáo/voice (PLAN mục 8) qua server THẬT — client `ws` thật, không mock tầng nào. Trọng tâm
// nghiệm thu M7: "whisper chỉ tới đúng người" (test tự động), cộng giới hạn tốc độ/hạn chế do báo cáo (PLAN 8.4),
// kênh "Người đã bị loại" (PLAN 8.1) và relay tín hiệu voice (PLAN 8.5, xem docs/decisions.md M7 vì sao chỉ relay).
import { afterEach, describe, expect, it } from 'vitest';
import { defaultConfig, type Seat } from '@hexwar/rules';
import type { ChatServerMessage, LobbyServerMessage, ServerMessage } from '@hexwar/protocol';
import type { HexwarServer } from '../src/index';
import { isType, startServer, TestClient } from './support';

type HelloAck = Extract<LobbyServerMessage, { type: 'hello.ack' }>;
type RoomState = Extract<LobbyServerMessage, { type: 'room.state' }>;
type GameSnapshot = Extract<ServerMessage, { type: 'game.snapshot' }>;
type GameEvents = Extract<ServerMessage, { type: 'game.events' }>;
type ChatMessage = Extract<ChatServerMessage, { type: 'chat.message' }>;
type ChatError = Extract<ChatServerMessage, { type: 'chat.error' }>;
type ReportAck = Extract<ChatServerMessage, { type: 'report.ack' }>;
type VoiceSignal = Extract<ChatServerMessage, { type: 'voice.signal' }>;

let server: HexwarServer | null = null;
let clients: TestClient[] = [];

afterEach(async () => {
  await Promise.all(clients.map((c) => c.close()));
  clients = [];
  await server?.close();
  server = null;
});

async function join(port: number, name: string): Promise<{ client: TestClient; ack: HelloAck }> {
  const client = await TestClient.connect(port);
  clients.push(client);
  client.send({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name });
  const ack = await client.waitFor(isType<HelloAck>('hello.ack'));
  return { client, ack };
}

/** Dựng một phòng riêng đủ 6 người thật, tất cả Sẵn sàng — trả về khi ván đã bắt đầu (mỗi client đã có snapshot). */
async function startSixHumanGame(port: number): Promise<{ client: TestClient; ack: HelloAck; snapshot: GameSnapshot }[]> {
  const players: { client: TestClient; ack: HelloAck }[] = [await join(port, 'P0')];
  players[0].client.send({ type: 'room.create', preset: 'classic' });
  const hostState = await players[0].client.waitFor(isType<RoomState>('room.state'));
  const code = hostState.code as string;
  for (let i = 1; i < 6; i++) {
    const p = await join(port, `P${i}`);
    p.client.send({ type: 'room.join', code });
    await p.client.waitFor(isType<RoomState>('room.state'));
    players.push(p);
  }
  for (const p of players) p.client.send({ type: 'room.ready', ready: true });
  const withSnapshots = [];
  for (const p of players) withSnapshots.push({ ...p, snapshot: await p.client.waitFor(isType<GameSnapshot>('game.snapshot'), 3000) });
  return withSnapshots;
}

/** true nếu người này CÓ nhận được một message khớp `predicate` trong `timeoutMs` — dùng cho khẳng định "không ai
 * khác thấy" (đổi timeout-từ-chối thành `false` thay vì để lỗi chưa-bắt văng ra, xem docs/decisions.md M6 — cùng
 * bài học rút ra từ một lỗi test đua trước đó). */
function sawMessage<T>(client: TestClient, predicate: (m: unknown) => m is T, timeoutMs = 300): Promise<boolean> {
  return client.waitFor(predicate, timeoutMs).then(
    () => true,
    () => false,
  );
}

describe('chat toàn phòng + nhắn riêng (PLAN 8.1, 8.2)', () => {
  it('chat.send channel=all phát cho mọi ghế đã kết nối, kể cả người gửi', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a] = players;
    a.client.send({ type: 'chat.send', channel: 'all', kind: 'text', text: 'Chào cả nhà!' });
    for (const p of players) {
      const msg = await p.client.waitFor(isType<ChatMessage>('chat.message'));
      expect(msg.channel).toBe('all');
      expect(msg.from).toBe(a.snapshot.you[0]);
      expect(msg.kind === 'text' && msg.text).toBe('Chào cả nhà!');
    }
  });

  it('câu có sẵn gửi bằng mã (phraseId), không phải chữ tự do (PLAN 8.3)', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b] = players;
    a.client.send({ type: 'chat.send', channel: 'all', kind: 'phrase', phraseId: 'greeting.goodLuck' });
    const msg = await b.client.waitFor(isType<ChatMessage>('chat.message'));
    expect(msg.kind === 'phrase' && msg.phraseId).toBe('greeting.goodLuck');
  });

  it('nhắn riêng chỉ tới đúng người gửi + người nhận, không ai khác thấy (nghiệm thu M7)', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b, ...rest] = players;
    const bSeat = b.snapshot.you[0];
    a.client.send({ type: 'chat.send', channel: 'whisper', to: bSeat, kind: 'text', text: 'chỉ mình bạn thấy nhé' });
    const atA = await a.client.waitFor(isType<ChatMessage>('chat.message'));
    const atB = await b.client.waitFor(isType<ChatMessage>('chat.message'));
    expect(atA.channel).toBe('whisper');
    expect(atB.channel === 'whisper' && atB.kind === 'text' && atB.text).toBe('chỉ mình bạn thấy nhé');
    const bystandersSaw = await Promise.all(rest.map((p) => sawMessage(p.client, isType<ChatMessage>('chat.message'))));
    expect(bystandersSaw.every((saw) => !saw)).toBe(true);
  });

  it('không nhắn riêng được cho bot hoặc cho chính mình (PLAN 8.2 "không nhắn riêng cho bot được")', async () => {
    server = startServer();
    const a = await join(server.port, 'Solo');
    a.client.send({ type: 'room.create', preset: 'classic' });
    await a.client.waitFor(isType<RoomState>('room.state'));
    a.client.send({ type: 'room.addBot', difficulty: 'easy' });
    const state = await a.client.waitFor(isType<RoomState>('room.state'));
    const botSeat = state.seats.find((s) => s.kind === 'bot')?.seat as Seat;
    const selfSeat = state.seats.find((s) => s.kind === 'human')?.seat as Seat;

    a.client.send({ type: 'chat.send', channel: 'whisper', to: botSeat, kind: 'text', text: 'hi' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('INVALID_TARGET');

    a.client.send({ type: 'chat.send', channel: 'whisper', to: selfSeat, kind: 'text', text: 'hi' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('INVALID_TARGET');
  });
});

describe('giới hạn tốc độ + hạn chế do báo cáo (PLAN 8.4)', () => {
  it('quá 5 tin / 10 giây thì bị RATE_LIMITED (riêng cho chat, không đụng giới hạn chung của kết nối)', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a] = players;
    for (let i = 0; i < 5; i++) a.client.send({ type: 'chat.send', channel: 'all', kind: 'text', text: `tin ${i}` });
    for (let i = 0; i < 5; i++) await a.client.waitFor(isType<ChatMessage>('chat.message'));
    a.client.send({ type: 'chat.send', channel: 'all', kind: 'text', text: 'tin thứ 6, phải bị chặn' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('RATE_LIMITED');
  });

  it('bị 3 người khác báo cáo trong ngày thì bị hạn chế chat tạm thời', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b, c, d] = players;
    const aSeat = a.snapshot.you[0];
    for (const reporter of [b, c, d]) {
      reporter.client.send({ type: 'report.player', seat: aSeat, reason: 'spam' });
      await reporter.client.waitFor(isType<ReportAck>('report.ack'));
    }
    a.client.send({ type: 'chat.send', channel: 'all', kind: 'text', text: 'còn nói được không' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('RESTRICTED');
  });

  it('một người báo cáo NHIỀU LẦN không cộng dồn thành "nhiều người báo cáo" (chống tự ý câm người khác một mình)', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b] = players;
    const aSeat = a.snapshot.you[0];
    for (let i = 0; i < 3; i++) {
      b.client.send({ type: 'report.player', seat: aSeat, reason: 'spam' });
      await b.client.waitFor(isType<ReportAck>('report.ack'));
    }
    a.client.send({ type: 'chat.send', channel: 'all', kind: 'text', text: 'vẫn nói được, chỉ một người báo cáo thôi' });
    const msg = await a.client.waitFor(isType<ChatMessage>('chat.message'));
    expect(msg.kind === 'text' && msg.text).toBe('vẫn nói được, chỉ một người báo cáo thôi');
  });

  it('không báo cáo được ghế trống/bot/chính mình', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a] = players;
    a.client.send({ type: 'report.player', seat: a.snapshot.you[0], reason: 'spam' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('INVALID_TARGET');
  });
});

describe('kênh "Người đã bị loại" (PLAN 8.1)', () => {
  it('chỉ người đã bị loại mới gửi/nhận được; người đang chơi bị NOT_ALLOWED', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, ...rest] = players;

    a.client.send({ type: 'chat.send', channel: 'dead', kind: 'text', text: 'chưa ai bị loại cả' });
    expect((await a.client.waitFor(isType<ChatError>('chat.error'))).code).toBe('NOT_ALLOWED');

    await a.client.waitFor((m): m is GameEvents => isType<GameEvents>('game.events')(m) && m.state.phase === 'playing');
    a.client.send({ type: 'game.resign' }); // X-05: tự loại chính mình để có một ghế "đã bị loại" thật
    const aSeat = a.snapshot.you[0];
    await a.client.waitFor((m): m is GameEvents => isType<GameEvents>('game.events')(m) && m.state.eliminated.some((e) => e.seat === aSeat));

    a.client.send({ type: 'chat.send', channel: 'dead', kind: 'text', text: 'chỉ khán giả thấy' });
    const seen = await a.client.waitFor(isType<ChatMessage>('chat.message'));
    expect(seen.channel).toBe('dead');
    const bystandersSaw = await Promise.all(rest.map((p) => sawMessage(p.client, isType<ChatMessage>('chat.message'))));
    expect(bystandersSaw.every((saw) => !saw)).toBe(true); // R-14: 5 người còn lại vẫn đang chơi, không thấy kênh này
  });
});

describe('voice.signal relay (PLAN 8.5)', () => {
  it('relay nguyên văn tới đúng một ghế đích, không hiểu/không đổi nội dung', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b, ...rest] = players;
    const payload = { sdp: 'v=0 (giả lập offer SDP)' };
    a.client.send({ type: 'voice.signal', to: b.snapshot.you[0], data: payload });
    const signal = await b.client.waitFor(isType<VoiceSignal>('voice.signal'));
    expect(signal.from).toBe(a.snapshot.you[0]);
    expect(signal.data).toEqual(payload);
    const bystandersSaw = await Promise.all(rest.map((p) => sawMessage(p.client, isType<VoiceSignal>('voice.signal'))));
    expect(bystandersSaw.every((saw) => !saw)).toBe(true);
  });

  it('không relay được cho ghế đang mất kết nối (im lặng bỏ qua, không báo lỗi)', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const [a, b] = players;
    await b.client.close();
    a.client.send({ type: 'voice.signal', to: b.snapshot.you[0], data: {} });
    // Không có `voice.signal` nào quay lại cho `a` (ghế đích đã mất kết nối) — không lỗi, không gì cả, chỉ im lặng.
    const gotSignal = await sawMessage(a.client, isType<VoiceSignal>('voice.signal'), 200);
    expect(gotSignal).toBe(false);
  });
});
