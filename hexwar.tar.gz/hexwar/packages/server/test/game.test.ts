// Test tích hợp tầng ván (`game.*`) qua server thật (PLAN 6.6 nghiệm thu M6: "test tích hợp 6 client + ngắt/nối").
// Trọng tâm: hai chỗ GameSession (viết cho hotseat, M4) bị vá lại cho online nhiều kết nối (xem đầu file room.ts) —
//   1. từ chối (`game.rejected`) chỉ tới ĐÚNG người gửi lệnh hỏng, không phát cho cả phòng;
//   2. mỗi kết nối chỉ thấy `you` là đúng MỘT ghế của mình trong `game.snapshot`.
// Và luồng ngắt/nối lại (PLAN 7.5): mất kết nối giữa ván vẫn giữ ghế trong hạn ân hạn rồi vào lại được; quá hạn thì
// không còn được nhận lại ghế (X-04 của GameSession tự lo bot lái tạm, độc lập với việc này).
import { afterEach, describe, expect, it } from 'vitest';
import type { LobbyServerMessage, ServerMessage } from '@hexwar/protocol';
import { defaultConfig, legalMovesOfPiece, type Seat } from '@hexwar/rules';
import type { HexwarServer } from '../src/index';
import { isType, startServer, TestClient } from './support';

type HelloAck = Extract<LobbyServerMessage, { type: 'hello.ack' }>;
type RoomState = Extract<LobbyServerMessage, { type: 'room.state' }>;
type LobbyError = Extract<LobbyServerMessage, { type: 'lobby.error' }>;
type GameSnapshot = Extract<ServerMessage, { type: 'game.snapshot' }>;
type GameEvents = Extract<ServerMessage, { type: 'game.events' }>;
type GameRejected = Extract<ServerMessage, { type: 'game.rejected' }>;

let server: HexwarServer | null = null;
let clients: TestClient[] = [];

afterEach(async () => {
  await Promise.all(clients.map((c) => c.close()));
  clients = [];
  await server?.close();
  server = null;
});

async function join(port: number, name: string, token?: string): Promise<{ client: TestClient; ack: HelloAck }> {
  const client = await TestClient.connect(port);
  clients.push(client);
  client.send({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name, ...(token !== undefined ? { token } : {}) });
  const ack = await client.waitFor(isType<HelloAck>('hello.ack'));
  return { client, ack };
}

/** Dựng một phòng riêng đủ 6 người thật, tất cả Sẵn sàng — trả về khi ván đã bắt đầu (mỗi client đã có snapshot). */
async function startSixHumanGame(port: number): Promise<{ client: TestClient; ack: HelloAck; snapshot: GameSnapshot }[]> {
  const players: { client: TestClient; ack: HelloAck }[] = [await join(port, 'P0')];
  players[0].client.send({ type: 'room.create', preset: 'classic' });
  const hostState = await players[0].client.waitFor(isType<RoomState>('room.state'));
  const code = hostState.code as string;
  for (let i = 1; i < 6; i++) {
    const p = await join(port, `P${i}`);
    p.client.send({ type: 'room.join', code });
    await p.client.waitFor(isType<RoomState>('room.state'));
    players.push(p);
  }
  for (const p of players) p.client.send({ type: 'room.ready', ready: true });
  const withSnapshots = [];
  for (const p of players) withSnapshots.push({ ...p, snapshot: await p.client.waitFor(isType<GameSnapshot>('game.snapshot'), 3000) });
  return withSnapshots;
}

describe('ván 6 người thật qua WebSocket (PLAN 7.3, 7.6)', () => {
  it('mỗi kết nối chỉ thấy đúng ghế của mình, và 6 ghế không trùng nhau', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const seats = players.map((p) => p.snapshot.you[0]);
    expect(new Set(seats).size).toBe(6);
    for (const p of players) expect(p.snapshot.you).toHaveLength(1);
  });

  it('tung xúc xắc tự động rồi tới lượt: nước đi hợp lệ phát tới cả 6 người; seq sai chỉ báo lỗi cho đúng người gửi', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);

    // autoDiceMs=0 (FAST_TIMING) -> xúc xắc tự tung ngay, mọi người nhận cùng một game.events kind=dice.
    const diceEvents = await Promise.all(players.map((p) => p.client.waitFor(isType<GameEvents>('game.events'), 3000)));
    for (const e of diceEvents) expect(e.action.kind).toBe('dice');
    const afterDice = diceEvents[0].state;
    expect(afterDice.phase).toBe('playing');
    const turnSeat = afterDice.turnSeat as Seat;
    const mover = players.find((p) => p.snapshot.you[0] === turnSeat)!;
    const bystander = players.find((p) => p.snapshot.you[0] !== turnSeat)!;

    const piece = afterDice.pieces.find((pc) => pc.status === 'active' && pc.owner === turnSeat && legalMovesOfPiece(afterDice, pc.id).length > 0)!;
    const move = legalMovesOfPiece(afterDice, piece.id)[0]!;

    // Vá lỗi (1): seq cố tình sai -> game.rejected chỉ người gửi thấy, người khác KHÔNG thấy gì trong lúc đó.
    const bystanderSawNothing = bystander.client.waitFor(isType<GameRejected>('game.rejected'), 300).then(
      () => false,
      () => true,
    );
    mover.client.send({ type: 'game.move', seq: diceEvents[0].seq + 999, move: { pieceId: piece.id, to: move.to } });
    const rejected = await mover.client.waitFor(isType<GameRejected>('game.rejected'));
    expect(rejected.reason).toBe('STALE_SEQ');
    expect(await bystanderSawNothing).toBe(true);

    // Nước đi đúng seq -> phát game.events cho cả 6 người, cùng một seq/state.
    mover.client.send({ type: 'game.move', seq: diceEvents[0].seq, move: { pieceId: piece.id, to: move.to } });
    const moveEvents = await Promise.all(players.map((p) => p.client.waitFor(isType<GameEvents>('game.events'), 3000)));
    for (const e of moveEvents) {
      expect(e.action).toEqual({ kind: 'move', seat: turnSeat, move: { pieceId: piece.id, to: move.to } });
      expect(e.seq).toBe(moveEvents[0].seq);
    }
  });
});

describe('ngắt/nối lại giữa ván (PLAN 7.5)', () => {
  it('mất kết nối rồi vào lại trong hạn ân hạn -> nhận lại đúng ghế và một game.snapshot mới', async () => {
    server = startServer();
    const players = await startSixHumanGame(server.port);
    const victim = players[2];
    await victim.client.close();

    const rejoined = await join(server.port, 'P2-lai', victim.ack.token);
    expect(rejoined.ack.identityId).toBe(victim.ack.identityId); // cùng danh tính (token khớp)
    const snapshot = await rejoined.client.waitFor(isType<GameSnapshot>('game.snapshot'), 2000);
    expect(snapshot.you).toEqual(victim.snapshot.you); // nhận lại đúng ghế cũ
  });

  it('mất kết nối quá hạn ân hạn -> hello sau đó KHÔNG được nối lại phòng (không nhận room.state/game.snapshot nào)', async () => {
    server = startServer({ reconnectGraceSecondsOverride: 0 });
    const players = await startSixHumanGame(server.port);
    const victim = players[3];
    await victim.client.close();
    await new Promise((resolve) => setTimeout(resolve, 100)); // để hẹn giờ ân hạn 0ms chắc chắn đã chạy

    const client = await TestClient.connect(server.port);
    clients.push(client);
    client.send({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name: 'P3-tre', token: victim.ack.token });
    const ack = await client.waitFor(isType<HelloAck>('hello.ack'));
    expect(ack.identityId).toBe(victim.ack.identityId); // danh tính vẫn còn, chỉ mất chỗ trong phòng

    const sawNothing = await Promise.race([
      client.waitFor(isType<RoomState>('room.state'), 300).then(
        () => false,
        () => true,
      ),
      client.waitFor(isType<GameSnapshot>('game.snapshot'), 300).then(
        () => false,
        () => true,
      ),
    ]);
    expect(sawNothing).toBe(true);

    // Không còn ở trong phòng nào -> gửi message ván bị từ chối NOT_IN_ROOM.
    client.send({ type: 'game.rollDice' });
    const err = await client.waitFor(isType<LobbyError>('lobby.error'), 1000);
    expect(err.code).toBe('NOT_IN_ROOM');
  });
});
