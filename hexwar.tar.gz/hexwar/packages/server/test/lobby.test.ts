// Test tích hợp tầng phòng/ghép trận (PLAN 7.1, 7.2) — server thật trên cổng thật, client `ws` thật (không mock
// mạng). Tầng ván (`game.*`) có file riêng: game.test.ts.
import { afterEach, describe, expect, it } from 'vitest';
import type { LobbyServerMessage, ServerMessage } from '@hexwar/protocol';
import { defaultConfig } from '@hexwar/rules';
import type { HexwarServer } from '../src/index';
import { isType, startServer, TestClient } from './support';

type HelloAck = Extract<LobbyServerMessage, { type: 'hello.ack' }>;
type RoomState = Extract<LobbyServerMessage, { type: 'room.state' }>;
type LobbyError = Extract<LobbyServerMessage, { type: 'lobby.error' }>;
type GameSnapshot = Extract<ServerMessage, { type: 'game.snapshot' }>;

let server: HexwarServer | null = null;
let clients: TestClient[] = [];

afterEach(async () => {
  await Promise.all(clients.map((c) => c.close()));
  clients = [];
  await server?.close();
  server = null;
});

async function join(port: number, name: string, token?: string): Promise<{ client: TestClient; ack: HelloAck }> {
  const client = await TestClient.connect(port);
  clients.push(client);
  client.send({ type: 'hello', rulesVersion: defaultConfig.rulesVersion, name, ...(token !== undefined ? { token } : {}) });
  const ack = await client.waitFor(isType<HelloAck>('hello.ack'));
  return { client, ack };
}

describe('hello (PLAN 7.1)', () => {
  it('không có token -> cấp danh tính khách mới, ack đúng tên', async () => {
    server = startServer();
    const { ack } = await join(server.port, 'Alice');
    expect(ack.name).toBe('Alice');
    expect(ack.token.length).toBeGreaterThan(0);
  });

  it('rulesVersion khác bị từ chối, không cấp danh tính', async () => {
    server = startServer();
    const client = await TestClient.connect(server.port);
    clients.push(client);
    client.send({ type: 'hello', rulesVersion: 'khac', name: 'Bob' });
    const err = await client.waitFor(isType<LobbyError>('lobby.error'));
    expect(err.code).toBe('RULES_VERSION');
  });

  it('token lạ/chưa từng cấp vẫn được cấp danh tính khách mới thay vì lỗi', async () => {
    server = startServer();
    const { ack } = await join(server.port, 'Carol', 'token-khong-ton-tai');
    expect(ack.name).toBe('Carol');
  });
});

describe('ghép nhanh + bot lấp chỗ (PLAN 7.2)', () => {
  it('1 người vào hàng chờ -> bot lấp 5 ghế còn lại sau botFillDelayMs -> ván tự bắt đầu', async () => {
    server = startServer({ botFillDelayMs: 30 });
    const { client } = await join(server.port, 'Solo');
    client.send({ type: 'queue.join', preset: 'classic' });
    const state = await client.waitFor(isType<RoomState>('room.state'));
    expect(state.quickMatch).toBe(true);
    expect(state.code).toBeNull();

    const snapshot = await client.waitFor(isType<GameSnapshot>('game.snapshot'), 2000);
    expect(snapshot.you).toHaveLength(1);
    expect(snapshot.seats).toHaveLength(6);
    expect(snapshot.seats.filter((s) => s.kind === 'bot')).toHaveLength(5);
  });

  it('hai người vào cùng hàng chờ cùng preset -> ghép chung một phòng', async () => {
    server = startServer({ botFillDelayMs: 60_000 });
    const a = await join(server.port, 'A');
    const b = await join(server.port, 'B');
    a.client.send({ type: 'queue.join', preset: 'classic' });
    const stateA = await a.client.waitFor(isType<RoomState>('room.state'));
    b.client.send({ type: 'queue.join', preset: 'classic' });
    const stateB = await b.client.waitFor(isType<RoomState>('room.state'));
    expect(stateA.quickMatch).toBe(true);
    expect(stateB.seats.filter((s) => s.kind === 'human')).toHaveLength(2);
  });
});

describe('phòng riêng (PLAN 7.2)', () => {
  it('tạo phòng có mã, người khác vào bằng mã, chủ phòng thêm bot, cả hai Sẵn sàng -> ván tự bắt đầu', async () => {
    server = startServer();
    const host = await join(server.port, 'Host');
    host.client.send({ type: 'room.create', preset: 'classic' });
    const hostState = await host.client.waitFor(isType<RoomState>('room.state'));
    expect(hostState.code).not.toBeNull();
    const code = hostState.code as string;
    expect(code).toHaveLength(6);

    const guest = await join(server.port, 'Guest');
    guest.client.send({ type: 'room.join', code });
    await guest.client.waitFor(isType<RoomState>('room.state'));

    for (let i = 0; i < 4; i++) host.client.send({ type: 'room.addBot', difficulty: 'easy' });
    host.client.send({ type: 'room.ready', ready: true });
    guest.client.send({ type: 'room.ready', ready: true });

    const hostSnap = await host.client.waitFor(isType<GameSnapshot>('game.snapshot'), 2000);
    const guestSnap = await guest.client.waitFor(isType<GameSnapshot>('game.snapshot'), 2000);
    // Vá lỗi "you" (xem room.ts đầu file): mỗi kết nối chỉ thấy đúng MỘT ghế của chính mình, khác nhau.
    expect(hostSnap.you).toHaveLength(1);
    expect(guestSnap.you).toHaveLength(1);
    expect(hostSnap.you[0]).not.toBe(guestSnap.you[0]);
  });

  it('vào mã không tồn tại -> ROOM_NOT_FOUND; tạo/vào phòng khi đã ở trong một phòng -> ALREADY_IN_ROOM', async () => {
    server = startServer();
    const a = await join(server.port, 'A');
    a.client.send({ type: 'room.join', code: 'ZZZZZZ' });
    const notFound = await a.client.waitFor(isType<LobbyError>('lobby.error'));
    expect(notFound.code).toBe('ROOM_NOT_FOUND');

    a.client.send({ type: 'room.create', preset: 'classic' });
    await a.client.waitFor(isType<RoomState>('room.state'));
    a.client.send({ type: 'room.create', preset: 'classic' });
    const already = await a.client.waitFor(isType<LobbyError>('lobby.error'));
    expect(already.code).toBe('ALREADY_IN_ROOM');
  });

  it('không phải chủ phòng thì room.addBot/setConfig bị từ chối NOT_HOST', async () => {
    server = startServer();
    const host = await join(server.port, 'Host');
    host.client.send({ type: 'room.create', preset: 'classic' });
    const hostState = await host.client.waitFor(isType<RoomState>('room.state'));
    const guest = await join(server.port, 'Guest');
    guest.client.send({ type: 'room.join', code: hostState.code as string });
    await guest.client.waitFor(isType<RoomState>('room.state'));

    guest.client.send({ type: 'room.addBot', difficulty: 'easy' });
    const err1 = await guest.client.waitFor(isType<LobbyError>('lobby.error'));
    expect(err1.code).toBe('NOT_HOST');

    guest.client.send({ type: 'room.setConfig', preset: 'blitz' });
    const err2 = await guest.client.waitFor(isType<LobbyError>('lobby.error'));
    expect(err2.code).toBe('NOT_HOST');
  });
});

describe('không tin dữ liệu client (PLAN 7.6)', () => {
  it('gửi dồn dập vượt hạn mức -> RATE_LIMITED', async () => {
    server = startServer();
    const { client } = await join(server.port, 'Spam');
    for (let i = 0; i < 60; i++) client.send({ type: 'queue.leave' });
    const err = await client.waitFor(isType<LobbyError>('lobby.error'), 2000);
    expect(err.code).toBe('RATE_LIMITED');
  });

  it('message vượt kích thước cho phép -> server tự đóng kết nối', async () => {
    server = startServer();
    const client = await TestClient.connect(server.port);
    clients.push(client);
    const closed = new Promise<void>((resolve) => client.socket.once('close', () => resolve()));
    client.socket.send('x'.repeat(64 * 1024));
    await closed;
    expect(client.socket.readyState).toBe(client.socket.CLOSED);
  });

  it('message rác (không phải JSON, hoặc thiếu "hello" trước) -> BAD_MESSAGE', async () => {
    server = startServer();
    const client = await TestClient.connect(server.port);
    clients.push(client);
    client.socket.send('không phải JSON {{{');
    const err = await client.waitFor(isType<LobbyError>('lobby.error'));
    expect(err.code).toBe('BAD_MESSAGE');
  });
});
