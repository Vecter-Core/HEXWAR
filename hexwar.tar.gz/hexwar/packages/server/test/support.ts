// Tiện ích dùng chung cho test tích hợp: client `ws` THẬT nói chuyện với một `HexwarServer` THẬT trên cổng thật
// (PLAN 7 nghiệm thu M6 "test tích hợp 6 client + ngắt/nối") — không có mock nào ở tầng mạng.
import { WebSocket } from 'ws';
import { defaultConfig } from '@hexwar/rules';
import { HexwarServer, type HexwarServerOptions } from '../src/index';

/** Nhịp trình bày rút gọn hết mức (giống `?fast=1` của client, packages/client/src/app/main.ts) để một bài test
 * chạy hết cả ván bằng đồng hồ THẬT trong vài trăm mili-giây thay vì vài phút thật. */
export const FAST_TIMING = {
  botDelayMinMs: 0,
  botDelayMaxMs: 0,
  spectatorBotDelayMs: 0,
  autoDiceMs: 0,
  graceMoveMs: 0,
  graceCollapseMs: 0,
};

export function startServer(overrides: Partial<HexwarServerOptions> = {}): HexwarServer {
  return new HexwarServer(
    { rulesVersion: defaultConfig.rulesVersion, botFillDelayMs: 60_000, timing: FAST_TIMING, ...overrides },
    { port: 0 },
  );
}

/** Bọc một `ws.WebSocket` client: gom mọi message JSON nhận được vào một hàng đợi, chờ message khớp điều kiện. */
export class TestClient {
  private readonly received: unknown[] = [];
  private readonly waiters: { predicate: (m: unknown) => boolean; resolve: (m: unknown) => void }[] = [];
  readonly socket: WebSocket;

  private constructor(socket: WebSocket) {
    this.socket = socket;
    socket.on('message', (data) => {
      const message: unknown = JSON.parse(data.toString());
      const waiterIndex = this.waiters.findIndex((w) => w.predicate(message));
      if (waiterIndex !== -1) {
        const [waiter] = this.waiters.splice(waiterIndex, 1);
        waiter.resolve(message);
        return;
      }
      this.received.push(message);
    });
  }

  static async connect(port: number): Promise<TestClient> {
    const socket = new WebSocket(`ws://127.0.0.1:${port}`);
    await new Promise<void>((resolve, reject) => {
      socket.once('open', () => resolve());
      socket.once('error', reject);
    });
    return new TestClient(socket);
  }

  send(message: unknown): void {
    this.socket.send(JSON.stringify(message));
  }

  /** Chờ message tiếp theo khớp `predicate` — quét cả những message đã đến trước đó và chưa ai nhận. */
  waitFor<T>(predicate: (m: unknown) => m is T, timeoutMs = 5000): Promise<T> {
    const bufferedIndex = this.received.findIndex((m) => predicate(m));
    if (bufferedIndex !== -1) {
      const [message] = this.received.splice(bufferedIndex, 1);
      return Promise.resolve(message as T);
    }
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        const idx = this.waiters.findIndex((w) => w.resolve === (resolve as (m: unknown) => void));
        if (idx !== -1) this.waiters.splice(idx, 1);
        reject(new Error(`TestClient.waitFor: hết ${timeoutMs}ms mà không thấy message khớp`));
      }, timeoutMs);
      this.waiters.push({
        predicate: predicate as (m: unknown) => boolean,
        resolve: (m) => {
          clearTimeout(timer);
          resolve(m as T);
        },
      });
    });
  }

  async close(): Promise<void> {
    if (this.socket.readyState === WebSocket.CLOSED) return;
    await new Promise<void>((resolve) => {
      this.socket.once('close', () => resolve());
      this.socket.close();
    });
  }
}

export function isType<T extends { type: string }>(type: T['type']) {
  return (m: unknown): m is T => typeof m === 'object' && m !== null && (m as { type?: unknown }).type === type;
}
