import { defineConfig } from 'vitest/config';

// Test tích hợp mở server WebSocket thật trên cổng ngẫu nhiên + nhiều client `ws` thật (PLAN 6.6 nghiệm thu M6:
// "test tích hợp 6 client + ngắt/nối"). Chạy trọn một ván 6 người có thể mất vài giây thật (đồng hồ thật).
export default defineConfig({
  test: { include: ['test/**/*.test.ts'], environment: 'node', testTimeout: 60_000 },
});
