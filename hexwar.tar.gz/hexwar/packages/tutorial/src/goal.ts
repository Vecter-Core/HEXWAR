// Đánh giá `Goal` (xem types.ts). Dùng chung bởi runner (kiểm tra bước) và solver (tìm nước thoả mục tiêu),
// nên hai bên không thể lệch nhau — đúng tinh thần "một nguồn duy nhất" của packages/rules/src/moves.ts.
import { ring, sameCell, type GameEvent, type GameState } from '@hexwar/rules';
import type { EventRecord, Goal } from './types';

function matches(event: GameEvent, match: Readonly<Record<string, string | number | boolean>>): boolean {
  const record = event as EventRecord;
  return Object.entries(match).every(([key, value]) => record[key] === value);
}

/**
 * `goal` đã đạt chưa, dựa trên các sự kiện phát ra bởi ĐÚNG một hành động (một `applyMove`/`rollDice`...),
 * và trạng thái sau hành động đó. Chỉ gọi sau khi hành động đã được xác nhận hợp lệ.
 */
export function goalMet(goal: Goal, after: GameState, events: readonly GameEvent[]): boolean {
  switch (goal.kind) {
    case 'anyMove':
      return true;
    case 'pieceMoved':
      return events.some((e) => e.type === 'MOVED' && e.pieceId === goal.pieceId);
    case 'eventType':
      return events.some((e) => e.type === goal.eventType);
    case 'eventMatch':
      return events.some((e) => e.type === goal.eventType && matches(e, goal.match));
    case 'pieceRingAtMost': {
      const piece = after.pieces.find((p) => p.id === goal.pieceId);
      return piece !== undefined && ring(piece.cell) <= goal.ring;
    }
    case 'pieceAt': {
      const piece = after.pieces.find((p) => p.id === goal.pieceId);
      return piece !== undefined && sameCell(piece.cell, goal.cell);
    }
    case 'all':
      return goal.goals.every((g) => goalMet(g, after, events));
  }
}
