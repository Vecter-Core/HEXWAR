// @hexwar/tutorial — Kịch bản bài học, runner, hint engine (M8, PLAN.md mục 10).
// Chạy trên engine thật (@hexwar/rules) qua LocalTransport ở client, không mô phỏng luật riêng.
export type { EventRecord, Goal, Lesson, LessonId, RealGameLesson, ScenarioLesson, Step } from './types';
export { LESSON_IDS, isScenarioLesson } from './types';
export { goalMet } from './goal';
export { acknowledgeInfo, attemptMove, currentStep, pump, startLesson, type RunnerState } from './runner';
export { findHintMove, solveLesson, LessonUnsolvableError } from './solver';
export { LESSONS, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13 } from './scenarios';
export { TUTORIAL_STRINGS, type TutorialString } from './strings';
