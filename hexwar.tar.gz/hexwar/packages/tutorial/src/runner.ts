// Runner chạy một ScenarioLesson trên engine thật (PLAN 10.1: "chạy bằng engine thật, không mô phỏng giả").
// Không đọc DOM/localStorage — thuần, tất định, dùng được cả ở client lẫn ở test Node (theo quy ước của
// packages/rules: `rules` không đụng DOM; gói này không CẦN đụng DOM nên cũng tránh, dù không bắt buộc).
import { applyMove, checkMove, rollDice, type GameEvent, type GameState, type IllegalReason, type Move } from '@hexwar/rules';
import { goalMet } from './goal';
import type { ScenarioLesson, Step } from './types';

export interface RunnerState {
  readonly lesson: ScenarioLesson;
  readonly stepIndex: number;
  readonly game: GameState;
  /** Sự kiện của hành động GẦN NHẤT (một applyMove/rollDice) — để hoạt ảnh/lời thoại phản ứng. */
  readonly log: readonly GameEvent[];
  /** Đã hết bài (đi qua step cuối). */
  readonly done: boolean;
  /** Lý do nước vừa thử bị từ chối (để hiện giải thích, PLAN 10.1); null nếu chưa thử hoặc lần cuối hợp lệ. */
  readonly lastRejection: IllegalReason | null;
}

export function currentStep(r: RunnerState): Step | undefined {
  return r.lesson.steps[r.stepIndex];
}

export function startLesson(lesson: ScenarioLesson): RunnerState {
  const game = lesson.setup();
  return pump({ lesson, stepIndex: 0, game, log: [], done: lesson.steps.length === 0, lastRejection: null });
}

function advance(r: RunnerState, game: GameState, log: readonly GameEvent[]): RunnerState {
  const stepIndex = r.stepIndex + 1;
  return { lesson: r.lesson, stepIndex, game, log, done: stepIndex >= r.lesson.steps.length, lastRejection: null };
}

/**
 * Tự động chạy qua các bước không cần người chơi quyết định ('auto', 'roll'), dừng lại ở bước 'move', 'info'
 * hoặc khi hết bài. Gọi lại sau mỗi `attemptMove`/`acknowledgeInfo`.
 */
export function pump(r: RunnerState): RunnerState {
  let cur = r;
  for (;;) {
    if (cur.done) return cur;
    const step = currentStep(cur);
    if (step === undefined) return { ...cur, done: true };
    if (step.kind === 'move' || step.kind === 'info') return cur;
    if (step.kind === 'roll') {
      const { state, events } = rollDice(cur.game);
      cur = advance(cur, state, events);
      continue;
    }
    // step.kind === 'auto'
    const { state, events } = applyMove(cur.game, step.move);
    if (step.expect !== undefined && !events.some((e) => e.type === step.expect)) {
      throw new Error(`Bài ${cur.lesson.id}, bước ${cur.stepIndex}: mong sự kiện "${step.expect}" nhưng không xảy ra (lỗi soạn bài)`);
    }
    cur = advance(cur, state, events);
  }
}

/** Người chơi bấm "Tiếp tục" ở một bước 'info'. Không làm gì nếu bước hiện tại không phải 'info'. */
export function acknowledgeInfo(r: RunnerState): RunnerState {
  const step = currentStep(r);
  if (r.done || step === undefined || step.kind !== 'info') return r;
  return pump(advance(r, r.game, []));
}

/**
 * Người chơi thử đi `move` ở một bước 'move'. Nước sai luật: chỉ ghi `lastRejection`, KHÔNG đổi trạng thái
 * (để UI gọi `explainIllegal`-style giải thích, PLAN 10.1). Nước đúng luật nhưng chưa thoả mục tiêu bài:
 * vẫn áp dụng thật (chơi thật) và ở lại bước này để người chơi thử tiếp. Nước thoả mục tiêu: sang bước kế.
 * Không làm gì (trả lại y nguyên) nếu bước hiện tại không phải 'move' hoặc sai lượt của `move.pieceId`.
 */
export function attemptMove(r: RunnerState, move: Move): RunnerState {
  const step = currentStep(r);
  if (r.done || step === undefined || step.kind !== 'move') return r;
  const reason = checkMove(r.game, step.seat, move);
  if (reason !== null) return { ...r, lastRejection: reason };
  const { state, events } = applyMove(r.game, move);
  if (goalMet(step.goal, state, events)) return pump(advance(r, state, events));
  return { ...r, game: state, log: events, lastRejection: null };
}
