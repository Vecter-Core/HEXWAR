import { t1 } from './t1';
import { t2 } from './t2';
import { t3 } from './t3';
import { t4 } from './t4';
import { t5 } from './t5';
import { t6 } from './t6';
import { t7 } from './t7';
import { t8 } from './t8';
import { t9 } from './t9';
import { t10 } from './t10';
import { t11 } from './t11';
import { t12 } from './t12';
import { t13 } from './t13';
import type { Lesson } from '../types';

/** 13 bài tân thủ theo đúng thứ tự PLAN.md mục 10.2. */
export const LESSONS: readonly Lesson[] = [t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13];

export { t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13 };
