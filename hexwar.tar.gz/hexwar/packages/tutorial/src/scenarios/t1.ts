// T1 — Làm quen bàn cờ (PLAN 10.2, mục 3.3). Xoay/zoom/kéo camera và bản đồ nhỏ là việc của client (không có
// sự kiện engine tương ứng); phần engine hoá được ở đây là "chọn quân, đi 1 nước".
import { cell, createPiece, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

export const t1: ScenarioLesson = {
  id: 'T1',
  kind: 'scenario',
  titleKey: 'tutorial.t1.title',
  ruleRefs: ['3.3'],
  setup: () =>
    makeState({
      radius: 3,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [createPiece('t1-king', 0, 'K', cell(0, 0))],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t1.intro' },
    { kind: 'info', textKey: 'tutorial.t1.orient' },
    { kind: 'move', seat: 0, goal: { kind: 'anyMove' }, textKey: 'tutorial.t1.move' },
  ],
};
