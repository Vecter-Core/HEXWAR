// T10 — Kill và phong cấp (PLAN 10.2, R-40…42). Đơn ghế: một Tốt đã có sẵn 5 kill (dựng thẳng vào dữ liệu
// quân — hợp lệ vì `kills` chỉ là số đếm, không phải bất biến bố trí) ăn thêm 1 quân để chạm ngưỡng 6 (mặc
// định `rules.config.json`) và tự động phong thành Mã.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const PAWN = cell(0, 1);
const ENEMY = add(PAWN, DIR.NE); // (1, 0)

export const t10: ScenarioLesson = {
  id: 'T10',
  kind: 'scenario',
  titleKey: 'tutorial.t10.title',
  ruleRefs: ['R-40', 'R-41', 'R-42'],
  setup: () =>
    makeState({
      radius: 3,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [{ ...createPiece('t10-pawn', 0, 'P', PAWN), kills: 5 }, createPiece('t10-enemy', 5, 'P', ENEMY)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t10.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'PROMOTED' }, textKey: 'tutorial.t10.promote' },
  ],
};
