// T11 — Thu hẹp và thời gian (PLAN 10.2, R-70, R-71). Đơn ghế, `round` dựng sẵn ở 1 và lịch thu hẹp được ghi
// đè chỉ còn một mốc ở hiệp 2: vì bàn chỉ có một ghế, MỌI nước đi đều hoàn tất trọn hiệp (round += 1) ngay
// lập tức (xem docs/decisions.md), nên nước đi duy nhất của người chơi vừa là nước cuối hiệp 1 vừa là nước
// kích hoạt thu hẹp — đúng thời điểm để dạy "phải vào trong TRƯỚC KHI vòng biến mất".
import { cell, configWith, createPiece, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const RADIUS = 6;
const KING_START = cell(6, 0); // hạng 6: đúng vòng ngoài cùng, sắp biến mất (an toàn: đi 1 bước vào hạng ≤ 5)

export const t11: ScenarioLesson = {
  id: 'T11',
  kind: 'scenario',
  titleKey: 'tutorial.t11.title',
  ruleRefs: ['R-70', 'R-71'],
  setup: () =>
    makeState({
      radius: RADIUS,
      round: 1,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      config: configWith({ collapse: { rounds: [2], extension: { enabled: false } } }),
      pieces: [createPiece('t11-king', 0, 'K', KING_START)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t11.intro' },
    {
      kind: 'move',
      seat: 0,
      goal: {
        kind: 'all',
        goals: [
          { kind: 'pieceMoved', pieceId: 't11-king' },
          { kind: 'eventType', eventType: 'RING_COLLAPSED' },
          { kind: 'pieceRingAtMost', pieceId: 't11-king', ring: RADIUS - 1 },
        ],
      },
      textKey: 'tutorial.t11.move',
    },
    { kind: 'info', textKey: 'tutorial.t11.result' },
  ],
};
