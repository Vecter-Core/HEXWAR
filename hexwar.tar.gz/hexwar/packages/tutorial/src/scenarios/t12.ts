// T12 — Xúc xắc, lượt, chat, voice (PLAN 10.2, R-02, R-03, mục 8). Chat/voice không có sự kiện engine tương
// ứng (là tính năng của @hexwar/server/@hexwar/client) nên chỉ dạy bằng lời thoại (xem docs/questions.md,
// mục "M8"); phần dựng được bằng engine thật là tung xúc xắc và lượt đi đầu tiên.
// Seed được TÌM RA (không đoán tay) để ghế 0 luôn thắng, giữ bài dễ hiểu và không phụ thuộc cách sinh số
// ngẫu nhiên hiện tại thay đổi trong tương lai.
import { cell, createPiece, createRng, makeState, rollForFirst, type Seat } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const SEATS: readonly Seat[] = [0, 1];

function seedWhereSeatZeroWins(): number {
  for (let seed = 0; seed < 1000; seed++) {
    if (rollForFirst(SEATS, createRng(seed)).winner === 0) return seed;
  }
  throw new Error('T12: không tìm được seed để ghế 0 thắng xúc xắc trong 1000 lần thử (không nên xảy ra)');
}

export const t12: ScenarioLesson = {
  id: 'T12',
  kind: 'scenario',
  titleKey: 'tutorial.t12.title',
  ruleRefs: ['R-02', 'R-03', '8'],
  setup: () =>
    makeState({
      radius: 4,
      phase: 'dice',
      seats: SEATS,
      seed: seedWhereSeatZeroWins(),
      pieces: [createPiece('t12-king0', 0, 'K', cell(0, 0)), createPiece('t12-king1', 1, 'K', cell(0, -3))],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t12.intro' },
    { kind: 'roll', textKey: 'tutorial.t12.roll' },
    { kind: 'move', seat: 0, goal: { kind: 'anyMove' }, textKey: 'tutorial.t12.move' },
    { kind: 'info', textKey: 'tutorial.t12.order' },
    { kind: 'info', textKey: 'tutorial.t12.chat' },
    { kind: 'info', textKey: 'tutorial.t12.voice' },
  ],
};
