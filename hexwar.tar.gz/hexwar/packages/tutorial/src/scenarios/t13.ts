// T13 — Trận tập (PLAN 10.2). Không có kịch bản riêng: dùng nguyên luồng chơi solo thật (1 người + 5 bot Dễ),
// đã có từ M4. Xem `RealGameLesson` ở types.ts.
import type { RealGameLesson } from '../types';

export const t13: RealGameLesson = {
  id: 'T13',
  kind: 'realGame',
  titleKey: 'tutorial.t13.title',
  ruleRefs: ['tổng hợp'],
};
