// T2 — Quân Tốt (PLAN 10.2, R-22, mục 4.3). Đơn ghế: một Tốt của người chơi tiến, lùi, rồi ăn chéo 3 quân
// địch tĩnh (chủ sở hữu 5 không nằm trong `order` nên không bao giờ tự đi — xem docs/decisions.md).
// Bước tiến/lùi dùng goal `pieceAt` (chọn đúng MỘT trong nhiều nước hợp lệ) vì tại các ô này Tốt luôn có sẵn
// một nước ăn chéo khác cũng hợp lệ — goal `pieceMoved` sẽ không ép được đi đúng hướng dạy.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const START = cell(0, 3);
const FORWARD = add(START, DIR.N); // (0, 2), ô trống để minh hoạ "tiến 1 ô"
// Ba lần ăn chéo liên tiếp về hướng NE, xuất phát lại từ START (không đụng FORWARD).
const CAP1 = add(START, DIR.NE); // (1, 2)
const CAP2 = add(CAP1, DIR.NE); // (2, 1)
const CAP3 = add(CAP2, DIR.NE); // (3, 0)

export const t2: ScenarioLesson = {
  id: 'T2',
  kind: 'scenario',
  titleKey: 'tutorial.t2.title',
  ruleRefs: ['R-22', '4.3'],
  setup: () =>
    makeState({
      radius: 4,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [
        createPiece('t2-pawn', 0, 'P', START),
        createPiece('t2-e1', 5, 'P', CAP1),
        createPiece('t2-e2', 5, 'P', CAP2),
        createPiece('t2-e3', 5, 'P', CAP3),
      ],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t2.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'pieceAt', pieceId: 't2-pawn', cell: FORWARD }, textKey: 'tutorial.t2.forward' },
    { kind: 'move', seat: 0, goal: { kind: 'pieceAt', pieceId: 't2-pawn', cell: START }, textKey: 'tutorial.t2.back' },
    { kind: 'info', textKey: 'tutorial.t2.diagWarn' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t2.capture1' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t2.capture2' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t2.capture3' },
  ],
};
