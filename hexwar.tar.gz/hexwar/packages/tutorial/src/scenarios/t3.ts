// T3 — Quân Xe (PLAN 10.2, R-20). Đơn ghế: một Xe ăn một quân địch ở xa theo đường thẳng, rồi ăn quân GẦN
// nhất trong hai quân xếp thẳng hàng ở hướng khác — quân đứng sau tự động không ăn được (R-20), không cần
// kịch bản riêng để "chứng minh": engine đã chặn đúng luật.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const ROOK = cell(0, 0);
const FAR = add(ROOK, DIR.N, 3); // (0, -3): quân địch ở xa, ăn thẳng theo hướng N
// Hai quân xếp thẳng hàng theo hướng SW, tính từ vị trí Xe SAU nước ăn đầu (FAR) — không phải từ ROOK.
const NEAR_BLOCKER = add(FAR, DIR.SW, 2); // (-2, -1)
const FAR_BLOCKED = add(FAR, DIR.SW, 4); // (-4, 1): đứng sau NEAR_BLOCKER trên cùng hướng, không ăn được

export const t3: ScenarioLesson = {
  id: 'T3',
  kind: 'scenario',
  titleKey: 'tutorial.t3.title',
  ruleRefs: ['R-20'],
  setup: () =>
    makeState({
      radius: 5,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [
        createPiece('t3-rook', 0, 'R', ROOK),
        createPiece('t3-far', 5, 'R', FAR),
        createPiece('t3-near', 5, 'R', NEAR_BLOCKER),
        createPiece('t3-blocked', 5, 'R', FAR_BLOCKED),
      ],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t3.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t3.capture' },
    { kind: 'info', textKey: 'tutorial.t3.blockedInfo' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t3.captureBlocked' },
  ],
};
