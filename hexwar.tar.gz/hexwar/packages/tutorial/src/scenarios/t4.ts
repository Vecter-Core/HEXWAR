// T4 — Quân Tượng (PLAN 10.2, D-02, R-20). Đơn ghế: Tượng ăn hai quân địch liên tiếp theo hai hướng đỉnh
// (V_DIRS) khác nhau, minh hoạ đường "ngang zíc-zắc".
import { add, cell, createPiece, makeState, V_DIRS } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const BISHOP = cell(0, 0);
const CAP1 = add(BISHOP, V_DIRS[0]); // (1, -2)
const CAP2 = add(CAP1, V_DIRS[2]); // (2, -1)

export const t4: ScenarioLesson = {
  id: 'T4',
  kind: 'scenario',
  titleKey: 'tutorial.t4.title',
  ruleRefs: ['D-02', 'R-20'],
  setup: () =>
    makeState({
      radius: 5,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [createPiece('t4-bishop', 0, 'B', BISHOP), createPiece('t4-e1', 5, 'B', CAP1), createPiece('t4-e2', 5, 'B', CAP2)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t4.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t4.capture' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t4.capture' },
  ],
};
