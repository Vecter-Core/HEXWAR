// T5 — Quân Mã (PLAN 10.2, mục 3.2). Đơn ghế: một Mã ăn quân địch bằng cách nhảy qua một quân khác đứng
// chắn giữa đường — Mã không quan tâm quân chắn (không phải quân trượt).
import { cell, createPiece, KNIGHT_JUMPS, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const KNIGHT = cell(0, 0);
const TARGET = KNIGHT_JUMPS[0]; // (1, -3)
const WALL = cell(0, -1); // đứng "trên đường" nhìn bằng mắt, nhưng không cản Mã vì Mã nhảy qua

export const t5: ScenarioLesson = {
  id: 'T5',
  kind: 'scenario',
  titleKey: 'tutorial.t5.title',
  ruleRefs: ['3.2'],
  setup: () =>
    makeState({
      radius: 4,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [createPiece('t5-knight', 0, 'N', KNIGHT), createPiece('t5-target', 5, 'N', TARGET), createPiece('t5-wall', 5, 'P', WALL)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t5.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t5.capture' },
  ],
};
