// T6 — Quân Hậu (PLAN 10.2, mục 4.3): Hậu = Xe + Tượng. Đơn ghế: ăn một quân theo đường thẳng (như Xe), rồi
// một quân theo đường chéo (như Tượng), từ vị trí mới sau nước ăn đầu.
import { add, cell, createPiece, DIR, makeState, V_DIRS } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const QUEEN = cell(0, 0);
const STRAIGHT = add(QUEEN, DIR.N, 3); // (0, -3): ăn như Xe
const DIAGONAL = add(STRAIGHT, V_DIRS[0]); // (1, -5): ăn như Tượng, tính từ vị trí Hậu sau nước ăn đầu

export const t6: ScenarioLesson = {
  id: 'T6',
  kind: 'scenario',
  titleKey: 'tutorial.t6.title',
  ruleRefs: ['4.3'],
  setup: () =>
    makeState({
      radius: 6,
      seats: [0, 1], // ghế 1 không có quân, chỉ giữ cho aliveSeats() luôn >= 2 (tránh R-80 kết thúc ván sớm khi chỉ có 1 ghế thật sự chơi)
      pieces: [createPiece('t6-queen', 0, 'Q', QUEEN), createPiece('t6-straight', 5, 'Q', STRAIGHT), createPiece('t6-diag', 5, 'Q', DIAGONAL)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t6.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t6.captureStraight' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTURED' }, textKey: 'tutorial.t6.captureDiag' },
  ],
};
