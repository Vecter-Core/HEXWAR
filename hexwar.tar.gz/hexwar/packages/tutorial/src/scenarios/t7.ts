// T7 — Vua và cách thắng (PLAN 10.2, R-14, R-60). Hai ghế thật (seat1 là một "đối thủ" có Vua thật, không
// phải quân tĩnh) vì thắng/loại người chơi chỉ có ý nghĩa giữa những ghế thực sự tham gia ván (`order`).
// Ghế 0 ăn được Vua ghế 1 ngay lượt đầu nên ghế 1 không bao giờ thực sự phải đi.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const MY_KING = cell(0, 0);
const ENEMY_KING = add(MY_KING, DIR.N); // (0, -1): kề cạnh, Vua đi 1 bước ăn được ngay

export const t7: ScenarioLesson = {
  id: 'T7',
  kind: 'scenario',
  titleKey: 'tutorial.t7.title',
  ruleRefs: ['R-14', 'R-60'],
  setup: () =>
    makeState({
      radius: 3,
      seats: [0, 1],
      pieces: [createPiece('t7-my-king', 0, 'K', MY_KING), createPiece('t7-enemy-king', 1, 'K', ENEMY_KING)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t7.intro' },
    {
      kind: 'move',
      seat: 0,
      goal: { kind: 'all', goals: [{ kind: 'eventType', eventType: 'KING_CAPTURED' }, { kind: 'eventType', eventType: 'GAME_OVER' }] },
      textKey: 'tutorial.t7.capture',
    },
  ],
};
