// T8 — Quân Hề (PLAN 10.2, R-50…52). Hai ghế thật: ghế 1 chỉ tồn tại để thực hiện ĐÚNG MỘT nước kịch bản
// (ăn Vua ghế 0) rồi thôi — không cần "bot" nào, dùng bước 'auto' của runner áp thẳng nước đi đã biết trước.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const KING = cell(0, 0);
const JESTER_START = cell(3, 0); // cách Vua 3 ô, đã trong tầm cứu (≤ 5)
const JESTER_SAFE = add(JESTER_START, DIR.NW); // (2, 0): sau khi đi vẫn cách Vua 2 ô, còn trong tầm cứu
const ROOK = add(KING, DIR.N, 3); // (0, -3): đủ gần để ăn Vua trong một nước

export const t8: ScenarioLesson = {
  id: 'T8',
  kind: 'scenario',
  titleKey: 'tutorial.t8.title',
  ruleRefs: ['R-50', 'R-51', 'R-52'],
  setup: () =>
    makeState({
      radius: 4,
      seats: [0, 1],
      pieces: [createPiece('t8-king', 0, 'K', KING), createPiece('t8-jester', 0, 'J', JESTER_START), createPiece('t8-rook', 1, 'R', ROOK)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t8.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'pieceAt', pieceId: 't8-jester', cell: JESTER_SAFE }, textKey: 'tutorial.t8.move' },
    { kind: 'auto', seat: 1, move: { pieceId: 't8-rook', to: KING }, expect: 'JESTER_REVIVED', textKey: 'tutorial.t8.autoCapture' },
    { kind: 'info', textKey: 'tutorial.t8.result' },
  ],
};
