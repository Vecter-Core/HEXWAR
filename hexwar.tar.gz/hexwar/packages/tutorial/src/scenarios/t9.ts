// T9 — Tù binh (PLAN 10.2, R-30…36). Đúng kịch bản PLAN nêu: "Tốt ăn Hậu → hiệp sau dùng Hậu ăn Vua".
// Ghế 1 có một nước kịch bản ('auto', dịch Vua ra xa 1 ô) chỉ để chứng minh việc trưng dụng vẫn hoạt động
// sau khi một lượt khác trôi qua — không đổi kết quả cuối.
import { add, cell, createPiece, DIR, makeState } from '@hexwar/rules';
import type { ScenarioLesson } from '../types';

const PAWN = cell(0, 1);
const QUEEN = add(PAWN, DIR.NE); // (1, 0): Tốt ăn chéo được ngay
const KING_START = add(QUEEN, DIR.S, 3); // (1, 3)
const KING_AFTER = add(KING_START, DIR.S); // (1, 4): Vua dịch ra xa thêm 1 ô ở lượt ghế 1

export const t9: ScenarioLesson = {
  id: 'T9',
  kind: 'scenario',
  titleKey: 'tutorial.t9.title',
  ruleRefs: ['R-30', 'R-32', 'R-33', 'R-34'],
  setup: () =>
    makeState({
      radius: 6,
      seats: [0, 1],
      pieces: [createPiece('t9-pawn', 0, 'P', PAWN), createPiece('t9-queen', 1, 'Q', QUEEN), createPiece('t9-king', 1, 'K', KING_START)],
    }),
  steps: [
    { kind: 'info', textKey: 'tutorial.t9.intro' },
    { kind: 'move', seat: 0, goal: { kind: 'eventType', eventType: 'CAPTIVE_CREATED' }, textKey: 'tutorial.t9.capture' },
    { kind: 'auto', seat: 1, move: { pieceId: 't9-king', to: KING_AFTER } },
    { kind: 'info', textKey: 'tutorial.t9.conscriptInfo' },
    {
      kind: 'move',
      seat: 0,
      goal: { kind: 'all', goals: [{ kind: 'eventType', eventType: 'KING_CAPTURED' }, { kind: 'eventType', eventType: 'GAME_OVER' }] },
      textKey: 'tutorial.t9.conscript',
    },
  ],
};
