// "Người chơi ảo" (PLAN 10.3): tìm nước thoả mục tiêu bước hiện tại bằng chính engine thật (`legalMoves` +
// `applyMove` thử trên trạng thái, không đổi trạng thái gốc vì applyMove là hàm thuần). Dùng CHUNG bởi:
//   - test CI "giải hết 13 bài" (solveLesson dưới đây),
//   - hệ gợi ý theo thời gian trong client (PLAN 10.1: 15s làm nổi bật quân/ô, 30s bóng mờ đường đi) — client
//     gọi `findHintMove` với đúng `Goal` của bước hiện tại rồi tự vẽ theo ý mình (gói này không đụng đồ hoạ).
import { applyMove, legalMoves, type GameState, type Move, type Seat } from '@hexwar/rules';
import { goalMet } from './goal';
import { acknowledgeInfo, attemptMove, currentStep, pump, startLesson, type RunnerState } from './runner';
import type { Goal, ScenarioLesson } from './types';

/**
 * Nước hợp lệ đầu tiên (thứ tự tất định của `legalMoves`) của `seat` thoả `goal` ngay bây giờ, hoặc
 * `undefined` nếu không có nước nào thoả (bài soạn sai, hoặc mục tiêu đã đạt bằng cách khác).
 */
export function findHintMove(game: GameState, seat: Seat, goal: Goal): Move | undefined {
  for (const move of legalMoves(game, seat)) {
    const { state, events } = applyMove(game, move);
    if (goalMet(goal, state, events)) return move;
  }
  return undefined;
}

export class LessonUnsolvableError extends Error {
  constructor(
    readonly lessonId: string,
    readonly stepIndex: number,
  ) {
    super(`Không tìm được nước đi thoả mục tiêu — bài ${lessonId}, bước ${stepIndex} (bài soạn sai hoặc luật đã đổi)`);
    this.name = 'LessonUnsolvableError';
  }
}

/**
 * Giải trọn một bài bằng "người chơi ảo": ở mỗi bước 'move', tìm và đi nước đầu tiên thoả mục tiêu; các bước
 * khác tự chạy qua (runner lo, xem `pump`/`acknowledgeInfo`). Ném `LessonUnsolvableError` nếu kẹt.
 * Trả về trạng thái runner cuối cùng (`done === true`) để test kiểm tra thêm nếu cần.
 */
export function solveLesson(lesson: ScenarioLesson): RunnerState {
  let r = startLesson(lesson);
  while (!r.done) {
    const step = currentStep(r);
    if (step === undefined) break;
    if (step.kind === 'info') {
      r = acknowledgeInfo(r);
      continue;
    }
    // pump() chỉ dừng ở 'move' hoặc 'info' (đã xử lý ở trên) — còn lại chắc chắn là 'move'.
    if (step.kind !== 'move') throw new Error(`Bài ${lesson.id}: bước ${r.stepIndex} có loại không mong đợi "${step.kind}"`);
    const move = findHintMove(r.game, step.seat, step.goal);
    if (move === undefined) throw new LessonUnsolvableError(lesson.id, r.stepIndex);
    const next = attemptMove(r, move);
    if (next.stepIndex === r.stepIndex && !next.done) throw new LessonUnsolvableError(lesson.id, r.stepIndex);
    r = pump(next);
  }
  return r;
}
