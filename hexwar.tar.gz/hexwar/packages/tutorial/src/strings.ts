// Nội dung lời thoại (vi/en) của các bài tân thủ, theo khoá dùng trong scenarios/*.ts. Đây là NGUỒN DUY NHẤT
// của phần chữ này; `@hexwar/client` copy các cặp khoá→chữ dưới đây vào i18n vi.json/en.json của nó (mục 10.1:
// "chữ hiển thị luôn qua i18n"). Bản dịch tiếng Anh là bản dịch thẳng nghĩa, chưa qua người bản ngữ duyệt.
export interface TutorialString {
  readonly vi: string;
  readonly en: string;
}

export const TUTORIAL_STRINGS: Readonly<Record<string, TutorialString>> = {
  'tutorial.t1.title': { vi: 'Làm quen bàn cờ', en: 'Meet the board' },
  'tutorial.t1.intro': {
    vi: 'Chào mừng! Bàn cờ Hexwar là một lưới lục giác rất lớn, nhưng bài này chỉ dùng một góc nhỏ để bạn làm quen.',
    en: 'Welcome! The Hexwar board is a huge hex grid, but this lesson only uses a small corner of it.',
  },
  'tutorial.t1.orient': {
    vi: 'Hướng "tiến về tâm" luôn là phía trước quân của bạn. Bản đồ nhỏ ở góc màn hình luôn chỉ đúng ghế và vị trí của bạn.',
    en: 'The direction "toward the center" is always in front of your pieces. The minimap always shows your seat and position.',
  },
  'tutorial.t1.move': { vi: 'Chọn Vua của bạn rồi bấm một ô sáng bên cạnh để đi 1 nước.', en: 'Select your King, then click a highlighted cell to move.' },

  'tutorial.t2.title': { vi: 'Quân Tốt', en: 'The Pawn' },
  'tutorial.t2.intro': { vi: 'Tốt đi 1 ô mỗi lượt, tiến hoặc lùi, và chỉ đi vào ô trống.', en: 'A Pawn moves 1 cell per turn, forward or backward, only into an empty cell.' },
  'tutorial.t2.forward': { vi: 'Đi Tốt của bạn tiến lên 1 ô.', en: 'Move your Pawn forward one cell.' },
  'tutorial.t2.back': { vi: 'Tốt cũng lùi được 1 ô — thử lùi lại vị trí cũ.', en: 'A Pawn can also step back — try returning to its old cell.' },
  'tutorial.t2.diagWarn': {
    vi: 'Tốt ăn quân theo đường CHÉO, không bao giờ ăn thẳng. Bấm thẳng vào quân địch phía trước sẽ bị từ chối kèm lý do.',
    en: 'A Pawn captures diagonally, never straight ahead. Clicking the enemy directly in front will be rejected with a reason.',
  },
  'tutorial.t2.capture1': { vi: 'Ăn quân địch bằng một nước chéo.', en: 'Capture the enemy piece with a diagonal move.' },
  'tutorial.t2.capture2': { vi: 'Ăn tiếp quân địch kế bên bằng một nước chéo khác.', en: 'Capture the next enemy piece with another diagonal move.' },
  'tutorial.t2.capture3': { vi: 'Ăn nốt quân địch cuối cùng bằng một nước chéo.', en: 'Capture the last enemy piece with a diagonal move.' },

  'tutorial.t3.title': { vi: 'Quân Xe', en: 'The Rook' },
  'tutorial.t3.intro': {
    vi: 'Xe đi thẳng theo 6 hướng cạnh, xa tối đa 9 ô, và bị chặn bởi bất kỳ quân nào (kể cả tù binh) trên đường đi.',
    en: 'A Rook slides in 6 straight directions, up to 9 cells, blocked by any piece (even a captive) in its path.',
  },
  'tutorial.t3.capture': { vi: 'Trượt Xe theo một hướng để ăn quân địch phía xa.', en: 'Slide the Rook in one direction to capture the distant enemy.' },
  'tutorial.t3.blockedInfo': {
    vi: 'Phía kia có hai quân địch xếp thẳng hàng. Xe chỉ ăn được quân GẦN nhất — quân đứng sau tạm thời không ăn được.',
    en: 'Two enemies stand in a line over there. The Rook can only capture the NEAREST one — the one behind it is blocked.',
  },
  'tutorial.t3.captureBlocked': { vi: 'Ăn quân địch gần nhất trên hướng đó.', en: 'Capture the nearest enemy on that line.' },

  'tutorial.t4.title': { vi: 'Quân Tượng', en: 'The Bishop' },
  'tutorial.t4.intro': {
    vi: 'Tượng đi theo đường "ngang zíc-zắc": mỗi bước nhảy qua 2 ô, ô ở giữa không cản đường. Tầm xa tương đương 9 ô thường.',
    en: 'A Bishop moves in a "zigzag" line: each hop skips 2 cells, and the middle cell never blocks it. Its reach equals 9 normal cells.',
  },
  'tutorial.t4.capture': { vi: 'Trượt Tượng theo hướng chéo để ăn quân địch.', en: 'Slide the Bishop diagonally to capture the enemy.' },

  'tutorial.t5.title': { vi: 'Quân Mã', en: 'The Knight' },
  'tutorial.t5.intro': { vi: 'Mã nhảy thẳng tới 1 trong 12 ô cố định quanh nó, bỏ qua mọi quân chắn đường.', en: 'A Knight jumps directly to one of 12 fixed cells around it, ignoring anything in between.' },
  'tutorial.t5.capture': { vi: 'Nhảy Mã của bạn để ăn quân địch.', en: 'Jump your Knight to capture the enemy.' },

  'tutorial.t6.title': { vi: 'Quân Hậu', en: 'The Queen' },
  'tutorial.t6.intro': { vi: 'Hậu mạnh nhất bàn cờ: đi được như Xe VÀ như Tượng cộng lại.', en: 'The Queen is the strongest piece: it moves like a Rook AND a Bishop combined.' },
  'tutorial.t6.captureStraight': { vi: 'Ăn quân địch theo đường thẳng (như Xe).', en: 'Capture the enemy in a straight line (like a Rook).' },
  'tutorial.t6.captureDiag': { vi: 'Ăn nốt quân địch còn lại theo đường chéo (như Tượng).', en: 'Capture the remaining enemy diagonally (like a Bishop).' },

  'tutorial.t7.title': { vi: 'Vua và cách thắng', en: 'The King and winning' },
  'tutorial.t7.intro': {
    vi: 'Hexwar không có chiếu hay chiếu bí — thắng bằng cách ăn được Vua đối phương. Vua bị ăn thì cả đội của người đó bị loại ngay.',
    en: 'Hexwar has no check or checkmate — you win by capturing the enemy King. Once a King falls, that whole player is eliminated at once.',
  },
  'tutorial.t7.capture': { vi: 'Đi Vua của bạn 1 bước để ăn Vua đối phương và thắng bài học này.', en: "Move your King one step to capture the enemy King and win this lesson." },

  'tutorial.t8.title': { vi: 'Quân Hề', en: 'The Jester' },
  'tutorial.t8.intro': {
    vi: 'Hề không bao giờ ăn được quân, chỉ đi tối đa 3 ô. Nhưng nếu Vua của bạn bị ăn trong lúc Hề còn sống và cách Vua không quá 5 ô, Hề sẽ hy sinh để Vua hồi sinh ngay tại chỗ Hề đứng.',
    en: 'A Jester never captures and moves at most 3 cells. But if your King is captured while your Jester is alive within 5 cells, the Jester sacrifices itself to revive the King on the spot.',
  },
  'tutorial.t8.move': { vi: 'Thử đi Hề của bạn 1 nước, vẫn giữ khoảng cách gần Vua.', en: 'Try moving your Jester one step, while staying close to your King.' },
  'tutorial.t8.autoCapture': { vi: 'Bây giờ đối thủ ăn Vua của bạn — xem điều gì xảy ra.', en: "Now the opponent captures your King — watch what happens." },
  'tutorial.t8.result': {
    vi: 'Hề đã cứu Vua! Đây là cách duy nhất một người "sống lại" sau khi mất Vua — nhưng chỉ dùng được đúng một lần.',
    en: 'The Jester saved the King! This is the only way to "come back" after losing your King — but it only works once.',
  },

  'tutorial.t9.title': { vi: 'Tù binh', en: 'Captives' },
  'tutorial.t9.intro': {
    vi: 'Khi quân của bạn ăn một quân địch (trừ Vua), quân đó KHÔNG biến mất — nó trở thành tù binh, đứng chung ô với quân vừa ăn.',
    en: 'When your piece captures an enemy (not a King), that piece does NOT disappear — it becomes a captive, sharing the cell with your attacker.',
  },
  'tutorial.t9.capture': { vi: 'Dùng Tốt ăn Hậu của đối phương.', en: "Use your Pawn to capture the opponent's Queen." },
  'tutorial.t9.conscriptInfo': {
    vi: 'Tù binh vừa bắt đã sẵn sàng: lượt này bạn "trưng dụng" được nó, đi nó như quân của chính mình. Cơ hội chỉ một lượt — dùng hay không thì tù binh cũng biến mất sau lượt này.',
    en: 'The captive you just took is ready: this turn you can "conscript" it and move it as your own. You get exactly one turn — used or not, it vanishes after this turn.',
  },
  'tutorial.t9.conscript': { vi: 'Trưng dụng Hậu vừa bắt được để ăn Vua đối phương.', en: "Conscript the Queen you captured to take the opponent's King." },

  'tutorial.t10.title': { vi: 'Kill và phong cấp', en: 'Kills and promotion' },
  'tutorial.t10.intro': {
    vi: 'Tốt ăn đủ 6 quân địch (tính dồn cả trận) thì lập tức phong thành Mã, không cần chọn. Ngưỡng tiếp theo là 10 (Tượng), 15 (Xe), 20 (Hậu).',
    en: 'A Pawn that reaches 6 kills (cumulative for the whole match) is instantly promoted to a Knight, no choice needed. Next thresholds: 10 (Bishop), 15 (Rook), 20 (Queen).',
  },
  'tutorial.t10.promote': { vi: 'Tốt này đã ăn 5 quân — ăn thêm 1 quân nữa để phong cấp.', en: 'This Pawn already has 5 kills — capture one more to get promoted.' },

  'tutorial.t11.title': { vi: 'Thu hẹp và thời gian', en: 'Shrinking and time' },
  'tutorial.t11.intro': {
    vi: 'Bàn cờ thu hẹp dần: vòng ngoài cùng nhấp nháy vàng vài hiệp trước, đỏ ngay trước khi biến mất, rồi mọi quân trên đó bị loại — kể cả Vua, và lần này Hề không cứu được.',
    en: 'The board shrinks over time: the outer ring blinks yellow a few rounds ahead, red right before, then everything on it is removed — even a King, and this time the Jester cannot save it.',
  },
  'tutorial.t11.move': { vi: 'Vòng ngoài sắp biến mất ngay sau lượt này. Đưa Vua của bạn vào trong để không bị loại.', en: 'The outer ring vanishes right after this move. Move your King inward so it survives.' },
  'tutorial.t11.result': { vi: 'Vòng ngoài đã biến mất — Vua của bạn an toàn vì đã di chuyển kịp lúc.', en: 'The outer ring is gone — your King is safe because it moved in time.' },

  'tutorial.t12.title': { vi: 'Xúc xắc, lượt và trò chuyện', en: 'Dice, turns and chat' },
  'tutorial.t12.intro': {
    vi: 'Đầu ván, mọi người tung 3 xúc xắc; ai tổng cao nhất đi trước. Đồng điểm cao nhất thì chỉ những người đó tung lại.',
    en: "At the start, everyone rolls 3 dice; the highest total goes first. A tie for the highest re-rolls only among those tied.",
  },
  'tutorial.t12.roll': { vi: 'Tung xúc xắc để xem ai đi trước.', en: 'Roll the dice to see who goes first.' },
  'tutorial.t12.move': { vi: 'Người thắng xúc xắc đi trước — đi 1 nước bất kỳ.', en: 'The dice winner moves first — make any move.' },
  'tutorial.t12.order': {
    vi: 'Sau đó lượt đi theo chiều kim đồng hồ quanh bàn; hết một vòng quay lại người mở hiệp là sang hiệp mới.',
    en: 'After that, turns go clockwise around the table; a full circle back to the round opener starts a new round.',
  },
  'tutorial.t12.chat': {
    vi: 'Trong trận thật, bạn gửi được câu chat có sẵn ở toàn phòng, hoặc bấm vào tên một người để nhắn riêng — không gõ chữ tự do.',
    en: 'In a real match you can send preset chat phrases to the whole room, or click a name to whisper them — no free typing.',
  },
  'tutorial.t12.voice': { vi: 'Bạn cũng bật được mic/loa để nói chuyện trực tiếp với những người không bị bạn chặn.', en: "You can also turn on mic/speaker to talk directly with anyone you haven't blocked." },

  'tutorial.t13.title': { vi: 'Trận tập', en: 'Practice match' },
  'tutorial.t13.intro': {
    vi: 'Bài cuối: một ván thật, 1 người + 5 bot Dễ, gợi ý luôn bật sẵn. Chơi tới khi thắng hoặc tới hiệp 50.',
    en: 'Final lesson: a real match, you plus 5 Easy bots, hints on by default. Play until you win or round 50.',
  },
};
