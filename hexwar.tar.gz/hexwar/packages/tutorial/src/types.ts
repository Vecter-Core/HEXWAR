// Mô hình dữ liệu bài tân thủ (PLAN.md mục 10). Thuần dữ liệu (JSON/TS-serializable) để dùng chung cho:
// (1) runner chạy bài trên engine thật, (2) "người chơi ảo" giải bài (test CI), (3) hệ gợi ý theo thời gian
// (15s làm nổi bật, 30s bóng mờ đường đi) — cả ba đọc cùng một `Goal` nên không thể lệch nhau.
//
// Lệch cố ý so với PLAN 10.3 ("mỗi bài là một file scenarios/Tn.json"): bài học viết bằng module TypeScript
// thay vì JSON để giữ kiểm tra kiểu tĩnh (id quân, ô, Seat...); lý do ghi ở docs/decisions.md.
import type { Cell, GameEvent, GameEventType, GameState, Move, Seat } from '@hexwar/rules';

export type LessonId = 'T1' | 'T2' | 'T3' | 'T4' | 'T5' | 'T6' | 'T7' | 'T8' | 'T9' | 'T10' | 'T11' | 'T12' | 'T13';

export const LESSON_IDS: readonly LessonId[] = ['T1', 'T2', 'T3', 'T4', 'T5', 'T6', 'T7', 'T8', 'T9', 'T10', 'T11', 'T12', 'T13'];

/**
 * Điều kiện hoàn thành một bước 'move'. Chỉ được gọi SAU KHI nước đi đã hợp lệ (`checkMove` qua), nên
 * `anyMove` luôn đúng — nó tồn tại để diễn tả "đi nước nào cũng được, miễn đúng luật".
 */
export type Goal =
  | { readonly kind: 'anyMove' }
  /** Có sự kiện MOVED của đúng quân này trong lượt vừa xử lý. */
  | { readonly kind: 'pieceMoved'; readonly pieceId: string }
  /** Có ít nhất một sự kiện đúng loại trong lượt vừa xử lý. */
  | { readonly kind: 'eventType'; readonly eventType: GameEventType }
  /** Như `eventType`, thêm điều kiện khớp một số trường (so sánh bằng, chỉ trường kiểu chuỗi/số/bool). */
  | { readonly kind: 'eventMatch'; readonly eventType: GameEventType; readonly match: Readonly<Record<string, string | number | boolean>> }
  /** Quân (theo id) đứng ở hạng ≤ `ring` trong trạng thái SAU lượt vừa xử lý (ví dụ: Vua đã vào trong trước khi thu hẹp). */
  | { readonly kind: 'pieceRingAtMost'; readonly pieceId: string; readonly ring: number }
  /** Quân (theo id) đứng đúng ô này trong trạng thái SAU lượt vừa xử lý (chọn chính xác một trong nhiều nước hợp lệ). */
  | { readonly kind: 'pieceAt'; readonly pieceId: string; readonly cell: Cell }
  /** Tất cả các mục tiêu con đều đạt (dùng chung một lượt đi). */
  | { readonly kind: 'all'; readonly goals: readonly Goal[] };

export type Step =
  /** Chỉ lời thoại (textKey), người chơi bấm "Tiếp tục"; người chơi ảo bỏ qua ngay. */
  | { readonly kind: 'info'; readonly textKey: string }
  /** Tung xúc xắc thật (`rollDice`) để vào pha chơi. Chỉ dùng khi trạng thái đang ở pha 'dice'. */
  | { readonly kind: 'roll'; readonly textKey: string }
  /**
   * Nước đi kịch bản của một ghế khác (đối thủ mẫu), áp bằng `applyMove` y như thật, không cần người chơi.
   * `expect` (tuỳ chọn) là sự kiện phải xuất hiện — sai thì runner ném lỗi ngay (bắt lỗi soạn bài từ CI).
   */
  | { readonly kind: 'auto'; readonly seat: Seat; readonly move: Move; readonly expect?: GameEventType; readonly textKey?: string }
  /** Chờ `seat` đi một nước hợp lệ thoả `goal`. Nước hợp lệ nhưng chưa thoả vẫn được áp dụng thật (chơi thật, không giả lập). */
  | { readonly kind: 'move'; readonly seat: Seat; readonly goal: Goal; readonly textKey: string; readonly hintTextKey?: string };

interface LessonBase {
  readonly id: LessonId;
  /** Khoá i18n tên bài (danh sách chọn bài). */
  readonly titleKey: string;
  /** Mã luật liên quan (PLAN.md), chỉ để truy vết tài liệu. */
  readonly ruleRefs: readonly string[];
}

/** Bài chạy trên bàn cờ dựng riêng (`makeState`), qua runner của gói này. */
export interface ScenarioLesson extends LessonBase {
  readonly kind: 'scenario';
  /** Dựng trạng thái đầu bài. Thuần, tất định — gọi lại nhiều lần (Làm lại) phải ra cùng kết quả. */
  readonly setup: () => GameState;
  readonly steps: readonly Step[];
}

/**
 * T13 "Trận tập": không có kịch bản riêng — dùng nguyên luồng chơi solo thật (1 người + 5 bot Dễ, mục 10.2).
 * Không có `steps`/`setup` nên không nằm trong phạm vi kiểm tra "người chơi ảo" của gói này (PLAN 8, M4 đã
 * kiểm bằng test riêng của `@hexwar/client`/`@hexwar/bot`); client tự khởi động ván thật khi chọn bài này.
 */
export interface RealGameLesson extends LessonBase {
  readonly kind: 'realGame';
}

export type Lesson = ScenarioLesson | RealGameLesson;

export function isScenarioLesson(lesson: Lesson): lesson is ScenarioLesson {
  return lesson.kind === 'scenario';
}

// Cho phép so khớp trường của GameEvent mà không cần ép kiểu `any` ở nơi dùng.
export type EventRecord = GameEvent & Record<string, unknown>;
