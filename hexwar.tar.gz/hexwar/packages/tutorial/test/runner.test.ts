// Kiểm tra hành vi của runner độc lập với nội dung bài học thật: nước sai luật không đổi trạng thái, nước
// đúng luật nhưng chưa thoả mục tiêu vẫn được áp dụng thật (chơi thật), và bước 'info' phải được xác nhận.
import { cell, createPiece, makeState } from '@hexwar/rules';
import { describe, expect, it } from 'vitest';
import { acknowledgeInfo, attemptMove, currentStep, pump, startLesson } from '../src/runner';
import { findHintMove } from '../src/solver';
import type { ScenarioLesson } from '../src/types';

// Hai Tốt của ghế 0; ghế 1 không có quân (chỉ giữ chỗ, xem ghi chú ở scenarios/*.ts) nên luôn tới lượt ghế 0.
// Mục tiêu bước 'move' buộc chọn ĐÚNG quân "p1".
const lesson: ScenarioLesson = {
  id: 'T1',
  kind: 'scenario',
  titleKey: 'x',
  ruleRefs: [],
  setup: () =>
    makeState({
      radius: 4,
      seats: [0, 1],
      pieces: [createPiece('p0', 0, 'P', cell(0, 2)), createPiece('p1', 0, 'P', cell(2, 2))],
    }),
  steps: [
    { kind: 'info', textKey: 'a' },
    { kind: 'move', seat: 0, goal: { kind: 'pieceMoved', pieceId: 'p1' }, textKey: 'b' },
  ],
};

describe('runner', () => {
  it('dừng ở bước info, chỉ đi tiếp khi được acknowledge', () => {
    const r = startLesson(lesson);
    expect(currentStep(r)?.kind).toBe('info');
    expect(r.done).toBe(false);
    const after = acknowledgeInfo(r);
    expect(currentStep(after)?.kind).toBe('move');
  });

  it('nước sai luật: bị từ chối, không đổi trạng thái, ghi lại lý do', () => {
    let r = startLesson(lesson);
    r = acknowledgeInfo(r);
    const before = r.game;
    const rejected = attemptMove(r, { pieceId: 'p0', to: cell(0, 0) }); // xa hơn 1 ô: sai luật Tốt
    expect(rejected.game).toBe(before);
    expect(rejected.lastRejection).not.toBeNull();
    expect(rejected.stepIndex).toBe(r.stepIndex);
  });

  it('nước đúng luật nhưng sai quân mục tiêu: áp dụng thật, không sang bước kế', () => {
    let r = startLesson(lesson);
    r = acknowledgeInfo(r);
    const moved = attemptMove(r, { pieceId: 'p0', to: cell(0, 1) }); // đi p0, mục tiêu cần p1
    expect(moved.stepIndex).toBe(r.stepIndex); // vẫn ở bước 'move'
    expect(moved.done).toBe(false);
    expect(moved.game.pieces.find((p) => p.id === 'p0')?.cell).toEqual(cell(0, 1)); // nhưng nước đã thật sự xảy ra
  });

  it('nước đúng luật và đúng mục tiêu: sang bước kế / hoàn thành bài', () => {
    let r = startLesson(lesson);
    r = acknowledgeInfo(r);
    const finished = attemptMove(r, { pieceId: 'p1', to: cell(2, 1) });
    expect(finished.done).toBe(true);
  });

  it('findHintMove trả về đúng nước mà nghiệm thu bằng attemptMove cũng chấp nhận', () => {
    let r = startLesson(lesson);
    r = acknowledgeInfo(r);
    const step = currentStep(r);
    if (step === undefined || step.kind !== 'move') throw new Error('kỳ vọng bước move');
    const hint = findHintMove(r.game, step.seat, step.goal);
    expect(hint).toBeDefined();
    const applied = attemptMove(r, hint as NonNullable<typeof hint>);
    expect(applied.done).toBe(true);
  });

  it('pump() không tự vượt qua bước info (chỉ auto/roll)', () => {
    const r = pump(startLesson(lesson));
    expect(currentStep(r)?.kind).toBe('info');
  });
});
