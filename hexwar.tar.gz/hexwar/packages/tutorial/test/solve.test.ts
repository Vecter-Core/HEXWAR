// Nghiệm thu M8 (PLAN.md mục 15): "'Người chơi ảo' giải xong cả 13 bài trong CI". T13 không có kịch bản
// (dùng nguyên ván thật, đã kiểm ở @hexwar/client/@hexwar/bot) nên không nằm trong vòng lặp này — xem
// `isScenarioLesson` và ghi chú ở types.ts.
import { describe, expect, it } from 'vitest';
import { isScenarioLesson, LESSON_IDS, LESSONS, solveLesson } from '../src';

describe('người chơi ảo giải hết các bài tân thủ', () => {
  const scenarioLessons = LESSONS.filter(isScenarioLesson);

  it('có đủ 13 bài, đúng thứ tự T1..T13', () => {
    expect(LESSONS.map((l) => l.id)).toEqual(LESSON_IDS);
  });

  it('T13 là ván thật, không có kịch bản riêng', () => {
    const t13 = LESSONS.find((l) => l.id === 'T13');
    expect(t13?.kind).toBe('realGame');
  });

  for (const lesson of scenarioLessons) {
    it(`giải xong bài ${lesson.id}`, () => {
      const result = solveLesson(lesson);
      expect(result.done).toBe(true);
    });
  }

  it('mỗi bài kịch bản dựng lại (Làm lại) ra đúng cùng kết quả — setup tất định', () => {
    for (const lesson of scenarioLessons) {
      const a = solveLesson(lesson);
      const b = solveLesson(lesson);
      expect(a.game).toEqual(b.game);
    }
  });
});
