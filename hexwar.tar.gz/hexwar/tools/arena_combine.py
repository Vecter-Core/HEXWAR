#!/usr/bin/env python3
"""
arena_combine.py — Gộp nhiều file JSON số liệu thô của `pnpm --filter @hexwar/bot arena`
(ghi bằng biến môi trường ARENA_RAW_OUT, xem packages/bot/test/winrate.arena.ts) thành MỘT báo cáo
Markdown duy nhất, cộng thẳng số ván/số thắng thật (không lấy trung bình của trung bình).

Lý do có script này (docs/decisions.md mục M9): PLAN 9.5 muốn 1000 ván mỗi mục để sai số chuẩn ≈ 1,2%,
nhưng một ván chạy hết trên bàn 1801 ô tốn tới chục giây thật — 1000 ván một lần vượt quá thời gian một
lệnh có thể chạy trong sandbox này. Chạy nhiều đợt nhỏ (ARENA_SEED_OFFSET khác nhau mỗi đợt để không lặp
ván), mỗi đợt ghi một file JSON, rồi gộp bằng script này.

Dùng:
    ARENA_GAMES=10 ARENA_ONLY=hardVsNormal,fairness ARENA_SEED_OFFSET=0  ARENA_RAW_OUT=/tmp/a0.json pnpm --filter @hexwar/bot arena
    ARENA_GAMES=10 ARENA_ONLY=hardVsNormal,fairness ARENA_SEED_OFFSET=10 ARENA_RAW_OUT=/tmp/a1.json pnpm --filter @hexwar/bot arena
    ...
    python3 tools/arena_combine.py /tmp/a0.json /tmp/a1.json ... > /tmp/combined.md
"""
import json
import sys
import math


def percentile(values, p):
    if not values:
        return 0
    s = sorted(values)
    return s[min(len(s) - 1, int((len(s) - 1) * p))]


def pct(x, n):
    return f"{100 * x / n:.1f}%" if n else "—"


def combine_tally(tallies):
    out = {"games": 0, "wins": 0, "hardCap": 0, "collapseDeaths": 0, "rounds": [], "think": []}
    for t in tallies:
        out["games"] += t["games"]
        out["wins"] += t["wins"]
        out["hardCap"] += t["hardCap"]
        out["collapseDeaths"] += t["collapseDeaths"]
        out["rounds"] += t["rounds"]
        out["think"] += t["think"]
    return out


def combine_fairness(tallies):
    out = {"games": 0, "wins": [0] * 6, "hardCap": 0, "rounds": []}
    for t in tallies:
        out["games"] += t["games"]
        for seat in range(6):
            out["wins"][seat] += t["wins"][seat]
        out["hardCap"] += t["hardCap"]
        out["rounds"] += t["rounds"]
    return out


def report_tally(label, t):
    n = t["games"]
    lines = [
        f"### {label} ({n} ván, gộp từ nhiều đợt thật)",
        "",
        "| Chỉ số | Giá trị |",
        "|---|--:|",
        f"| Tỉ lệ thắng (ngẫu nhiên = 16,7%) | {pct(t['wins'], n)} ({t['wins']}/{n}) |",
        f"| Ván kết thúc ở hiệp giới hạn 450 | {pct(t['hardCap'], n)} |",
        f"| Số người bị loại vì thu hẹp (tổng, mọi ván) | {t['collapseDeaths']} |",
        f"| Số hiệp khi kết thúc: trung vị / p90 | {percentile(t['rounds'], 0.5)} / {percentile(t['rounds'], 0.9)} |",
        f"| Thời gian nghĩ mỗi nước: p50 / p95 / max (ms) | {percentile(t['think'], 0.5):.1f} / {percentile(t['think'], 0.95):.1f} / {max(t['think']) if t['think'] else 0:.1f} |",
        "",
    ]
    return "\n".join(lines)


def report_fairness(label, f):
    n = f["games"]
    se = 100 * math.sqrt(0.5 / 6 / n) if n else 0
    rows = "\n".join(f"| Ghế {seat} | {pct(f['wins'][seat], n)} ({f['wins'][seat]}/{n}) |" for seat in range(6))
    lines = [
        f"### {label} ({n} ván, gộp từ nhiều đợt thật, PLAN 9.5: mục tiêu 16,7% ± 3%, sai số chuẩn ước lượng ≈ {se:.2f}%)",
        "",
        "| Ghế | Tỉ lệ thắng |",
        "|---|--:|",
        rows,
        "",
        f"Ván kết thúc ở hiệp giới hạn 450: {pct(f['hardCap'], n)}. Số hiệp khi kết thúc: trung vị {percentile(f['rounds'], 0.5)} / p90 {percentile(f['rounds'], 0.9)}.",
        "",
    ]
    return "\n".join(lines)


LABELS = {
    "hardVsNormal": "1 Khó vs 5 Thường (M9, PLAN 9.3: ≥ 30%)",
    "fairness": "6 Khó — công bằng ghế (M9, PLAN 9.5)",
    "normalVsEasy": "1 Thường vs 5 Dễ (hồi quy M4, PLAN 9.3: ≥ 35%)",
    "easyFairness": "6 Dễ — đo công bằng ghế thô (hồi quy M4)",
}


def main():
    paths = sys.argv[1:]
    if not paths:
        print(__doc__)
        sys.exit(1)
    batches = [json.load(open(p, encoding="utf-8")) for p in paths]
    offsets = sorted({b.get("seedOffset", 0) for b in batches})
    if len(offsets) != len(batches):
        print(f"# CẢNH BÁO: {len(batches)} file nhưng chỉ {len(offsets)} ARENA_SEED_OFFSET khác nhau — có thể trùng ván!", file=sys.stderr)

    for key in ["hardVsNormal", "normalVsEasy", "easyFairness"]:
        present = [b[key] for b in batches if key in b]
        if present:
            print(report_tally(LABELS[key], combine_tally(present)))

    if any("fairness" in b for b in batches):
        present = [b["fairness"] for b in batches if "fairness" in b]
        print(report_fairness(LABELS["fairness"], combine_fairness(present)))


if __name__ == "__main__":
    main()
