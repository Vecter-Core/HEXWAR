#!/usr/bin/env python3
"""
gen_golden.py - Sinh fixture đối chiếu cho packages/rules từ tools/verify_board.py.

Chạy:  python3 tools/gen_golden.py
Ghi:   packages/rules/test/fixtures/initial-moves.json

Tại sao có file này: verify_board.py là "nguồn chân lý" hình học và có bộ sinh nước đi
riêng bằng Python. Engine TypeScript được viết độc lập; test `python-crosscheck.test.ts`
so từng nước đi ở thế cờ đầu của cả 6 ghế giữa hai bản hiện thực. CI chạy lại script này
rồi `git diff --exit-code` để chắc fixture luôn khớp verify_board.py.

Script KHÔNG sửa verify_board.py: nó nạp mã nguồn, chạy trong một namespace riêng,
rồi đọc các biến toàn cục (occupied, gen_moves, mind, ...).
"""
import contextlib
import io
import json
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
SOURCE = ROOT / "tools" / "verify_board.py"
OUT = ROOT / "packages" / "rules" / "test" / "fixtures" / "initial-moves.json"


def load_reference():
    ns = {"__name__": "verify_board", "__file__": str(SOURCE)}
    with contextlib.redirect_stdout(io.StringIO()):
        try:
            exec(compile(SOURCE.read_text(encoding="utf-8"), str(SOURCE), "exec"), ns)
        except SystemExit:
            pass  # verify_board.py luôn kết thúc bằng sys.exit(...)
    if not ns.get("ok"):
        sys.exit("verify_board.py báo lỗi; sửa trước khi sinh fixture")
    return ns


def main():
    ns = load_reference()
    occupied = ns["occupied"]
    gen_moves = ns["gen_moves"]
    mind = ns["mind"]

    pieces = sorted([s, t, c[0], c[1]] for c, (s, t) in occupied.items())
    moves = {}
    for seat in range(6):
        moves[seat] = sorted(
            [t, n[0], n[1], 1 if cap else 0] for t, n, cap in gen_moves(seat, occupied)
        )

    by_type = {}
    for t, _, _, _ in moves[0]:
        by_type[t] = by_type.get(t, 0) + 1

    lines = ["{"]
    lines.append('  "source": "tools/gen_golden.py (từ tools/verify_board.py) - KHÔNG sửa tay",')
    lines.append(f'  "radius": {ns["R"]},')
    lines.append(f'  "adjacentMinDistance": {mind[(0, 1)]},')
    lines.append(f'  "oppositeMinDistance": {mind[(0, 3)]},')
    lines.append(f'  "seat0MovesByType": {json.dumps(dict(sorted(by_type.items())))},')
    lines.append('  "pieces": [')
    lines.append(",\n".join("    " + json.dumps(p) for p in pieces))
    lines.append("  ],")
    lines.append('  "moves": {')
    blocks = []
    for seat in range(6):
        body = ",\n".join("      " + json.dumps(m) for m in moves[seat])
        blocks.append(f'    "{seat}": [\n{body}\n    ]')
    lines.append(",\n".join(blocks))
    lines.append("  }")
    lines.append("}")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines) + "\n", encoding="utf-8")
    total = sum(len(v) for v in moves.values())
    print(f"Đã ghi {OUT.relative_to(ROOT)}: {len(pieces)} quân, {total} nước đi (6 ghế)")


if __name__ == "__main__":
    main()
