#!/usr/bin/env python3
"""
mutate.py - Kiểm thử đột biến thủ công cho packages/rules (M2).

Mỗi đột biến: sửa đúng 1 chỗ trong packages/rules/src, chạy vitest (dừng ở test đỏ đầu tiên), rồi khôi phục file.
Đột biến "bị bắt" (killed) = có test đỏ; "SURVIVED" = mọi test vẫn xanh, tức là test chưa bảo vệ chỗ đó (hoặc
đột biến là tương đương, xem EQUIVALENT).

Chạy:  python3 tools/mutate.py            # tất cả (~10 phút)
       python3 tools/mutate.py C09 T      # chỉ các đột biến có id bắt đầu bằng C09 hoặc T
Thoát mã 0 nếu mọi đột biến không-tương-đương đều bị bắt. Không chạy trong CI (chậm, và chuỗi cần vá gắn với mã nguồn:
đổi mã nguồn thì đột biến báo NOPATCH, cần cập nhật bảng bên dưới).

An toàn: file gốc được sao lưu thành `.bak` rồi khôi phục trong `finally`; nếu tiến trình bị giết giữa chừng,
hãy kiểm tra `git status`/`find packages/rules -name '*.bak'` và khôi phục thủ công.
"""
import os, shutil, subprocess, sys, time

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'packages', 'rules')
SRC = os.path.join(ROOT, 'src') + os.sep

# Đột biến tương đương: không thể bị test bắt vì không đổi hành vi quan sát được với luật hiện tại.
EQUIVALENT = {
    'H05': 'điểm người A không bao giờ đổi khi loại người B (R-31: tù binh vẫn tính cho chủ cũ); '
           'bất biến này có test thường trực ở score.test.ts. Phần chụp điểm ở shrink.ts chỉ là phòng thủ.',
}

M = []
def m(id, file, old, new): M.append((id, file, old, new))

# captives.ts
m('C01 kills của quân ăn không tăng', 'captives.ts', "kills: actor.kills + 1 }; // R-30, R-40", "kills: actor.kills }; // R-30, R-40")
m('C02 playerKills không tăng', 'captives.ts', "d.playerKills[seat] = (d.playerKills[seat] ?? 0) + 1;", "d.playerKills[seat] = (d.playerKills[seat] ?? 0) + 0;")
m('C03 trưng dụng ăn quân không tính kill người chơi', 'captives.ts', "  addKill(d, mover);\n  emit(d, { type: 'CAPTURED', attackerId: captive.id,", "  emit(d, { type: 'CAPTURED', attackerId: captive.id,")
m('C04 không giải cứu khi chủ ăn lại người giữ', 'captives.ts', "    if (captive.owner === capturer) {", "    if (captive.owner === (99 as never)) {")
m('C05 tù binh mới tạo đã armed (hết hạn ngay)', 'captives.ts', "replacePiece(d, { ...victim, status: 'captive', holder, armed: false });", "replacePiece(d, { ...victim, status: 'captive', holder, armed: true });")
m('C06 tù binh không bao giờ hết hạn', 'captives.ts', "p.status === 'captive' && p.holder === mover && p.armed === true);", "p.status === 'captive' && p.holder === mover && p.armed === false);")
m('C07 Hề cứu khi cách <5 thay vì <=5', 'captives.ts', "dist(p.cell, king.cell) <= d.config.reach.jesterReviveDistance", "dist(p.cell, king.cell) < d.config.reach.jesterReviveDistance")
m('C08 Hề tù binh vẫn cứu Vua', 'captives.ts', "      p.status === 'active' &&\n      dist(", "      dist(")
m('C09 Vua bị ăn bằng tù binh xử lý như ăn thường', 'captives.ts', "if (viaConscript) releaseStillCaptive(d, heldIds, 'holder_lost');", "if (!viaConscript) releaseStillCaptive(d, heldIds, 'holder_lost');")
m('C10 tù binh trưng dụng tạo chuỗi tù binh', 'captives.ts', "removePieces(d, new Set([victim.id]));\n    releaseStillCaptive", "makeCaptive(d, victim, mover);\n    releaseStillCaptive")
m('C11 tù binh chuyển giao armed ngay', 'captives.ts', "replacePiece(d, { ...captive, holder: capturer, armed: false });", "replacePiece(d, { ...captive, holder: capturer, armed: true });")
m('C12 không phong cấp sau nước ăn', 'captives.ts', "  promoteIfReady(d, attacker.id); // R-41: sau nước ăn, cùng lượt", "  void attacker; // R-41")
m('C13 Hề cứu xong Hề vẫn còn', 'captives.ts', "  removePieces(d, new Set([jester.id]));\n  replacePiece(d, { ...king, cell: jester.cell });", "  replacePiece(d, { ...king, cell: jester.cell });")
m('C14 Vua bị ăn không loại người chơi', 'captives.ts', "  eliminatePlayer(d, king.owner, 'king', nextBatch(d));", "  void nextBatch;")
m('C15 tù binh chủ ở chung ô người chuyển giao mất', 'captives.ts', "    emit(d, { type: 'CAPTIVE_TRANSFERRED', pieceId: id, owner: captive.owner, from: formerHolder, to: capturer });", "")
# promotion.ts
m('P01 ngưỡng phong cấp dùng <=', 'promotion.ts', "if (piece.kills < d.config.promotion[next]) return;", "if (piece.kills <= d.config.promotion[next]) return;")
m('P02 quân không phải xuất thân Tốt cũng phong', 'promotion.ts', "  if (piece.origin !== 'P') return;\n", "")
m('P03 cumulativeKills đảo', 'promotion.ts', "kills: d.config.promotion.cumulativeKills ? piece.kills : 0", "kills: d.config.promotion.cumulativeKills ? 0 : piece.kills")
m('P04 chỉ phong một bậc mỗi nước', 'promotion.ts', "    piece = promoted;\n  }", "    return;\n  }")
# draft.ts
m('D01 ô trống gần nhất bỏ ô gốc', 'draft.ts', "for (let distance = 0; distance <= 2 * radius; distance++)", "for (let distance = 1; distance <= 2 * radius; distance++)")
m('D02 người bị loại không thả tù binh đang giữ', 'draft.ts', "  releaseCaptives(d, heldIds, 'holder_eliminated'); // R-35", "  void heldIds; // R-35")
m('D03 người mở hiệp bị loại không chuyển', 'draft.ts', "  if (next !== undefined) d.opener = next;", "  void next;")
m('D04 hoà nhưng ghi lastKing', 'draft.ts', "else if (alive === 0) finishGame(d, 'allEliminated');", "else if (alive === 0) finishGame(d, 'lastKing');")
m('D05 người thắng lastKing là ghế đầu', 'draft.ts', "winner = aliveSeats(d)[0] ?? null; // R-80", "winner = d.order[0] ?? null; // R-80")
m('D06 hardCap không xét đồng hạng nhất', 'draft.ts', "winner = best.length === 1 ? (best[0] as { seat: Seat }).seat : null;", "winner = (best[0] as { seat: Seat }).seat;")
m('D07 nearestEmpty không kiểm tra trên bàn', 'draft.ts', "if (isOnBoard(candidate, radius) && !occupied.has(cellKey(candidate))) return candidate;", "if (!occupied.has(cellKey(candidate))) return candidate;")
m('D08 loại người chơi không xoá quân', 'draft.ts', "  removePieces(d, new Set(removedIds));\n\n  const heldIds", "  const heldIds0 = removedIds;\n  void heldIds0;\n\n  const heldIds")
# score.ts
m('S01 bị loại muộn hơn xếp thấp hơn', 'score.ts', "return b.batch - a.batch;", "return a.batch - b.batch;")
m('S02 điểm thấp hơn xếp trên', 'score.ts', "return b.entry.score - a.entry.score;", "return a.entry.score - b.entry.score;")
m('S03 đồng hạng không xét điểm', 'score.ts', "&& a.entry.score === b.entry.score;", ";")
m('S04 điểm bỏ kill', 'score.ts', "return total + (state.playerKills[seat] ?? 0) * state.config.score.perKill;", "return total;")
# shrink.ts
m('H01 thu hẹp loại cả vòng kế', 'shrink.ts', "ring(piece.cell) > newRadius;", "ring(piece.cell) >= newRadius;")
m('H02 không giảm bán kính', 'shrink.ts', "  d.radius = newRadius;\n", "")
m('H03 Hề cứu khỏi thu hẹp đảo cờ', 'shrink.ts', "if (d.config.jester.savesFromCollapse) {", "if (!d.config.jester.savesFromCollapse) {")
m('H04 mỗi người một batch', 'shrink.ts', "eliminatePlayer(d, seat, 'collapse', batch, scores[index])", "eliminatePlayer(d, seat, 'collapse', nextBatch(d), scores[index])")
m('H05 điểm chụp sau khi loại người trước', 'shrink.ts', "eliminatePlayer(d, seat, 'collapse', batch, scores[index])", "eliminatePlayer(d, seat, 'collapse', batch)")
m('H06 mức đỏ dùng <', 'shrink.ts', "roundsLeft <= redRoundsBefore ? 'red'", "roundsLeft < redRoundsBefore ? 'red'")
m('H07 cảnh báo tính cả hiệp hiện tại', 'shrink.ts', ".filter((event) => event.round > state.round)", ".filter((event) => event.round >= state.round)")
m('H08 phát cảnh báo cả khi chưa tới ngưỡng', 'shrink.ts', "if (level !== null) emit(", "if (level !== null || roundsLeft > 0) emit(")
m('H09 thu hẹp có tính kill', 'shrink.ts', "  d.radius = newRadius;\n  emit(d, { type: 'RING_COLLAPSED'", "  for (const p of removed) d.playerKills[p.owner] = (d.playerKills[p.owner] ?? 0) + 1;\n  d.radius = newRadius;\n  emit(d, { type: 'RING_COLLAPSED'")
# turn.ts
m('T01 vượt người mở hiệp dùng <', 'turn.ts', "return toOpener <= toNext;", "return toOpener < toNext;")
m('T02 hiệp cứng dùng >', 'turn.ts', "if (round >= d.config.collapse.hardCapRound) {", "if (round > d.config.collapse.hardCapRound) {")
m('T03 lượt tự bỏ không hết hạn tù binh', 'turn.ts', "  finishTurnCaptives(d, seat);\n  return false;", "  return false;")
m('T04 cuối lượt không loại tù binh', 'turn.ts', "  finishTurnCaptives(d, mover); // bước 4, R-33", "  void mover; // bước 4")
m('T05 đầu hàng ở lượt mình không chuyển lượt', 'turn.ts', "state.turnSeat === seat) advanceTurn", "false) advanceTurn")
m('T06 hết giờ không phát TURN_SKIPPED', 'turn.ts', "  emit(d, { type: 'TURN_SKIPPED', seat, reason: 'timeout' });\n", "")
m('T07 checkMove không kiểm quyền sở hữu', 'turn.ts', "if (foreign) return 'NOT_YOUR_PIECE';", "void foreign;")
m('T08 người mở hiệp không cập nhật sau thu hẹp', 'turn.ts', "seat = d.opener ?? next;", "seat = next;")
m('T09 thu hẹp sai hiệp', 'turn.ts', "if (collapseEventAt(d.config, round) !== undefined) applyCollapse(d);", "if (collapseEventAt(d.config, round) === undefined) applyCollapse(d);")
m('T10 đầu hàng dùng người mở hiệp mới', 'turn.ts', "advanceTurn(d, seat, state.opener ?? seat);\n  return { state: snapshot(d)", "advanceTurn(d, seat, d.opener ?? seat);\n  return { state: snapshot(d)")
m('T11 hết ván kiểm trước khi hết hạn tù binh', 'turn.ts', "  finishTurnCaptives(d, mover); // bước 4, R-33\n  if (!checkGameOver(d)) advanceTurn(d, mover, opener ?? mover);", "  if (!checkGameOver(d)) advanceTurn(d, mover, opener ?? mover);\n  finishTurnCaptives(d, mover);")
m('T12 không cảnh báo', 'turn.ts', "  announceWarnings(d);\n  return true;", "  return true;")
m('T13 lượt không có nước đi không bỏ qua', 'turn.ts', "  if (hasLegalMove(d, seat)) return true;", "  if (true as boolean) return true;")
m('T14 lượt mới quên round', 'turn.ts', "  d.round = round;\n  emit(d, { type: 'ROUND_STARTED', round });", "  emit(d, { type: 'ROUND_STARTED', round });")
m('T15 người mở hiệp hiệp 1 sai', 'turn.ts', "  d.opener = first;\n  if (!startRound(d, 1)) return;", "  d.opener = d.order[1] ?? first;\n  if (!startRound(d, 1)) return;")
# dice.ts
m('X01 xúc xắc: luôn chốt lần đầu', 'dice.ts', "const winner = top.length === 1 ?", "const winner = top.length >= 1 ?")
m('X02 xúc xắc: tung lại cả bàn', 'dice.ts', "contenders = top.map((roll) => roll.seat);", "contenders = [...seats];")
m('X03 thứ tự đi không xoay', 'dice.ts', "d.order = [...state.order.slice(start), ...state.order.slice(0, start)]; // R-03", "d.order = [...state.order]; // R-03")
m('X04 xúc xắc chỉ 5 mặt', 'dice.ts', "return rng.int(6) + 1;", "return rng.int(5) + 1;")
# moves.ts
m('V01 trưng dụng không cần armed', 'moves.ts', "piece.holder !== undefined && piece.armed === true;", "piece.holder !== undefined;")
m('V02 trưng dụng đi theo khung chủ cũ', 'moves.ts', "return { ...piece, owner: piece.holder, status: 'active' };", "return { ...piece, status: 'active' };")
m('V03 trưng dụng bỏ qua cờ cấu hình', 'moves.ts', "state.config.captive.conscript && piece.holder", "true && piece.holder")
# validate.ts
m('L01 bỏ kiểm co-location tù binh', 'validate.ts', "if (guard === undefined || guard.owner !== piece.holder) {", "if (false as boolean) {")
m('L02 bỏ kiểm hai quân cùng ô', 'validate.ts', "if (activeAt.has(key)) fail(", "if (false as boolean) fail(")
m('L03 bỏ kiểm Vua', 'validate.ts', "if (kings !== 1) fail(", "if (false as boolean) fail(")
m('L04 bỏ kiểm kills', 'validate.ts', "if (sum > (state.playerKills[seat] ?? 0)) fail(", "if (false as boolean) fail(")

only = sys.argv[1:]  # tiền tố id để chạy một phần
results = []
for (mid, file, old, new) in M:
    if only and not any(mid.startswith(p) for p in only):
        continue
    path = SRC + file
    original = open(path, encoding='utf-8').read()
    if original.count(old) != 1:
        line = f'NOPATCH  {mid}  (tìm thấy {original.count(old)} chỗ)'
        print(line, flush=True); results.append((mid, 'NOPATCH')); continue
    shutil.copy(path, path + '.bak')
    try:
        open(path, 'w', encoding='utf-8').write(original.replace(old, new))
        t0 = time.time()
        p = subprocess.run(['pnpm', 'exec', 'vitest', 'run', '--bail', '1'], cwd=ROOT, capture_output=True, text=True, timeout=300)
        status = 'SURVIVED' if p.returncode == 0 else 'killed'
        first = ''
        if p.returncode != 0:
            for ln in (p.stdout + p.stderr).splitlines():
                if ' FAIL ' in ln or 'FAIL' in ln and '>' in ln:
                    first = ln.strip()[:150]; break
        line = f'{status:9} {mid}  [{time.time()-t0:4.1f}s] {first}'
    finally:
        shutil.move(path + '.bak', path)
    print(line, flush=True); results.append((mid, status))
survivors = [r for r in results if r[1] != 'killed']
real = [r for r in survivors if r[0].split()[0] not in EQUIVALENT]
print(f"\nTổng: {len(results)} đột biến; {sum(1 for _, st in results if st == 'killed')} bị bắt; "
      f"{len(survivors) - len(real)} tương đương; {len(real)} sống sót thật.")
for mid, st in survivors:
    key = mid.split()[0]
    print(f"  {st:8} {mid}" + (f"  → tương đương: {EQUIVALENT[key]}" if key in EQUIVALENT else ''))
sys.exit(1 if real else 0)
