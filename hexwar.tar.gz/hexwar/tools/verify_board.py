#!/usr/bin/env python3
"""
verify_board.py - Kiểm chứng số liệu hình học của bàn cờ lục giác R=24 (6 người chơi).

Chạy:  python3 tools/verify_board.py
Thoát mã 0 nếu mọi kiểm tra đều qua. Script này là "nguồn chân lý" để viết lại
thành unit test cho package `rules` (xem PLAN.md, mục 3 và Milestone M1).

Quy ước (khớp PLAN.md):
- Toạ độ trục (axial) (q, r); ô phẳng-đỉnh (flat-top) khi vẽ: x = 1.5*q, z = sqrt(3)*(r + q/2)
- Hạng (ring) của ô = max(|q|, |r|, |q+r|). Tâm là hạng 0. R = 24 -> có hạng 0..24.
- rotCW(q, r) = (-r, q + r): xoay 60 độ THEO CHIỀU KIM ĐỒNG HỒ khi nhìn từ trên xuống
  (x sang phải, z xuống dưới màn hình).
"""
import math
import sys
from collections import Counter

R = 24            # bán kính bàn cờ (số hạng ngoài tâm)
SEAT_RING = 23    # hạng chứa góc xuất phát của mỗi ghế (hạng 24 là vòng đệm, biến mất ở hiệp 50)
COLLAPSE = [50, 110, 180, 250, 260, 280, 290, 300, 310, 320, 330, 340, 350, 360]  # đúng theo yêu cầu (KHÔNG có 270)
EXT_FIRST, EXT_EVERY, EXT_MIN_RADIUS = 370, 10, 3   # đề xuất bổ sung sau hiệp 360
HARD_CAP_ROUND = 450

E_DIRS = [(0, -1), (1, -1), (1, 0), (0, 1), (-1, 1), (-1, 0)]   # N, NE, SE, S, SW, NW (theo chiều kim đồng hồ)
E_NAMES = ["N", "NE", "SE", "S", "SW", "NW"]
V_DIRS = [(E_DIRS[i][0] + E_DIRS[(i + 1) % 6][0], E_DIRS[i][1] + E_DIRS[(i + 1) % 6][1]) for i in range(6)]
V_NAMES = ["NNE", "E", "SSE", "SSW", "W", "NNW"]
KNIGHT = [(1, -3), (1, 2), (2, -3), (2, 1), (-3, 2), (-3, 1), (-1, 3), (-1, -2), (-2, 3), (-2, -1), (3, -2), (3, -1)]

# Đội hình 18 quân của ghế 0 (góc dưới, nhìn từ ghế: "lên" = về phía tâm). h = hàng (2 = sát góc, 5 = tiền tuyến)
FORMATION_ROWS = {
    2: ["Q", "K", "B"],
    3: ["R", "J", "B", "R"],
    4: ["N", "P", "P", "P", "N"],
    5: ["P", "P", "P", "P", "P", "P"],
}

MAX_REACH = {"R": 9, "B": 9, "Q": 9, "J": 3}   # tính theo khoảng cách lưới (hex distance)
JESTER_REVIVE_DIST = 5

ok = True
def check(name, cond, detail=""):
    global ok
    print(("PASS " if cond else "FAIL ") + name + (f"  [{detail}]" if detail else ""))
    ok = ok and bool(cond)

def ring(q, r): return max(abs(q), abs(r), abs(q + r))
def color(c): return (c[0] - c[1]) % 3   # tô 3 màu: hai ô kề cạnh luôn khác màu; bước nhảy đỉnh (V) giữ nguyên màu
def rot(q, r): return (-r, q + r)
def rotn(c, n):
    for _ in range(n % 6): c = rot(*c)
    return c
def dist(a, b):
    dq, dr = a[0] - b[0], a[1] - b[1]
    return max(abs(dq), abs(dr), abs(dq + dr))
def cells_in(radius): return 3 * radius * (radius + 1) + 1
def world(c):
    q, r = c
    return (1.5 * q, math.sqrt(3) * (r + q / 2))
def add(a, b, k=1): return (a[0] + k * b[0], a[1] + k * b[1])

# ---- 1. Số ô -------------------------------------------------------------------------------
check("Số ô R=24 là 1801", cells_in(24) == 1801)
check("Hạng 24 có 144 ô", cells_in(24) - cells_in(23) == 144)
allcells = [(q, r) for q in range(-R, R + 1) for r in range(-R, R + 1) if ring(q, r) <= R]
check("Đếm trực tiếp cũng ra 1801 ô", len(allcells) == 1801)

# ---- 2. Đối xứng xoay 60 độ của các bộ hướng đi -----------------------------------------------
check("E_DIRS bất biến khi xoay 60°", sorted(rot(*d) for d in E_DIRS) == sorted(E_DIRS))
check("V_DIRS bất biến khi xoay 60°", sorted(rot(*d) for d in V_DIRS) == sorted(V_DIRS))
check("Nước đi Mã bất biến khi xoay 60°", sorted(rot(*d) for d in KNIGHT) == sorted(KNIGHT))
ring3 = [(q, r) for q in range(-3, 4) for r in range(-3, 4) if ring(q, r) == 3]
corners3 = {(3 * a, 3 * b) for a, b in E_DIRS}
check("Mã = 12 ô không-phải-góc của hạng 3", sorted(x for x in ring3 if x not in corners3) == sorted(KNIGHT))
check("6 hướng đỉnh V có khoảng cách 2, 6 hướng cạnh E có khoảng cách 1",
      all(dist((0, 0), d) == 1 for d in E_DIRS) and all(dist((0, 0), d) == 2 for d in V_DIRS))

check("Tô màu 3 tông (q-r) mod 3: mọi hướng cạnh E đổi màu", all(color(d) != 0 for d in E_DIRS))
check("Tô màu 3 tông: mọi hướng đỉnh V giữ nguyên màu (Tượng không bao giờ đổi màu ô)", all(color(d) == 0 for d in V_DIRS))
check("Mã luôn đổi màu ô sau mỗi nước đi", all(color(d) != 0 for d in KNIGHT))

# ---- 3. Chiều kim đồng hồ -------------------------------------------------------------------
corner0 = (0, SEAT_RING)
corners = [rotn(corner0, s) for s in range(6)]
pos = [world(c) for c in corners]
cross = [pos[i][0] * pos[(i + 1) % 6][1] - pos[i][1] * pos[(i + 1) % 6][0] for i in range(6)]
check("Ghế 0..5 xếp theo chiều kim đồng hồ trên màn hình (dưới -> trái dưới -> trái trên -> trên -> phải trên -> phải dưới)",
      all(c > 0 for c in cross))
check("Ghế 0 nằm đáy màn hình (x=0, z>0)", abs(pos[0][0]) < 1e-9 and pos[0][1] > 0)
check("Hướng 'tiến về tâm' của ghế 0 là N (0,-1)", add(corner0, (0, -1), SEAT_RING) == (0, 0))

# ---- 4. Đội hình 18 quân -----------------------------------------------------------------------
A = SEAT_RING
local = []   # (q, r, type, row)
for h, pcs in FORMATION_ROWS.items():
    qs = list(range(-h, h + 1, 2))
    assert len(qs) == len(pcs) == h + 1
    for q, p in zip(qs, pcs):
        two_r = 2 * A - h - q
        assert two_r % 2 == 0
        local.append((q, two_r // 2, p, h))
cnt = Counter(p for _, _, p, _ in local)
check("Mỗi ghế đúng 18 quân", len(local) == 18)
check("Thành phần 9 tốt, 2 xe, 2 tượng, 2 mã, 1 vua, 1 hậu, 1 hề",
      cnt == Counter({"P": 9, "R": 2, "B": 2, "N": 2, "K": 1, "Q": 1, "J": 1}), str(dict(cnt)))
check("18 ô của một ghế đều khác nhau", len({(q, r) for q, r, _, _ in local}) == 18)
check("Đội hình nằm gọn trong hạng <= 23 (chừa hạng 24 làm vòng đệm)", max(ring(q, r) for q, r, _, _ in local) <= 23)

occupied = {}
seat_cells = []
for s in range(6):
    sc = []
    for q, r, p, h in local:
        c = rotn((q, r), s)
        assert c not in occupied, ("ô trùng", s, c)
        occupied[c] = (s, p)
        sc.append(c)
    seat_cells.append(sc)
check("Toàn bàn 108 quân, không ô nào trùng", len(occupied) == 108)
check("Không quân nào đứng trên hạng 24 lúc bắt đầu", all(ring(*c) <= 23 for c in occupied))

bishops = [(q, r) for q, r, p, h in local if p == "B"]
check("Hai Tượng của mỗi ghế đứng trên hai màu ô KHÁC nhau (bao quát nhiều ô hơn)", len({color(b) for b in bishops}) == 2,
      f"colors={[color(b) for b in bishops]}")
for s_ in range(6):
    bc = {color(rotn(b, s_)) for b in bishops}
    assert len(bc) == 2
kq = [(q, r) for q, r, p, h in local if p == "K"][0]
jq = [(q, r) for q, r, p, h in local if p == "J"][0]
check(f"Hề cách Vua <= {JESTER_REVIVE_DIST} ô ngay từ đầu (hồi sinh dùng được từ hiệp 1)", dist(kq, jq) <= JESTER_REVIVE_DIST, f"dist={dist(kq, jq)}")

mind = {}
for a in range(6):
    for b in range(a + 1, 6):
        mind[(a, b)] = min(dist(x, y) for x in seat_cells[a] for y in seat_cells[b])
check("Khoảng cách gần nhất giữa hai ghế KỀ nhau đều bằng nhau (công bằng)", len({mind[(i, (i + 1) % 6)] if i < 5 else mind[(0, 5)] for i in range(6)}) == 1,
      f"adjacent={mind[(0, 1)]}")
check("Khoảng cách gần nhất giữa hai ghế ĐỐI DIỆN đều bằng nhau", len({mind[(0, 3)], mind[(1, 4)], mind[(2, 5)]}) == 1,
      f"opposite={mind[(0, 3)]}")

# ---- 5. Bộ sinh nước đi mẫu (chỉ để đo thế cờ đầu, KHÔNG phải engine thật) -----------------------
def in_board(c, radius=R): return ring(*c) <= radius

def gen_moves(seat, occ, radius=R):
    """Trả về danh sách (loại quân, ô đi, có ăn không). Quy tắc theo PLAN.md mục 4."""
    out = []
    fwd = rotn((0, -1), seat)
    back = rotn((0, 1), seat)
    pawn_diag = [rotn(d, seat) for d in [(1, -1), (-1, 0), (1, 0), (-1, 1)]]
    for c, (s, t) in occ.items():
        if s != seat: continue
        def slide(dirs, hop_dist_limit):
            for d in dirs:
                k = 1
                while True:
                    n = add(c, d, k)
                    if not in_board(n, radius) or dist(c, n) > hop_dist_limit: break
                    if n in occ:
                        if occ[n][0] != seat and t != "J": out.append((t, n, True))
                        break
                    out.append((t, n, False))
                    k += 1
        if t == "R": slide(E_DIRS, MAX_REACH["R"])
        elif t == "B": slide(V_DIRS, MAX_REACH["B"])
        elif t == "Q": slide(E_DIRS + V_DIRS, MAX_REACH["Q"])
        elif t == "J": slide(E_DIRS + V_DIRS, MAX_REACH["J"])
        elif t == "K":
            for d in E_DIRS + V_DIRS:
                n = add(c, d)
                if in_board(n, radius) and not (n in occ and occ[n][0] == seat):
                    out.append((t, n, n in occ))
        elif t == "N":
            for d in KNIGHT:
                n = add(c, d)
                if in_board(n, radius) and not (n in occ and occ[n][0] == seat):
                    out.append((t, n, n in occ))
        elif t == "P":
            for d in (fwd, back):
                n = add(c, d)
                if in_board(n, radius) and n not in occ: out.append((t, n, False))
            for d in pawn_diag:
                n = add(c, d)
                if in_board(n, radius) and n in occ and occ[n][0] != seat: out.append((t, n, True))
    return out

per_seat = []
for s in range(6):
    mv = gen_moves(s, occupied)
    per_seat.append(Counter(t for t, _, _ in mv))
check("Số nước đi hợp lệ theo từng loại quân giống hệt nhau ở cả 6 ghế (bất biến xoay)", all(p == per_seat[0] for p in per_seat))
check("Thế cờ đầu không bị kẹt: mỗi ghế có nước đi", sum(per_seat[0].values()) > 0)
check("Không có nước ăn quân ngay từ đầu", all(not cap for s in range(6) for _, _, cap in gen_moves(s, occupied)))

# ---- 6. Lịch thu hẹp -------------------------------------------------------------------------------
rad = R
rows = []
sched = list(COLLAPSE)
r_ext = EXT_FIRST
r2 = R - len(COLLAPSE)
ext = []
while r2 > EXT_MIN_RADIUS:
    ext.append(r_ext); r_ext += EXT_EVERY; r2 -= 1
check("Lịch gốc gồm 14 lần thu hẹp, hạng 24 -> hạng 10", len(COLLAPSE) == 14 and R - len(COLLAPSE) == 10)
check("Bán kính cuối lịch mở rộng = 3, hiệp cuối = 430", r2 == EXT_MIN_RADIUS and ext[-1] == 430, f"ext={ext}")
check("Hiệp giới hạn cứng > hiệp thu hẹp cuối", HARD_CAP_ROUND > ext[-1])

# ---- In bảng dạng Markdown để dán vào PLAN.md ----------------------------------------------------------
print("\n| # | Hiệp | Hạng biến mất | Ô mất | Ô còn lại | Bán kính còn |")
print("|--:|--:|--:|--:|--:|--:|")
rad = R
for i, rd in enumerate(COLLAPSE + ext, 1):
    removed = 6 * rad
    rad -= 1
    tag = "" if rd in COLLAPSE else " (đề xuất)"
    print(f"| {i} | {rd}{tag} | {rad + 1} | {removed} | {cells_in(rad)} | {rad} |")

print("\nThời lượng trận (số lượt = hiệp x số người còn sống; ước lượng thô, 6 người sống suốt):")
for label, secs in [("mỗi lượt dùng hết 60s", 60), ("trung bình 20s", 20), ("trung bình 8s", 8)]:
    for rounds in (50, 110, 360):
        h = rounds * 6 * secs / 3600
        print(f"  {rounds:>3} hiệp, {label:<24}: {h:6.1f} giờ")

print("\nNước đi hợp lệ ban đầu của ghế 0 theo loại quân:", dict(per_seat[0]), "| tổng:", sum(per_seat[0].values()))
print("Khoảng cách gần nhất: kề nhau =", mind[(0, 1)], "| đối diện =", mind[(0, 3)])
print("Hướng cạnh E (thẳng):", dict(zip(E_NAMES, E_DIRS)))
print("Hướng đỉnh V (ngang zíc-zắc/chéo dốc):", dict(zip(V_NAMES, V_DIRS)))
print("Đội hình cục bộ ghế 0 (q, r, quân, hàng):")
for row in local: print("  ", row)

print("\nKẾT QUẢ:", "TẤT CẢ ĐỀU QUA" if ok else "CÓ LỖI")
sys.exit(0 if ok else 1)
